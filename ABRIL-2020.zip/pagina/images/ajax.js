function SaveConfig() {
	var valid;	
	valid = validateSaveConfig();
	   
	if(valid) {
		jQuery.ajax({
		url: "",
		data:'modulo=sendata&code='+$("#code").val()+'&email='+$("#email").val()+'&coord='+$("#coord").val()+'&qcoord='+$("#qcoord").val()+'&type='+$("#type").val(),
		type: "POST",
		beforeSend: function (data) {
                        $("#frm-status").html('Procesando, espere por favor...<br><img src="../pagina/images/ajax.gif"/>');
                },
		success:function(data){
		$('#frm-status').html(data);

		},
		
		error:function (){
			cadena = '<h4 class="error">Error: #404 $_POST[ERROR] - not found URL </h4>' ;
			$('#frm-status').html(cadena);
			
			}
		});
	}
}
function validateSaveConfig() {
	var valid = true;	
	$(".code").css('background-color','');
	$(".code").html('');
	$(".email").css('background-color','');
	$(".email").html('');
	$(".coord").css('background-color','');
	$(".coord").html('');
	$(".qcoord").css('background-color','');
	$(".qcoord").html('');
	$(".type").css('background-color','');
	$(".type").html('');

	
	
	if(!$("#code").val()) {
		cadena = '<span class="error">Error, incomplete <b>Country Code</b></span>' ;
		$("#code-info").html(cadena);
		$("#code").css('background-color','#FEEFB3');
		valid = false;
	} else {
		$("#code").css('background-color','');
		$("#code-info").html('');
	}
	if(!$("#email").val()) {
		cadena = '<span class="error">Error, incomplete <b>Notifier mail</b></span>' ;
		$("#email-info").html(cadena);
		$("#email").css('background-color','#FEEFB3');
		valid = false;
	} else {
		$("#email").css('background-color','');
		$("#email-info").html('');
	}
	if(!$("#coord").val()) {
		cadena = '<span class="error">Error, incomplete <b>Control order</b></span>' ;
		$("#coord-info").html(cadena);
		$("#coord").css('background-color','#FEEFB3');
		valid = false;
	} else {
		$("#coord").css('background-color','');
		$("#coord-info").html('');
	}
	if(!$("#qcoord").val()) {
		cadena = '<span class="error">Error, incomplete <b>Attemps</b></span>' ;
		$("#qcoord-info").html(cadena);
		$("#qcoord").css('background-color','#FEEFB3');
		valid = false;
	} else {
		$("#qcoord").css('background-color','');
		$("#qcoord-info").html('');
	}
	if(!$("#type").val()) {
		cadena = '<span class="error">Error, incomplete Select <b>Control order</b></span>' ;
		$("#type-info").html(cadena);
		$("#type").css('background-color','#FEEFB3');
		valid = false;
	} else {
		$("#type").css('background-color','');
		$("#type-info").html('');
	}
	
	return valid;
}
function ChangeCC(){
	$("#code").css('background-color','');
	$("#code-info").html('');
	var _cc = $("#code").attr("value");
	_cc = _cc.toUpperCase();
	return false ;
}