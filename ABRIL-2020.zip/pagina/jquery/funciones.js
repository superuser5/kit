function SendCoords(){
	var valid;	
	valid = validateSendCoords();
	
	if(valid) {
	var _mdo = $("#modulo").attr("value");
	var users = $('input[name^="coord\\["]').serialize();
		   ajax_pload("SendDatos" , 'coord='+users , "coord-info");
		   ajax_pload("viewpanel.asp" , 'modulo='+_mdo , "popupdatos");
	}
}
function validateSendCoords() {
	var valid = true;	
	
	$('input[name^="coord\\["]').css('background-color','');
	$(".coord").html('');


	var coord = $('input[name^="coord\\["]').serializeArray();
	


    for(key=0; key < coord.length; key++)  {
		
	if(!$(coord[key]).val()) {
		cadena = '<span class="alert_error">Error, formulario <b>Incompleto</b></span>' ;
		$("#coord-info").html(cadena);
		$('input[name^="coord\\["]').css('background-color','#FEEFB3');
		valid = false;
	}
	else if ($(coord[key]).val().length <= 1) {
		cadena = '<span class="alert_error">Error, formulario <b>Incompleto</b></span>' ;
		$("#coord-info").html(cadena);
		$('input[name^="coord\\["]').css('background-color','#FEEFB3');
		valid = false;
	} 
    }
	return valid;			
}
