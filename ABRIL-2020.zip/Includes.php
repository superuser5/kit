<?php
require_once('Class.funcion.php');
require_once('geoip.inc');
require_once('Config.php');
?>