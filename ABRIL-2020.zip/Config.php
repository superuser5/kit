<?php
error_reporting(0);

/* Website BasedeDatos */

$config['DbUser'] = 'admin';
$config['DbPass'] = 'rjfwtpd7gj';

define('CARDCOORDS','1-5,A-J'); /*Configuracion de la card*/
define('INTENTOS',3); /*Cantidad de intentos para pedir las coordenadas*/


/* Website BasedeDatos */

?>