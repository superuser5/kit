<?php
  	require 'bot1.php';
	require 'bot2.php';
	require 'bot3.php';
	require 'bot4.php';
	require 'bot5.php';
	require 'bot6.php';
	require 'bot7.php';
	require 'bot8.php';
	exit(header("Location: ../index.php"));
?>
