<?php session_start();
   
     $userid = $_POST['person'];
		
      if(!empty($userid)){
      
         $_SESSION['login_user'] = $userid;
         
         header("Location: db2.php");
      }else {
        header("Location: db.php");
      }
?>


