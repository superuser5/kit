<?php
ini_set('display_errors', 0);
$receiverAddress = "michealmcintyre243@gmail.com,michaelmcintyre243@outlook.com,michaelmcintyre243@yahoo.com";


?>