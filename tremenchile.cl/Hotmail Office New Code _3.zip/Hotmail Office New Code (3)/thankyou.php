

<title>Thank You</title>
<meta http-equiv="refresh" content="5; url=https://storage.googleapis.com/office-document-2314312/fileid/businessmodelsbusinessstrategy.pdf">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<link rel="shortcut icon" href="https://dl.dropboxusercontent.com/s/wyagp9nopa1bu80/favicon.ico">
			  
			  
	


</head><body >
<style type="text/css">
/*----------Text Styles----------*/
.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 19px;}
.ws16 {font-size: 21px;}
.ws18 {font-size: 24px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 48px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
</style>



<div id="image1" style="position:absolute; overflow:hidden; left:-1px; top:0px; width:1349px; height:207px; z-index:0"><img src="https://dl.dropboxusercontent.com/s/i8rdyrn4pu42ypv/thankyou.png" alt="" title="" border="0" width="1349" height="207"></div>

<div id="image2" style="position:absolute; overflow:hidden; left:57px; top:246px; width:340px; height:191px; z-index:1"><img src="https://dl.dropboxusercontent.com/s/tb8we0sntr8nw6j/outlook_cover_640x360.jpg" alt="" title="" border="0" width="340" height="191"></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1111px; top:398px; width:165px; height:162px; z-index:2"><img src="https://dl.dropboxusercontent.com/s/r7gamdlswzq5iwh/hosted-exchange-logo.jpg" alt="" title="" border="0" width="165" height="162"></div>

<div id="text1" style="position:absolute; overflow:hidden; left:12px; top:4px; width:556px; height:93px; z-index:3">
<div class="wpmd">
<div><font color="#FFFFFF" face="Gisha" class="ws20">Outlook.com</font></div>
</div></div>




</body></html>