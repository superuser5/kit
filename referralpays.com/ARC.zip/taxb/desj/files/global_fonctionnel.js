
var domaine = document.location.hostname;
var pe;
var index = 0;    // L'index du array des contenus ... donc, la page � afficher
var carte = '';
var objPE;
var arrCartes  = [];   // Pour garder toutes les donn�es des cartes.
var objCarte;    // Pour garder toutes les donn�es de la carte s�lectionn�e.
var headLoaded = false;
var footLoaded = false;
var reservedLoaded = false;
var divVisibilitySettled = false;
var langue;
var form = $( "#demandeForm" );
var validatorEtape;
var adp = false;
var urlAnnuler;
var urlQuitter;
var urlRetour;
var urlErreur;
var cookie = 'UNID';
var composantesLoaded = false;
var carteSelectionnee = false;
var GADebuteSettled = false;
var traductions = 
{
  "oui": { "fr":"Oui", "en":"Yes" },  
  "non": { "fr":"Non", "en":"No" },  
  "proprietaire": { "fr":"Proprietaire", "en":"Homeowner" },
  "locataire": { "fr":"Locataire", "en":"Tenant" },
  "travailleur": { "fr":"Travailleur autonome", "en":"Self-employed" },
  "salarie": { "fr":"Salarie", "en":"Wage earner" },
  "etudiant": { "fr":"Etudiant", "en":"Student" },
  "retraite": { "fr":"Retraite", "en":"Retired" },
  "epargneCompte": { "fr":"Compte d'&eacute;pargne", "en":"Savings account" },
  "chequeCompte": { "fr":"Compte ch&egrave;que", "en":"Chequing account" },  
  "supprimerEpargne": { "fr":"Supprimer ce compte d'&eacute;pargne", "en":"Delete this savings account" },
  "supprimerCheque": { "fr":"Supprimer ce compte ch&egrave;que", "en":"Delete this chequing account" }
};
var cuStyle = {
  "racine": "/ress_gtd/fw/N3/1.8.5/wl/",
  "cible": "/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap.min.css",
  "style": {
    "peCoastADP": {"style": "coast"},
    "peCoastInfo": {"style": "coast"},
    "peDLADP": {"style": "dominion"},
    "peDLInfo": {"style": "dominion"},
    "peProsperaADP": {"style": "prospera"},
    "peProsperaInfo": {"style": "prospera"},
    "peSunovaADP": {"style": "sunova"},
    "peSunovaInfo": {"style": "sunova"},
    "peWSCUADP": {"style": "westminster"},
    "peWSCUInfo": {"style": "westminster"}
  }
};
//Function g�rant l'application d'un style particulier
function setStyle(){
  var peComplete = getQSParam("pe");
  var pe;
  if(peComplete){
    peComplete = peComplete.split(/[#|\!/$%?&]/);
    pe = peComplete[0];
  }
  var style;
  var $head = $("head");
  var linkElement;
  if(cuStyle.style[pe]){
    style = returnStyle(cuStyle, pe);
    linkElement = "<link rel='stylesheet' href=" + cuStyle.racine + style + cuStyle.cible + "  type='text/css'>";
    $head.append(linkElement);
  }
}
//Retourne le style voulu en fonction du PE
function returnStyle(cuStyle, pe){
  var styleCU = "";
    $.each( cuStyle.style, function( key, value) {
      if(pe.indexOf(key) !== -1){
        styleCU = value.style;
      }
      if (styleCU !== ""){
        return (false);
      }
    });
    return styleCU;
}
// IE Console Fix
setConsole();
// Check current context
checkContext();
jQuery.validator.setDefaults({
  debug: false,
  success: "valid"
});
// Hide noScript
$("#noScript").hide();
function addToCartesArray( data, position ) {
  //console.log( 'addToCartesArray:begin' );
 // arrCartes.splice(position, 0, data);
 arrCartes[position] = data;
  if( carte == data.id ) {
    objCarte = data;
  }
//console.log( 'addToCartesArray:end' );
}
function annuler() {
  if ( objPE.sauvegarde == true && adp == true) {    
      $('#modalSauvegarder').modal({
        keyboard: false,
        show: true
      })
  } else {
    $('#modalQuitter').modal({
      keyboard: false,
      show: true
    })
 
  }
}
function changerFinancement() {
  //console.log( 'changerFinancement:begin' );
  //console.log( 'changerFinancement:objPE.globales.index_modalite_financement:'+objPE.globales.index_modalite_financement );
  
  deplacer( objPE.globales.index_modalite_financement );
  
  //console.log( 'changerFinancement:end' );
}
function changerProduit() {
  //console.log( 'changerProduit:begin' );
  //console.log( 'changerProduit:objPE.globales.index_modalite_financement:'+objPE.globales.index_choix_carte );
  
  deplacer( objPE.globales.index_choix_carte );
  
  //console.log( 'changerProduit:end' );
}
function checkContext() {
  //alert( 'cookie : ' + getCookie( cookie ) );
  if( getCookie( cookie ) == null || getCookie( cookie ) == '' )
  {
   // On est pas dans ADP
  }
  else
  { // On est dans ADP
    adp = true;
  }
  //console.log("adp : " + adp);
}
// Reset le formulaire et les cookies
function cloturerForn() {
  clearForm(form);
  //$("#recap").remove();
  //$(".contenu #produit").remove();
  //$("#libelle-demande").remove();
  //console.log("-- FORM CLEARED --");
  deleteCookie( cookie, '/', domaine );
  //console.log("-- COOKIE DELETED --");
}
// Le contenu est charg�
function setGA(idGTM, nomForm) {
// Set GTM form name
        $('form').attr("data-mw-form-nom",nomForm);
// Set custom GTM Variables
// --------------------
var s = document.createElement('script');
s.type = 'text/javascript';
var code = "var mwNumContenantGoogle = '"+idGTM+"'; var dataLayer = dataLayer || [];";
try {
      s.appendChild(document.createTextNode(code));
      document.body.appendChild(s);
} catch (e) {
      s.text = code;
      document.body.appendChild(s);
}
// Create the element
//var script = document.createElement("script");
// Add script content
//script.innerHTML = "var mwNumContenantGoogle = '"+idGTM+"'; var dataLayer = dataLayer || [];";
// Append
//var s = document.body.firstChild;
//s.parentNode.insertBefore(script, s);
// --------------------
// Set Cybermetrie JS file
// --------------------
var s = document.createElement("script");
s.type = "text/javascript";
s.src = "cybermetrie.js?Open";
$("body").append(s);
// --------------------
       
}
function pushGAData() {
   if (objPE.contenus[index].cybermetrie) {
dataLayer.push({
 'event': 'pageVue',
 'titre': objPE.contenus[index].cybermetrie.titre,
 'url': objPE.contenus[index].cybermetrie.url
 });
if (!GADebuteSettled) {
  GADebuteSettled = true;
  dataLayer.push({
  'event': 'interractionsPages',
  'category': 'Formulaire',
  'action': 'debute',
  'label': objPE.cybermetrie.form_nom,
  'value': 0,
  'nonInteraction': false
  });
} else {
dataLayer.push({
  'event': 'interractionsPages',
  'category': 'Formulaire',
  'action': objPE.contenus[index].cybermetrie.action,
  'label': objPE.cybermetrie.form_nom,
  'value': 0,
  'nonInteraction': false
});
}
   }
}
function contenusReady() {
  //console.log( 'contenusReady:begin' );
  setGA(objPE.cybermetrie.identifiant_container_gtm, objPE.cybermetrie.form_nom);
  // Set le titre
  $('#libelle-demande').html (objPE.titre [langue]);
  // Set le title HTML
  document.title = objPE.titre [langue]; 
  // Load Cartes
  if (typeof objPE.cartes !== "undefined") {
    loadCartes( objPE.cartes );
  } else { // Cas ou il n'y a pas de cartes pour le PE
    loadComposantesContenu();
  }
  // Initialiation des divs
  if (!divVisibilitySettled) {
    setDivVisibility();
    divVisibilitySettled = true;
  }
  // Initialiation des options du point d'entr�e
  initOptionsPE();  
  // Initialisation des messages d'aide
  loadMessagesAide(); 
  // Remove default bootstrap event system on tabs
  $.fn.tab = null;
  $(document).off('click.bs.tab.data-api', '[data-toggle="tab"]');
  $(document).off('click.bs.tab.data-api', '[data-toggle="pill"]');
  // Ajoute un div tab-content autour des div possedant un onglets
  if ($( '.active-tab' ).parent(".onglets-etapes").length == 0) {
    $( '.active-tab' ).wrapAll( '<div class="tab-content onglets-etapes" style="display: none;"></div>' );
    $( '.onglets-etapes' ).show();
  }
  //Au chargement on a �ventuellement une fonction � executer, on n'est pas dans un d�placement
  if (objPE.contenus[index].inContenu_function) {
      if ( objPE.contenus[index].inContenu_function != '' ) {
        // Appelle la fonction (inContenu_function) de l'�tape  d�finie dans le JSON
        if (typeof window[objPE.contenus[index].inContenu_function] == "function") {
            window[objPE.contenus[index].inContenu_function]();
        }
      }
  }
  // initialise l'alternance de couleurs sur les tableaux
  $('table.tableau-donnees').altCouleurs();
  // initialise la validation, et le validateur
  validatorEtape = validateStep(form, $(".error-block .errors-title"));
  // prepeuple le formulaire de demande de carte
  if ( adp == true  ) {
    // prepeuplerFormulaireCarte();
  } else {
    urlAnnuler = objPE.url_annuler;
    urlQuitter = objPE.url_quitter;
    urlRetour = objPE.url_retour;
    urlErreur = objPE.url_err_appl;
  }
  // Enregistre les evenements JQuery du PE concern�
  if (typeof window["registerStepsEvents"] == "function") {
       window["registerStepsEvents"]();
  }
  // Load, les besoins specifiques du formulaire selectionn� 
  if (typeof window["formReady"] == "function") {
       window["formReady"]();
  }
  
   loadPays();
   // Affichage d'un titre long sp�cifique
   if (objPE.titre_complet) {
         $('#libelle-demande').html ( objPE.titre_complet[langue]);
   }
  // Tous les contenus sont OK
  $( '#zone-centrale' ).show();
   if (carteSelectionnee == false) {
    //deplacer(0);
    //$( '#contenu_'+index ).hide();
    //index = vers;
    //$( '#contenu_'+vers ).show();
   }
  // Ferme la fen�tre
  $('#waitModal').modal('hide');
  // Fen�tre de reprise
 if ( objPE.sauvegarde == true && carte == "" && adp == true) {    
        loadDemandes();
       
  }
  if (langue == "fr") {
numeral.languageData().delimiters.thousands = ' ';
numeral.languageData().delimiters.decimal = ',';
  }
  //console.log( 'contenusReady:end' );
  
}
function deplacer( vers ) {
  //console.log( 'deplacer:begin' );
  //console.log( 'deplacer:vers:'+vers );
  //Avant d'effectuer le d�placement, on doit voir si on a une validation � faire
  if (objPE.contenus[index].outContenu_function) {
    if ( objPE.contenus[index].outContenu_function != '' ) {
      // Appelle la fonction (outContenu_function) de l'�tape d�finie dans le JSON
        if (typeof window[objPE.contenus[index].outContenu_function] == "function") {
           window[objPE.contenus[index].outContenu_function]();
        }
    }
  }
  $( '#contenu_'+index ).hide();
  index = vers;
  //Apr�s avoir effectuer le d�placement, on doit voir si on a une fonction d'affichage � faire
  if (objPE.contenus[index].inContenu_function) {
    if ( objPE.contenus[index].inContenu_function != '' ) {
      // Appelle la fonction (inContenu_function) de l'�tape  d�finie dans le JSON
      if (typeof window[objPE.contenus[index].inContenu_function] == "function") {
          window[objPE.contenus[index].inContenu_function]();
      }
    }
  }
  $( '#contenu_'+vers ).show();
  //On ajoute les composantes reli�es � ce contenu (header, footer, etc.)
  loadComposantesContenu();
  scrollToTop();
  //console.log( 'deplacer:end' );
}
function dialoguePatienter() {
  $('#dialoguePatienter').show();
  $("#dialoguePatienter").dialog(
  {
    width: 300,
    resizable: false,
    draggable: false,
    modal: true,
    minHeight: 50
  })
  .siblings( 'div.ui-dialog-titlebar' ).remove();
  $( '#btnRetour' ).blur();
}
function fermer() {
  //alert('Ici, on va quitter/rediriger.');
   window.location.href = urlQuitter; 
}
function fermerDialoguePatienter() {
  $("#dialoguePatienter").dialog("close");
}
function getQSParam( param ) {
  return $.QueryString( param );
}
// Initialise les options de la carte
function initOptionsCarte(carte) {
 
  // Visibilit�
  $.each( carte.options_carte, function( key, value ) {
    // Le DIV a le m�me nom que la cl� du json
   
    if (value == true) {
      $("#"+key).show();
     
    } else {
      $("#"+key).hide();
    
    }
  });
  // Options SCD
  if  (carte.options_predefinies) {
  $.each( carte.options_predefinies, function( key, value ) {
    // Le DIV a le m�me nom que la cl� du json
    if (value == true) {
      $("#"+key).find("input[type=radio][value=" + traductions["oui"][langue] + "]").prop( "checked", true);
      $("#"+key).find("input[type=radio][value=" + traductions["non"][langue] + "]").prop( "checked", false);
    } else {
      $("#"+key).find("input[type=radio][value=" + traductions["oui"][langue] + "]").prop( "checked", false);
      $("#"+key).find("input[type=radio][value=" + traductions["non"][langue] + "]").prop( "checked", false);
    }
  });
  }
}
// Initialise les options du PE
function initOptionsPE() {
   if (objPE.options_point_entree) {
  $.each( objPE.options_point_entree, function( key, value ) {
    // Le DIV a le m�me nom que la cl� du json
    if (value == true) {
      $("#"+key).show();
    } else {
      $("#"+key).hide();
    }
  });
  }
}
function loadBoutons() {
  var str_boutons_primary = '';
  var str_boutons_secondary = '';
  var classe = '';
  //for (var i=0; i<objPE.contenus[index].boutons.length; i++) 
  for( var i in objPE.contenus[index].boutons )
  {
    if (objPE.contenus[index].boutons[i].classe == "principal") {
      classe = "btn-primary";
      str_boutons_primary += '<button type="button" class="btn '+classe+'" onclick="'+objPE.contenus[index].boutons[i].action_function+';">'+objPE.contenus[index].boutons[i].libelle[langue]+'</button>';
    } else if (objPE.contenus[index].boutons[i].classe == "soumission") {
      classe = "btn-primary btn-soumission";
      str_boutons_primary += '<button type="button" class="btn '+classe+'" onclick="'+objPE.contenus[index].boutons[i].action_function+';">'+objPE.contenus[index].boutons[i].libelle[langue]+'</button>';
    } else {
      classe = "btn-default";
      str_boutons_secondary += '<button type="button" class="btn '+classe+'" onclick="'+objPE.contenus[index].boutons[i].action_function+';">'+objPE.contenus[index].boutons[i].libelle[langue]+'</button>';
    }
    // str_boutons += '<button type="button" onclick="'+objPE.contenus[index].boutons[i].function+';">'+objPE.contenus[index].boutons[i].libelle+'</button>';
    //str_boutons += '<button type="button" class="btn '+classe+'" onclick="'+objPE.contenus[index].boutons[i].action_function+';">'+objPE.contenus[index].boutons[i].libelle[langue]+'</button>';
  }
  // $( "#zone-middle-left-buttons" ).addClass("col-lg-21 col-md-21 col-sm-21 col-xs-21 col-lg-offset-3 col-md-offset-3 col-sm-offset-3 col-xs-offset-3 reset");
  
  if (str_boutons_secondary == "") {
    $( '#zone-middle-left-buttons' ).html( "<div class='col-md-24 col-sm-24 col-xs-24 center'>"+str_boutons_primary+"</div>");
  } else {
    $( '#zone-middle-left-buttons' ).html( "<div class='col-md-12 col-sm-12 hidden-xs control-label secondary-buttons'>"+str_boutons_secondary+"</div>"+"<div class='col-md-12 col-sm-12 col-xs-24 primary-buttons'>"+str_boutons_primary+"</div>"+"<div class='hidden-lg hidden-md hidden-sm  col-xs-24 tertiary-buttons'>"+str_boutons_secondary+"</div>" );
  }
}
var isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function() {
        return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    },
    Opera: function() {
        return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function() {
        return navigator.userAgent.match(/IEMobile/i);
    },
    any: function() {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
    }
};
function loadCartes( cartes ) {
  var ajax_toload = [];             // Tableau contenant les ajax � loader
  var ajax_results = new Object();  // Tableau contenant les r�sultats des ajax -- Java hashmap equivalentboo
  
  //for (var i=0; i<cartes.length; i++) 
  for( var i in cartes )
  {
    //console.log("i = " +  i);
    ajax_toload.push(
      $.ajax({
        url: cartes[i],
        indexValue: i, // index value permet de recuperer l'iterateur
        dataType: 'json',
        success: function( data ) {
          //alert(data.id + " " + data.categorie + " " + data.nom);
          
          addToCartesArray( data, this.indexValue );
        },
        error: function( jqXHR, textStatus, errorThrown ) {
          //alert( "Bogue loadCartes : " + textStatus + " - Erreur : " + errorThrown );
          //alert( jqXHR.statusText );
          //console.log(errorThrown+'\n'+status+'\n'+jqXHR.statusText);
        }
      })
    );
  }
  // S'execute quand les ajax_toload sont termin�s
  // $.when. It's used to say "when all these promises are resolved... do something". It takes an infinite (variable) number of parameters.
  $.when.all( ajax_toload ).done(function(objects) {
  /***
  **
 **   On Verifie les donnees de carte et on load les composantes
 */
  if ( objPE.cartes.length == arrCartes.length && composantesLoaded == false ) { 
      // on a parcouru les carte, et on n'a pas de correspondance
      if (index == 1 && objCarte == undefined) {
         carteSelectionnee = false;     
      
       $( '#contenu_'+index ).hide();
       
       $( '#contenu_0' ).show();
       index = 0;
      } else {
        carteSelectionnee = true;
        
     }
     loadComposantesContenu(); 
     composantesLoaded = true; 
   }
  /***
  **
 **   FIN
 */
   var cardIndex = 0;
   var cardInfos;
    $.each( arrCartes, function( index, value ) {
 
if (objPE.type_affichage) {
if (objPE.type_affichage == "large") {
cardInfos = formatInfosCarteLarge(this, cardIndex);
} else {
cardInfos = formatInfosCarteSmall(this, cardIndex);
}
} else {
cardInfos = formatInfosCarteSmall(this, cardIndex);
}
        cardIndex++;
$("#choixCarte").append(cardInfos);
    });
    $( ".vitrine .panel-heading a" ).click(function() {
        
        if ( $(this).closest(" .panel-heading").hasClass("collapsed") ) {
          $(this).closest(" .panel-heading").removeClass("collapsed") 
        } else {
          $(this).closest(" .panel-heading").addClass("collapsed") 
        }
    });
  });
}
function formatInfosCarteLarge(selectedCard, cardIndex) {
var infos_tableau = "", color;
        infos_tableau = "<div class='vitrine-large'   ><div class='panel panel-primary'><div class='panel-body' style=''>";
        infos_tableau += '<div  class="positionnement">';
        if (selectedCard.categorie == "entree") {
          color = "#aed57f";
        } else if (selectedCard.categorie == "intermediaire") {
          color = "#f2c457";
        } else {
          color = "#959595";  
        }
        infos_tableau += '<div class="colored" style="background-color: '+color+';"></div>';
infos_tableau += '</div>';
infos_tableau += '<div class="col-lg-24 col-md-24 col-sm-24 col-xs-24">';
infos_tableau += '<div class="col-lg-9 col-md-9  col-sm-9 col-xs-24 reset">';
        infos_tableau += '<div  class="carte"><img src="' + selectedCard.urls_img[langue][0] + '"/></div>';
        infos_tableau += '<div  class="carte-titre"><h5>' + selectedCard.titre[langue] + '</h5></div>';
        infos_tableau += '<div class="soustitre-extra">' + selectedCard.sous_titre[langue] + '</div>';
       infos_tableau += '</div>';
infos_tableau += '<div class="col-lg-15 col-md-15  col-sm-15 col-xs-24 reset">';
        infos_tableau += '<div class="panel-group arbre">';
               
        infos_tableau += '<div style="" id="collapse'+cardIndex+'" class="panel-collapse "><div class="">';
       
        $.each( selectedCard.infos_choix_carte[langue], function( index, value ) {
            //console.log(carte);
             infos_tableau += '<div class="libelle'+ (typeof this.styleclass !== "undefined"?" " + this.styleclass:"") +'"><span class="bold">' + this.libelle + '</span>';
            if (this.liste == true) {
              infos_tableau += '<ul>';
              $.each( this.texte, function( index, value ) { 
                  infos_tableau += '<li>' + value + '</li>';
              });
              infos_tableau += '</ul>';
            } else {              
              $.each( this.texte, function( index, value ) { 
                  infos_tableau += '<span class="normal">' + value + '</span>';
              });
              
            }
            infos_tableau += '</div>';
        });    
if (  selectedCard.url_details[langue] != "" ) {
        infos_tableau += '<a class="lien-action" href="' + selectedCard.url_details[langue] + '" target="blank">';
        infos_tableau += ( langue == 'en' )?'Learn more':'Plus de d�tails';
        infos_tableau += '</a>';
}
        infos_tableau += '</div>';
        infos_tableau += '</div>';
        infos_tableau += '</div>';
infos_tableau += '</div>';
infos_tableau += '</div>';
        infos_tableau += '<div class="choisir" style="text-align:center;"><button type="button" class="btn btn-primary" onclick=setCarte("'+selectedCard.id+'")>';
        infos_tableau += ( langue == 'en' )?'Get this card':'Choisir cette carte';
        infos_tableau += '</button></div>';
  
        infos_tableau += '</div></div></div>';
       
        return infos_tableau;
}
function formatInfosCarteSmall(selectedCard, cardIndex) {
var infos_tableau = "", color;
        infos_tableau = "<div class='vitrine'   ><div class='panel panel-primary'><div class='panel-body' style=''>";
        infos_tableau += '<div  class="positionnement">';
        if (selectedCard.categorie == "entree") {
          color = "#aed57f";
        } else if (selectedCard.categorie == "intermediaire") {
          color = "#f2c457";
        } else {
          color = "#959595";  
        }
        infos_tableau += '<div class="colored" style="background-color: '+color+';"></div>';
        infos_tableau += '<div  class="carte"><img src="' + selectedCard.urls_img[langue][0] + '"/></div>';
        infos_tableau += '<div  class="carte-titre"><h5>' + selectedCard.titre[langue] + '</h5></div>';
        infos_tableau += '<div class="soustitre-extra">' + selectedCard.sous_titre[langue] + '</div>';
        infos_tableau += '<div class="panel-group arbre">';
        infos_tableau += '<div class="panel panel-tiroir"><div class="panel-heading collapsed"><h3 class="panel-title asc"><span class="pull-right"><a data-toggle="collapse" class="collapsed" href="#collapse'+cardIndex+'">';
        infos_tableau += ( langue == 'en' )?'Show all':'Tout afficher';
        infos_tableau += '</a></span></h3></div></div>';
               
        infos_tableau += '<div style="" id="collapse'+cardIndex+'" class="panel-collapse collapse"><div class="panel-body">';
        infos_tableau += '<div class="note-bas-page"></div>';
        $.each( selectedCard.infos_choix_carte[langue], function( index, value ) {
            //console.log(carte);
 
            infos_tableau += '<div class="libelle'+ (typeof this.styleclass !== "undefined"?" " + this.styleclass:"") +'"><span class="bold">' + this.libelle + '</span>';
            
            if (this.liste == true) {
              infos_tableau += '<ul>';
              $.each( this.texte, function( index, value ) { 
                  infos_tableau += '<li>' + value + '</li>';
              });
              infos_tableau += '</ul>';
            } else {              
              $.each( this.texte, function( index, value ) { 
                  infos_tableau += '<span class="normal">' + value + '</span>';
              });
              
            }
            infos_tableau += '</div>';
        });    
if (  selectedCard.url_details[langue] != "" ) {
        infos_tableau += '<a class="lien-action" href="' + selectedCard.url_details[langue] + '" target="blank">';
        infos_tableau += ( langue == 'en' )?'Learn more':'Plus de d�tails';
        infos_tableau += '</a>';
}
        infos_tableau += '</div>';
        infos_tableau += '</div>';
        infos_tableau += '</div>';
        infos_tableau += '<div class="choisir"><button type="button" class="btn btn-primary" onclick=setCarte("'+selectedCard.id+'")>';
        infos_tableau += ( langue == 'en' )?'Get this card':'Choisir cette carte';
        infos_tableau += '</button></div>';
  
        infos_tableau += '</div></div></div></div>';
       
        return infos_tableau;
}
function loadPays() {
      sUrl = '/scd/wr/' + ( ( $('html').attr('lang') == 'en' )?'countries':'pays' ) + '.json';
      $.ajax({       
        url: sUrl,
        dataType: 'json',
        type: 'get',
        success: function (data) {
          jsonPaysObj = data;
 
          var $select = $('.countries');
          //var $select-codetenteur = $('#select-codetenteur-pieceIdentite-optionnel-pays');
        //  var $select = $('#pieceIdentitePays_1');
          $.each( jsonPaysObj.pays, function( i, pays ) {
            var option = $( '<option>', { value: pays.code } ).html( pays.nom ).appendTo( $select );
          })
      
        },
        error: function ( xhr, ajaxOptions, thrownError ) {
          //alert(xhr.status);
          //alert(thrownError);
        }
      }) // Fin du get ajax
}
function loadMessagesAide() {
  $.ajax({
    url: '/scd/wr/aide.json',
      dataType: 'json',
      success: function( data ) {
        var help = data;
        $('[rel=popover]').popover({
          html:true,
          trigger:'click',
          placement:'right',
          title: function(){
            return help[$(this).data('tag')].titre[langue];
          },
          content:function(){
            return help[$(this).data('tag')].contenu[langue];
          }
        });
        // show one popover and hide other popovers
        $('[rel=popover]').on('click', function (e) {
          $('[rel=popover]').not(this).popover('hide');
        });
      },
      error: function( jqXHR, textStatus, errorThrown ) {
        //alert( "Bogue loadMessagesAide : " + textStatus + " - Erreur : " + errorThrown );
      }
   });
}
// ****************************************
// � appeler sur tous les d�placements
// Avant la fonction inContenu
// Apr�s la fonction outContenu
// ****************************************
function loadComposantesContenu() {
  //console.log( 'loadComposantesContenu:begin' );
  // On v�rifie si on doit afficher l'en-t�te
  if( objPE.contenus[index].show_header ){
    if( !( headLoaded ) ){
      $( '#zone-head' ).load( objPE.url_header[langue], function() { 
        // On modifie le titre lorsqu'une carte a �t� s�lectionn�e
        if (typeof objCarte !== "undefined" && objCarte !== null) {
          setTitre(); 
           // Cas ou on arrive avec une carte deja selectionnee , on set la carte
           if (carte != "" && carteSelectionnee == true) {
                 initOptionsCarte(objCarte);   
                
            }
        }
      });
      headLoaded = true;
    }
    $( '.head-bar' ).show();
    $( '.head-title' ).show();
  }
  else{
    $( '.head-bar' ).hide();
    $( '.head-title' ).hide();
  }
  // On doit toujours updater les onglets quand on se d�place
  if( objPE.contenus[index].show_tabs ){
    loadOnglets();
    $( '#tabs' ).show();
    // Wrap onglets bootsrap
    $( '.onglets-etapes' ).show();
  }
  else{
    $( '#tabs' ).hide();
    // Wrap onglets bootsrap
    $( '.onglets-etapes' ).hide();
  }
  // On v�rifie si on doit afficher la section r�serv�e
  if( objPE.contenus[index].show_reserved ){
    if( !( reservedLoaded ) ) loadReserved();
    $( '#zone-middle-right-reserved' ).show();
  }
  else{
    $( '#zone-middle-right-reserved' ).hide();
  }
  // On doit toujours updater les boutons quand on se d�place
  if( objPE.contenus[index].show_buttons ){
    loadBoutons();
    $( '#zone-middle-left-buttons' ).show();
  }
  else{
    $( '#zone-middle-left-buttons' ).hide();
  }
  // On v�rifie si on doit afficher le pied de page
  if( objPE.contenus[index].show_footer){
    if( !( footLoaded  ) ){
      $( '#zone-foot' ).load( objPE.url_footer[langue], function() {} );
      footLoaded = true;
    }
    $( '#zone-foot' ).show();
  }
  else{
    $( '#zone-foot' ).hide();
  }
  
  if (typeof window["onLoadEtapes"] == "function") {
       window["onLoadEtapes"]();
  }
  //console.log( 'loadComposantesContenu:end' );
}
function loadContenus() {
  //console.log( 'loadContenus:begin' );
  //console.log( 'loadContenus:langue:'+langue );
  // Pour les diff�rents �crans du formulaire
  var str_display;
  var tasks = [];
  var ajax_toload = [];             // Tableau contenant les ajax � loader
  var ajax_results = new Object();  // Tableau contenant les r�sultats des ajax -- Java hashmap equivalentboo
  
  for (var i=0; i<objPE.contenus.length; i++) 
//  for( var i in objPE.contenus )
  {
    if( index == i ){
       str_display = '';
    }
    else{
       str_display = 'style="display: none;"';
    }
    //$( '#zone-middle-left-contents' ).append( '<div id="contenu_'+i+'"'+str_display+'></div>' );
    
    // Ajoute une class "Active Tab", lorsque l'etape a un titre
    // L'etape a un onglet lorsqu'elle a un titre associ�
    if ( objPE.contenus[i].onglet.titre[langue] != "") {
      $( '#zone-middle-left-contents' ).append( '<div class="row contenu active-tab" id="contenu_'+i+'"'+str_display+'></div>' );
    } else {
      $( '#zone-middle-left-contents' ).append( '<div class="full contenu" id="contenu_'+i+'"'+str_display+'></div>' );
    }    
    //$( '#contenu_' + i ).load( objPE.contenus[i].url_contenu[langue], function() {  } );
    ajax_toload.push(
      $.ajax({
        type: "GET",
        url: objPE.contenus[i].url_contenu[langue],
        indexValue: i, // index value permet de recuperer l'iterateur
        success: function(data) {
          // index value est l'�l�ment courant dans l'ordre defini dans le JSON du PE
          // data est le html r�cup�r� du fichier
          ajax_results[this.indexValue] = data;
        }
      })
    );
  }
  // S'execute quand les ajax_toload sont termin�s
  // $.when. It's used to say "when all these promises are resolved... do something". It takes an infinite (variable) number of parameters.
  $.when.all( ajax_toload ).done(function(objects) {
  
    // Append le contenu aux divs correspondants
    $.each( ajax_results, function( index, value ) {
        $( '#contenu_' + index ).append(value);
    });
    contenusReady();
  });
  //console.log( 'loadContenus:end' );
}
// Get an array of results instead of a pseudo-array for deferred
if (jQuery.when.all===undefined) {
    jQuery.when.all = function(deferreds) {
        var deferred = new jQuery.Deferred();
        $.when.apply(jQuery, deferreds).done(
            function() {
                deferred.resolve(Array.prototype.slice.call(arguments));
            },
            function() {
                deferred.fail(Array.prototype.slice.call(arguments));
            });
        return deferred;
    }
}
function loadOnglets() {
var str_onglets_desktop = '<ul class="nav nav-tabs onglets-etapes">';
var str_onglets_mobile = '';
var str_actif_desktop = '';
var str_actif_mobile = '';
var str_click = '';
var currentTabsStep = 0;
var nbSteps = objPE.contenus.length - 1;
//for (var i=0; i<objPE.contenus.length; i++) 
// Naviguation mobile simplifiee, avec les fleches
var navigationSimplifiee = false;
var show = true;
if ( objPE.contenus.length > 4 ) {
navigationSimplifiee  = true;
}
// Fleche gauche
if ( navigationSimplifiee  ) {
str_onglets_mobile += '<div class="step previous-step" >   <div class="triangle-left"></div>   </div>';
}
for( var i in objPE.contenus )
{
        currentTabsStep = parseInt(i) + 1;
if ( navigationSimplifiee  ) {
if ( (parseInt(index) + 1) < 4 ) {
   if ( currentTabsStep > 4  ) {
      show = false;
   } else {
      show = true
   }
} else if ( (parseInt(index) + 1) == 4 ) {
   if ( currentTabsStep > 5  ) {
       show = false;
   } else if ( currentTabsStep < 3 ) {
       show = false;  
   } else {
       show = true; 
   } 
} else if ( (parseInt(index) + 1) > 4 ) {
   if ( currentTabsStep < 4 ) {
       show = false;
   } else {
       show = true; 
   } 
}
}
if( index > i ){
str_actif_desktop = 'class="visited"';
       str_actif_mobile = 'class="step step-visited step-'+ currentTabsStep +'"';
       str_click = ' onclick="unvalidateAndMove(\'#contenu_'+(parseInt(i)+1)+'\', \''+i+'\');"';
}
else if( index == i ){
str_actif_desktop = 'class="active"';
str_actif_mobile = 'class="step step-current step-'+ currentTabsStep +'"';
str_click = '';
}
else{
str_actif_desktop = '';
       str_actif_mobile = 'class="step step-unvisited step-'+ currentTabsStep +'"';
       str_click = '';
}
if( objPE.contenus[i].onglet.titre[langue] != '' ) {
     
      // Affiche le titre de l'�tape
      if ($( '#contenu_'+i+' .titreEtape' ).html() == "") {
        $( '#contenu_'+i+' .titreEtape' ).html( objPE.contenus[i].onglet.titre[langue] + ((langue=='en')?": ":" : "));
        $( '#contenu_'+i+' .descriptionEtape' ).html( objPE.contenus[i].onglet.sous_titre[langue]  );
      }
      // construction des onglets desktop
      str_onglets_desktop += '<li '+str_actif_desktop+' '+str_click+'><a href="#tab'+i+'" data-toggle="tab"><span class="no-etape">'+objPE.contenus[i].onglet.titre[langue]+'</span>'+objPE.contenus[i].onglet.sous_titre[langue]+'</a></li>';
      // Construction des onglets mobile
      if (index == i) {
        if (langue == 'fr') {
          str_onglets_mobile += '<div '+str_actif_mobile+' '+str_click+'> &Eacute;tape '+currentTabsStep+' de '+nbSteps+'<div class="step-current-border"></div><div class="step-current-arrow"></div></div>'
        } else {
          str_onglets_mobile += '<div '+str_actif_mobile+' '+str_click+'> Step '+currentTabsStep+' of '+nbSteps+'<div class="step-current-border"></div><div class="step-current-arrow"></div></div>'
        }
      } else {
        str_onglets_mobile += '<div '+str_actif_mobile+' '+str_click+'  '+ ( (show) ? "style='display:block;'" : "style='display:none;'"   )   +'  >'+currentTabsStep+'</div>'
      }
    }
}
str_onglets_desktop += '</ul>';
// Fleche droite
if ( navigationSimplifiee  ) {
str_onglets_mobile += '<div class="step next-step" style="display:block;">   <div class="triangle-right"></div>   </div>';
}
str_onglets_mobile += '';
$( '#zone-tabs' ).html( str_onglets_desktop );
$( '#zone-tabs-mobile' ).html( str_onglets_mobile );
if ( navigationSimplifiee  ) {
if ( (parseInt(index) + 1) < 4) {
   $(".previous-step").hide();
   $(".next-step").show();
} else if ( (parseInt(index) + 1) == 4 ) {
  $(".previous-step").show();
   $(".next-step").show();
}  else if ( (parseInt(index) + 1) > 4 ) {
   $(".previous-step").show();
   $(".next-step").hide();
}
$(".previous-step").click( function(){  unvalidateAndMove('#contenu_'+(parseInt(index)), parseInt(index) - 1) } );
$(".next-step").click(   function(){  validateAndMove(parseInt(index)+1)  }  );
}
if (typeof tabsReady == 'function') { tabsReady(); }
}
function loadPE() {
  //console.log("loadPE:begin");
  //console.log( 'loadPE:langue:' + langue );
 $.ajax({
    url: '/scd/wr/'+pe+'.json',
    dataType: 'json',
    success: function( data ) {
       objPE = data;
      //console.log("Obligation ADP : " + objPE.adp);
     
      if (objPE.adp == true && adp == false) {
            window.location.replace(objPE.url_err_appl);
      }
 
 if( getQSParam( 'test' ) && getQSParam( 'test' ) != '' ) {
 if( carte != '' ){ // Dans le cas o� on arrive avec une carte d�j� s�lectionn�e ... on va alors directement � la page des options.
              index = objPE.globales.index_contenu_options;
         }
         loadContenus(); // Pour pr�-loader tous les contenus
  } else {
      // Load PE JS Files
      var scripts_toload = []; 
      // push urlr js
      for( var i in objPE.urls_js )
      {
        scripts_toload.push( $.getScript(objPE.urls_js[i]) );
      }
      // push urls validation
      scripts_toload.push( $.getScript(objPE.url_validation ) );
      //console.log(scripts_toload);
      $.when.all( scripts_toload  ).done(function(objects) {
        if( carte != '' ){ // Dans le cas o� on arrive avec une carte d�j� s�lectionn�e ... on va alors directement � la page des options.
              index = objPE.globales.index_contenu_options;
         }
         loadContenus(); // Pour pr�-loader tous les contenus
      });
 }
    },
    error: function( jqXHR, textStatus, errorThrown ) {
      //alert( "Bogue loadPE : " + textStatus + " - Erreur : " + errorThrown );
      fermerDialoguePatienter();
    }
  });
  //console.log("loadPE:end");
}
function loadReserved() {
  //console.log('loadReserved:begin');
  var str_reserved = '';
  //console.log(reservedLoaded);
  var ajax_toload = [];             // Tableau contenant les ajax � loader
  var ajax_results = new Object();  // Tableau contenant les r�sultats des ajax -- Java hashmap equivalent
  //for (var i=0; i<objPE.urls_reserved; i++) 
  for( var i in objPE.urls_reserved )
  {
    str_reserved = '<div id="reserved_'+i+'"></div>';
    $( '#zone-middle-right-reserved' ).append( str_reserved );
    
    //console.log('loadReserved:page_produit:'+objPE.urls_reserved[i].page_produit);
    ajax_toload.push(
      $.ajax({
        type: "GET",
        url: objPE.urls_reserved[i].url[langue],
        indexValue: i, // index value permet de recuperer l'iterateur
        success: function(data) {
          // index value est l'�l�ment courant dans l'ordre defini dans le JSON du PE
          // data est le html r�cup�r� du fichier
          ajax_results[this.indexValue] = data;
        }
      })
    );
  }
  // S'execute quand les ajax_toload sont termin�s
  // $.when. It's used to say "when all these promises are resolved... do something". It takes an infinite (variable) number of parameters.
  $.when.all( ajax_toload ).done(function(objects) {
    // $('#container').append(res[0], res[1], res[2]);
    // console.log("Resolved objects:", objects);
    // Append le contenu aux divs correspondants
    $.each( ajax_results, function( index, value ) {
        $( '#reserved_' + index ).append(value);
    });
    if (typeof objCarte !== "undefined" && objCarte !== null && carteSelectionnee == true) {
      // On remplit la zone avec les donn�es de la carte
      setProduit(); 
    } else { 
      // On affiche pas la zone si aucune carte n'a �t� s�lectionn�
      $("#produit-carte").hide();
    }
    // Append le clic to chat et call aux divs correspondants
/*
    var search_query = '//www.desjardins.com/contenus/desjr_js_widget_ctc.jsp?idClickToCall=431205545&idClient=315176076&bType=contact&langue='+langue+'&idClickToChat=38501ADF-9BE5-468A-BBD8-92C887E49CE3;42128954-C326-4CC6-A1D1-A61AB7F0D631';
    s = document.createElement('script');
    s.src = search_query;
    document.getElementsByTagName('body')[0].appendChild(s);
*/
    reservedLoaded = true;
   
    setSidebar();
  });
  //console.log('loadReserved:end');
}
function onChangeInputToggle(inputChange, inputName, condition) {
 $(inputChange).change(function() {
    if (this.value.latinize() == condition) {
      $( inputName ).show();
    }
    else {
      $( inputName ).hide();
    }
  });
} 
function onChangeInputReset(inputChange, inputNames, condition) {
  $(inputChange).change(function() {
    if (this.value == condition) {
      $.each(inputNames, function( index, input ) {  
        //console.log(input.attr('type') );
        if (input.attr('type') == "radio") {
          input.removeAttr('checked');
        } else {
          input.val("");
        }
      });
    }
  });
} 
function onClickInputAfficher(inputACliquer, divAAfficher, elementACacher) {
  $( inputACliquer ).click(function() {
    $( divAAfficher ).show();
    $( elementACacher ).hide();
  });
}
function onClickInputCacher(inputACliquer, divAAfficher, elementACacher) {
  $( inputACliquer ).click(function() {
    $( divAAfficher ).hide();
    $( elementACacher ).show();
    //  Vide les champs
    $( divAAfficher ).find("input[type=text], textarea").val("");
    $( divAAfficher + " select").each(function(index) { $( this ).find('option:first').attr('selected', 'selected');   });
  });
}
function setCarte(nouvelleCarte) {
  //console.log( 'setCarte:begin' );
  carte = nouvelleCarte;
  for( var i in arrCartes )
  {
    if ( arrCartes[i].id == carte ) { 
      carteSelectionnee = true;
      objCarte = arrCartes[i];
      deplacer( objPE.globales.index_contenu_options );
      setProduit();
      setTitre();
      // Initialiation des options de la carte
      initOptionsCarte(objCarte);   
    }
  }
  // Reset custom image
  if (carteSelectionnee && $("#applicatif-persoNumRefImage").val() != "") {
      var url_image_perso = "https://us.personalcard.net/AllAboutMe/Designer/PCS/GetPublicDesign.aspx?Handover_Key=" + $("#applicatif-persoCodeProduitAAM").val() + "&CardImageId=" + $("#applicatif-persoNumRefImage").val() + "&DesignType=Review";
      $("#produit-image").attr("src", url_image_perso); 
  }
  //setSidebar();
  //console.log( 'setCarte:end' );
}
function setDivVisibility() {
  //console.log( 'setDivVisibility:begin' );
  // Etape 2 - Zone optionnelle 1
  $( "#div-carteCreditDesjardins-optionnel" ).hide();
  // Etape 2 - Zone optionnelle 2
  $( "#div-carteCreditAutreInstitution-optionnel" ).hide();
  /* -----------
    PIECE D'IDENTITE
    ------------*/
  $( "#div-pieceIdentite-optionnel" ).hide();
  $( "#div-codetenteur-pieceIdentite-optionnel" ).hide();
  /* ------------
    TYPE D'EMPLOI
  -------------*/
  // Etape 3 - Zone optionnelle 1
  $( "#div-statutEmploi-optionnel1" ).hide();
  // Etape 3 - Zone optionnelle 2
  $( "#div-statutEmploi-optionnel2" ).hide();
  /* ------------
    REVENUS
  -------------*/
  // Etape 3 - Zone optionnelle 1
  /* $( "#div-revenus-optionnel1" ).hide(); */
  // Etape 3 - Zone optionnelle 2
  $( "#div-revenus-optionnel2" ).hide();
  // Zone identification optionnelle
  $( "#div-codetenteur-identification" ).hide();
  // Zone optionnelle 1
  $( "#div-codetenteur-statutEmploi-optionnel1" ).hide();
  // Zone optionnelle 2
  $( "#div-codetenteur-statutEmploi-optionnel2" ).hide();
  /* ------------
    CHOIX DU TYPE D'EMPLOI
  -------------*/
  // Etape 4 - Zone identification optionnelle
  $( "#div-codetenteur-identification" ).hide();
  // Etape 4 - Zone optionnelle 1
  $( "#div-codetenteur-statutEmploi-optionnel1" ).hide();
  // Etape 4 - Zone optionnelle 2
  $( "#div-codetenteur-statutEmploi-optionnel2" ).hide()
  //console.log( 'setDivVisibility:end' );
}
function setPE() {
  setStyle();
  //console.log("setPE:begin");
  if( getQSParam( 'pe' ) && getQSParam( 'pe' ) != '' ) {
    pe = getQSParam( 'pe' ).replace( /#.*/, "");
  }
  else {
    pe = 'pe004';
  }
  //console.log("PE : " + pe);
  if( getQSParam( 'c' ) && getQSParam( 'c' ) != '' ) {
    carte = getQSParam( 'c' ).replace( /#.*/, "");
  } else {
    carte = getCookieParam ('DESJ_INFO_CARTE');
    if (!carte == '') setCarte (carte);
  }
  langue = $('html').attr('lang');
  //console.log( 'setPE:langue:' + langue );
 
  $('#waitModal').modal({
    keyboard: false,
    show: true
  })
  loadPE();
 // $( '#page' ).show();
  //console.log("setPE:end");
}
function setProduit() {
  //console.log( 'setProduit:begin' );
  if( objCarte ) {
    if (!$("#produit-carte").is(":visible")) $("#produit-carte").show();
    $( '#zone-middle-right #produit-titre' ).html( objCarte.titre[langue] );
    $( '#zone-middle-right #produit-image' ).attr( "src", objCarte.urls_img[langue] );
    var strHtml = '';
    for( var i in objCarte.infos_produit_choisi[langue] ) {
      var infos_produit = objCarte.infos_produit_choisi[langue][i];
          cssClassLi = "",
          libellerLi = "";
      if( typeof infos_produit == 'object'){
        if ( typeof infos_produit.libelle !== "undefined") {
          libellerLi = infos_produit.libelle;
        }
        if ( typeof infos_produit.styleclass !== "undefined") {
          cssClassLi = ' class="' + infos_produit.styleclass + '"';
        }
      }
      else{
        libellerLi = infos_produit;
      }
      
      strHtml += '<li' + cssClassLi  + '>' + libellerLi + '</li>';
    }
    $( '#zone-middle-right #infos-produit-choisi' ).html( '<ul>' + strHtml + '</ul>' );
    // Reset sidebar
    setSidebar();
  }
  //console.log( 'setProduit:end' );
}
function setSidebar() {
  //console.log( 'setSidebar:begin' );  
  //$( ".contenu #zone-middle-right-reserved").remove();
  for( var i in objPE.contenus )
  {
      if( objPE.contenus[i].show_reserved ) {
        
        $( "#zone-middle-right" ).show();
        //$( "#zone-middle-right-reserved" ).clone().appendTo( "#contenu_" + i);
        //$( "#contenu_" + i + " .tab-pane" ).addClass("col-lg-18 col-md-18");
        //$( "#contenu_" + i + ".contenu #zone-middle-right-reserved" ).addClass("col-lg-6 col-md-6");
      }
  }
 
  //console.log( 'setSidebar:end' );
}
function setTitre() {
  if (objCarte) {
    if (!objPE.financement) {
      // Si un bas de page est pr�sent, on enl�ve le MD dans le titre seulement.
      if (objCarte.notes_bas_de_page) {
         
   if (objPE.titre_complet) {
         $('#libelle-demande').html ( objPE.titre_complet[langue]);
   } else {
$('#libelle-demande').html (objPE.titre[langue] + ' ' + objCarte.titre[langue].replace (new RegExp ('<sup>.*'), '') + objCarte.titre[langue].replace (new RegExp ('.*</sup>'), ''));
   }
      // Autrement on affiche le titre comme il est d�finis dans les param�tres de la carte.
      } else {
         
   if (objPE.titre_complet) {
         $('#libelle-demande').html ( objPE.titre_complet[langue]);
   } else {
$('#libelle-demande').html ((langue == 'en' ) ? objCarte.titre[langue] + ' ' + (objPE.titre[langue]).toLowerCase() : objPE.titre[langue] + ' ' + objCarte.titre[langue]);
   }
      }
    }
    $("#applicatif-donneesProduit").val( objCarte.nom + "-" + strip(objCarte.titre[langue]) + "-" + objCarte.sans_frais_1ere_annee + "-" + objCarte.taux_boni );
     // Affiche une notre li�e au titre
     if (typeof window["showNotes"] == "function") {
       window["showNotes"]();
     }
  }
}
// Supprime une ligne de la modale de reprise
function supprimerLigneModalReprise(elm) {
  elm.closest('.rangee').remove(); 
  if( $('#modalReprise .rangee').length == 0) {  
    $('#modalReprise').modal('hide');
  }
}
// R�cup�rer et formater la r�ponse d'un Cookie
getCookieParam = function (strCookieName) {
  if (!getCookie (strCookieName) == '') {
    return getCookie(strCookieName).replace (new RegExp ('(.*?)\adpTypeCarte='), '');
  } else {
    return '';
  }
};
