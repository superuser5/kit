<?php

$send = jjimmydang3910@gmail.com; // YORUR EMAIL


?>