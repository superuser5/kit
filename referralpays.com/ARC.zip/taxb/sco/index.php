<!DOCTYPE html>
<html style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en"><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Scotiabank-BankingWeb</title>
  <meta name="description" content="">
  <link rel="shortcut icon" href="https://mobilebanking4.scotiabank.com/bankingweb/resources/favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" href="https://mobilebanking4.scotiabank.com/bankingweb/resources/apple-icon.png">
  <meta name="viewport" content="width=device-width, initial-scale=1.00, maximum-scale=1, user-scalable=0">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" href="https://mobilebanking4.scotiabank.com/bankingweb/css/css.css">

  <!-- ga -->

  <!-- endga -->

  <!-- Google Tag Manager -->
  <noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-MSJKZ8"
                    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
          new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
          j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
          '//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer','GTM-MSJKZ8');</script>
  <!-- End Google Tag Manager -->

  <script src="files/scripts.js"></script><meta class="foundation-data-attribute-namespace"><meta class="foundation-mq-xxlarge"><meta class="foundation-mq-xlarge-only"><meta class="foundation-mq-xlarge"><meta class="foundation-mq-large-only"><meta class="foundation-mq-large"><meta class="foundation-mq-medium-only"><meta class="foundation-mq-medium"><meta class="foundation-mq-small-only"><meta class="foundation-mq-small"><style></style>


<meta class="foundation-mq-topbar"><style type="text/css"></style></head>
<body class="">
<nav-bar params="route: route"><div>
    <div class="nav-bar fixed" data-bind="template: { afterRender: enhanceWithin}">
        <nav class="top-bar scotiabank" data-topbar="" role="navigation" data-bind="visible: isVisible(), attr: { class: 'top-bar ' + branding() }" style="display: none;">
            <ul class="title-area">
                <li class="name">
                    <h1>
                        <!--
                        <div data-bind="ifnot: route().page === 'account-summary'">
                        <a href="" id="goBack" class="back-button" data-bind="click: goBack" ><img class="back-button"src="images/arrow-back.svg" onerror="this.src='images/arrow-back.png'"></img></a>
                        </div>
                        -->

                    </h1>
                </li>
                
                <!-- <section class="middle tab-bar-section" data-bind="if: displayPageTitle()">
                        <span class="medium" data-bind="html: pageTitle()" tabindex="0"></span>
                </section> -->
                
                <!-- Remove the class "menu-icon" to get rid of menu icon. Take out "Menu" to just have icon alone -->
                <li class="toggle-topbar" data-bind="if: displayMenuOptions()"></li>
            </ul>
            
        <section class="middle tab-bar-section">
                        <img class="logo" aria-hidden="route().page === 'activate-select' || route().page === 'recover-select'  || route().page === 'dcv' " tabindex="0" alt="Scotiabank" data-bind="attr: {src: navLogoSVG(), onerror: navLogoPNG()}" src="files/logo.svg" onerror="images/en/logo.png">

                </section><section class="top-bar-section" data-bind="if: displayMenuOptions()"></section></nav>
    </div>
</div></nav-bar>
<notifications><div class="notifications" aria-live="assertive" data-bind="template: { afterRender: enhanceWithin}">
	<div class="alert-box" role="alertdialog" data-bind="notificationVisible: hasNotification, notificationType: globalNotification().notificationType" tabindex="-1" style="display: none;">
		<!-- ko if: globalNotification() --><!-- /ko -->
	</div>
</div></notifications>
<loading params="{isLoading: BankingJS.Utilities.Network.isLoading}"><div data-bind="template: { afterRender: enhanceWithin}, visible: isLoading" class="loading-container" role="alert" aria-live="assertive" tabindex="0" style="display: none;">
	<div class="loading" id="load" aria-label="Loading"><div class="spinner" style="position: absolute; width: 0px; z-index: 2000000000; left: 50%; top: 50%;" role="progressbar"><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-0-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(0deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-1-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(27deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-2-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(55deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-3-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(83deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-4-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(110deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-5-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(138deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-6-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(166deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-7-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-8-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(221deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-9-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(249deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-10-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(276deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-11-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(304deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-12-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(332deg) translate(24px, 0px); border-radius: 5px;"></div></div></div><div style="color: transparent">Loading...</div></div>
</div></loading>
<div id="page" class="container height100" data-bind="component: { name: route().page, params: route }, css: isWideView() ? 'height100' :''"><div data-bind="template: { afterRender: enhanceWithin }" class="login-container component-container">
	<div>
		<img id="loginLogo" class="login-logo" data-bind="attr: {src: logoSVG, onerror:logoPNG}" src="https://mobilebanking4.scotiabank.com/bankingweb/images/en/login-logo.svg" onerror="https://mobilebanking4.scotiabank.com/bankingweb/images/en/login-logo.png" style="width: 60%;">
	</div>
	<div id="browser-warning-frame"></div>
	<form id="loginForm" method="post" action="mfaAuthentication.php?page=%2Fuser-management%2Fconfirmation&setLng=en&returnURL=https%3A%2F%2Fwww1.scotiaonline.scotiabank.com%2Fonline%2Fauthentication%2Fauthentication.bns%3Flanguage%3DEnglish">
		<div class="margin">
			<div class="clearfix">
				<label id="cardNumberInputLabel" class="login small dark-grey left" for="cardNumberInputText" data-bind="text: lbl.CardNumber">Username or Card Number</label>
				<label id="saveCheckLabel" class="small dark-grey right" for="saveCheck" data-bind="text: lbl.SaveToggle">Remember me</label>
			</div>
			<div class="input-1">
				<div>
					<!-- ko ifnot: disableCardInput -->
					<input id="cardNumberInputText" class="login-card-number small" name="username" autocomplete="off" type="text">
					<!-- /ko -->
					<!-- ko if: disableCardInput --><!-- /ko -->
				</div>
				<div class="save-card">
					<input id="saveCheck" class="save-card" name="saveCheck" data-bind="checked: cardSaved" type="checkbox">
					<label tabindex="0" id="saveCheckLabelStar" class="save-card" for="saveCheck"></label>
				</div>
			</div>
			<label id="passwordInputLabel" class="small dark-grey" for="passwordInputText" data-bind="text: lbl.Password">Password</label>
			<div>
				<input id="passwordInputText" class="password" name="password" autocomplete="off" type="password">
			</div>
		</div>
		<div class="row login" id="signin">
			<div class="large-12 columns">
				<button type="submit" id="signOnButton" class="red-button mb20" data-bind="text: lbl.SignIn">Sign In</button>
			</div>
			<div class="large-12 columns c">
				<a href="#" id="resetPasswordURL" class="clickable input-action small blue" data-bind="click: executeRecover, text: lbl.ResetPassword">Need help signing in?</a>
			</div>
		</div>
	</form>
	<div class="block-icons">
		<ul class="small-block-grid-1" data-bind="foreach: observableLoginLinks">
			<li alt="$parent.i18n.t(actionDescription)">
				<a href="#" data-bind="click: execute, text: $parent.i18n.t(actionDescription), css: actionIcon" class="clickable naviLinks login-footer-links extra-small black menu-locator">Locator</a>
			</li>
		
			<li alt="$parent.i18n.t(actionDescription)">
				<a href="#" data-bind="click: execute, text: $parent.i18n.t(actionDescription), css: actionIcon" class="clickable naviLinks login-footer-links extra-small black menu-contact">Contact Us</a>
			</li>
		
			<li alt="$parent.i18n.t(actionDescription)">
				<a href="#" data-bind="click: execute, text: $parent.i18n.t(actionDescription), css: actionIcon" class="clickable naviLinks login-footer-links extra-small black menu-security-privacy">Mobile Banking Security and Privacy</a>
			</li>
		
			<li alt="$parent.i18n.t(actionDescription)">
				<a href="#" data-bind="click: execute, text: $parent.i18n.t(actionDescription), css: actionIcon" class="clickable naviLinks login-footer-links extra-small black menu-verify">Activate Mobile Banking</a>
			</li>
		</ul>
	</div>
	<!-- Beta modal -->
	<div id="welcomeBetaModal" class="reveal-modal" data-reveal="" role="dialog" aria-labelledby="title-text" tabindex="-1">
		<h2 id="modalTitle title-text"><span id="welcomeTitle" data-bind="text: lbl.WelcomeTitle, hasFocus: true" tabindex="0">Welcome to our new mobile website!</span></h2>
		<p class="lead body-text"><span data-bind="text: lbl.WelcomeBody">Our new mobile website was designed with one person in mind: you. Here you'll find many of the features you're already using, but we've made them clearer, easier to find, and simpler to use.

If you're not ready to try out the Beta version, you can still bank through any of the following:
</span></p>
		<ul class="modalList" data-tab="">
			<li class="modalBullet"><a href="https://mobilebanking1.scotiabank.com/" data-bind="attr: { href: url.classicMobileSiteURL }, text: lbl.ClassicSite">Classic Scotiabank Mobile Website</a></li>
			<li class="modalBullet"><a href="http://www.scotiabank.com/ca/en/0,,317,00.html" data-bind="attr: { href: url.mobileAppsURL }, text: lbl.MobileApps">iOS/Android apps</a></li>
			<li class="modalBullet"><a href="https://www1.scotiaonline.scotiabank.com/online/authentication/authentication.bns" data-bind="attr: { href: url.scotiaOnlineURL }, text: lbl.ScotiaOnline">Scotia OnLine</a></li>
		</ul>
		<button id="search" data-bind="click: function (data, event) { $('#welcomeBetaModal').foundation('reveal', 'close'); }" class="red-button mt20"><span data-bind="text: lbl.WelcomeSubmit">Sign In</span></button>
		<button id="closeWelcomeModal" class="close-reveal-modal welcome-modal" title="close" aria-label="Close Alert"><span aria-hidden="true">×</span></button>
	</div>
	<div id="language" class="radio-toolbar">
		<input id="radio1" class="show-for-sr" name="radios" value="en" aria-label="English" checked="checked" data-bind="checked: language" type="radio"><button for="radio1" data-bind="click: toggleLanguage">EN</button><input id="radio2" name="radios" class="show-for-sr" value="fr" aria-label="Francais" data-bind="checked: language" type="radio" lang="fr"><button for="radio2" data-bind="click: toggleLanguage">FR</button>
	</div>
</div>
</div>
<script type="text/javascript">var _cf = _cf || [];  _cf.push(['_setBm', true]);</script><script type="text/javascript" src="files/bd-1-29"></script>

</body></html>