$(function () {
	// We need to check ie10 and ie11 this way as it doesn't support conditional comments
	if (navigator.appVersion.indexOf('MSIE 10') !== -1){
		$('html').addClass('ie10 oldie');
	}
	// Inject Placeholder.js
	/*yepnope({
		test : Modernizr.placeholder,
		nope : ['/uos/external/placeholders/4.0.1/js/placeholders.jquery.min.js']
	});*/
	
	// Placehoder issue for ie9
	if($('.ie9').length){
		var hasPlaceholderSupport = function() {
		  var input = document.createElement('input');
		  return ('placeholder' in input);
		};
		if(!hasPlaceholderSupport()){
			var inputs = document.getElementsByTagName('input');
			for(var i=0,  count = inputs.length;i<count;i++){
				if(inputs[i].getAttribute('placeholder')){
					inputs[i].value = inputs[i].getAttribute("placeholder");
					inputs[i].onclick = function(){
						if(this.value == this.getAttribute("placeholder")){
							this.value = '';
						}
					};
					inputs[i].onblur = function(){
						if(this.value === ''){
							this.value = this.getAttribute("placeholder");
						}
					};
				}
			}
		}
	}
	
	// Helper Functions
	// Prevent Default
	var rbcPreventDefault = function(event){
		event.preventDefault();
		event.stopPropagation();
		event.returnValue = false;
		return false;
	};

	// Match heights
	var equalheight = function(container){
		var currentTallest = 0,
		currentRowStart = 0,
		rowDivs = [],
		topPosition = 0;
		$(container).each(function() {
			$el = $(this);
			$($el).height('auto');
			topPostion = $el.position().top;

			if (currentRowStart != topPostion) {
				for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
					rowDivs[currentDiv].height(currentTallest);
				}
				rowDivs.length = 0; // empty the array
				currentRowStart = topPostion;
				currentTallest = $el.height();
				rowDivs.push($el);
			}
			else {
				rowDivs.push($el);
				currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);
			}
			for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
				rowDivs[currentDiv].height(currentTallest);
			}
		});
	};
	// if ie8 or ie9 Equalize columns
	if($('.ie8, .ie9').length){
		$(window).load(function() {
			if($('#signInPage').length){
				equalheight('#olbLinks .boxShadow');
			}
			if($('#secGenProductBanner').length){
				if($('.ccadDetailsTable').length){
					$('.ccadDetailsTable').next().width($('.ccadDetailsTable').width());
				}
				else {
					$('.alignBottom').width($('.alignBottom').parent().width());
				}
				$.when(equalheight('.cardInfoCont')).then(function(){
					$('.productCardSeparator').each(function(){
						var nearLeft = $(this).prev().outerHeight();
						var nearRight = $(this).next().outerHeight();
						var tallest = (Math.max(nearLeft, nearRight));
						$(this).animate({height: tallest}, 400);
					});
				});
				$('.cardImageCont p:nth-of-type(1)').css('margin-bottom', '5px');
				$('.tableHeaderRow th:last-child, .genericTable td:last-child').css({'padding-right':'10px', 'white-space':'nowrap'});
			}
			
			if($('.sidebarQuickPayment').length){
				$('.sidebarQuickPayment .input-group:last').css('float','right');
			}
			
			equalheight('.footerCols');
		});
	}
	// Purpose: Traverse up the hierarchy of elements, starting with the
	// element passed as an argument to this function. Will return true if
	// a matched parent element has the class "dropdown-menu". This can easily
	// be refactored to support any user-defined class name to search for.
	//
	// Note: Will only traverse up the hierarchy as far as the <body> element
	function hasParent(el) {
		if (el[0].nodeName === "BODY") {
			// The node passed to this function is the <body> element
			return false;
		}
		else {
			// The node passed as an argument is not the <body> element
			// Get the classname of the parent node, or set to undefined
			var selector = el[0].parentElement.className || undefined;

			if (selector) {
				// The current parent node has a class name
				if (selector === "dropdown-menu") {
					// The element the user is tabbing to is within a dropdown-menu
					return true;
				}
				else {
					// The parent element of this node does not have the dropdown-menu class
					return hasParent($(el).parent());
				}
			}
			else {
				// The parent element of this node does not have a class
				return hasParent($(el).parent());
			}
		}
	}
	// This solution only works on ieEdge and the rest of the browsers.  Removing temporarily
	// $('[data-toggle="tooltip"]').hover(function(){
	// 	$(this).attr({'title': $('option:selected',this).text()});
	// },function(){
	// 	$(this).attr('title', '');
	// });
	$('.tableWellBtn').on('click', function(){
		$(this).toggleClass('rotate180');
	});
	$('.infoBtn').hover(function(){
		$(this).children('.toolTipTop').removeClass('accessible');
	},function(){
		$(this).children('.toolTipTop').addClass('accessible');
	});
	$('.toolTipTop').focus(function(){
		$(this).removeClass('accessible');
	}).blur(function(){
		$(this).addClass('accessible');
	});
	$('.closeTooltip').on('click', function(){
		$(this).parent().addClass('accessible');
	});
	// Account Summary Dropdown (Quick Links)
	// Extends Bootstrap dropdown
	$.fn.rbcTooltip = function(){
		var toggle = $('.dropdown-toggle', this),
		mainParent = this,
		close = $('.closeDropdown', this),
		menu = $('.dropdown-menu', this),
		menuFirst = $('.dropdown-header');
		// This solves accessibility for top5Dropdown title
		toggle.dropdown();
		// Keypress on close button
		close.on('keypress keyup', function(event){
			// on pressing return
			var keycode = (event.keyCode ? event.keyCode : event.which);
			if(keycode == '13'){
				mainParent.removeClass('open');
				mainParent.find(toggle).attr('aria-expanded', 'false').focus();
				rbcPreventDefault(event);
			}
		});
		$(close).on('focusout', function(e) {
			parent = e.target.parentNode.previousSibling.previousSibling;

			if (hasParent($(e.relatedTarget)) === true) {
				$(e.relatedTarget).focus();
			}
			else {
				$(parent).focus();
			}
		});
		close.on('click', function(){
			mainParent.removeClass('open');
			mainParent.find(toggle).attr('aria-expanded', 'false').focus();
		});
		//Add focus class to first child of the dropdown-menu
		// Focus jumps to first anchor of the dropdown-menu if there's any
		// This fixes jumping issue.
		mainParent.on('shown.bs.dropdown', function(){
			if(menuFirst.length > 0){
				menuFirst.attr('tabindex', '0');
				menuFirst.focus();
			}
		});
		// On tabbing inside the menu, close when tab is out of it
		// This corrects a bug present only in Safari and provides a cross browser solution
		menu.on('keypress keyup', function(event){
			var keycode = (event.keyCode ? event.keyCode : event.which);
			// Detect Tab on the menu
			if(keycode == '9'){
				// Detect Tab on the document and compare state
				$(document).on('keypress, keyup', function(event){
					if(keycode == '9' && menu.is(':visible')){
						if($(event.target).closest(menu).attr('class') === undefined) {
							setTimeout(function() {
								mainParent.removeClass('open');
								mainParent.find(toggle).attr('aria-expanded', 'false').focus();
							}, 0.5);
						}
					}
				});

			}
		});
		menu.on('keydown', function(event){
			var keycode = (event.keyCode ? event.keyCode : event.which);
			// Detect when user is using arrows to navigate
			if(keycode == '37'|| keycode == '38' || keycode == '39' || keycode == '40'){
				$(document).on('keypress, keyup', function(event){
					if(keycode == '37'|| keycode == '38' || keycode == '39' || keycode == '40' && menu.is(':visible')){
						if($(event.target).closest(menu).attr('class') === undefined) {
							setTimeout(function() {
								mainParent.removeClass('open');
								mainParent.find(toggle).attr('aria-expanded', 'false').focus();
							}, 0.5);
						}
					}
				});
			}
		});
		// Prevent the dropdown to close unless click on a link
		menu.on('click', function(event){
			if(event.target.tagName.toLowerCase() === 'a'){
				event.target.returnValue = true;
				mainParent.removeClass('open');
				mainParent.find(toggle).attr('aria-expanded', 'false').focus();
			}
			else{
				rbcPreventDefault(event);
			}
		});
		// ESC key. Focus lands on trigger
		$(window).on('keypress keyup', function(event){
			var keycode = (event.keyCode ? event.keyCode : event.which);
			if(keycode == '27' && menu.is(':visible')){
				mainParent.removeClass('open');
				mainParent.find(toggle).attr('aria-expanded', 'false').focus();
			}
		});
	};
	//Initiate any dropdown here.  Keep html structure



	// Initiate rbcTooltip only on click (less expensive and obtrusive)
	$('.top5Dropdown').on('click keydown', function(){
		$(this).rbcTooltip();
	});
	$('.toolTip').on('click keydown', function(){
		$(this).rbcTooltip();
	});
	$('.accQuickDropdown').on('click keydown', function(){
		$(this).rbcTooltip();
		// $(this).rbcTooltip();
	});
	// Account Details Toggle
	// Different behavior than the tooltips
	$.fn.rbcDropdown = function(){
		var toggle = $('.dropdown-toggle', this),
		mainParent = this,
		close = $('.closeDropdown', this),
		menu = $('.dropdown-menu', this),
		menuFirst = $('.accToggleBank');
		toggle.dropdown();
		// Keypress on close button
		close.on('keypress keyup', function(event){
			// on pressing return
			var keycode = (event.keyCode ? event.keyCode : event.which);
			if(keycode == '13'){
				mainParent.removeClass('open');
				mainParent.find(toggle).removeAttr('aria-expanded');
				rbcPreventDefault(event);
			}
		});
		close.on('click', function(){
			mainParent.removeClass('open');
			mainParent.find(toggle).removeAttr('aria-expanded');
		});
		//Add focus class to first child of the dropdown-menu
		// Focus jumps to first anchor of the dropdown-menu if there's any
		// This fixes jumping issue.
		mainParent.on('shown.bs.dropdown', function(){
			if(menuFirst.length > 0){
				menuFirst.attr('tabindex', '0');
				menuFirst.focus();
			}
		});
		mainParent.on('hidden.bs.dropdown', function(){
			$(this).find(toggle).removeAttr('aria-expanded');
		});
		//This prevents clicking events on the dropdown that will close it
		menu.on('click', function(event){
			if(event.target.tagName.toLowerCase() === 'a'){
				event.target.returnValue = true;
			}
			else{
				rbcPreventDefault(event);
			}
		});
		//This makes the dropdown trigger behave like an actual toggle
		toggle.on('click', function(event){
			rbcPreventDefault(event);
		});
		// Scroll to top when first link is focused
		menuFirst.focus(function(){
			if(menu.is(':visible')){
				menu.scrollTop(0);
			}
		});
	};
	$('.accToggle').rbcDropdown();
	// Modals
	// Make the modals generic
	// Add a class of '.modalBtn' to the element that triggers the Modal
	// Keep the HTML structure.
	// The trigger can be wrapped in any tag
	// The modal needs to be sibling of the above wrapper
	//If problems, please flag and some containers need to be created
	$('.modalBtn').on('click', function(event){
		rbcPreventDefault(event);
		yepnope({
			load : ['js/libs/jquery.trap.min.js'],
			complete: function(){
				$(".trap").trap();
			}
		});
		var mainModal = $(this).closest('.modalWrapper').find('.modal');
		var modalDialog = mainModal.find('.modal-dialog');
		var header = mainModal.find('.modal-title');
		var content = mainModal.find('.modal-content');

		//Pass options to prevent default behavior
		$(mainModal).modal({
			backdrop: 'static',
			keyboard: false
		});

		// Reposition the modal function
		function reposition() {
			var modal = $(this),
				dialog = modal.find('.modal-dialog');
			modal.css('display', 'block');
			// Dividing by two centers the modal exactly, but dividing by three
			// or four works better for larger screens.
			dialog.css('margin-top', Math.max(0, ($(window).height() - dialog.height()) / 2));
		}
		// extend Modal functionality for accessibility
		function focusOnTrigger(){
			$(mainModal).modal('hide');
			$(mainModal).closest('.modalWrapper').find('.modalBtn').focus();
		}

		header.attr('id', 'modalLabel').focus();
		mainModal.attr('aria-hidden', 'false');
		content.attr('tabindex', '-1');

		$(mainModal)
			.on('show.bs.modal', reposition)
			.modal('show')
			.on('hide.bs.modal', function(){
				header.removeAttr('id');
				mainModal.attr('aria-hidden', 'true');
			});

		//Reposition when the window is resized
		$(window).on('resize', function() {
			if ($(mainModal).is(':visible'))
				$(mainModal).each(reposition);
		});
		//Add any accessibility functionality here
		//If Esc is pressed, focus on the parent btn
		$(window).on('keypress keyup', function(event){
			var keycode = (event.keyCode ? event.keyCode : event.which);
			if(keycode == '27' && $(mainModal).is(':visible')){
				focusOnTrigger();
			}
		});
		$('.closeModal').on('keypress keyup', function(event){
			var keycode = (event.keyCode ? event.keyCode : event.which);
			if(keycode == '13'){
				focusOnTrigger();
			}
		}).on('click', function(){
			focusOnTrigger();
			$(this).off('click');
		});
		// Solves click outside the modal box
		$(document).on('click', function(event){
			if(!$(event.target).closest('.modal-content').length) {
				if($(mainModal).is(':visible')){
					focusOnTrigger();
					$(this).off('click');
				}
			}
		});
		// Click on data-dismiss='modal' button (Cancel Button)
		$('[data-dismiss="modal"]').on('click', function(event){
			focusOnTrigger();
		});
	});

	// Load and Prepopulate Calendar
	if($('.rbc_calendar').length){
		yepnope.injectJs('/uos/common/javascript/calendar_encapsulated_new.js');
		yepnope.injectJs('/uos/common/javascript/calendar_new.js');

	}
	// Smooth Scroll for account summary products banner
	$.fn.rbcScrollTo = function(target){
		// Accessibility Extension for productCards
		// Make them Focusable
		$(this).attr('tabindex', '0');
		$(target).find('h3').attr('tabindex', '-1');
		function scrollToTarget(){
			$('html, body').animate({
					scrollTop: $(target).offset().top
			}, 600);
			$(target).find('h3').focus();
		}
		// Trigger a click event or keyboard event
		$(this).on('click', function(){
			scrollToTarget();
		}).on('keypress keyup', function(event){
			var keycode = (event.keyCode ? event.keyCode : event.which);
			if(keycode == '13'){
				scrollToTarget();
			}
		});
	};
	$('.accountsActive').rbcScrollTo('#bankAcc');
	$('.creditCardsActive').rbcScrollTo('#creditCards');
	$('.investmentsActive').rbcScrollTo('#investAcc');
	$('.loansActive').rbcScrollTo('#linesLoansAcc');
	$('.mortgageActive').rbcScrollTo('#mortgageAcc');

	// Sign in accessibility tab issue when critical error messages are present
	if($('.redNotice').length){
			if($('#signInPage').length){
			$('.redMessage').attr('tabindex','1').focus();
			$('.redNotice').each(function(){
				$(this).find('a').attr('tabindex','1');
			});
		}
	}
	else {
		// Focus when page loads
		if($('.ccUsername').length){
			$('.ccUsername').focus();
		}
		if($('.selectAccount').length){
			$('.selectAccount').focus();
		}
	}
	
	// Solves on focus for firefox.
	$('.errorLink').on('click', function(event){
		rbcPreventDefault(event);
		var link = $(this).attr('href');
		setTimeout(function() {
			$(link).focus();
		}, 200);
	}).on('keypress keyup', function(event){
		var link = $(this).attr('href');
		var keycode = (event.keyCode ? event.keyCode : event.which);
		if(keycode == '13'){
			rbcPreventDefault(event);
			setTimeout(function() {
				$(link).focus();
			}, 200);
		}
	});
});