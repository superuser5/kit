<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/ion.rangeSlider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/ion.rangeSlider.skinFlat.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/newpages.css')); ?>">
<style>
.invest-step_1{
    width: 170px;
    height: 170px;
    margin: 0 auto;
    border-radius: 50%;
    background-color: #<?php echo e($general->color); ?>;
    text-align: center;
}
.invest-step_1:hover{
   
    background-color: #101010;

}
.invest-step_1 img {
    position: relative;
    top: 45px;
    z-index: 1;
}
.our-service .item{
    min-height:353px!important;
}
.pricing .price-inner .text{
    color: #163e51!important;
}
#pricing-1 .item:hover .text{
    color: #fff!important;
}
input.invest-type__profit--val {
    display: inline-block;
    border: none;
    width: 276px;
    margin: 0 auto;
    background: #fff;
    color: #<?php echo e($general->color); ?>;
    font-family: 'Bree Serif', serif;
    font-size: 32px;
    font-weight: 500;
    text-align: center;
}
.irs-from, .irs-to, .irs-single {
    background: #<?php echo e($general->color); ?>!important;
}

.invest-type .irs .irs-slider {
    width: 15px;
    height: 15px;
    background-color:#<?php echo e($general->color); ?>!important;
    box-shadow: none;
    top: 20px;
    cursor: pointer;
    transition: 0.3s transform ease;
}

.amount-change{
    padding: 8px;
}
#blog{
    margin: 50px 0px;
}
#header{
    height: 100vh;
    background-size: 100% 100%!important;
}
#why-choose-us:after {
    content: "";
    background-color: #000;
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: -1;
    opacity: .7;
}
#why-choose-us .title{
    color:#fff;
}
.irs-bar {
    background-color: #<?php echo e($general->color); ?>;
    z-index: 9;
}
.irs-from:after, .irs-to:after, .irs-single:after {
    position: absolute;
    display: block;
    content: "";
    bottom: -23px;
    left: 25%;
    width: 15px;
    height: 15px;
    margin-left: 0px;
    overflow: hidden;
    background-color: #101010;
    border-radius: 50%;
    z-index: 9999;
    border: none;
}
.irs-line {
    height: 12px;
    top: 25px;
    background-color: gray;
}
.irs-line-mid, .irs-line-left, .irs-line-right, .irs-bar, .irs-bar-edge, .irs-slider{
    background-image: none;
}

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <!-- Slider -->
  <div id="slider">
            <div class="container-fluid">
                <div class="slider-inner">
                    <div id="header-carousel" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                        
                    <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($s->id % 2): ?>
                            <!-- First slide -->
                            <div class="item active">
                           
                                <div class="carousel-caption">
                                <h1 data-animation="animated fadeInUp">
                                        <?php echo e($s->title); ?>

                                    </h1>
                                    <h1 data-animation="animated fadeInDown" class="color">
                                    <span class="color"><?php echo e($s->description); ?> </span>
                                    </h1>
                                </div>
                            </div>
                    
                        <?php else: ?>
                            <!-- Second slide -->
                            <div class="item">
                                <div class="carousel-caption">
                                <h1 data-animation="animated fadeInUp">
                                <?php echo e($s->title); ?>

                                    </h1>
                                    <h1 data-animation="animated fadeInDown">
                                    <span class="color"><?php echo e($s->description); ?> </span>
                                    </h1>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <!-- /.carousel-inner -->

                        <!-- Controls -->
                        <a class="left carousel-control" href="#header-carousel" role="button" data-slide="prev">
                            <span class="fa fa-chevron-left"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="right carousel-control" href="#header-carousel" role="button" data-slide="next">
                            <span class="fa fa-chevron-right"></span>
                            <span class="sr-only">Next</span>
                        </a>

                    </div>
                    <!-- /.carousel -->
                </div>
            </div>
        </div>
</header>
    <!--=-=-=-=-=-=-=-=-=-=-=-=
         ABOUT US  
-=-=-=-=-=-=-=-=-==-=-=-=-=-->
<section id="about-us">
        <div class="container">
            <div class="title common text-center">
                <h2>about us</h2>
            </div>
            <div class="main">
                <div class="row">
                    <div class="col-md-5">
                        <div class="about-img">
                            <img src="<?php echo e(asset('assets/images/about.png')); ?>" class="img-responsive" alt="About">
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="about-text">
                        <?php echo $general->about_text; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> 
    <!--=-=-=-=-=-=-=-=-=-=-=-=-=-=-
          WHY CHOOSE US    
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-->
<section id="why-choose-us" style="background: url(<?php echo e(asset('assets/images/front-bg/image_why_chose_us.jpg')); ?>) center no-repeat fixed;">
        <div class="container">
            <div class="wcu-inner">
                <div class="title common text-center">
                    <h2>why choose us</h2>
                </div>
                <div class="main">
                    <ul class="nav nav-pills">
                    <?php  $first_id = round(count($chose)/2)  ?>
                        <?php $__currentLoopData = $chose; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php if($first_id == $c->id): ?> active <?php endif; ?>"><a href="#tab-<?php echo e($c->id); ?>" data-toggle="tab"><?php echo e($c->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="tab-content">
                    <?php $__currentLoopData = $chose; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div id="tab-<?php echo e($c->id); ?>" class="row tab-pane fade <?php if($first_id == $c->id): ?> active in <?php endif; ?>">
                            <div class="col-md-5 col-lg-6 col-md-push-7 col-lg-push-6">
                            <span style="font-size: 200px; padding-left: 29%;"><?php echo $c->icon; ?></span>
                            </div>
                            <div class="col-md-7 col-lg-6 col-md-pull-5 col-lg-pull-6">
                                <h2><?php echo e($c->title); ?></h2>
                                <p style="text-align:justify;padding: 0px 5px"><?php echo e($c->s_text); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
 
<!--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
          PRICING TABLE 1   
-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-->
<section id="pricing-1"  class="pricing">
        <div class="container">
            <div class="pricing-inner">
                <div class="title common text-center">
                    <h2>Investment Plan</h2>
                </div>
                <div class="main">
                    <div class="row">
                    <?php $__currentLoopData = $plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-sm-6">
                            <div class="item">
                                <div class="item-title text-center">
                                    <h2><?php echo e($p->name); ?></h2>
                                </div>
                                <div class="item-price">
                                    <div class="item-bor">
                                        <div class="price-inner">
                                            <div class="text">
                                                <span><?php echo e($p->percent); ?>%</span>
                                                <span><?php echo e($p->compound->name); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-offers">
                                    <div>

                                    </div>
                                    <div class="amount-change">
                                            <?php echo Form::open(['route'=>'auto-deposit','method'=>'get']); ?>

                                            <div class="invest-type__profit plan__value--<?php echo e($p->id); ?>">
                                                <input type="text" value="<?php echo e($basic->symbol); ?><?php echo e(($p->minimum + $p->maximum) / 2); ?>" class="invest-type__profit--val" data-slider=".slider-input--<?php echo e($p->id); ?>"></div>
                                            <input type="hidden" name="amount" value="<?php echo e(($p->minimum + $p->maximum) / 2); ?>" class="slider-input slider-input--<?php echo e($p->id); ?>" data-perday="<?php echo e($p->percent); ?>" data-peryear="<?php echo e($p->time); ?>" data-min="<?php echo e($p->minimum); ?>" data-max="<?php echo e($p->maximum); ?>" data-dailyprofit=".daily-profit-<?php echo e($p->id); ?>" data-totalprofit=".total-profit-<?php echo e($p->id); ?> " data-valuetag=".plan__value--<?php echo e($p->id); ?> .invest-type__profit--val"/>
                                            <input type="hidden" name="plan_id" value="<?php echo e($p->id); ?>">
                                            <div class="row">
                                                <div class="col-xs-6 invest-type__calc invest-type__calc--daily">
                                                    <span>Per Rebeat</span>
                                                    <b class="daily-profit-<?php echo e($p->id); ?>"><?php echo e($basic->symbol); ?><?php echo e((($p->minimum + $p->maximum) / 2 ) * $p->percent /100); ?>.0</b>
                                                </div>
                                                <div class="col-xs-6 invest-type__calc invest-type__calc--total">
                                                    <span>Total Return</span>
                                                    <b class="total-profit-<?php echo e($p->id); ?>"><?php echo e($basic->symbol); ?><?php echo e((((($p->minimum + $p->maximum) / 2) * $p->percent) /100 ) * $p->time); ?>.0</b>
                                                </div>
                                            </div>
                                            <div class="get-btn">
                                                    <a type="submit" class="btn btn-default">Choose Plan</a>
                                            
                                            <?php echo Form::close(); ?>

                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </div>
                </div>
            </div>
        </div>
    </section>

 <!--=-=-=-=-=-=-=-=-=-=-=-=-
          HOW TO INVEST    
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-->
<section id="our-service" class="our-service">
    <div class="container">
        <div class="os-inner">
            <div class="title common text-center">
                <h2>How to Invest</h2>
            </div>
            <div class="main text-center">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="item">
                            <span>
                                <div class="invest-step_1">
                                    <img src="<?php echo e(asset('assets/images/investstep/step_invest.png')); ?>" alt="" width="70px">
                                </div>
                            </span>
                            <h3>1. Registration</h3>
                            <p>Free registration. To open an account, it's sufficient to enter your e-mail. and phone</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="item">
                            <span>
                                <div class="invest-step_1">
                                    <img src="<?php echo e(asset('assets/images/investstep/step_invest.png')); ?>" alt="" width="70px">
                                </div>
                            </span>
                            <h3>2. Investing</h3>
                            <p>Transfer of investment funds in trust to our traders </p>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="item">
                            <span>
                                <div class="invest-step_1">
                                    <img src="<?php echo e(asset('assets/images/investstep/step_trade.png')); ?>" alt="" width="70px">
                                </div>
                            </span>
                            <h3>3. Trading</h3>
                        <p>Trading on the cryptocurrency exchanges and daily accrual of interest </p>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="item">
                            <span>
                                <div class="invest-step_1">
                                    <img src="<?php echo e(asset('assets/images/investstep/step_profit.png')); ?>" alt="" width="70px">
                                </div>
                            </span>
                            <h3>4. Profit</h3>
                            <p>Equal division of final profit between the company and its investors.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


     <!--=-=-=-=-=-=-=-=-=-=-=-=-=-=
            COUNTER   
-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-->
<div id="counter" style="background: url(<?php echo e(asset('assets/images/front-bg/counter-bg.jpg')); ?>) center no-repeat fixed;">
        <div class="container">
            <div class="counter-inner">
                <div class="row">
                <?php $__currentLoopData = $promo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3  col-sm-6">
                        <div class="item">
                            <span class="icon"><?php echo $p->icon; ?></span>
                            <span class="count"><?php echo e($p->number); ?></span>
                            <span class="text"><?php echo e($p->title); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>


    <!--=-=-=-=-=-=-=-=-=-=-=
          BLOG   
-=-=-=-=-=-=-=-=-==-=-=-=-->
    <section id="blog">
        <div class="container">
            <div class="blog-inner">
                <div class="title common text-center">
                    <h2>latest news</h2>
                </div>
                <div class="main">
                      <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if($n->id % 2 == 0 ): ?>
                            <div class="item left">
                            <div class="row">
                                <div class="col-md-5">
                                    <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($n->image); ?>" class="img-responsive" alt="news-img">
                                </div>
                                <div class="col-md-7">
                                    <div class="item-title">
                                        <h2><?php echo e($n->title); ?></h2>
                                        <div class="item-info">
                                            <i class="fa fa-bars"></i> Posted On <?php echo e($n->category->name); ?>

                                            <i class="fa fa-calendar"></i> <?php echo e(\Carbon\Carbon::parse($n->created_at)->format('d F Y')); ?> 
                                        </div>
                                    </div>
                                    <div class="item-text">
                                        <p> <?php echo substr(strip_tags($n->description),0,280); ?><?php echo e(strlen(strip_tags($n->description)) > 280 ? "..." : ""); ?></p>
                                    </div>
                                     <a href="<?php echo e(route('news-details',['id'=>$n->id,'slug'=>str_slug($n->title)])); ?>" target="_blank" class="btn btn-info">read more <span class="fa fa-angle-double-right"></span></a>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="item right">
                        <div class="row">
                            <div class="col-md-5 col-md-push-7 col-lg-push-7">
                                <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($n->image); ?>" class="img-responsive" alt="">
                            </div>
                            <div class="col-md-7 col-md-pull-5 col-lg-pull-5">
                                <div class="item-title">
                                    <h2><?php echo e($n->title); ?></h2>
                                    <div class="item-info">
                                         <i class="fa fa-bars"></i> Posted On <?php echo e($n->category->name); ?>

                                         <i class="fa fa-calendar"></i> <?php echo e(\Carbon\Carbon::parse($n->created_at)->format('d F Y')); ?> 
                                    </div>
                                </div>
                                <div class="item-text">
                                    <p> <?php echo substr(strip_tags($n->description),0,280); ?><?php echo e(strlen(strip_tags($n->description)) > 280 ? "..." : ""); ?></p>
                                </div>
                                <a href="<?php echo e(route('news-details',['id'=>$n->id,'slug'=>str_slug($n->title)])); ?>" target="_blank" class="btn btn-info">read more <span class="fa fa-angle-double-right"></span></a>
                            </div>
                        </div>
                    </div>
                        <?php endif; ?>
                        

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('news')); ?>" class="btn btn-default more">load more</a>
                </div>
            </div>
        </div>
    </section>

<!--=-=-=-=-=-=-=-=-=-=-=-=
         TESTIMONIALS   
-=-=-=-=-=-=-=-=-==-=-=-=-=-->
<section id="testimonial" style="background: url(<?php echo e(asset('assets/images/front-bg/why-people-bg.jpg')); ?>) center no-repeat fixed;">
        <div class="container-fluid">
            <div class="testi-inner">
                <div class="title common text-center">
                    <h2>what people say</h2>
                </div>
               
                <div class="owl-carousel owl-theme testi-carousel">
                    <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="item-top">
                            <div class="item-info">
                                <div class="item-img">
                                  
                                </div>
                                <div class="item-title">
                                    <h4 class="name"><?php echo e($t->name); ?><small class="post"><?php echo e($t->position); ?></small></h4>
                                </div>
                            </div>
                        </div>
                        <div class="item-main">
                            <div class="quote-icon">
                                <span class="fa fa-quote-left"></span>
                            </div>
                            <div class="main-text">
                                <p><?php echo e($t->description); ?></p>
                            </div>
                        </div>
                       
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
               
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<!-- 
    <script type="text/javascript" src="<?php echo e(asset('assets/js/venobox.min.js')); ?>"></script> -->
    <script type="text/javascript" src="<?php echo e(asset('assets/js/ion.rangeSlider.js')); ?>"></script>

    <script>
        $.each($('.slider-input'), function() {
            var $t = $(this),

                    from = $t.data('from'),
                    to = $t.data('to'),

                    $dailyProfit = $($t.data('dailyprofit')),
                    $totalProfit = $($t.data('totalprofit')),

                    $val = $($t.data('valuetag')),

                    perDay = $t.data('perday'),
                    perYear = $t.data('peryear');


            $t.ionRangeSlider({
                input_values_separator: ";",
                prefix: '<?php echo e($basic->symbol); ?>',
                hide_min_max: true,
                force_edges: true,
                onChange: function(val) {
                    $val.val( '<?php echo e($basic->symbol); ?>' + val.from);

                    var profit = (val.from * perDay / 100).toFixed(1);
                    profit  = '<?php echo e($basic->symbol); ?>' + profit.replace('.', '.') ;
                    $dailyProfit.text(profit) ;

                    profit = ( (val.from * perDay / 100)* perYear ).toFixed(1);
                    profit  =  '<?php echo e($basic->symbol); ?>' + profit.replace('.', '.');
                    $totalProfit.text(profit);

                }
            });
        });
        $('.invest-type__profit--val').on('change', function(e) {

            var slider = $($(this).data('slider')).data("ionRangeSlider");

            slider.update({
                from: $(this).val().replace('<?php echo e($basic->symbol); ?>', "")
            });
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>