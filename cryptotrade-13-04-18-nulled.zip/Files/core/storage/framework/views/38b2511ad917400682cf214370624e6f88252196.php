<?php $__env->startSection('import-css'); ?>
    <link href="<?php echo e(asset('assets/dashboard/css/bootstrap-fileinput.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

    <script type="text/javascript" src="<?php echo e(asset('assets/dashboard/js/nicEdit.js')); ?>">

    </script>
    <script type="text/javascript">
        //<![CDATA[
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
        //]]>
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                <!-- panel head -->
                <div class="panel-heading">
                    <div class="panel-title"><?php echo e($page_title); ?></div>

                </div>

                <!-- panel body -->
                <div class="panel-body">
                    <?php echo Form::model($news,['route'=>['news-update',$news->id],'method'=>'put','class'=>'form-horizontal','files' => true]); ?>

                    <div class="form-body">

                        <div class="form-group">
                            <label class="col-sm-2 control-label">News Category : </label>

                            <div class="col-sm-10">
                                <select name="category_id" id="" class="form-control input-lg" required>
                                    <option value="">Select One</option>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($news->category_id == $cat->id): ?>
                                            <option value="<?php echo e($cat->id); ?>" selected><?php echo e($cat->name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">News Title : </label>

                            <div class="col-sm-10">
                                <input type="text" name="title" id="" value="<?php echo e($news->title); ?>" class="form-control input-lg" required placeholder="News Title">
                            </div>
                        </div>
                        </div>


                        <div class="form-group">
                            <label class="col-sm-2 control-label">Image :</label>
                            <div class="col-sm-10">
                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                    <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;" data-trigger="fileinput">
                                        <?php if($news->image == null): ?>
                                        <img style="width: 200px" src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=Fetured Image" alt="...">
                                        <?php else: ?>
                                            <img style="width: 200px" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($news->image); ?>" alt="...">
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <span class="btn btn-info btn-file">
                                            <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                            <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                            <input type="file" name="image" accept="image/*" required>
                                        </span>
                                        <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">News Description : </label>

                            <div class="col-sm-10">
                                <textarea name="description" class="form-control input-lg" id="area1" cols="30" rows="10" required placeholder="News Description"><?php echo e($news->description); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-offset-2 col-md-10">
                                <button type="submit" onclick="nicEditors.findEditor('area1').saveContent();" class="btn btn-info btn-block margin-top-10"><i class="fa fa-paper-plane"></i> Update News</button>
                            </div>
                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>

            </div>
        </div>
    </div><!---ROW-->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('import-js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/js/bootstrap-fileinput.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>