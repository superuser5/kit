<?php $__env->startSection('style'); ?>
<style>
    .sub-page .page-header {
        padding: 150px 100px;
        color: #FFFFFF;
        position: relative;
        z-index: 1;
        margin-bottom: 0;
        border-bottom: none;
    }
    .sub-page .page-header a {
    color: #FFFFFF;
    text-decoration: underline;
    }
    #header{
            height: auto;
            background-size: 100% 100%!important;
            position: relative;
            margin-bottom:50px;
        }
    .our_mission{
        margin-top: 65px;
        margin-bottom: 20px;
    }
    .capitalize_name{
        text-transform:capitalize;
    }
    .empty-news{
        text-align: center;
        font-weight: 600;
        color: #1E223F;
        padding: 100px 0px;
        font-size: 25px;
        border: 1px solid #f3f3f3;
        background-color: #F6F6F6;
    }
    #blog-details .post-body{
        overflow:hidden;
    }
    #blog-details .share-icons{
        padding: 15px 0px 0px 0px;
        overflow: hidden;

    }
    #blog-details .share-icons .views p{
        float: left;
        padding: 10px 40px;
        background-color: #f3f3f3;
        margin: 0!important;
    }
    #blog-details .share-icons .share-button{
        float: right;
        overflow: hidden;
        padding: 10px 0px;
    }
</style>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
        <!-- MAIN HEADER -->
        <div class="sub-page">
            <div class="page-header">
                <div class="container">
                    <h1><?php echo e($page_title); ?></h1>
                    <span><a href="<?php echo e(route('home')); ?>">Home</a> / <span class="capitalize_name">News Detail</span></span>
                </div>
            </div>
    </div>
    </header>

    <!--=-=-=-=-=-=-=-=-=-=-=-=-=-=
         BLOG DETAILS   
-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-->
<section id="blog-details">
        <div class="container">
            <div class="bd-inner">
                <div class="row">
                    <div class="col-md-12">

                        <!-- ========== Main post ========= -->
                        <div class="post-main">
                            <div class="post-header">
                                <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($news->image); ?>" alt="">
                                <div class="details">
                                    <h1 class="header"><?php echo e($news->title); ?></h1>
                                    <span class="meta"><span class="data"><i class="fa fa-calendar"></i> <?php echo e(\Carbon\Carbon::parse($news->created_at)->format('d F Y')); ?> </span> | <i class="fa fa-bars"></i>  <a href="<?php echo e(route('category-news',['id'=>$news->category->id,'slug'=>str_slug($news->category->name)])); ?>" class="author"> Posted On <?php echo e($news->category->name); ?></a></span>
                                </div>
                            </div>
                            <div class="post-body">
                                <p><?php echo $news->description; ?></p>
                            </div>
                        </div>

                        <!-- ======= POST-SHARE-ICONS ======= -->
                       
                        <div class="share-icons">
                            <div class="views">
                                   
                                         <p> <i class="fa fa-eye"></i> View: <?php  $gr = \App\News::findOrFail($news->id)  ?> <?php echo e($gr->view); ?></p>
                                   
                            </div>
                            <div class="share-button">
                                 
                                    <ul class="no-style">
                                            <li class="share-text"><i class="fa fa-share"></i> Share: </li>
                                            <li>
                                                <a class="fa fa-facebook" target="_blank" href="http://www.facebook.com/share.php?u=<?php echo e(url()->current()); ?>/<?php echo e($news->id); ?>/<?php echo e(str_slug($news->title)); ?>&title=<?php echo e($news->title); ?>"></a>
                                            </li>
                                            <li>
                                                <a class="fa fa-twitter" target="_blank" href="http://twitter.com/home?status=<?php echo e($news->title); ?>+<?php echo e(url()->current()); ?>/<?php echo e($news->id); ?>/<?php echo e(str_slug($news->title)); ?>"></a>
                                            </li>
                                            <li>
                                                <a class="fa fa-google-plus" target="_blank" href="https://plus.google.com/share?url=<?php echo e(url()->current()); ?>/<?php echo e($news->id); ?>/<?php echo e(str_slug($news->title)); ?>"></a>
                                            </li>
                                        </ul>
                                  
                            </div>
                               
                            </div>
                        <hr/>

                        <!-- ======== COMMENT-BOX ======== -->
                        <div class="comment-box">
                            <h2>Comments</h2>
                            <div class="comment-list">
                                <div id="fb-root"></div>
                                    <script>(function(d, s, id) {
                                        var js, fjs = d.getElementsByTagName(s)[0];
                                        if (d.getElementById(id)) return;
                                        js = d.createElement(s); js.id = id;
                                        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=1421567158073949";
                                        fjs.parentNode.insertBefore(js, fjs);
                                        }(document, 'script', 'facebook-jssdk'));
                                    </script>
                                <div class="fb-comments" data-href="<?php echo e(url()->current()); ?>" data-width="100%" data-numposts="5"></div>
                            </div>
                        </div>

                    </div>

                    <!-- =========== SIDEBAR ========== -->
                    <div class="col-md-4">
                       
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>