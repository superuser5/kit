<?php $__env->startSection('style'); ?>
<style>
    .sub-page .page-header {
        padding: 150px 100px;
        color: #FFFFFF;
        position: relative;
        z-index: 1;
        margin-bottom: 0;
        border-bottom: none;
        text-align: center;
        text-transform: uppercase;
    }
    .sub-page .page-header a {
    color: #FFFFFF;
    text-decoration: underline;
    }
    #header{
            height: auto;
            background-size: 100% 100%!important;
            position: relative;
        }
</style>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
        <!-- MAIN HEADER -->
        <div class="sub-page">
            <div class="page-header">
                <div class="container">
                    <h1>log in form</h1>
                    <span><a href="<?php echo e(route('home')); ?>">Home</a> / <span>log in</span></span>
                </div>
            </div>
    </div>
    </header>

<div class="row">
    <div class="col-md-6 col-md-offset-3">
            <?php if(session()->has('message')): ?>
            <div style="margin-top: 20px;margin-bottom: -15px;" class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <?php if(session()->has('status')): ?>
            <div style="margin-top: 20px;margin-bottom: -15px;" class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e(session()->get('status')); ?>

            </div>
        <?php endif; ?>
        
        <?php if($errors->any()): ?>
        
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                <div style="margin-top: 20px;margin-bottom: -15px;" class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <?php echo $error; ?>

                </div>
        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>


   

                    
    <!--=-=-=-=-=-=-=-=-=-=-=-=
         LOG IN   
-=-=-=-=-=-=-=-=-==-=-=-=-=-->
    <section id="login">
        <div class="container">
            <div class="section-inner">
                <div class="sign-main">
                    <div class="title">
                        <h2><span class="fa fa-lock"></span> log in</h2>
                    </div>
                    <div class="main-form">
                        <form action="<?php echo e(route('login')); ?>" method="post" accept-charset="utf-8" class="block">
                                        <?php echo csrf_field(); ?>

                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Your Email">
                            </div>

                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="password" name="password" autocomplete="new-password" class="form-control" placeholder="Password">
                            </div>

                            <input type="submit" value="login" class="btn btn-default">
                        </form> 
                    </div>
                    <span class="reset bottom"><i class="fa fa-question-circle"></i> Forgot your password? <a href="<?php echo e(route('password.request')); ?>">Reset now</a></span>
                    <span class="signup bottom"><i class="fa fa-question-circle"></i> Don't Have an Account? <a href="<?php echo e(route('register')); ?>">Sign up</a></span>
              
                </div>
            </div>
        </div>
    </section>

               
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>