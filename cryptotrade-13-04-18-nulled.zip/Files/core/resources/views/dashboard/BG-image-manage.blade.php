@extends('layouts.dashboard')
@section('style')
<style>
.bg-img img{
    height:110px;
    width: 100% !important;
}
.img-input{
    padding-top: 27%;
}
.save-button{
    margin-top: 25px;
}
.image-format{
    display: inline-block;
    color: red;
}
</style>

@endsection
@section('content')
<div class="row">
        <div class="col-md-12">

            <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                <!-- panel head -->
                <div class="panel-heading">
                    <div class="panel-title"><p class="image-format"><b><i>Image Resize 1920 X 650px. Image Type PNG &amp; JPEG</i></b></p></div>
                </div>

                <!-- panel body -->
                <div class="panel-body">

                    {!! Form::open(['method'=>'post','class'=>'form-horizontal','files'=>true]) !!}
                   
                    <div class="row">
                        <div class="col-md-8">
                            <h3>Header Background Image</h3>
                            <div class="bg-img">
                                <img src="{{ asset('assets/images/front-bg/image_header.jpg')}}">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="img-input"> 
                                <input type="file" name="image_header" id="" class="form-control input-lg" >
                            </div>
                        </div>
                    </div>
                    <div class="row">
                            <div class="col-md-8">
                                <h3>Why Choose Us Background Image</h3>
                                <div class="bg-img">
                                        <img src="{{ asset('assets/images/front-bg/image_why_chose_us.jpg')}}" alt="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="img-input"> 
                                    <input type="file" name="image_why_chose_us" id="" class="form-control input-lg" >
                                </div>
                            </div>
                        </div>
                        <div class="row">
                                <div class="col-md-8">
                                    <h3>Site Statistics Background Image</h3>
                                    <div class="bg-img">
                                            <img src="{{ asset('assets/images/front-bg/counter-bg.jpg')}}" alt="">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="img-input"> 
                                        <input type="file" name="image_statistics" id="" class="form-control input-lg">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                    <div class="col-md-8">
                                        <h3>What People Say Background Image</h3>
                                        <div class="bg-img">
                                            <img src="{{ asset('assets/images/front-bg/why-people-bg.jpg')}}" alt="">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="img-input"> 
                                            <input type="file" name="image_people" id="" class="form-control input-lg">
                                        </div>
                                    </div>
                                </div>
                            <div class="row save-button">
                                    <div class="col-md-offset-3 col-md-6">
                                        <button type="submit" class="btn btn-blue btn-block margin-top-10"><i class="entypo-direction"></i>Update</button>
                                    </div>
                            </div>
                    {!! Form::close() !!}

                </div>

            </div>

        </div>
    </div>
   

@endsection
@section('scripts')




@endsection