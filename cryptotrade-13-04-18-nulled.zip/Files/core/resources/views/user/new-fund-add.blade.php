@extends('layouts.user')
@section('style')

    <script type="text/javascript" src="{{ asset('assets/dashboard/js/nicEdit.js') }}">

    </script>
    <script type="text/javascript">
        //<![CDATA[
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
        //]]>
    </script>

@endsection
@section('content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                <!-- panel head -->
                <div class="panel-heading">
                    <div class="panel-title"><i class="fa fa-money"></i> <strong>{{ $page_title }}</strong></div>

                </div>

                <!-- panel body -->
                <div class="panel-body">
                    <div class="row">
                        @foreach($gateways as $gateway)
                        <div class="col-md-3">
                            <div class="panel panel-info" data-collapsed="0">
                                <!-- panel head -->
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        @if($gateway->id == 1)
                                        <i class="fa fa-paypal"></i>
                                        @elseif($gateway->id == 2)
                                           <i class="fa fa-money"></i>>
                                        @elseif($gateway->id == 3)
                                          <i class="fa fa-btc"></i> 
                                        @elseif($gateway->id == 4)
                                           <i class="fa fa-cc-stripe"></i> 
                                        @elseif($gateway->id == 5)
                                           <i class="fa fa-compass"></i>
                                        @elseif($gateway->id == 6)
                                           <i class="fa fa-money"></i>
                                        @elseif($gateway->id == 8)
                                           <i class="fa fa-bars"></i>  
                                        @else
                                          <i class="fa fa-money"></i> 
                                        @endif 
                                    <strong>{{ $gateway->name }}</strong></div>

                                </div>
                                <!-- panel body -->
                                <div class="panel-body">
                                    <img width="100%" class="image-responsive" src="{{ asset('assets/images/gateway') }}/{{ $gateway->gateimg }}" alt="">
                                </div>
                                <div class="panel-footer">
                                    <a href="javascript:;" onclick="jQuery('#modal-{{$gateway->id}}').modal('show');" class="btn btn-info btn-block btn-icon icon-left"><i class="fa fa-money"></i> ADD FOUND</a>
                                </div>
                            </div>
                        </div>

                            <!-- Modal 1 (Basic)-->
                            <div class="modal fade" id="modal-{{$gateway->id}}">
                                <div class="modal-dialog">
                                    <div class="modal-content">

                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title"><i class="fa fa-money"></i> Add Found via {{$gateway->name}}</h4>
                                        </div>
                                        {{ Form::open() }}
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label style="margin-top: 20px;font-size: 14px;" class="col-sm-2 col-sm-offset-2 control-label">Amount : </label>
                                                        <div class="col-sm-7">
                                                            <span style="color: green;margin-left: 10px;"><strong>{{$gateway->minamo}} - {{$gateway->maxamo}} {{ $basic->currency }}. Charge ({{$gateway->chargefx}} + {{$gateway->chargepc}}%) {{ $basic->currency }}</strong></span>
                                                            <div class="input-group" style="margin-bottom: 15px;">
                                                                <input type="text" value="" id="amount" name="amount" class="form-control amount" required />
                                                                <span class="input-group-addon">&nbsp;<strong>{{ $basic->currency }}</strong></span>
                                                                <input type="hidden" name="payment_type" id="payment_type" value="{{$gateway->id}}">
                                                                <input type="hidden" name="rate" value="{{$gateway->rate}}">
                                                                <input type="hidden" name="fix" value="{{$gateway->chargefx}}">
                                                                <input type="hidden" name="percent" value="{{$gateway->chargepc}}">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <div id="result"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        {{ Form::close() }}
                                    </div>
                                </div>
                            </div>

                        @endforeach
                    </div>
                </div>

            </div>
        </div>
    </div><!---ROW-->

@endsection
@section('scripts')
    <script type='text/javascript'>

        jQuery(document).ready(function(){

            $('.amount').on('input', function() {

                var amount = $(this).parent().find("#amount").val();
                var payment_type = $(this).parent().find("#payment_type").val();
                var result = $(this).parent().parent().parent().parent();

                $.post(
                        '{{ route('paypal-check-amount') }}',
                        {
                            _token: '{{ csrf_token() }}',
                            amount : amount,
                            payment_type : payment_type
                        },
                        function(data) {
                            result.find("#result").html(data);
                        }
                );
                
            });
        });
    </script>
    @endsection

