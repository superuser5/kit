@extends('layouts.front-master')
@section('style')
<style>
    .sub-page .page-header {
        padding: 150px 100px;
        color: #FFFFFF;
        position: relative;
        z-index: 1;
        margin-bottom: 0;
        border-bottom: none;
        text-align: center;
    }
    .sub-page .page-header a {
    color: #FFFFFF;
    text-decoration: underline;
    }
    #header{
            height: auto;
            background-size: 100% 100%!important;
            position: relative;
        }
    .our_mission{
        margin-top: 65px;
        margin-bottom: 20px;
    }

</style>

@endsection 

@section('content')
        <!-- MAIN HEADER -->
        <div class="sub-page">
            <div class="page-header">
                <div class="container">
                    <h1>PASSWORD RESET</h1>
                    <span><a href="{{route('home')}}">Home</a> / <span>Password Reset</span></span>
                </div>
            </div>
    </div>
    </header>
    <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-lg-offset-3 col-md-offset-3 col-xs-12">
                    @if (session()->has('message'))
                        <div style="margin-top: 20px;margin-bottom: -10px;" class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            {{ session()->get('message') }}
                        </div>
                    @endif
                    @if (session()->has('status'))
                        <div style="margin-top: 20px;margin-bottom: -10px;" class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            {{ session()->get('status') }}
                        </div>
                    @endif

                    @if($errors->any())

                        @foreach ($errors->all() as $error)

                            <div style="margin-top: 20px;margin-bottom: -20px;" class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                {!!  $error !!}
                            </div>

                        @endforeach
                    @endif
                   
                </div>
            </div>
        </div>
    <!-- ========================== /Inner Banner =================== -->
        <section id="forgot">
        <div class="container">
            <div class="section-inner">
                <div class="sign-main">
                    <div class="title">
                        <h2><span class="fa fa-question-circle"></span> password reset</h2>
                    </div>
                    <form action="{{ route('password.email') }}" method="post" accept-charset="utf-8" class="block">
                    {!! csrf_field() !!}    
                        <div class="main-form">

                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="email" name="email" value="{{ old('email') }}" class="form-control" placeholder="Your Email Address">
                            </div>

                            <input type="submit" value="Reset Password" class="btn btn-default">
                        </div>
                    </form>
                    <span class="forgot bottom"><i class="fa fa-question-circle"></i> Need an Account? <a href="{{ route('register') }}">Sign Up</a></span>
                </div>
            </div>
        </div>
    </section>

@endsection
