@extends('layouts.front-master')
@section('style')
<style>
    .sub-page .page-header {
        padding: 150px 100px;
        color: #FFFFFF;
        position: relative;
        z-index: 1;
        margin-bottom: 0;
        border-bottom: none;
        text-align: center;

    }
    .sub-page .page-header a {
    color: #FFFFFF;
    text-decoration: underline;
    }
    #header{
            height: auto;
            background-size: 100% 100%!important;
            position: relative;
        }
    .our_mission{
        margin-top: 65px;
        margin-bottom: 20px;
    }
    .login_page {
        padding-bottom: 30px;
        margin-top: 84px;
    }

</style>

@endsection 

@section('content')
        <!-- MAIN HEADER -->
        <div class="sub-page">
            <div class="page-header">
                <div class="container">
                    <h1>PASSWORD RESET</h1>
                    <span><a href="{{route('home')}}">Home</a> / <span>Password Reset</span></span>
                </div>
            </div>
    </div>
    </header>
    <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                             @if (session()->has('message'))
                            <div style="margin-top: 20px;margin-bottom: -10px;" class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                {{ session()->get('message') }}
                            </div>
                            @endif
                            @if (session()->has('status'))
                                <div style="margin-top: 20px;margin-bottom: -10px;" class="alert alert-danger alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    {{ session()->get('status') }}
                                </div>
                            @endif

                            @if($errors->any())

                                @foreach ($errors->all() as $error)

                                    <div style="margin-top: 20px;margin-bottom: -20px;" class="alert alert-danger alert-dismissable">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        {!!  $error !!}
                                    </div>

                                @endforeach
                            @endif
                                </div>
                    </div>
                   
 </div>

    <!--=-=-=-=-=-=-=-=-=-=-=-=
         FORGOT PASSWORD   
-=-=-=-=-=-=-=-=-==-=-=-=-=-->
    <section id="forgot">
        <div class="container">
            <div class="section-inner">
                <div class="sign-main">
                    <div class="title">
                        <h2><span class="fa fa-question-circle"></span> password reset</h2>
                    </div>
                    <div class="main-form">
                        <form action="{{ route('password.request') }}" method="post" accept-charset="utf-8" class="block">
                        {!! csrf_field() !!}
                        <input type="hidden" name="token" value="{{ $token }}">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="email" name="email" value="{{ old('email') }}" class="form-control" placeholder="Enter Mail id *">
                            </div>

                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="password" name="password" class="form-control" required placeholder="Enter Password">
                            </div>

                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-unlock"></i></span>
                                <input type="password" name="password_confirmation" class="form-control" required placeholder="Confirm Password">
                            </div>

                            <input type="submit" value="Update" class="btn btn-default">
                     </form>
                    </div>
                    <span class="forgot bottom"><i class="fa fa-question-circle"></i> Need an Account? <a href="registration.html">Sign Up</a></span>
                </div>
            </div>
        </div>
    </section>

@endsection
