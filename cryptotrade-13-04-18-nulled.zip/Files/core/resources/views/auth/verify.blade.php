@extends('layouts.front-master')
@section('style')
<style>
    .sub-page .page-header {
        padding: 150px 100px;
        color: #FFFFFF;
        position: relative;
        z-index: 1;
        margin-bottom: 0;
        border-bottom: none;
        text-align: center;
        text-transform: uppercase;
    }
    .sub-page .page-header a {
    color: #FFFFFF;
    text-decoration: underline;
    }
    #header{
            height: auto;
            background-size: 100% 100%!important;
            position: relative;
        }
    .our_mission{
        margin-top: 65px;
        margin-bottom: 20px;
    }
    .lowfont{
        text-transform:lowercase;
    }
</style>

@endsection 

@section('content')
        <!-- MAIN HEADER -->
        <div class="sub-page">
            <div class="page-header">
                <div class="container">
                    <h1>Mail Verify</h1>
                    <span><a href="{{route('home')}}">Home</a> / <span class="lowfont">>Mail Verify</span></span>
                </div>
            </div>
    </div>
    </header>

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Verify.</div>
                    <div class="panel-body">
                        <div class="text-center">
                            <h4 class="color-red">Check Your MailBox and Verify Your Account.</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
