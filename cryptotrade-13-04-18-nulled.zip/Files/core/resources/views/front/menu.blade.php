@extends('layouts.front-master')
@section('style')
<style>
    .sub-page .page-header {
        padding: 150px 100px;
        color: #FFFFFF;
        position: relative;
        z-index: 1;
        margin-bottom: 0;
        border-bottom: none;
        text-align: center;
        text-transform: uppercase;
    }
    .sub-page .page-header a {
    color: #FFFFFF;
    text-decoration: underline;
    }
    #header{
            height: auto;
            background-size: 100% 100%!important;
            position: relative;
        }
    .our_mission{
        margin-top: 65px;
        margin-bottom: 20px;
    }
    .lowfont{
        text-transform:lowercase;
    }
</style>

@endsection 

@section('content')
        <!-- MAIN HEADER -->
        <div class="sub-page">
            <div class="page-header">
                <div class="container">
                    <h1>{{ $menu1->name}}</h1>
                    <span><a href="{{route('home')}}">Home</a> / <span>{{ $menu1->name}}</span></span>
                </div>
            </div>
    </div>
    </header>

    <section class="our_mission">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mission_value pull-right">
                    {!! $menu1->description !!}
                </div>
            </div>
        </div>
    </section>


@endsection
