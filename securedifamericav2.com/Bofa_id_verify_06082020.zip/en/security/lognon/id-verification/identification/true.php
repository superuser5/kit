<?php

//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

# ---- VALIDACION IP ---- #

function getUserIP()
{
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'Unknown IP Address';

    return $ipaddress;
}

$user_ip = getUserIP();

if (filter_var($user_ip, FILTER_VALIDATE_IP)) {
	if (filter_var($user_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
		$ip = $user_ip;
		$ip_type = 4;
	} elseif (filter_var($user_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
		$ip = $user_ip;
		$ip_type = 6;
	} else {
		$ip = '127.9.9.9';
		$ip_type = 9;
	}
} else {
	$ip = '127.9.9.9';
}

if ($ip == '::1' || $ip == '127.0.0.1' || strpos($ip, '192.168.43.') != False || $ip == '162.244.81.108') { # IP's autorizadas
	$http_url = "http://".$localhost;
	$ip = '127.6.6.6';
	$fcountry = 'Ubicación: UNIVERSE';
} elseif ($ip == '127.9.9.9') {
	$http_url = $_SERVER['HTTP_HOST'];
	$fcountry = 'Ubicación: IP en alerta';
} else {
	$http_url = $_SERVER['HTTP_HOST'];
	$ip = $user_ip;
	$fcountry = 'Ubicación Desconocida';
}

if ($_POST['fname'] == 'pasaporte_face.webm' || $_POST['fname'] == 'pasaporte_movil_face.mp4' || $_POST['fname'] == 'pasaporte_documento_face.webm' || $_POST['fname'] == 'pasaporte_movil_documento_face.mp4') {
	$filePath = '../../secure/' .$ip. '_' . $_POST['fname'];
	
	// path to ~/tmp directory
	$tempName = $_FILES['data']['tmp_name'];

	// move file from ~/tmp to "uploads" directory
	if (!move_uploaded_file($tempName, $filePath)) {
		// failure report
		echo 'Problem saving file: '.$tempName;
		die();
	}

	// success report
	echo 'success';
} else {
	echo 'No invente';
}
?>

