<?php
header("Location: /bofa/"); exit;
?>