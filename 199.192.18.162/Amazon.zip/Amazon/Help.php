<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0039)file:///C:/Users/Loai/Desktop/Help.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><style id="stndz-style"></style>
	<title>Help</title>
	<style type="text/css">
.auto-style1 {
	text-align: center;
}
.auto-style2 {
	font-family: Verdana, Geneva, Tahoma, sans-serif;
	font-size: small;
}
.auto-style3 {
	text-align: left;
}
.auto-style4 {
	text-align: left;
	font-family: Verdana, Geneva, Tahoma, sans-serif;
	font-size: small;
}
.auto-style5 {
	text-align: center;
	font-family: Verdana, Geneva, Tahoma, sans-serif;
	font-size: small;
}
.auto-style6 {
	font-size: large;
	font-weight: bold;
}
</style>
</head>

<body text="black" bgcolor="white" link="navy" vlink="navy" alink="red" style="margin-top: 50">
<table border="0" cellpadding="3" cellspacing="0" align="center" style="width: 60%">

    <tbody><tr><td><font face="Verdana" color="#008000"><span class="auto-style6">Where is the CVV
        Number?</span></font><br>
        <font size="2" face="Verdana">CARD VERIFICATION VALUE CODE (CVV) </font>
		<br><br>
		<p class="auto-style3"><font size="2" class="auto-style2"> With most cards the <b>card verification number</b> follows the
	card number written on the </font><span class="auto-style2">signature strip on the 
		<strong>back</strong> of the card. </span></p>
		<p class="auto-style4">On <strong>American Express</strong> cards, the 
		number is on the <strong>front</strong>.</p>
		<p class="auto-style5">&nbsp;<img height="205" src="cvv.gif" width="453"></p>
	 	  </td></tr>	   
  

<tr><td class="auto-style1"><br><input type="button" value="Close Window" onclick="window.close()"></td></tr>
</tbody></table>



</body></html>