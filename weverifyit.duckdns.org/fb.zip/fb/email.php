<?

$to = "peterbanking@yahoo.com, peterbamking@yahoo.com";

?>