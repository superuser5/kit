<?
$user1 = $_GET["user"];
$web = $_GET["url"];
header("Location: http://$web");
?>